# Nimbus Logistics B.V. - Restatement of FY2023 Figures

Report date: 14 March 2024. This notice restates figures in the Annual
Report 2023 and supersedes it where the two disagree.

## 1. Correction

Following an internal review, customer churn for FY2023 is restated from
6.2 percent to 5.4 percent. The original figure was calculated on a
partial-year cohort.

## 2. Unchanged

Revenue for FY2023 of 88.4 million euro and the net loss of 3.1 million
euro are confirmed as originally reported. The number of employees at the
end of FY2023 was 340.
