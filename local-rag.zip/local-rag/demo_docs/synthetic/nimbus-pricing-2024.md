# Nimbus Logistics B.V. - Enterprise Pricing Schedule 2024

Report date: 4 January 2024. This schedule supersedes the 2023 pricing
schedule in full and applies to all enterprise contracts signed during 2024.

## 1. Terms

Enterprise contracts during 2024 are billed at a 45.5 percent gross margin.
The minimum committed volume rises to 5,000 pallets per quarter.

## 2. Supersession

The 2023 pricing schedule is withdrawn. Contracts signed under it renew on the
2024 terms.
