# Nimbus Logistics B.V. - Annual Report 2024

Report date: 31 December 2024. Fiscal year 2024.

## 1. Financial summary

Revenue for FY2024 reached 104.7 million euro, an increase of 18 percent
over FY2023. Gross margin improved to 37.5 percent and the company moved
from a net loss to a net profit of 4.6 million euro.

## 2. People

At the end of FY2024 the number of employees was 392.

## 3. Operations

Fleet utilisation rose to 78 percent in FY2024. Nimbus opened a second
distribution centre in Antwerp during August 2024.

## 4. Risk factors

Customer churn fell to 4.4 percent in FY2024. The Rotterdam contract was
retained on renegotiated terms.
