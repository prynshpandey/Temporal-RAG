# Nimbus Logistics B.V. - Enterprise Pricing Schedule 2023

Report date: 1 June 2023. This schedule applies to all enterprise contracts
signed during 2023 and remains the basis for renewal until superseded.

## 1. Terms

Enterprise contracts during 2023 were billed at a 42.0 percent gross margin.
The minimum committed volume was 4,000 pallets per quarter.

## 2. Renewal

Contracts signed under this schedule renew on the same terms unless a
superseding schedule is issued.
