# Nimbus Logistics B.V. - Annual Report 2023

Report date: 31 December 2023. Fiscal year 2023.

## 1. Financial summary

Revenue for FY2023 reached 88.4 million euro. Gross margin was 34.0 percent.
The company reported a net loss of 3.1 million euro.

## 2. People

Nimbus Logistics was founded in 2016 by Tomas Berg and Aisha Rahman.
At the end of FY2023 the number of employees was 340.

## 3. Operations

Nimbus operates a warehouse network across the Benelux region. Fleet
utilisation was 71 percent in FY2023.

## 4. Risk factors

Customer churn was 6.2 percent in FY2023. The loss of the Rotterdam
distribution contract is the single largest risk to FY2024 revenue.
