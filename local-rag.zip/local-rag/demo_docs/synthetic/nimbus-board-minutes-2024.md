# Nimbus Logistics B.V. - Board Minutes, 12 June 2024

Report date: 12 June 2024.

The board approved the Antwerp distribution centre, budgeted at
11.0 million euro over eighteen months. The board noted that customer
churn had fallen to 4.8 percent year to date and that the Rotterdam
contract renewal was signed on 3 June 2024.
