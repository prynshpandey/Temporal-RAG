# Nimbus Logistics B.V. - Annual Report 2025

Report date: 31 December 2025. Fiscal year 2025.

## 1. Financial summary

Revenue for FY2025 reached 131.2 million euro, an increase of 25 percent
over FY2024. Gross margin reached 40.0 percent. Net profit was 9.8 million
euro.

## 2. People

At the end of FY2025 the number of employees was 455.

## 3. Operations

Fleet utilisation reached 84 percent in FY2025.

## 4. Risk factors

Customer churn fell to 3.1 percent in FY2025.
