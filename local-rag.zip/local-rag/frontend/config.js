/* frontend/config.js - endpoints and limits, change here or override with ?n8n=... */
window.CONFIG = {
  n8nBaseUrl: "http://localhost:5678",
  ingestPath: "/webhook/rag/ingest",
  queryPath: "/webhook/rag/query",
  documentsPath: "/webhook/rag/documents",
  documentPath: "/webhook/rag/document",
  uploadFieldName: "data",
  maxUploadMb: 25,
  maxQuestionChars: 2000,
  ingestTimeoutMs: 900000,
  queryTimeoutMs: 900000,
  listTimeoutMs: 60000,

  // The temporal endpoints (time.js) live on the backend rather than behind
  // n8n. Routing them through the webhook layer would mean a new workflow per
  // endpoint purely to forward a request, which adds a failure mode without
  // adding capability.
  backendBaseUrl: "http://localhost:8000",
  apiPrefix: "/api/v1",
  stateTimeoutMs: 120000,
};
