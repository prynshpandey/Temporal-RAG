/* frontend/time.js - point-in-time query, state reconstruction, and comparison.
 *
 * Deliberately separate from app.js. app.js drives the legacy n8n webhooks and
 * has a working, depended-upon contract; nothing in the temporal features may
 * be able to break it. This file owns the backend API instead.
 *
 * The organising idea: a temporal answer is only trustworthy if the reader can
 * see what was withheld as well as what was used. A snapshot that silently
 * drops a future document reads identically to one that never had it, so
 * exclusions are always rendered, with reasons.
 */
(function () {
  "use strict";

  const CFG = window.CONFIG;
  const API = (CFG.backendBaseUrl || "").replace(/\/+$/, "") + (CFG.apiPrefix || "/api/v1");
  const OVERRIDE_KEY = "local-rag-backend-url";

  const params = new URLSearchParams(window.location.search);
  const apiBase = (params.get("api") || window.localStorage.getItem(OVERRIDE_KEY) || API)
    .replace(/\/+$/, "");

  const el = (tag, cls, text) => {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined && text !== null) n.textContent = String(text);
    return n;
  };
  const clear = (n) => { while (n.firstChild) n.removeChild(n.firstChild); };

  const els = {
    machinePanel: document.getElementById("panel-machine"),
    changePanel: document.getElementById("panel-change"),
    asOf: document.getElementById("as-of"),
    asOfInline: document.getElementById("as-of-inline"),
    asOfWarning: document.getElementById("asof-warning"),
    stateArea: document.getElementById("state-area"),
    machineForm: document.getElementById("machine-ask-form"),
    machineQuestion: document.getElementById("machine-question"),
    machineAnswer: document.getElementById("machine-answer"),
    changeFrom: document.getElementById("change-from"),
    changeTo: document.getElementById("change-to"),
    runChange: document.getElementById("run-change"),
    changeArea: document.getElementById("change-area"),
  };
  if (!els.machinePanel) return;

  // ---------------------------------------------------------------- requests
  async function request(path, params, body) {
    const url = new URL(apiBase + path, window.location.origin);
    if (params) {
      for (const [k, v] of Object.entries(params)) {
        if (v !== "" && v !== null && v !== undefined) url.searchParams.set(k, v);
      }
    }
    const init = { headers: { Accept: "application/json" } };
    if (body !== undefined) {
      init.method = "POST";
      init.headers["Content-Type"] = "application/json";
      init.body = JSON.stringify(body);
    }
    const res = await fetch(url, init);
    let payload = null;
    try { payload = await res.json(); } catch (_) { /* non-JSON error page */ }
    if (!res.ok) {
      const detail = payload && payload.detail;
      const msg = typeof detail === "string"
        ? detail
        : (payload && payload.error) || `request failed (${res.status})`;
      throw new Error(msg);
    }
    return payload;
  }

  const get = (path, params) => request(path, params);
  // /answer is POST-only. It takes a question with a real request body rather
  // than a query string, so it does not share the GET helper.
  const post = (path, body) => request(path, null, body);

  const show = (node, msg, cls) => {
    clear(node);
    node.appendChild(el("p", cls || "empty", msg));
  };

  // ------------------------------------------------------------------ dates
  const today = () => new Date().toISOString().slice(0, 10);
  const shift = (iso, days) => {
    const d = new Date(iso + "T00:00:00Z");
    d.setUTCDate(d.getUTCDate() + days);
    return d.toISOString().slice(0, 10);
  };
  const prettyDate = (iso) => {
    if (!iso) return "—";
    const d = new Date(iso.length === 10 ? iso + "T00:00:00Z" : iso);
    return Number.isNaN(d.getTime()) ? iso : d.toISOString().slice(0, 10);
  };
  // Dates arrive as date or datetime depending on column; show the calendar day.
  const day = (value) => (value ? String(value).slice(0, 10) : null);

  function defaultDates() {
    const t = today();
    els.asOf.value = t;
    els.changeTo.value = t;
    els.changeFrom.value = shift(t, -365);
  }

  // ------------------------------------------------------------------ state
  function warn(node, message) {
    clear(node);
    node.textContent = message;
    node.classList.remove("hidden");
  }

  function section(title, subtitle) {
    const s = el("section", "subpanel");
    s.appendChild(el("h3", null, title));
    if (subtitle) s.appendChild(el("p", "panel-sub", subtitle));
    return s;
  }

  const REASON_TEXT = {
    dated_after_window: "did not exist yet",
    expired_before_window: "no longer valid",
    unknown: "could not be placed in time",
  };

  function reasonText(code, fallback) {
    return (REASON_TEXT[code] || fallback || {}).toString();
  }

  function renderState(data) {
    const area = els.stateArea;
    clear(area);
    const sum = data.summary || {};

    const head = el("div", "state-head");
    for (const [num, label] of [
      [sum.documents_in_scope, "documents in scope"],
      [sum.families, "revision chains"],
      [sum.passages, "passages available"],
    ]) {
      const st = el("span", "stat");
      st.appendChild(el("span", "stat-num", num === undefined ? "—" : num));
      st.appendChild(el("span", "stat-label", label));
      head.appendChild(st);
    }
    area.appendChild(head);
    if (sum.oldest_evidence) {
      area.appendChild(el("p", "panel-sub",
        `Evidence spans ${prettyDate(sum.oldest_evidence)} to ${prettyDate(sum.newest_evidence)}`));
    }
    if (sum.stale_days !== undefined && sum.stale_days !== null) {
      area.appendChild(el("p", "panel-sub", `Newest evidence is ${sum.stale_days} days old on this date.`));
    }

    // Withheld first, and prominently. A snapshot that silently drops a future
    // document is indistinguishable from one that never had it.
    const excluded = data.excluded || {};
    const reasons = data.exclusion_reasons || {};
    const groups = [
      ["not_yet_known", "Did not exist yet", "Dated after this date. Nothing below used them."],
      ["expired", "No longer valid", "Excluded by a validity end date that had already passed."],
    ];
    let withheld = 0;
    for (const [key, title, note] of groups) {
      const items = excluded[key] || [];
      if (!items.length) continue;
      withheld += items.length;
      const box = section(`${title} (${items.length})`, note);
      const ul = el("ul", "excluded-list");
      for (const d of items) {
        const li = el("li");
        li.appendChild(el("span", "doc-name", d.name || d.document_id));
        li.appendChild(el("span", "reason", reasonText(d.reason, reasons[d.reason])));
        if (d.effective_date) li.appendChild(el("span", "doc-date", prettyDate(d.effective_date)));
        ul.appendChild(li);
      }
      box.appendChild(ul);
      area.appendChild(box);
    }
    if (data.entity) area.appendChild(el("p", "panel-sub", `Entity: ${data.entity}`));

    const families = data.families || [];
    if (families.length) {
      const box = section(`Revision chains (${families.length})`,
        "Successive statements of the same thing. Only the latest one in scope counts as current.");
      for (const f of families) {
        const card = el("div", "family");
        card.appendChild(el("div", "family-name", f.key || "chain"));
        const ul = el("ul", "chain-list");
        for (const v of f.versions || []) {
          const li = el("li", v.in_scope ? "chain-current" : "chain-old");
          li.appendChild(el("span", "doc-name", v.name || v.document_id));
          if (v.effective_date) li.appendChild(el("span", "doc-date", prettyDate(v.effective_date)));
          li.appendChild(el("span", v.in_scope ? "reason reason-current" : "reason",
            v.in_scope ? "current" : "out of scope"));
          ul.appendChild(li);
        }
        card.appendChild(ul);
        area.appendChild(card);
      }
      area.appendChild(box);
    }

    const passages = data.passages || [];
    if (passages.length) {
      const box = section(`Passages in scope (${passages.length})`,
        "The material available to answer questions on this date.");
      const ul = el("ul", "passage-list");
      for (const p of passages.slice(0, 30)) {
        const li = el("li");
        li.appendChild(el("span", "doc-name", p.document_name || p.document_id));
        if (p.section_title) li.appendChild(el("span", "section-title", p.section_title));
        li.appendChild(el("p", "excerpt", p.text || ""));
        ul.appendChild(li);
      }
      if (passages.length > 30) {
        ul.appendChild(el("li", "panel-sub", `and ${passages.length - 30} more`));
      }
      box.appendChild(ul);
      area.appendChild(box);
    }

    if (!withheld && !families.length && !passages.length) {
      show(area, "No documents in scope on this date.");
    }
    for (const w of data.warnings || []) warn(els.asOfWarning, w);
  }

  async function loadState() {
    const asOf = els.asOf.value;
    if (!asOf) { show(els.stateArea, "Pick a date."); return; }
    els.asOfInline.textContent = prettyDate(asOf);
    show(els.stateArea, "Reconstructing…", "empty loading");
    clear(els.machineAnswer);
    clear(els.asOfWarning);
    els.asOfWarning.classList.add("hidden");
    try {
      renderState(await get("/state", { as_of: asOf }));
    } catch (err) {
      show(els.stateArea, "Could not reconstruct state: " + err.message, "error");
    }
  }

  // ----------------------------------------------------------------- answer
  function renderAnswer(data) {
    const area = els.machineAnswer;
    clear(area);
    const card = el("div", "answer-card");

    const modeLabels = {
      generated: "answered by the model",
      extractive: "quoted directly from the sources",
      unsupported: "the sources do not answer this",
      no_context: "nothing in the library covers this date",
    };
    const meta = el("div", "answer-meta");
    meta.appendChild(el("span", "badge badge-" + data.mode,
      modeLabels[data.mode] || data.mode || "unknown"));
    meta.appendChild(el("span", "asof-tag", "as of " + prettyDate(data.as_of)));
    if (data.supported === false) meta.appendChild(el("span", "badge badge-warn", "not supported"));
    card.appendChild(meta);

    card.appendChild(el("div", "answer-text", data.answer || ""));

    const cites = data.citations || [];
    if (cites.length) {
      const box = section(`Sources (${cites.length})`, "Every claim above traces to one of these.");
      const ol = el("ol", "citation-list");
      for (const c of cites) {
        const li = el("li", "citation");
        const head = el("div", "citation-head");
        head.appendChild(el("span", "cite-num", "[" + c.number + "]"));
        head.appendChild(el("span", "doc-name", c.document_name || c.document_id));
        if (c.effective_date) head.appendChild(el("span", "doc-date", prettyDate(c.effective_date)));
        if (c.page !== null && c.page !== undefined) head.appendChild(el("span", "doc-page", "p" + c.page));
        li.appendChild(head);
        if (c.section_title) li.appendChild(el("span", "section-title", c.section_title));
        if (c.quote) li.appendChild(el("p", "excerpt", c.quote));
        ol.appendChild(li);
      }
      box.appendChild(ol);
      card.appendChild(box);
    }

    const rejected = data.rejected_citations || [];
    if (rejected.length) {
      const box = section(`Rejected (${rejected.length})`,
        "The model tried to cite these, but they were not in the retrieved set, so they were dropped rather than shown.");
      const ul = el("ul", "rejected-list");
      for (const r of rejected) {
        ul.appendChild(el("li", null, typeof r === "string" ? r : JSON.stringify(r)));
      }
      box.appendChild(ul);
      card.appendChild(box);
    }

    // Provenance, so the numbers are checkable without re-running the query.
    const prov = [];
    if (data.llm && data.llm.provider) prov.push("model: " + data.llm.provider);
    if (data.llm && data.llm.usage && data.llm.usage.fallbacks) {
      prov.push(data.llm.usage.fallbacks + " fallback call(s)");
    }
    if (data.stats) {
      prov.push(`${data.stats.fused} passage(s) after fusion from ${data.stats.keyword_candidates} keyword / ${data.stats.vector_candidates} vector candidates`);
    }
    if (data.elapsed_ms) prov.push(data.elapsed_ms + " ms");
    if (prov.length) card.appendChild(el("p", "provenance", prov.join(" · ")));

    area.appendChild(card);
  }

  async function askAsOf(event) {
    event.preventDefault();
    const question = els.machineQuestion.value.trim();
    const asOf = els.asOf.value;
    if (!question) { els.machineQuestion.focus(); return; }
    if (!asOf) { warn(els.asOfWarning, "Pick a date first."); return; }
    show(els.machineAnswer, "Asking as of " + prettyDate(asOf) + "…", "empty loading");
    try {
      renderAnswer(await post("/answer", { question, as_of: asOf }));
    } catch (err) {
      show(els.machineAnswer, "Could not answer: " + err.message, "error");
    }
  }

  // ----------------------------------------------------------------- compare
  function metricLabel(fact) {
    if (!fact) return null;
    const unit = fact.unit ? " (" + fact.unit + ")" : "";
    return (fact.label || "") + unit;
  }

  function factCard(fact, tag) {
    const wrap = el("div", "fact");
    if (fact) {
      if (tag) wrap.appendChild(el("span", "fact-tag", tag));
      wrap.appendChild(el("span", "val",
        fact.value === undefined || fact.value === null ? "—" : fact.value));
      if (fact.document_name) wrap.appendChild(el("span", "doc-name", fact.document_name));
      if (fact.effective_date) wrap.appendChild(el("span", "doc-date", prettyDate(fact.effective_date)));
      if (fact.sentence) wrap.appendChild(el("p", "excerpt", fact.sentence));
    } else {
      wrap.appendChild(el("span", "val missing", "not stated"));
    }
    return wrap;
  }

  function renderCompare(data) {
    const area = els.changeArea;
    clear(area);
    const from = data.from || {}, to = data.to || {};

    for (const w of data.warnings || []) area.appendChild(el("p", "warn", w));
    area.appendChild(el("p", "panel-sub",
      `${prettyDate(from.as_of)} — ${from.documents_in_scope} documents, ${from.metrics} metrics.  ` +
      `${prettyDate(to.as_of)} — ${to.documents_in_scope} documents, ${to.metrics} metrics.`));

    const docs = data.documents || {};
    if ((docs.added || []).length || (docs.removed || []).length) {
      const box = section("Documents", "New or withdrawn between the two dates.");
      for (const d of docs.added || []) {
        const li = el("li", "doc-line");
        li.appendChild(el("span", "tag tag-added", "added"));
        li.appendChild(el("span", "doc-name", d.name || d.document_id));
        if (d.effective_date) li.appendChild(el("span", "doc-date", prettyDate(d.effective_date)));
        box.appendChild(li);
      }
      for (const d of docs.removed || []) {
        const li = el("li", "doc-line");
        li.appendChild(el("span", "tag tag-removed", "withdrawn"));
        li.appendChild(el("span", "doc-name", d.name || d.document_id));
        if (d.effective_date) li.appendChild(el("span", "doc-date", prettyDate(d.effective_date)));
        box.appendChild(li);
      }
      area.appendChild(box);
    }

    const changes = data.changes || [];
    if (changes.length) {
      const box = section(`Changed (${changes.length})`,
        "The same metric reported differently in each window. The later figure supersedes the earlier one.");
      for (const c of changes) {
        const row = el("div", "change-row");
        row.appendChild(el("div", "change-metric", metricLabel(c)));
        if (c.rendered) {
          row.appendChild(el("div", "change-rendered", c.rendered));
        } else {
          const pair = el("div", "change-pair");
          pair.appendChild(factCard(c.from, "then"));
          pair.appendChild(el("span", "arrow", "→"));
          pair.appendChild(factCard(c.to, "now"));
          row.appendChild(pair);
        }
        if (c.percent_change !== undefined && c.percent_change !== null) {
          row.appendChild(el("span", "delta",
            (c.percent_change > 0 ? "+" : "") + c.percent_change + "%"));
        }
        box.appendChild(row);
      }
      area.appendChild(box);
    }

    const appeared = data.appeared || [];
    if (appeared.length) {
      const box = section(`Newly reported (${appeared.length})`,
        "Stated on the later date only. Either genuinely new, or simply labelled for the first time.");
      for (const a of appeared) {
        const row = el("div", "change-row");
        row.appendChild(el("div", "change-metric", metricLabel(a)));
        row.appendChild(factCard(a.now || a.to, "now"));
        box.appendChild(row);
      }
      area.appendChild(box);
    }

    const gone = data.disappeared || [];
    if (gone.length) {
      const box = section(`No longer reported (${gone.length})`,
        "Stated on the earlier date only. This is not a retraction — nothing says it stopped.");
      for (const g of gone) {
        const row = el("div", "change-row");
        row.appendChild(el("div", "change-metric", metricLabel(g)));
        row.appendChild(factCard(g.before || g.from, "then"));
        box.appendChild(row);
      }
      area.appendChild(box);
    }

    const conflicts = data.conflicts || [];
    if (conflicts.length) {
      const box = section(`Disagreements (${conflicts.length})`,
        "Two documents close in time report different values. Both are shown; neither is silently dropped.");
      for (const c of conflicts) {
        const row = el("div", "change-row conflict");
        row.appendChild(el("div", "change-metric", metricLabel(c)));
        const pair = el("div", "change-pair");
        pair.appendChild(factCard(c.from || c.a, "then"));
        pair.appendChild(factCard(c.to || c.b, "also"));
        row.appendChild(pair);
        box.appendChild(row);
      }
      area.appendChild(box);
    }

    const revised = (data.families || []).filter((f) => f.status === "revised");
    if (revised.length) {
      const box = section(`Revised (${revised.length})`,
        "Chains of statements about the same thing, which moved to a later version.");
      const ul = el("ul", "chain-list");
      for (const f of revised) {
        const li = el("li");
        li.appendChild(el("span", "doc-name", (f.from_version || {}).name || "—"));
        li.appendChild(el("span", "arrow", "→"));
        li.appendChild(el("span", "doc-name", (f.to_version || {}).name || "—"));
        ul.appendChild(li);
      }
      box.appendChild(ul);
      area.appendChild(box);
    }

    const groups = [changes, appeared, gone, conflicts, docs.added, docs.removed, revised];
    if (!groups.some((g) => g && g.length)) {
      show(area, "Nothing comparable between these dates.", "empty");
    }

    if (data.method && data.method.extraction) {
      area.appendChild(el("p", "provenance", "method: " + data.method.extraction));
    }
  }

  async function runCompare() {
    const from = els.changeFrom.value, to = els.changeTo.value;
    if (!from || !to) { show(els.changeArea, "Pick both dates."); return; }
    if (from === to) { show(els.changeArea, "Those are the same date."); return; }
    if (from > to) { show(els.changeArea, "The first date is after the second — swap them."); return; }
    show(els.changeArea, "Comparing…", "empty loading");
    try {
      renderCompare(await get("/compare", { from, to }));
    } catch (err) {
      show(els.changeArea, "Could not compare: " + err.message, "error");
    }
  }

  // ------------------------------------------------------------------- tabs
  // app.js owns the existing tabs and the class list. The temporal panels use
  // the same markup contract, so the same toggle logic applies, but only when a
  // temporal tab is actually being opened — otherwise leave the legacy tabs
  // entirely alone.
  function onTabClick(name) {
    // Runs for every tab, not just the temporal ones: the tab strip is shared,
    // and returning early for "ask" would leave a temporal panel on screen
    // underneath the Ask panel.
    els.machinePanel.classList.toggle("hidden", name !== "machine");
    els.changePanel.classList.toggle("hidden", name !== "change");
    if (name !== "machine" && name !== "change") return;
    // app.js owns the tab strip but only knows how to show its own two panels,
    // so nothing else would reveal these.
    if (name === "machine" && els.asOf.value) loadState();
    if (name === "change" && els.changeFrom.value && !els.changeArea.dataset.touched) {
      els.changeArea.dataset.touched = "1";
      runCompare();
    }
  }

  function bind() {
    defaultDates();
    els.asOf.addEventListener("change", loadState);
    els.asOf.addEventListener("input", () => {
      els.asOfInline.textContent = prettyDate(els.asOf.value);
    });
    els.machineForm.addEventListener("submit", askAsOf);
    els.machineQuestion.addEventListener("keydown", (e) => {
      if (e.key === "Enter") { e.preventDefault(); els.machineForm.requestSubmit(); }
    });
    els.runChange.addEventListener("click", runCompare);

    document.querySelectorAll(".tab").forEach((tab) => {
      tab.addEventListener("click", () => onTabClick(tab.dataset.tab));
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", bind);
  } else {
    bind();
  }
})();
