/* frontend/tests/dom.mjs - the smallest DOM that satisfies time.js.
 *
 * Not a browser. Enough of one to run the renderers against real API payloads
 * and see whether they throw on a field that is absent, null, or shaped
 * differently than assumed. A renderer that reads `data.state` when the API
 * sends `data.summary` looks fine in review and is blank in production.
 */
export class El {
  constructor(tag) {
    this.tagName = String(tag).toUpperCase();
    this.className = "";
    this.children = [];
    this.attrs = {};
    this.dataset = {};
    this.listeners = {};
    this._text = "";
    this.classList = {
      add: (...c) => {
        const set = new Set(this.className.split(/\s+/).filter(Boolean));
        c.forEach((x) => set.add(x));
        this.className = [...set].join(" ");
      },
      remove: (...c) => {
        const set = new Set(this.className.split(/\s+/).filter(Boolean));
        c.forEach((x) => set.delete(x));
        this.className = [...set].join(" ");
      },
      contains: (c) => this.className.split(/\s+/).includes(c),
      toggle: (c, force) => {
        const set = new Set(this.className.split(/\s+/).filter(Boolean));
        const on = force === undefined ? !set.has(c) : !!force;
        if (on) set.add(c); else set.delete(c);
        this.className = [...set].join(" ");
        return on;
      },
    };
  }
  set className(v) { this._class = v; }
  get className() { return this._class || ""; }
  set textContent(v) { this._text = v === null || v === undefined ? "" : String(v); this.children = []; }
  get textContent() { return this._text; }
  get firstChild() { return this.children[0] || null; }
  appendChild(c) { this.children.push(c); return c; }
  removeChild(c) { this.children = this.children.filter((x) => x !== c); return c; }
  setAttribute(k, v) { this.attrs[k] = v; }
  addEventListener(evt, fn) { (this.listeners[evt] ||= []).push(fn); }
  focus() { this.focused = true; }
  requestSubmit() { (this.listeners.submit || []).forEach((f) => f({ preventDefault() {} })); }
  set value(v) { this._value = v; }
  get value() { return this._value === undefined ? "" : this._value; }

  // Test helpers: flatten to text and collect classes for assertions.
  all() { return this.children.flatMap((c) => [c, ...(c.all ? c.all() : [])]); }
  find(pred) { return this.all().find(pred); }
  findAll(pred) { return this.all().filter(pred); }
  get text() {
    return this._text + this.children.map((c) => (c.text !== undefined ? c.text : "")).join(" ");
  }
}

export function installDOM(ids = [], tabNames = []) {
  const byId = {};
  for (const id of ids) byId[id] = new El("div");
  // Real tab elements, so tab wiring is actually exercised. Returning [] here
  // silently skips every tab test, which is how a panel that can never be shown
  // passes a green suite.
  const tabs = tabNames.map((name) => {
    const t = new El("button");
    t.className = "tab";
    t.dataset.tab = name;
    return t;
  });
  const doc = {
    tabs,
    getElementById: (id) => byId[id] || null,
    createElement: (tag) => new El(tag),
    querySelectorAll: (sel) => {
      if (sel === ".tab") return tabs;
      if (sel === ".tab.active") return tabs.filter((t) => t.className.includes("active"));
      return [];
    },
    addEventListener: () => {},
    readyState: "complete",
  };
  return { doc, byId };
}
