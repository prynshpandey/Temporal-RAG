/* frontend/tests/test_time_ui.mjs - render time.js against real API payloads.
 *
 * Run: node frontend/tests/test_time_ui.mjs
 * Fixtures are captured from a live backend by scripts/capture_fixtures.sh.
 *
 * The point is not pixel correctness. It is that every field the renderers read
 * actually exists in the API response, and that a missing or null field
 * degrades to something readable instead of throwing and blanking the panel.
 */
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import vm from "node:vm";
import { El, installDOM } from "./dom.mjs";

const here = dirname(fileURLToPath(import.meta.url));
const fixture = (name) => JSON.parse(readFileSync(join(here, "fixtures", `${name}.json`), "utf8"));

let passed = 0;
const failures = [];
const ok = (name) => { passed++; process.stdout.write(`  PASS  ${name}\n`); };
const bad = (name, err) => { failures.push([name, err]); process.stdout.write(`  FAIL  ${name}\n        ${err}\n`); };

const IDS = [
  "panel-machine", "panel-change", "as-of", "as-of-inline", "asof-warning",
  "state-area", "machine-ask-form", "machine-question", "machine-answer",
  "change-from", "change-to", "run-change", "change-area",
];

const TABS = ["ask", "library", "machine", "change"];

function boot(overrides = {}) {
  const { doc, byId } = installDOM(IDS, TABS);
  const calls = [];
  const ctx = {
    window: {
      CONFIG: {
        backendBaseUrl: "http://backend:8000",
        apiPrefix: "/api/v1",
      },
      location: { search: "", origin: "http://frontend" },
      localStorage: { getItem: () => null, setItem: () => {} },
      URLSearchParams,
    },
    document: doc,
    localStorage: { getItem: () => null },
    URL,
    URLSearchParams,
    console,
    fetch: async (url, init) => {
      calls.push({ url: String(url), method: (init && init.method) || "GET", body: init && init.body });
      const key = String(url).includes("/state") ? "state"
        : String(url).includes("/compare") ? "compare"
          : String(url).includes("/answer") ? "answer" : "state";
      return {
        ok: true,
        status: 200,
        json: async () => overrides[key],
      };
    },
    setTimeout,
  };
  ctx.globalThis = ctx;
  vm.createContext(ctx);
  const source = readFileSync(join(here, "..", "time.js"), "utf8");
  vm.runInContext(source, ctx, { filename: "time.js" });
  return { calls, byId, doc };
}

// ------------------------------------------------------------------ tab wiring
// app.js only knows how to show panel-ask and panel-library. If time.js does not
// show its own, the temporal panels are unreachable and the page goes blank.
{
  const { doc, byId } = boot({ state: fixture("state_2025") });
  const tab = (name) => doc.tabs.find((x) => x.dataset.tab === name);
  const shown = () => !byId["panel-machine"].className.split(/\s+/).includes("hidden");

  byId["as-of"].value = "2025-12-31";
  tab("machine").listeners.click.forEach((f) => f({}));
  if (shown()) ok("clicking Time machine reveals its panel");
  else bad("clicking Time machine reveals its panel", byId["panel-machine"].className);

  tab("ask").listeners.click.forEach((f) => f({}));
  if (!shown()) ok("leaving the temporal tab hides it again");
  else bad("leaving the temporal tab hides it again", "still visible");

  tab("change").listeners.click.forEach((f) => f({}));
  if (byId["panel-change"].className.split(/\s+/).includes("hidden") === false) {
    ok("clicking Change reveals the compare panel");
  } else bad("clicking Change reveals the compare panel", byId["panel-change"].className);
}

// ------------------------------------------------------------------ default dates
{
  const { byId } = boot();
  const t = (d) => d.value;
  if (t(byId["as-of"]) && t(byId["change-to"])) ok("as-of and change-to default to today");
  else bad("as-of and change-to default to today", `got ${t(byId["as-of"])} / ${t(byId["change-to"])}`);

  if (t(byId["change-from"]) < t(byId["change-to"])) ok("change-from defaults before change-to");
  else bad("change-from defaults before change-to", `${t(byId["change-from"])} !< ${t(byId["change-to"])}`);
}

// ------------------------------------------------------------------ state rendering
{
  const { byId } = boot({ state: fixture("state_2025") });
  byId["as-of"].value = "2025-12-31";
  await (byId["as-of"].listeners.change || []).reduce(
    (p, f) => p.then(() => f({})), Promise.resolve());

  const area = byId["state-area"];
  const text = area.text;
  if (text.includes("6") && /documents in scope/.test(text)) ok("state shows documents in scope");
  else bad("state shows documents in scope", text.slice(0, 120));

  if (/revision chains/.test(text)) ok("state shows revision chains");
  else bad("state shows revision chains", text.slice(0, 120));

  if (/Passages in scope/.test(text)) ok("state lists passages");
  else bad("state lists passages", text.slice(0, 120));

  if (/helios/.test(text)) ok("state names real documents");
  else bad("state names real documents", "no document name rendered");
}

// --------------------------------------------------------- state with exclusions
{
  const { byId } = boot({ state: fixture("state_2023") });
  byId["as-of"].value = "2023-12-31";
  await (byId["as-of"].listeners.change || []).reduce(
    (p, f) => p.then(() => f({})), Promise.resolve());

  const text = byId["state-area"].text;
  // The whole product claim: a future document must be visible as withheld.
  if (/Did not exist yet/i.test(text)) ok("withheld future documents are labelled as such");
  else bad("withheld future documents are labelled as such", text.slice(0, 200));

  if (/helios-annual-report-2025/.test(text)) ok("withheld list names the excluded document");
  else bad("withheld list names the excluded document", "excluded doc missing");
}

// ------------------------------------------------------------------ answer rendering
{
  const { byId, calls } = boot({ answer: fixture("answer") });
  byId["as-of"].value = "2024-06-30";
  byId["machine-question"].value = "What was the customer churn rate";
  await (byId["machine-ask-form"].listeners.submit || []).reduce(
    (p, f) => p.then(() => f({ preventDefault() {} })), Promise.resolve());

  const call = calls.find((c) => c.url.includes("/answer"));
  if (call && call.method === "POST") ok("/answer is called with POST");
  else bad("/answer is called with POST", JSON.stringify(call));

  if (call && call.body && JSON.parse(call.body).as_of === "2024-06-30") ok("as_of is sent in the body");
  else bad("as_of is sent in the body", call && call.body);

  const text = byId["machine-answer"].text;
  if (/3\.6/.test(text)) ok("answer text is rendered");
  else bad("answer text is rendered", text.slice(0, 160));

  if (/Sources/.test(text)) ok("answer shows its sources");
  else bad("answer shows its sources", text.slice(0, 160));

  if (/helios-annual-report-2024/.test(text)) ok("citations name their document");
  else bad("citations name their document", "document name missing");
}

// ------------------------------------------------------------------ compare rendering
{
  const { byId } = boot({ compare: fixture("compare") });
  byId["change-from"].value = "2023-12-31";
  byId["change-to"].value = "2025-12-31";
  await (byId["run-change"].listeners.click || []).reduce(
    (p, f) => p.then(() => f({})), Promise.resolve());

  const text = byId["change-area"].text;
  if (/Changed/.test(text)) ok("compare shows changed metrics");
  else bad("compare shows changed metrics", text.slice(0, 200));

  if (/churn/i.test(text)) ok("compare names the churn metric");
  else bad("compare names the churn metric", text.slice(0, 200));

  if (/4\.1/.test(text) && /3\.2/.test(text)) ok("compare shows both values with direction");
  else bad("compare shows both values with direction", text.slice(0, 240));

  if (/Documents/i.test(text) && /helios-corvus-launch-note/.test(text)) ok("compare lists added documents");
  else bad("compare lists added documents", text.slice(0, 240));
}

// -------------------------------------------------------------- degraded payloads
// A field going missing should cost detail, not blank the panel.
{
  const { byId } = boot({ answer: { answer: "partial", mode: "extractive", as_of: "2024-01-01" } });
  byId["as-of"].value = "2024-01-01";
  byId["machine-question"].value = "anything";
  await (byId["machine-ask-form"].listeners.submit || []).reduce(
    (p, f) => p.then(() => f({ preventDefault() {} })), Promise.resolve());
  const text = byId["machine-answer"].text;
  if (text.includes("partial")) ok("answer with no citations still renders");
  else bad("answer with no citations still renders", text.slice(0, 120));
}
{
  const { byId } = boot({ state: { as_of: "2024-01-01" } });
  byId["as-of"].value = "2024-01-01";
  await (byId["as-of"].listeners.change || []).reduce(
    (p, f) => p.then(() => f({})), Promise.resolve());
  const text = byId["state-area"].text;
  if (/No documents in scope/.test(text)) ok("empty state explains itself");
  else bad("empty state explains itself", text.slice(0, 120));
}
{
  const { byId } = boot({ compare: { from: { as_of: "a" }, to: { as_of: "b" } } });
  byId["change-from"].value = "2023-01-01";
  byId["change-to"].value = "2024-01-01";
  await (byId["run-change"].listeners.click || []).reduce(
    (p, f) => p.then(() => f({})), Promise.resolve());
  const text = byId["change-area"].text;
  if (/Nothing comparable/.test(text)) ok("empty comparison explains itself");
  else bad("empty comparison explains itself", text.slice(0, 120));
}

// ------------------------------------------------------------------ validation
{
  const { byId } = boot({ compare: fixture("compare") });
  byId["change-from"].value = "2025-01-01";
  byId["change-to"].value = "2023-01-01";
  await (byId["run-change"].listeners.click || []).reduce(
    (p, f) => p.then(() => f({})), Promise.resolve());
  if (/swap them/.test(byId["change-area"].text)) ok("reversed dates are refused, not silently swapped");
  else bad("reversed dates are refused, not silently swapped", byId["change-area"].text.slice(0, 120));
}
{
  const { byId } = boot({ compare: fixture("compare") });
  byId["change-from"].value = "2024-01-01";
  byId["change-to"].value = "2024-01-01";
  await (byId["run-change"].listeners.click || []).reduce(
    (p, f) => p.then(() => f({})), Promise.resolve());
  if (/same date/.test(byId["change-area"].text)) ok("identical dates are refused");
  else bad("identical dates are refused", byId["change-area"].text.slice(0, 120));
}

process.stdout.write(`\n${passed} checks passed, ${failures.length} failed\n`);
process.exit(failures.length ? 1 : 0);
