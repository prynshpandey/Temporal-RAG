(function () {
  "use strict";

  const OVERRIDE_KEY = "local-rag-n8n-url";
  const params = new URLSearchParams(window.location.search);
  const baseUrl = (
    params.get("n8n") ||
    window.localStorage.getItem(OVERRIDE_KEY) ||
    window.CONFIG.n8nBaseUrl
  ).replace(/\/+$/, "");

  const els = {
    status: document.getElementById("status"),
    docCount: document.getElementById("doc-count"),
    uploadForm: document.getElementById("upload-form"),
    fileInput: document.getElementById("file-input"),
    dropzone: document.getElementById("dropzone"),
    dropHint: document.getElementById("drop-hint"),
    uploadProgress: document.getElementById("upload-progress"),
    uploadLabel: document.getElementById("upload-label"),
    uploadResult: document.getElementById("upload-result"),
    askForm: document.getElementById("ask-form"),
    question: document.getElementById("question"),
    askButton: document.getElementById("ask-button"),
    answerArea: document.getElementById("answer-area"),
    libraryList: document.getElementById("library-list"),
    refreshLibrary: document.getElementById("refresh-library"),
  };

  els.dropHint.textContent =
    `PDF only · max ${window.CONFIG.maxUploadMb} MB · text-based PDFs, no OCR`;
  els.question.maxLength = window.CONFIG.maxQuestionChars;

  function url(path) {
    return baseUrl + path;
  }

  function el(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined && text !== null) node.textContent = String(text);
    return node;
  }

  function clear(node) {
    while (node.firstChild) node.removeChild(node.firstChild);
  }

  function startTimer(label, prefix) {
    const started = Date.now();
    label.textContent = prefix;
    const tick = setInterval(() => {
      const seconds = Math.round((Date.now() - started) / 1000);
      label.textContent = `${prefix} ${seconds}s`;
    }, 1000);
    return () => clearInterval(tick);
  }

  function describeError(payload, status) {
    if (payload && typeof payload === "object" && payload.error) {
      const error = payload.error;
      const code = error.code ? ` (${error.code})` : "";
      return { title: (error.message || "Request failed") + code, hint: error.hint || "" };
    }
    if (payload && payload.status === "no_context") {
      return { title: "No relevant passage found", hint: payload.hint || "" };
    }
    return { title: `Request failed with HTTP ${status}`, hint: "" };
  }

  function showNotice(container, kind, title, hint) {
    clear(container);
    const notice = el("div", `notice notice-${kind}`);
    notice.appendChild(el("strong", null, title));
    if (hint) notice.appendChild(el("div", "detail", hint));
    container.appendChild(notice);
  }

  async function postJson(path, payload, timeoutMs) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const response = await fetch(url(path), {
        method: "POST",
        headers: { "Content-Type": "text/plain;charset=UTF-8" },
        body: JSON.stringify(payload),
        signal: controller.signal,
      });
      return { status: response.status, data: await response.json().catch(() => ({})) };
    } catch (err) {
      if (err.name === "AbortError") {
        return {
          status: 0,
          data: {
            error: {
              code: "timeout",
              message: "The request timed out",
              hint: "On CPU this can take a while for the first question. Try a smaller LLM_MODEL in .env, or watch the run with: make logs",
            },
          },
        };
      }
      return {
        status: 0,
        data: {
          error: {
            code: "network_error",
            message: "Could not reach n8n",
            hint: "Start the stack with: make up — and check the n8n URL in frontend/config.js",
          },
        },
      };
    } finally {
      clearTimeout(timer);
    }
  }

  async function sha256Hex(file) {
    const buffer = await file.arrayBuffer();
    const digest = await crypto.subtle.digest("SHA-256", buffer);
    return Array.from(new Uint8Array(digest))
      .map((byte) => byte.toString(16).padStart(2, "0"))
      .join("");
  }

  async function uploadFile(file) {
    clear(els.uploadResult);
    if (!file) return;
    if (!/\.pdf$/i.test(file.name) && file.type !== "application/pdf") {
      showNotice(els.uploadResult, "error", "Only PDF files are supported", `Received: ${file.name}`);
      return;
    }
    if (file.size > window.CONFIG.maxUploadMb * 1024 * 1024) {
      showNotice(
        els.uploadResult,
        "error",
        "File is too large",
        `${file.name} is ${(file.size / 1048576).toFixed(1)} MB, the limit is ${window.CONFIG.maxUploadMb} MB.`
      );
      return;
    }

    const form = new FormData();
    const sha256 = await sha256Hex(file);
    form.append(window.CONFIG.uploadFieldName, file, file.name);
    form.append("sha256", sha256);

    els.uploadProgress.classList.remove("hidden");
    const stop = startTimer(els.uploadLabel, "Uploading");

    let result;
    try {
      const response = await fetch(url(window.CONFIG.ingestPath), {
        method: "POST",
        body: form,
        signal: AbortSignal.timeout(window.CONFIG.ingestTimeoutMs),
      });
      result = { status: response.status, data: await response.json().catch(() => ({})) };
    } catch (err) {
      result = {
        status: 0,
        data: {
          error: {
            code: "network_error",
            message: "Could not reach n8n",
            hint: "Start the stack with: make up, then retry",
          },
        },
      };
    } finally {
      stop();
      els.uploadProgress.classList.add("hidden");
    }

    if (result.status !== 200 || result.data.status !== "indexed") {
      const { title, hint } = describeError(result.data, result.status);
      showNotice(els.uploadResult, "error", title, hint);
      return;
    }

    const data = result.data;
    clear(els.uploadResult);
    els.uploadResult.classList.remove("hidden");
    els.uploadResult.appendChild(el("div", "result-title", `Indexed "${data.document_name}"`));
    els.uploadResult.appendChild(
      el(
        "div",
        "result-meta",
        `${data.chunk_count} chunks · ${data.page_count} page(s) · ${data.extracted_chars} characters · ${data.embedding_model} · ${data.duration_ms} ms`
      )
    );
    els.uploadResult.appendChild(el("div", "result-id", data.document_id));
    loadLibrary();
  }

  function renderSources(target, sources) {
    const list = el("div", "sources");
    sources.forEach((source, index) => {
      const details = el("details", "source");
      const summary = el("summary");
      summary.appendChild(el("span", "idx", index + 1));
      const where =
        source.page_known && source.page != null
          ? `${source.document} · page ${source.page}`
          : source.document;
      summary.appendChild(el("span", "where", where));
      const score = el("span", "score");
      const bar = el("span", "score-bar");
      const fill = el("span", "score-fill");
      fill.style.width = `${Math.max(4, Math.round((source.score || 0) * 100))}%`;
      bar.appendChild(fill);
      score.appendChild(bar);
      score.appendChild(el("span", null, Number(source.score || 0).toFixed(3)));
      summary.appendChild(score);
      details.appendChild(summary);
      details.appendChild(el("pre", null, source.text || ""));
      list.appendChild(details);
    });
    target.appendChild(list);
  }

  function renderAnswer(payload) {
    clear(els.answerArea);
    if (payload.status === "no_context") {
      showNotice(els.answerArea, "warn", payload.answer, payload.hint || "");
      return;
    }
    const wrapper = el("div", "answer");
    wrapper.appendChild(el("p", "answer-body", payload.answer || ""));
    const meta = el("div", "answer-meta");
    const usage = payload.usage || {};
    meta.appendChild(el("span", null, payload.llm_model || ""));
    if (usage.generation_ms) {
      meta.appendChild(el("span", null, `${(usage.generation_ms / 1000).toFixed(1)}s to generate`));
    }
    if (usage.completion_tokens) {
      meta.appendChild(el("span", null, `${usage.completion_tokens} tokens generated`));
    }
    if (usage.retrieval_ms) {
      meta.appendChild(el("span", null, `${usage.retrieval_ms}ms to retrieve`));
    }
    if (payload.sources) meta.appendChild(el("span", null, `${payload.sources.length} source(s)`));
    wrapper.appendChild(meta);
    if (payload.sources && payload.sources.length) renderSources(wrapper, payload.sources);
    els.answerArea.appendChild(wrapper);
  }

  async function ask(question) {
    els.askButton.disabled = true;
    clear(els.answerArea);
    showNotice(els.answerArea, "info", "Searching your documents…", "Embedding the question, searching Qdrant, then generating an answer. The first run loads the model into memory.");
    try {
      const { status, data } = await postJson(
        window.CONFIG.queryPath,
        { question },
        window.CONFIG.queryTimeoutMs
      );
      if (status !== 200) {
        const { title, hint } = describeError(data, status);
        showNotice(els.answerArea, "error", title, hint);
        return;
      }
      renderAnswer(data);
    } finally {
      els.askButton.disabled = false;
    }
  }

  function renderLibrary(documents) {
    clear(els.libraryList);
    if (!documents.length) {
      els.libraryList.appendChild(
        el("p", "empty", "No documents yet. Upload a PDF above to get started.")
      );
      els.docCount.classList.add("hidden");
      return;
    }
    els.docCount.textContent = documents.length;
    els.docCount.classList.remove("hidden");

    documents.forEach((doc) => {
      const row = el("div", "doc");
      const body = el("div");
      body.appendChild(el("div", "doc-name", doc.document_name));
      const parts = [`${doc.chunk_count} chunks`];
      if (doc.page_count) parts.push(`${doc.page_count} pages`);
      if (doc.size_bytes) parts.push(`${(doc.size_bytes / 1048576).toFixed(2)} MB`);
      if (doc.indexed_at) parts.push(new Date(doc.indexed_at).toLocaleString());
      body.appendChild(el("div", "doc-meta", parts.join(" · ")));
      body.appendChild(el("div", "result-id", doc.document_id));
      row.appendChild(body);

      const actions = el("div", "doc-actions");
      const remove = el("button", null, "Delete");
      remove.type = "button";
      remove.addEventListener("click", () => deleteDocument(doc.document_id, doc.document_name));
      actions.appendChild(remove);
      row.appendChild(actions);
      els.libraryList.appendChild(row);
    });
  }

  async function loadLibrary() {
    try {
      const response = await fetch(url(window.CONFIG.documentsPath), {
        signal: AbortSignal.timeout(window.CONFIG.listTimeoutMs),
      });
      const data = await response.json().catch(() => ({}));
      if (response.ok && Array.isArray(data.documents)) {
        renderLibrary(data.documents);
        setStatus("ok", `${data.documents.length} document(s) indexed`);
        return data.documents;
      }
      setStatus("down", "pipeline offline");
      return [];
    } catch (err) {
      setStatus("down", "cannot reach n8n");
      clear(els.libraryList);
      els.libraryList.appendChild(
        el("p", "empty", "Could not reach n8n. Start the stack with: make up")
      );
      return [];
    }
  }

  async function deleteDocument(documentId, name) {
    if (!window.confirm(`Delete "${name}" and all of its chunks from Qdrant?`)) return;
    try {
      const response = await fetch(
        `${url(window.CONFIG.documentPath)}?document_id=${encodeURIComponent(documentId)}`,
        { method: "DELETE" }
      );
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        const { title, hint } = describeError(data, response.status);
        showNotice(els.libraryList, "error", title, hint);
        return;
      }
      loadLibrary();
    } catch (err) {
      showNotice(els.libraryList, "error", "Could not reach n8n", "Start the stack with: make up");
    }
  }

  function setStatus(kind, text) {
    els.status.className = `pill pill-${kind}`;
    els.status.textContent = text;
  }

  function setupTabs() {
    document.querySelectorAll(".tab").forEach((tab) => {
      tab.addEventListener("click", () => {
        document.querySelectorAll(".tab").forEach((other) => {
          other.classList.toggle("active", other === tab);
          other.setAttribute("aria-selected", String(other === tab));
        });
        document.getElementById("panel-ask").classList.toggle("hidden", tab.dataset.tab !== "ask");
        document.getElementById("panel-library").classList.toggle("hidden", tab.dataset.tab !== "library");
        if (tab.dataset.tab === "library") loadLibrary();
      });
    });
  }

  function setupUpload() {
    els.uploadForm.addEventListener("submit", (event) => {
      event.preventDefault();
      uploadFile(els.fileInput.files[0]);
    });
    ["dragenter", "dragover"].forEach((type) =>
      els.dropzone.addEventListener(type, (event) => {
        event.preventDefault();
        els.dropzone.classList.add("dragover");
      })
    );
    ["dragleave", "drop"].forEach((type) =>
      els.dropzone.addEventListener(type, (event) => {
        event.preventDefault();
        els.dropzone.classList.remove("dragover");
      })
    );
    els.dropzone.addEventListener("drop", (event) => {
      const file = event.dataTransfer.files[0];
      if (file) uploadFile(file);
    });
    els.dropzone.addEventListener("click", () => els.fileInput.click());
    els.fileInput.addEventListener("change", () => uploadFile(els.fileInput.files[0]));
  }

  function setupAsk() {
    els.askForm.addEventListener("submit", (event) => {
      event.preventDefault();
      const question = els.question.value.trim();
      if (question) ask(question);
    });
    els.question.addEventListener("keydown", (event) => {
      if (event.key === "Enter" && (event.ctrlKey || event.metaKey)) {
        els.askForm.requestSubmit();
      }
    });
  }

  setupTabs();
  setupUpload();
  setupAsk();
  els.refreshLibrary.addEventListener("click", loadLibrary);
  loadLibrary();
})();
