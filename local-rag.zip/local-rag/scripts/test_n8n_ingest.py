#!/usr/bin/env python3
"""End-to-end test of the n8n BTM ingestion webhook.

`make test-ingest` covers the backend contract directly. This covers the part
only n8n can break: the workflow's own control flow, its batch loop, and what a
caller gets back when an upload cannot be parsed.

Checks, in order:
  1. an unreadable upload comes back 422 with a message a human can act on
  2. the same upload leaves nothing behind in the library
  3. the sample PDF ingests 200 with the right dates and vector count
  4. the document appears in the library and honours the temporal filter
  5. a clean document type is detected, not guessed from the extension
  6. the upload is deleted again
"""
from __future__ import annotations

import json
import os
import pathlib
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from common import bad, info, multipart_body, ok, request  # noqa: E402

ROOT = pathlib.Path(__file__).resolve().parents[1]
N8N = os.environ.get("N8N_URL", "http://localhost:5678")
API = os.environ.get("API_URL", "http://127.0.0.1:8000")
SAMPLE = ROOT / "sample" / "sample.pdf"

results: list[tuple[str, bool, str]] = []


def check(label: str, passed: bool, detail: str = "") -> None:
    results.append((label, passed, detail))
    (ok if passed else bad)(label, detail)


def main() -> int:
    started = time.perf_counter()
    print("n8n BTM ingest contract")

    if not SAMPLE.exists():
        bad("sample/sample.pdf is missing", "run: make sample")
        return 1

    # Snapshot every count *before* ingesting. Comparing a filtered query to an
    # unfiltered one is not the same thing: the library legitimately holds
    # future-dated documents that an as_of query must not see.
    before = request("GET", f"{API}/api/v1/documents?limit=100")[1]["total"]
    before_early = request("GET", f"{API}/api/v1/documents?as_of=2024-06-01&limit=100")[1]["total"]
    before_late = request("GET", f"{API}/api/v1/documents?as_of=2025-06-01&limit=100")[1]["total"]

    body, ctype = multipart_body("data", b"\x00\x01\x02 not a document", "garbage.bin")
    status, out = request("POST", f"{N8N}/webhook/btm/ingest", data=body, content_type=ctype, timeout=300)
    check("an unreadable upload is rejected", status == 422, f"HTTP {status}")
    message = ((out.get("error") or {}).get("message") or "") if isinstance(out, dict) else ""
    check(
        "the rejection explains itself, and is not an object printed as a string",
        bool(message) and message != "[object Object]" and len(message) > 15,
        message[:80] or json.dumps(out)[:80],
    )
    after = request("GET", f"{API}/api/v1/documents?limit=100")[1]["total"]
    check("a rejected upload leaves nothing behind", after == before, f"{before} -> {after}")

    body, ctype = multipart_body("data", SAMPLE.read_bytes(), SAMPLE.name)
    t0 = time.perf_counter()
    status, out = request("POST", f"{N8N}/webhook/btm/ingest", data=body, content_type=ctype, timeout=900)
    elapsed = time.perf_counter() - t0
    check("the sample document is indexed", status == 200, f"HTTP {status}")
    if status != 200:
        return report(started)
    check("the response says it succeeded", out.get("ok") is True, json.dumps(out)[:90])
    check("the document type was detected", out.get("document_type") == "pdf", str(out.get("document_type")))
    check("vectors were written", (out.get("vectors") or 0) > 0, str(out.get("vectors")))
    check("sections were detected", (out.get("sections") or 0) > 0, str(out.get("sections")))
    check("a document date came from the text", out.get("effective_date") == "2025-03-31", str(out.get("effective_date")))
    check("certainty is reported, not assumed", bool(out.get("temporal_certainty")), str(out.get("temporal_certainty")))
    llm = out.get("llm") or {}
    check(
        "llm usage is accounted for, whatever the outcome",
        isinstance(llm, dict) and "usage" in llm,
        json.dumps(llm)[:90],
    )
    # The reported provider has to match the usage: claiming groq on a run where
    # groq returned 429 is a lie a caller cannot detect.
    calls = (llm.get("usage") or {}).get("calls") or 0
    check(
        "the reported provider matches the usage",
        (llm.get("provider") == "groq") == (calls >= 1),
        f"provider={llm.get('provider')} calls={calls}",
    )
    info(f"the whole workflow took {elapsed:.1f}s")

    document_id = out.get("document_id")
    library = request("GET", f"{API}/api/v1/documents?limit=100")[1]
    check(
        "the document is in the library",
        any(d["document_id"] == document_id for d in library["documents"]),
        str(document_id),
    )
    early = request("GET", f"{API}/api/v1/documents?as_of=2024-06-01&limit=100")[1]["total"]
    late = request("GET", f"{API}/api/v1/documents?as_of=2025-06-01&limit=100")[1]["total"]
    check(
        "the temporal filter hides it before its date",
        early == before_early,
        f"{before_early} -> {early}",
    )
    check("the temporal filter shows it after", late == before_late + 1, f"{before_late} -> {late}")

    request("DELETE", f"{API}/api/v1/documents/{document_id}")
    left = request("GET", f"{API}/api/v1/documents?limit=100")[1]["total"]
    check("the upload can be deleted", left == before, f"{after} -> {left}")

    return report(started)


def report(started: float) -> int:
    failed = [r for r in results if not r[1]]
    print()
    if failed:
        print(f"[31m{len(failed)} of {len(results)} checks failed in {time.perf_counter()-started:.1f}s[0m")
        for label, _, detail in failed:
            bad(label, detail)
        return 1
    print(f"[32mn8n ingest contract verified end to end in {time.perf_counter()-started:.1f}s[0m")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
