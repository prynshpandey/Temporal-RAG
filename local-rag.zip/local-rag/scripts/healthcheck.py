#!/usr/bin/env python3
"""Check every moving part of the stack and print a single report.

    python3 scripts/healthcheck.py

Checks: host Ollama + required models + embedding dimension, Qdrant + the
collection, PostgreSQL (TCP, and a real query when psql is available), n8n, and
- importantly - the path from inside the n8n container to the host Ollama.
Exit code is non-zero when a required dependency is missing.
"""

from __future__ import annotations

import os
import shutil
import socket
import subprocess
import sys

from common import GREEN, RED, YELLOW, DIM, RESET, bad, info, load_env, ok, request, strip_trailing_slash, warn

failures = 0
warnings = 0


def fail(label: str, detail: str, fix: str) -> None:
    global failures
    failures += 1
    bad(label, detail)
    print(f"        {DIM}fix: {fix}{RESET}")


def soft_warn(label: str, detail: str, fix: str) -> None:
    global warnings
    warnings += 1
    warn(f"{label} {detail}")
    print(f"        {DIM}fix: {fix}{RESET}")


def check_ollama(config: dict) -> None:
    url = strip_trailing_slash(config["OLLAMA_URL"])
    try:
        status, body = request("GET", f"{url}/api/tags", timeout=10)
    except Exception as exc:  # connection refused, DNS, ...
        fail("Ollama is unreachable", str(exc), f"start it with: ollama serve  (or systemctl start ollama)")
        return
    if status != 200:
        fail("Ollama /api/tags", f"HTTP {status}", f"curl {url}/api/tags")
        return
    models = [m.get("name", "") for m in (body.get("models") or [])]
    ok("Ollama is running", f"{len(models)} model(s) at {url}")

    for label, key in (("generation", "LLM_MODEL"), ("embedding", "EMBEDDING_MODEL")):
        wanted = config[key]
        # Ollama reports names with a :latest suffix, so compare on the base.
        if any(m == wanted or m.split(":")[0] == wanted.split(":")[0] for m in models):
            ok(f"{label} model present: {wanted}")
        else:
            soft_warn(
                f"{label} model missing: {wanted}",
                f"have: {', '.join(models) or 'nothing'}",
                f"ollama pull {wanted}",
            )

    # The collection dimension must match what the model actually produces.
    size = int(config["QDRANT_VECTOR_SIZE"])
    try:
        status, body = request(
            "POST",
            f"{url}/api/embed",
            body={"model": config["EMBEDDING_MODEL"], "input": ["dimension check"]},
            timeout=120,
        )
        if status == 200 and isinstance(body, dict) and body.get("embeddings"):
            dim = len(body["embeddings"][0])
            if dim == size:
                ok(f"{config['EMBEDDING_MODEL']} produces {dim}-dim vectors", "matches QDRANT_VECTOR_SIZE")
            else:
                fail(
                    f"embedding dimension mismatch",
                    f"{config['EMBEDDING_MODEL']} gives {dim}, QDRANT_VECTOR_SIZE is {size}",
                    "either set QDRANT_VECTOR_SIZE to the real size, or switch EMBEDDING_MODEL and run: python3 scripts/setup_qdrant.py --recreate",
                )
        else:
            soft_warn("could not verify the embedding dimension", str(body)[:120], f"ollama pull {config['EMBEDDING_MODEL']}")
    except Exception as exc:
        soft_warn("could not verify the embedding dimension", str(exc)[:120], f"ollama pull {config['EMBEDDING_MODEL']}")


def check_ollama_from_container(config: dict) -> None:
    """The single most common failure: containers cannot reach host Ollama."""
    docker = os.environ.get("DOCKER", "docker")
    if shutil.which(docker) is None:
        soft_warn("container -> Ollama path not checked", "docker CLI not available", f"run: {docker} compose exec n8n curl $OLLAMA_URL/api/tags")
        return
    script = (
        "fetch(process.env.OLLAMA_URL + '/api/tags')"
        ".then(r => { console.log('HTTP ' + r.status); process.exit(r.status === 200 ? 0 : 1); })"
        ".catch(e => { console.log(String(e)); process.exit(1); })"
    )
    try:
        result = subprocess.run(
            [docker, "compose", "exec", "-T", "n8n", "node", "-e", script],
            cwd=str(__import__("pathlib").Path(__file__).resolve().parents[1]),
            capture_output=True,
            text=True,
            timeout=60,
        )
    except Exception as exc:
        soft_warn("container -> Ollama path not checked", str(exc)[:100], f"run: {docker} compose ps")
        return

    if "HTTP 200" in result.stdout:
        ok("n8n container can reach host Ollama", config.get("OLLAMA_URL_INTERNAL", "OLLAMA_URL"))
    else:
        detail = (result.stderr or result.stdout).strip().splitlines()
        fail(
            "n8n container cannot reach Ollama",
            detail[-1] if detail else "no response",
            "OLLAMA_URL_INTERNAL must be http://host.docker.internal:11434, the compose file needs "
            "extra_hosts: host.docker.internal:host-gateway, and the host Ollama must listen on 0.0.0.0 "
            "(sudo bash scripts/bootstrap_host.sh)",
        )


def check_qdrant(config: dict) -> None:
    url = strip_trailing_slash(config["QDRANT_URL"])
    try:
        status, _ = request("GET", f"{url}/readyz", timeout=10)
    except Exception as exc:
        fail("Qdrant is unreachable", str(exc), "docker compose up -d qdrant")
        return
    if status != 200:
        fail("Qdrant /readyz", f"HTTP {status}", "docker compose logs qdrant")
        return
    ok("Qdrant is ready", url)

    name = config["QDRANT_COLLECTION"]
    try:
        status, body = request("GET", f"{url}/collections/{name}", timeout=10)
    except Exception as exc:
        fail("Qdrant collection request failed", str(exc), "docker compose restart qdrant")
        return
    if status == 200 and isinstance(body, dict) and body.get("result"):
        result = body["result"]
        ok(f"collection '{name}'", f"{result.get('points_count', 0)} points, status={result.get('status')}")
    else:
        soft_warn(
            f"collection '{name}' is missing",
            f"HTTP {status}",
            "python3 scripts/setup_qdrant.py   (or: make qdrant)",
        )


def check_postgres(config: dict) -> None:
    host = config["POSTGRES_HOST"]
    if host in ("postgres", "qdrant", "n8n"):
        host = "127.0.0.1"  # running on the host, not inside the compose network
    port = int(config["POSTGRES_PORT"])
    try:
        with socket.create_connection((host, port), timeout=5):
            ok("PostgreSQL is accepting connections", f"{host}:{port}")
    except Exception as exc:
        fail("PostgreSQL is unreachable", str(exc), "docker compose up -d postgres")
        return

    if shutil.which("psql"):
        env = dict(os.environ, PGPASSWORD=config.get("POSTGRES_PASSWORD", ""))
        try:
            result = subprocess.run(
                ["psql", "-h", host, "-p", str(port), "-U", config["POSTGRES_USER"], "-d", config["POSTGRES_DB"],
                 "-tAc", "select count(*) from workflow_entity"],
                capture_output=True, text=True, timeout=20, env=env,
            )
            if result.returncode == 0:
                ok("n8n workflows in PostgreSQL", f"{result.stdout.strip()} row(s) in workflow_entity")
            else:
                soft_warn("psql query failed", result.stderr.strip()[:120], "check POSTGRES_* in .env")
        except Exception as exc:
            soft_warn("psql query failed", str(exc)[:100], "check POSTGRES_* in .env")
    else:
        info("psql not installed - skipped the n8n workflow table check")


def check_n8n(config: dict) -> None:
    url = f"http://localhost:{config['N8N_PORT']}"
    try:
        status, _ = request("GET", f"{url}/healthz", timeout=10)
    except Exception as exc:
        fail("n8n is unreachable", str(exc), "docker compose up -d n8n")
        return
    if status not in (200, 401):
        warn(f"n8n /healthz returned HTTP {status}")
    ok("n8n is up", url)

    # An inactive workflow answers 404; an active one validates the request.
    status, body = request("POST", f"{url}/webhook/rag/query", body={}, timeout=20,
                           headers={"Content-Type": "application/json"})
    if status == 400:
        error = body.get("error", {}) if isinstance(body, dict) else {}
        ok("query workflow is active", f"answered with {error.get('code', '400')}")
    elif status == 404:
        soft_warn("query workflow is not active", "webhook returned 404", "make import   (or activate it in the n8n UI)")
    else:
        soft_warn("query workflow check inconclusive", f"HTTP {status} {str(body)[:100]}", "make import")


def main() -> int:
    config = load_env()
    print(f"\n{GREEN}local-rag healthcheck{RESET}  (.env: {'.env' if (__import__('pathlib').Path('.env').exists()) else 'defaults'})\n")

    print(f"{YELLOW}Ollama (host){RESET}")
    check_ollama(config)
    print(f"\n{YELLOW}Qdrant{RESET}")
    check_qdrant(config)
    print(f"\n{YELLOW}PostgreSQL{RESET}")
    check_postgres(config)
    print(f"\n{YELLOW}n8n{RESET}")
    check_n8n(config)
    print(f"\n{YELLOW}Container network{RESET}")
    check_ollama_from_container(config)

    print()
    if failures:
        print(f"{RED}{failures} problem(s) found{RESET}" + (f", {warnings} warning(s)" if warnings else ""))
        return 1
    print(f"{GREEN}all checks passed{RESET}" + (f" ({warnings} warning(s))" if warnings else ""))
    return 0


if __name__ == "__main__":
    sys.exit(main())
