#!/usr/bin/env python3
"""Does the retrieval layer actually respect time?

`make test-ingest` proves documents land in the database. This proves the thing
the product is named for: that a question asked about a past date is answered
from what was known *then*, and that knowledge which did not exist yet cannot
leak into the answer no matter how well it matches the wording.

Each case names the documents that must appear and the ones that must not. The
negative half is the point: a system that returns the 2025 report for "what was
revenue in 2023?" has not failed to rank well, it has answered a different
question.
"""
from __future__ import annotations

import json
import os
import pathlib
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from common import bad as _bad, info, ok as _ok, request  # noqa: E402

results: list[tuple[str, bool, str]] = []


def _text(detail: tuple) -> str:
    return " ".join(str(part) for part in detail if part is not None)


def ok(label: str, *detail) -> None:
    results.append((label, True, _text(detail)))
    _ok(label, _text(detail))


def bad(label: str, *detail) -> None:
    results.append((label, False, _text(detail)))
    _bad(label, _text(detail))

ROOT = pathlib.Path(__file__).resolve().parents[1]
API = os.environ.get("API_URL", "http://127.0.0.1:8000")

# The corpus, by short name. Documents are only visible from their own date on.
FY2023 = "helios-annual-report-2023.md"
FY2024 = "helios-annual-report-2024.md"
Q1_2025 = "helios-q1-2025-update.md"
FY2025 = "helios-annual-report-2025.md"
LAUNCH = "helios-corvus-launch-note.md"
CLOSURE = "helios-utrecht-office-closure.md"

# (label, question, must_include, must_not_include, as_of, expected token, expected first)
#
# must_not_include is only ever a document dated *after* the window. A document
# that is in scope is not a leak just because it also shows up: "what was churn
# in 2024" may legitimately return the 2023 report as a secondary hit, and the
# interesting question is whether the newer one ranks above it.
CASES: list[tuple[str, str, list[str], list[str], str | None, str | None, str | None]] = [
    (
        "revenue asked for 2023 is answered from the 2023 report",
        "What was revenue in 2023?",
        [FY2023],
        [FY2024, Q1_2025, FY2025],
        "2023-12-31",
        "41.2",
        None,
    ),
    (
        "revenue asked for 2025 is answered from the 2025 report",
        "What was revenue in 2025?",
        [FY2025],
        [],
        "2025-12-31",
        "57.4",
        FY2025,
    ),
    (
        "headcount moves forward with the as-of date",
        "How many employees does Helios have?",
        [FY2024],
        [],
        "2024-12-31",
        "214",
        FY2024,
    ),
    (
        "a question about the future cannot see the future report",
        "What was the FY2025 revenue?",
        [],
        [FY2025],
        "2024-06-30",
        None,
        None,
    ),
    (
        "an as-of inside the question is honoured",
        "As of 2023-12-31, where was the company headquartered?",
        [FY2023, CLOSURE],
        [FY2024, FY2025],
        None,
        "Utrecht",
        None,
    ),
    (
        "a relocation note does not beat the later report",
        "Where is the headquarters now?",
        [FY2024, FY2025],
        [],
        "2026-01-01",
        "Rotterdam",
        None,
    ),
    (
        "the launch note answers product availability in 2024",
        "When did Corvus reach general availability?",
        [LAUNCH, FY2024],
        [],
        "2024-12-31",
        None,
        None,
    ),
    (
        "a quarter in the question becomes a window",
        "What was revenue in Q1 2025?",
        [Q1_2025],
        [FY2023],
        None,
        "13.8",
        Q1_2025,
    ),
    (
        "founding facts are findable without a date constraint",
        "Who founded Helios Robotics?",
        [FY2023, FY2024, FY2025],
        [],
        None,
        "Elena Fischer",
        None,
    ),
    (
        "churn is answered from the most recent in-scope report",
        "What was customer churn?",
        [FY2024],
        [],
        "2024-12-31",
        "3.6",
        FY2024,
    ),
]


def main() -> int:
    started = time.perf_counter()
    print("temporal retrieval")

    status, library = request("GET", f"{API}/api/v1/documents?limit=200")
    if status != 200:
        bad("the library is reachable", f"HTTP {status}")
        return 1
    names = {d["name"] for d in library["documents"]}
    missing = [name for case in CASES for name in case[2] + ([case[6]] if case[6] else []) if name not in names]
    if not any(name.startswith("helios-") for name in names):
        bad(
            "the seed corpus is loaded",
            "run: make seed-corpus",
        )
        return 1
    if missing:
        info(f"some expected documents are absent ({', '.join(sorted(set(missing))[:3])}); those cases will report it")

    for label, question, want, forbid, as_of, token, top in CASES:
        payload: dict = {"question": question, "limit": 8}
        if as_of:
            payload["as_of"] = as_of
        status, out = request(
            "POST",
            f"{API}/api/v1/query",
            data=json.dumps(payload).encode(),
            content_type="application/json",
            timeout=300,
        )
        if status != 200:
            bad(label, f"HTTP {status} {str(out)[:120]}")
            continue

        hits = out.get("hits", [])
        got = [h["document_name"] for h in hits]
        found = [name for name in want if name in got]
        leaked = [name for name in forbid if name in got]

        if want and not found:
            bad(label, f"none of {want} in {got[:4]}")
            continue
        if leaked:
            bad(label, f"leaked {leaked} for as_of={as_of}")
            continue
        if token:
            blob = " ".join((h.get("text") or "") + " " + (h.get("context") or "") for h in hits)
            if token.lower() not in blob.lower():
                bad(label, f"expected {token!r} in the returned text")
                continue
        if top and got and got[0] != top:
            bad(label, f"expected {top} first, got {got[0]}")
            continue
        ok(
            label,
            f"{len(hits)} hits, first={got[0] if got else None}, "
            f"both-sides={out.get('stats', {}).get('both', 0)}",
        )

    # The response has to show its work, or none of the above can be trusted.
    payload = {"question": "revenue", "as_of": "2024-12-31", "limit": 5}
    status, out = request(
        "POST",
        f"{API}/api/v1/query",
        data=json.dumps(payload).encode(),
        content_type="application/json",
        timeout=300,
    )
    if status == 200:
        ok("the response echoes the window it applied", out["filters"]["as_of"] == "2024-12-31", json.dumps(out["filters"])[:90])
        ok(
            "the response reports which systems contributed",
            {"keyword_candidates", "vector_candidates"} <= set(out.get("stats", {})),
            json.dumps(out.get("stats"))[:110],
        )
        ok(
            "every hit carries a document and a date",
            all(h.get("document_name") and h.get("effective_date") for h in out.get("hits", [])),
            f"{len(out.get('hits', []))} hits",
        )
        (ok if any(h.get("context") for h in out.get("hits", [])) else bad)(
            "at least one hit was expanded to its parent for context",
            f"{sum(1 for h in out.get('hits', []) if h.get('context'))}/{len(out.get('hits', []))} hits carry context",
        )
    else:
        bad("the response shape can be inspected", f"HTTP {status}")

    print()
    return report(started)


def report(started: float) -> int:
    failed = [r for r in results if not r[1]]
    if failed:
        print(f"[31m{len(failed)} of {len(results)} checks failed in {time.perf_counter()-started:.1f}s[0m")
        return 1
    print(f"[32mtemporal retrieval verified in {time.perf_counter()-started:.1f}s[0m")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
