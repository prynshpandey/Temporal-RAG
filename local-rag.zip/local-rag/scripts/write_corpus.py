#!/usr/bin/env python3
"""Regenerate the seed corpus files in the repo from ``eval_seed/corpus.py``.

The backend directory is read-only inside the container, so the corpus is a
checked-in input rather than something the seeding script writes for itself.

    python3 scripts/write_corpus.py
"""
from __future__ import annotations

import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))

from eval_seed.corpus import SEED_DIR, write_corpus  # noqa: E402

if __name__ == "__main__":
    for path in write_corpus(SEED_DIR):
        print(f"wrote {path.relative_to(ROOT)}")
