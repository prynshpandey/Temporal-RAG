#!/usr/bin/env python3
"""Assemble the n8n workflow JSON files.

The pipeline logic lives in real, lintable .js files under n8n/code/; this
script wires those Code nodes together with the Webhook, HTTP Request, IF,
Loop Over Items, Aggregate and Respond to Webhook nodes and writes valid n8n
workflow JSON to n8n/workflows/.

    make workflows        # or: python3 scripts/build_workflows.py

Nothing here talks to n8n: it only produces importable workflow definitions.
"""

from __future__ import annotations

import hashlib
import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
CODE_DIR = ROOT / "n8n" / "code"
OUT_DIR = ROOT / "n8n" / "workflows"
PROMPT_FILE = ROOT / "prompts" / "system_prompt.txt"

ALPHABET = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"


def node_id(seed: str) -> str:
    """Stable 16 char id so re-importing updates the same workflow."""
    digest = hashlib.sha256(seed.encode()).hexdigest()
    return "".join(ALPHABET[int(digest[i : i + 2], 16) % len(ALPHABET)] for i in range(16))


def load_code(name: str) -> str:
    path = CODE_DIR / name
    if not path.exists():
        sys.exit(f"missing Code node source: {path}")
    return path.read_text(encoding="utf-8")


def code(name: str, position: tuple[int, int], source: str) -> dict:
    return {
        "parameters": {"jsCode": source},
        "id": node_id(name),
        "name": name,
        "type": "n8n-nodes-base.code",
        "typeVersion": 2,
        "position": list(position),
    }


def webhook(
    name: str,
    position: tuple[int, int],
    http_method: str,
    path: str,
    binary_property: str | None = None,
) -> dict:
    options: dict = {"allowedOrigins": "*"}
    if binary_property:
        options["binaryPropertyName"] = binary_property
    return {
        "parameters": {
            "httpMethod": http_method,
            "path": path,
            "responseMode": "responseNode",
            "options": options,
        },
        "id": node_id(name),
        "name": name,
        "type": "n8n-nodes-base.webhook",
        "typeVersion": 2,
        "position": list(position),
        "webhookId": node_id("webhook:" + path),
    }


def http(
    name: str,
    position: tuple[int, int],
    method: str,
    url: str,
    json_body: str | None = None,
    timeout: int = 120000,
) -> dict:
    parameters: dict = {
        "method": method,
        "url": url,
        "options": {
            "timeout": timeout,
            # Never throw on 4xx/5xx: normalise the error in the next Code node.
            "response": {"response": {"neverError": True}},
        },
    }
    if json_body is not None:
        parameters["sendBody"] = True
        parameters["specifyBody"] = "json"
        parameters["jsonBody"] = json_body
    return {
        "parameters": parameters,
        "id": node_id(name),
        "name": name,
        "type": "n8n-nodes-base.httpRequest",
        "typeVersion": 4.2,
        "position": list(position),
        "onError": "continueRegularOutput",
        "retryOnFail": False,
    }


def extract_pdf(name: str, position: tuple[int, int], binary_property: str = "data") -> dict:
    return {
        "parameters": {
            "operation": "pdf",
            "binaryPropertyName": binary_property,
            # joinPages=false keeps one entry per page, which is what the page
            # aware chunker downstream needs; keepSource=json carries the
            # document_id/document_name context from the validation node.
            "options": {"joinPages": False, "keepSource": "json"},
        },
        "id": node_id(name),
        "name": name,
        "type": "n8n-nodes-base.extractFromFile",
        "typeVersion": 1,
        "position": list(position),
        "onError": "continueRegularOutput",
    }


def if_ok(name: str, position: tuple[int, int], field: str = "ok") -> dict:
    """Two-way branch: output 0 when <field> is truthy, output 1 otherwise."""
    return {
        "parameters": {
            "conditions": {
                "options": {
                    "caseSensitive": True,
                    "leftValue": "",
                    "typeValidation": "strict",
                    "version": 2,
                },
                "conditions": [
                    {
                        "id": node_id("cond:" + name),
                        "leftValue": "={{ $json." + field + " }}",
                        "rightValue": True,
                        "operator": {"type": "boolean", "operation": "true", "singleValue": True},
                    }
                ],
                "combinator": "and",
            },
            "options": {},
        },
        "id": node_id(name),
        "name": name,
        "type": "n8n-nodes-base.if",
        "typeVersion": 2.2,
        "position": list(position),
    }


def if_field(
    name: str,
    position: tuple[int, int],
    left: str,
    operation: str = "false",
) -> dict:
    """Branch on a boolean expression, e.g. no_context === false."""
    return {
        "parameters": {
            "conditions": {
                "options": {
                    "caseSensitive": True,
                    "leftValue": "",
                    "typeValidation": "strict",
                    "version": 2,
                },
                "conditions": [
                    {
                        "id": node_id("cond:" + name),
                        "leftValue": left,
                        "rightValue": True,
                        "operator": {"type": "boolean", "operation": operation, "singleValue": True},
                    }
                ],
                "combinator": "and",
            },
            "options": {},
        },
        "id": node_id(name),
        "name": name,
        "type": "n8n-nodes-base.if",
        "typeVersion": 2.2,
        "position": list(position),
    }


def respond(name: str, position: tuple[int, int], body: str, status: int) -> dict:
    return {
        "parameters": {
            "respondWith": "json",
            "responseBody": "={{ JSON.stringify(" + body + ") }}",
            "options": {"responseCode": status},
        },
        "id": node_id(name),
        "name": name,
        "type": "n8n-nodes-base.respondToWebhook",
        "typeVersion": 1.1,
        "position": list(position),
    }


def loop_over_items(name: str, position: tuple[int, int], batch_size: str) -> dict:
    return {
        "parameters": {"batchSize": "={{ " + batch_size + " }}", "options": {}},
        "id": node_id(name),
        "name": name,
        "type": "n8n-nodes-base.splitInBatches",
        "typeVersion": 3,
        "position": list(position),
    }


def http_upload(
    name: str,
    position: tuple[int, int],
    url: str,
    field_name: str = "file",
    binary_property: str = "data",
    timeout: int = 300000,
) -> dict:
    """POST the webhook's binary as multipart/form-data.

    The backend parses the upload itself, so the file travels as the raw body of
    a form field rather than as JSON text: encoding a PDF into a string and
    decoding it again is how bytes get corrupted.
    """
    node = {
        "parameters": {
            "method": "POST",
            "url": url,
            "sendBody": True,
            "contentType": "multipart-form-data",
            "bodyParameters": {
                "parameters": [
                    {
                        "parameterType": "formBinaryData",
                        "name": field_name,
                        "inputDataFieldName": binary_property,
                    }
                ]
            },
            "options": {"timeout": timeout, "response": {"response": {"neverError": True}}},
        },
        "id": node_id(name),
        "name": name,
        "type": "n8n-nodes-base.httpRequest",
        "typeVersion": 4.2,
        "position": list(position),
        "onError": "continueRegularOutput",
        "retryOnFail": False,
    }
    _authenticate(node)
    return node


def ingest_call(name: str, position: tuple[int, int], path: str, body: str | None = None) -> dict:
    """A call to a backend /api/internal endpoint, with the shared token header."""
    node = http(name, position, "POST", "={{ $env.BACKEND_URL }}/api/internal" + path, json_body=body)
    _authenticate(node)
    node["parameters"]["options"]["timeout"] = 600000
    return node


def ingest_delete(name: str, position: tuple[int, int], path: str, body: str | None = None) -> dict:
    node = http(name, position, "DELETE", "={{ $env.BACKEND_URL }}/api/internal" + path, json_body=body)
    _authenticate(node)
    return node


def _authenticate(node: dict) -> None:
    """Attach the shared ingest token.

    ``sendHeaders`` is a separate switch in the HTTP Request node: setting
    ``headerParameters`` without it sends nothing, and the backend answers 401.
    """
    node["parameters"]["sendHeaders"] = True
    node["parameters"]["headerParameters"] = {
        "parameters": [{"name": "X-Ingest-Token", "value": "={{ $env.INGEST_TOKEN }}"}]
    }


def link(source: str, target: str, target_input: int = 0) -> dict:
    # n8n connection entries describe the *target input*; the source output is
    # selected by the position inside the "main" list in the connections dict.
    return {"node": target, "type": "main", "index": target_input}


def workflow(name: str, nodes: list[dict], connections: dict) -> dict:
    return {
        "id": node_id("workflow:" + name),
        "name": name,
        "nodes": nodes,
        "connections": connections,
        "active": False,
        "settings": {"executionOrder": "v1"},
        "versionId": node_id("version:" + name),
        "meta": {"instanceId": "local-rag"},
        "pinData": {},
        "tags": [],
    }


# ---------------------------------------------------------------------------
# Workflow 1 - ingestion
# ---------------------------------------------------------------------------

INGEST = workflow(
    "RAG 1 - PDF Ingestion",
    [
        webhook("Ingest Webhook", (0, 300), "POST", "rag/ingest"),
        code("Validate Upload", (220, 300), load_code("01_validate_upload.js")),
        if_ok("Upload Valid?", (440, 300)),
        respond(
            "Reject Upload",
            (660, 520),
            "{ status: 'error', error: $json.error }",
            400,
        ),
        extract_pdf("Extract PDF Text", (660, 220)),
        if_field(
            "Extraction OK?",
            (880, 220),
            "={{ $json.error == null && $json.text != null }}",
            "true",
        ),
        respond(
            "Extraction Failed",
            (1100, 420),
            "{ status: 'error', document_id: $('Validate Upload').first().json.document_id,"
            " document_name: $('Validate Upload').first().json.document_name,"
            " error: { code: 'extraction_failed',"
            " message: 'The PDF could not be read: ' + (typeof $json.error === 'string' ? $json.error"
            " : (($json.error && ($json.error.message || $json.error.description)) || 'the extractor returned no text')),"
            " hint: 'The file is corrupt or password protected. Remove the password protection, or OCR the document first.' } }",
            422,
        ),
        code("Validate Text", (1100, 180), load_code("01_validate_text.js")),
        if_ok("Text Usable?", (1320, 180)),
        respond(
            "No Text Layer",
            (1540, 400),
            "{ status: 'error', document_id: $('Validate Upload').first().json.document_id,"
            " document_name: $('Validate Upload').first().json.document_name,"
            " error: $json.error }",
            422,
        ),
        code("Chunk Document", (1760, 180), load_code("01_chunk.js")),
        if_field("Chunks Produced?", (1980, 180), "={{ $input.all().length > 0 }}", "true"),
        respond(
            "No Chunks",
            (2200, 400),
            "{ status: 'error', document_name: $('Validate Upload').first().json.document_name,"
            " error: { code: 'no_chunks_produced',"
            " message: 'Chunking produced no chunks. Check CHUNK_SIZE and MIN_CHUNK_CHARS in .env.',"
            " hint: 'Inspect the Chunk Document node output in this execution to see the extracted text.' } }",
            422,
        ),
        http(
            "Delete Existing Chunks",
            (2140, 40),
            "POST",
            "={{ $env.QDRANT_URL }}/collections/{{ $env.QDRANT_COLLECTION }}/points/delete?wait=true",
            "={{ { filter: { must: [ { key: 'document_id', match: { value: $json.document_id } } ] } } }}",
        ),
        code("Load Chunks", (2280, 40), load_code("01_load_chunks.js")),
        loop_over_items("Embed Chunk Batches", (2420, 180), "Number($env.EMBED_BATCH_SIZE || 8)"),
        code("Build Embed Batch", (2640, 60), load_code("01_build_embed_batch.js")),
        http(
            "Ollama Embed Chunks",
            (2860, 60),
            "POST",
            "={{ $env.OLLAMA_URL }}/api/embed",
            "={{ { model: $json.embedding_model, input: $json.input, truncate: $json.truncate, keep_alive: '5m' } }}",
        ),
        code("Normalize Embeddings", (3080, 60), load_code("01_normalize_embeddings.js")),
        code("Collect Points", (3300, 200), load_code("01_collect_points.js")),
        if_ok("Ingest OK?", (3520, 200)),
        respond(
            "Ingest Failed",
            (3740, 420),
            "{ status: 'error', document_id: $('Validate Upload').first().json.document_id,"
            " document_name: $('Validate Upload').first().json.document_name,"
            " error: $json.error }",
            502,
        ),
        http(
            "Qdrant Upsert Points",
            (3740, 140),
            # Qdrant >= 1.10 uses PUT for the point list upsert; POST is the
            # batch update format ({"points": {"ids": ...}}).
            "PUT",
            "={{ $env.QDRANT_URL }}/collections/{{ $env.QDRANT_COLLECTION }}/points?wait=true",
            "={{ { points: $json.points } }}",
            timeout=180000,
        ),
        code(
            "Check Upsert",
            (3960, 140),
            "// The upsert node runs once per batch of points; reduce the\n"
            "// responses into a single result and fail loudly if any batch failed.\n"
            "const items = $input.all();\n"
            "const stats = $('Collect Points').first().json;\n"
            "const failed = items.find((item) => item.json && item.json.error);\n"
            "if (failed) {\n"
            "  return [{ json: { ok: false, error: { code: 'qdrant_upsert_failed',\n"
            "    message: 'Qdrant rejected the upsert: ' + String((failed.json.error && (failed.json.error.message || failed.json.error.status || failed.json.error)) || 'unknown error'),\n"
            "    hint: 'Check that the collection exists with the right vector size: python3 scripts/setup_qdrant.py --recreate' } } }];\n"
            "}\n"
            "const results = items.map((item) => item.json);\n"
            "const last = results.length ? results[results.length - 1] : {};\n"
            "return [{ json: Object.assign({}, stats, {\n"
            "  upsert_batches: results.length,\n"
            "  operation_id: (last.result && last.result.operation_id) || null,\n"
            "}) }];\n",
        ),
        http(
            "Qdrant Collection Info",
            (4180, 140),
            "GET",
            "={{ $env.QDRANT_URL }}/collections/{{ $env.QDRANT_COLLECTION }}",
        ),
        code("Ingest Summary", (4400, 200), load_code("01_ingest_summary.js")),
        respond(
            "Ingest Result",
            (4620, 200),
            "$json",
            200,
        ),
    ],
    {
        "Ingest Webhook": {"main": [[link("Ingest Webhook", "Validate Upload")]]},
        "Validate Upload": {"main": [[link("Validate Upload", "Upload Valid?")]]},
        "Upload Valid?": {"main": [[link("Upload Valid?", "Extract PDF Text")], [link("Upload Valid?", "Reject Upload")]]},
        "Extract PDF Text": {"main": [[link("Extract PDF Text", "Extraction OK?")]]},
        "Extraction OK?": {"main": [[link("Extraction OK?", "Validate Text")], [link("Extraction OK?", "Extraction Failed")]]},
        "Validate Text": {"main": [[link("Validate Text", "Text Usable?")]]},
        "Text Usable?": {"main": [[link("Text Usable?", "Chunk Document")], [link("Text Usable?", "No Text Layer")]]},
        "Chunk Document": {"main": [[link("Chunk Document", "Chunks Produced?")]]},
        "Chunks Produced?": {"main": [[link("Chunks Produced?", "Delete Existing Chunks")], [link("Chunks Produced?", "No Chunks")]]},
        "Delete Existing Chunks": {"main": [[link("Delete Existing Chunks", "Load Chunks")]]},
        "Load Chunks": {"main": [[link("Load Chunks", "Embed Chunk Batches")]]},
        "Embed Chunk Batches": {"main": [[link("Embed Chunk Batches", "Collect Points")], [link("Embed Chunk Batches", "Build Embed Batch")]]},
        "Build Embed Batch": {"main": [[link("Build Embed Batch", "Ollama Embed Chunks")]]},
        "Ollama Embed Chunks": {"main": [[link("Ollama Embed Chunks", "Normalize Embeddings")]]},
        "Normalize Embeddings": {"main": [[link("Normalize Embeddings", "Embed Chunk Batches")]]},
        "Collect Points": {"main": [[link("Collect Points", "Ingest OK?")]]},
        "Ingest OK?": {"main": [[link("Ingest OK?", "Qdrant Upsert Points")], [link("Ingest OK?", "Ingest Failed")]]},
        "Qdrant Upsert Points": {"main": [[link("Qdrant Upsert Points", "Check Upsert")]]},
        "Check Upsert": {"main": [[link("Check Upsert", "Qdrant Collection Info")]]},
        "Qdrant Collection Info": {"main": [[link("Qdrant Collection Info", "Ingest Summary")]]},
        "Ingest Summary": {"main": [[link("Ingest Summary", "Ingest Result")]]},
    },
)



# ---------------------------------------------------------------------------
# Workflow 5 - Business Time Machine ingestion
# ---------------------------------------------------------------------------
#
# The same job as workflow 1, with parsing, chunking, embedding and temporal
# metadata owned by the backend. n8n keeps the job it is good at: sequencing the
# steps, retrying HTTP, and reporting to the caller.
#
#   upload -> parse -> extract -> embed (batched) -> upsert -> register
#          -> finalize -> respond
#
# Nothing is written to the database until the vectors are in Qdrant, so a
# failure leaves no document half-ingested. Workflow 1 is left untouched: the
# legacy /webhook/rag/* contract and its 20 checks keep working.

BTM_INGEST = workflow(
    "RAG 5 - BTM Ingestion",
    [
        webhook("BTM Webhook", (0, 340), "POST", "btm/ingest"),
        http_upload("Parse Document", (220, 340), "={{ $env.BACKEND_URL }}/api/internal/parse"),
        if_field(
            "Parse OK?",
            (440, 340),
            "={{ $json.document_id != null && Array.isArray($json.units) && $json.units.length > 0 }}",
            "true",
        ),
        ingest_call(
            "Extract Metadata",
            (660, 280),
            "/extract",
            "={{ { plan: $('Parse Document').first().json } }}",
        ),
        code("Prepare Batches", (880, 200), load_code("05_btm_prepare_batches.js")),
        if_ok("Batches Ready?", (1100, 200)),
        loop_over_items("Embed Loop", (1320, 140), "1"),
        ingest_call(
            "Embed Texts",
            (1540, 60),
            "/embed",
            # The ids travel with the texts so the response can be matched to
            # chunks without relying on the order coming back unchanged.
            "={{ { texts: $json.texts, ids: $json.point_ids } }}",
        ),
        code("Attach Vectors", (1760, 60), load_code("05_btm_attach_vectors.js")),
        code("Build Points", (1980, 260), load_code("05_btm_build_points.js")),
        if_ok("Points Ready?", (2200, 260)),
        http(
            "Qdrant Upsert",
            (2420, 260),
            "PUT",
            "={{ $env.QDRANT_URL }}/collections/{{ $env.QDRANT_COLLECTION }}/points?wait=true",
            "={{ { points: $json.points } }}",
            timeout=180000,
        ),
        code(
            "Check Upsert",
            (2640, 260),
            "// One HTTP response per upsert batch. Any error aborts the ingest\n"
            "// before the database is touched, so a rejected write cannot leave\n"
            "// a document that answers with nothing.\n"
            "const items = $input.all();\n"
            "const first = $('Build Points').first().json;\n"
            "const failed = items.find((item) => item.json && item.json.error);\n"
            "if (failed) {\n"
            "  return [{ json: { ok: false, error: { code: 'qdrant_upsert_failed',\n"
            "    message: 'Qdrant rejected the upsert: ' + String((failed.json.error && (failed.json.error.message || failed.json.error.status || failed.json.error)) || 'unknown error'),\n"
            "    hint: 'Check the collection exists with the right vector size: make qdrant-btm' } } }];\n"
            "}\n"
            "return [{ json: { ok: true, upsert_batches: items.length,\n"
            "  operation_id: (items.length ? (items[items.length - 1].json.result || {}).operation_id : null) || null,\n"
            "  point_count: first.point_count } }];\n",
        ),
        ingest_call(
            "Register Document",
            (3080, 260),
            "/ingest/register",
            "={{ { request_id: $('Parse Document').first().json.request_id,"
            " plan: $('Parse Document').first().json,"
            " extracted: $('Extract Metadata').first().json } }}",
        ),
        if_field(
            "Registered?",
            (3300, 260),
            "={{ $json.document_id != null && $json.status === 'indexed' }}",
            "true",
        ),
        ingest_call(
            "Finalize Document",
            (3520, 140),
            "/ingest/finalize",
            "={{ { document_id: $('Parse Document').first().json.document_id, ready: true } }}",
        ),
        code("Ingest Response", (3740, 140), load_code("05_btm_response.js")),
        if_field(
            "Ingest Complete?",
            (3960, 140),
            # A finalize that failed is not a successful ingest: the document would
            # sit in the library forever with no way to tell it is incomplete.
            "={{ $json.ok === true && $json.status === 'indexed' }}",
            "true",
        ),
        respond("Ingest Result", (4400, 140), "$json", 200),
        code("Report Failure", (2860, 520), load_code("05_btm_failure.js")),
        ingest_call(
            "Record Failure",
            (3080, 620),
            "/ingest/fail",
            "={{ $json.fail_payload }}",
        ),
        ingest_delete(
            "Delete Partial",
            (3300, 620),
            "/ingest/document",
            "={{ $('Report Failure').first().json.delete_payload }}",
        ),
        respond(
            "Failure Response",
            (3740, 620),
            "{ status: 'error', document_id: $json.document_id, reason: $('Report Failure').first().json.reason,"
            " error: { code: 'btm_ingest_failed', message: $('Report Failure').first().json.reason,"
            " hint: 'The document was not indexed and any partial state was removed. Retry the upload.' } }",
            502,
        ),
        code("Format Rejection", (660, 700), load_code("05_btm_reject.js")),
        respond("Reject Upload", (880, 700), "$json", 422),
    ],
    {
        "BTM Webhook": {"main": [[link("BTM Webhook", "Parse Document")]]},
        "Parse Document": {"main": [[link("Parse Document", "Parse OK?")]]},
        "Parse OK?": {
            "main": [
                [link("Parse OK?", "Extract Metadata")],
                [link("Parse OK?", "Format Rejection")],
            ]
        },
        "Format Rejection": {"main": [[link("Format Rejection", "Reject Upload")]]},
        "Extract Metadata": {"main": [[link("Extract Metadata", "Prepare Batches")]]},
        "Prepare Batches": {"main": [[link("Prepare Batches", "Batches Ready?")]]},
        "Batches Ready?": {
            "main": [
                [link("Batches Ready?", "Embed Loop")],
                [link("Batches Ready?", "Report Failure")],
            ]
        },
        "Embed Loop": {
            "main": [
                [link("Embed Loop", "Build Points")],
                [link("Embed Loop", "Embed Texts")],
            ]
        },
        "Embed Texts": {"main": [[link("Embed Texts", "Attach Vectors")]]},
        "Attach Vectors": {"main": [[link("Attach Vectors", "Embed Loop")]]},
        "Build Points": {"main": [[link("Build Points", "Points Ready?")]]},
        "Points Ready?": {
            "main": [
                [link("Points Ready?", "Qdrant Upsert")],
                [link("Points Ready?", "Report Failure")],
            ]
        },
        "Qdrant Upsert": {"main": [[link("Qdrant Upsert", "Check Upsert")]]},
        "Check Upsert": {"main": [[link("Check Upsert", "Register Document")]]},
        "Register Document": {"main": [[link("Register Document", "Registered?")]]},
        "Registered?": {
            "main": [
                [link("Registered?", "Finalize Document")],
                [link("Registered?", "Report Failure")],
            ]
        },
        "Finalize Document": {"main": [[link("Finalize Document", "Ingest Response")]]},
        "Ingest Response": {"main": [[link("Ingest Response", "Ingest Complete?")]]},
        "Ingest Complete?": {
            "main": [
                [link("Ingest Complete?", "Ingest Result")],
                [link("Ingest Complete?", "Report Failure")],
            ]
        },
        "Report Failure": {"main": [[link("Report Failure", "Record Failure")]]},
        "Record Failure": {"main": [[link("Record Failure", "Delete Partial")]]},
        "Delete Partial": {"main": [[link("Delete Partial", "Failure Response")]]},
    },
)


# ---------------------------------------------------------------------------
# Workflow 2 - question answering
# ---------------------------------------------------------------------------

QUERY = workflow(
    "RAG 2 - Question Answering",
    [
        webhook("Query Webhook", (0, 300), "POST", "rag/query"),
        code("Query Config", (220, 300), load_code("02_query_config.js")),
        if_ok("Request Valid?", (440, 300)),
        respond("Reject Request", (660, 520), "{ status: 'error', error: $json.error }", 400),
        http(
            "Ollama Embed Question",
            (660, 200),
            "POST",
            "={{ $env.OLLAMA_URL }}/api/embed",
            "={{ { model: $('Query Config').first().json.embedding_model,"
            " input: [$('Query Config').first().json.question],"
            " truncate: true, keep_alive: '5m' } }}",
        ),
        code("Normalize Query Embedding", (880, 200), load_code("02_normalize_query_embedding.js")),
        if_ok("Embedding OK?", (1100, 200)),
        respond(
            "Embedding Failed",
            (1320, 420),
            "{ status: 'error', error: $json.error }",
            503,
        ),
        http(
            "Qdrant Search",
            (1320, 140),
            "POST",
            "={{ $('Query Config').first().json.qdrant_url }}/collections/{{ $('Query Config').first().json.qdrant_collection }}/points/search",
            "={{ { vector: $json.query_vector, limit: $('Query Config').first().json.top_k,"
            " with_payload: true, with_vector: false,"
            " score_threshold: $('Query Config').first().json.min_score,"
            " filter: $('Query Config').first().json.filter } }}",
        ),
        code("Build Context", (1540, 140), load_code("02_build_context.js")),
        if_ok("Retrieval OK?", (1760, 140)),
        respond(
            "Retrieval Failed",
            (1980, 360),
            "{ status: 'error', error: $json.error }",
            503,
        ),
        if_field("Has Context?", (1980, 100), "={{ $json.no_context }}", "false"),
        respond(
            "No Context Answer",
            (2200, 300),
            "{ status: 'no_context',"
            " question: $('Query Config').first().json.question,"
            " answer: 'I could not find this information in the provided documents.',"
            " reason: $json.reason, sources: [], top_k: $('Query Config').first().json.top_k,"
            " min_score: $('Query Config').first().json.min_score,"
            " llm_model: $('Query Config').first().json.llm_model,"
            " hint: 'Upload a document that covers this topic, lower MIN_SCORE in .env, or ask a more specific question.' }",
            200,
        ),
        code("Build Prompt", (2200, 40), load_code("02_build_prompt.js")),
        http(
            "Ollama Generate Answer",
            (2420, 40),
            "POST",
            "={{ $('Query Config').first().json.ollama_url }}/api/chat",
            "={{ { model: $('Query Config').first().json.llm_model, stream: false,"
            " options: { temperature: $('Query Config').first().json.temperature,"
            " num_ctx: $('Query Config').first().json.num_ctx,"
            " num_predict: $('Query Config').first().json.max_tokens },"
            " messages: [ { role: 'system', content: $json.system_prompt },"
            " { role: 'user', content: $json.user_prompt } ] } }}",
            timeout=600000,
        ),
        code("Assemble Answer", (2640, 40), load_code("02_assemble_answer.js")),
        if_ok("Generation OK?", (2860, 40)),
        respond(
            "Generation Failed",
            (3080, 320),
            "{ status: 'error', question: $('Query Config').first().json.question, error: $json.error }",
            502,
        ),
        respond(
            "Answer",
            (3080, 40),
            "$json",
            200,
        ),
    ],
    {
        "Query Webhook": {"main": [[link("Query Webhook", "Query Config")]]},
        "Query Config": {"main": [[link("Query Config", "Request Valid?")]]},
        "Request Valid?": {"main": [[link("Request Valid?", "Ollama Embed Question")], [link("Request Valid?", "Reject Request")]]},
        "Ollama Embed Question": {"main": [[link("Ollama Embed Question", "Normalize Query Embedding")]]},
        "Normalize Query Embedding": {"main": [[link("Normalize Query Embedding", "Embedding OK?")]]},
        "Embedding OK?": {"main": [[link("Embedding OK?", "Qdrant Search")], [link("Embedding OK?", "Embedding Failed")]]},
        "Qdrant Search": {"main": [[link("Qdrant Search", "Build Context")]]},
        "Build Context": {"main": [[link("Build Context", "Retrieval OK?")]]},
        "Retrieval OK?": {"main": [[link("Retrieval OK?", "Has Context?")], [link("Retrieval OK?", "Retrieval Failed")]]},
        "Has Context?": {"main": [[link("Has Context?", "Build Prompt")], [link("Has Context?", "No Context Answer")]]},
        "Build Prompt": {"main": [[link("Build Prompt", "Ollama Generate Answer")]]},
        "Ollama Generate Answer": {"main": [[link("Ollama Generate Answer", "Assemble Answer")]]},
        "Assemble Answer": {"main": [[link("Assemble Answer", "Generation OK?")]]},
        "Generation OK?": {"main": [[link("Generation OK?", "Answer")], [link("Generation OK?", "Generation Failed")]]},
    },
)


# ---------------------------------------------------------------------------
# Workflow 3 - list indexed documents
# ---------------------------------------------------------------------------

DOCUMENTS = workflow(
    "RAG 3 - Document Library",
    [
        webhook("List Documents", (0, 240), "GET", "rag/documents"),
        http(
            "Qdrant Scroll Points",
            (220, 240),
            "POST",
            "={{ $env.QDRANT_URL }}/collections/{{ $env.QDRANT_COLLECTION }}/points/scroll",
            "={{ { limit: 1000, with_vector: false,"
            " with_payload: ['document_id', 'document_name', 'sha256', 'page', 'indexed_at', 'embedding_model'] } }}",
        ),
        code("Aggregate Documents", (440, 240), load_code("03_aggregate_documents.js")),
        if_ok("Library OK?", (660, 240)),
        respond("Library Failed", (880, 420), "{ status: 'error', error: $json.error }", 503),
        respond("Document List", (880, 240), "$json", 200),
    ],
    {
        "List Documents": {"main": [[link("List Documents", "Qdrant Scroll Points")]]},
        "Qdrant Scroll Points": {"main": [[link("Qdrant Scroll Points", "Aggregate Documents")]]},
        "Aggregate Documents": {"main": [[link("Aggregate Documents", "Library OK?")]]},
        "Library OK?": {"main": [[link("Library OK?", "Document List")], [link("Library OK?", "Library Failed")]]},
    },
)


# ---------------------------------------------------------------------------
# Workflow 4 - delete a document
# ---------------------------------------------------------------------------

DELETE = workflow(
    "RAG 4 - Delete Document",
    [
        webhook("Delete Document", (0, 240), "DELETE", "rag/document"),
        code(
            "Delete Document Request",
            (220, 240),
            "// Read document_id from the query string (?document_id=doc_...) or the JSON body.\n"
            "const request = $input.first().json;\n"
            "const query = (request && request.query) || {};\n"
            "const body = (request && request.body) || {};\n"
            "const documentId = (typeof query.document_id === 'string' && query.document_id)"
            " || (typeof body.document_id === 'string' && body.document_id) || null;\n"
            "if (!documentId) {\n"
            "  return [{ json: { ok: false, error: { code: 'missing_document_id',\n"
            "    message: 'No document_id was supplied.',\n"
            "    hint: 'Call DELETE /webhook/rag/document?document_id=doc_xxxxxxxx' } } }];\n"
            "}\n"
            "return [{ json: { ok: true, document_id: documentId } }];\n",
        ),
        if_ok("Request Valid?", (440, 240)),
        respond("Reject Delete", (660, 420), "{ status: 'error', error: $json.error }", 400),
        http(
            "Qdrant Delete Points",
            (660, 180),
            "POST",
            "={{ $env.QDRANT_URL }}/collections/{{ $env.QDRANT_COLLECTION }}/points/delete?wait=true",
            "={{ { filter: { must: [ { key: 'document_id', match: { value: $json.document_id } } ] } } }}",
        ),
        code("Delete Summary", (880, 180), load_code("03_delete_document_summary.js")),
        if_ok("Delete OK?", (1100, 180)),
        respond("Delete Failed", (1320, 380), "{ status: 'error', error: $json.error }", 503),
        respond("Delete Result", (1320, 180), "$json", 200),
    ],
    {
        "Delete Document": {"main": [[link("Delete Document", "Delete Document Request")]]},
        "Delete Document Request": {"main": [[link("Delete Document Request", "Request Valid?")]]},
        "Request Valid?": {"main": [[link("Request Valid?", "Qdrant Delete Points")], [link("Request Valid?", "Reject Delete")]]},
        "Qdrant Delete Points": {"main": [[link("Qdrant Delete Points", "Delete Summary")]]},
        "Delete Summary": {"main": [[link("Delete Summary", "Delete OK?")]]},
        "Delete OK?": {"main": [[link("Delete OK?", "Delete Result")], [link("Delete OK?", "Delete Failed")]]},
    },
)


def main() -> int:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    prompt = PROMPT_FILE.read_text(encoding="utf-8").strip()

    workflows = [INGEST, BTM_INGEST, QUERY, DOCUMENTS, DELETE]
    for wf in workflows:
        for node in wf["nodes"]:
            if node["type"] == "n8n-nodes-base.code":
                source = node["parameters"]["jsCode"]
                if "__SYSTEM_PROMPT__" in source:
                    # Embed the prompt as a proper JS string literal.
                    node["parameters"]["jsCode"] = source.replace(
                        "__SYSTEM_PROMPT__", json.dumps(prompt)
                    )
        names = [n["name"] for n in wf["nodes"]]
        assert len(names) == len(set(names)), f"duplicate node name in {wf['name']}"
        for source, outputs in wf["connections"].items():
            assert source in names, f"{wf['name']}: connection from unknown node {source}"
            for output in outputs["main"]:
                for target in output:
                    assert target["node"] in names, f"{wf['name']}: unknown target {target['node']}"

    written = []
    for wf in workflows:
        filename = {
            "RAG 1 - PDF Ingestion": "01_rag_ingest.json",
            "RAG 2 - Question Answering": "02_rag_query.json",
            "RAG 3 - Document Library": "03_rag_documents.json",
            "RAG 4 - Delete Document": "04_rag_delete_document.json",
            "RAG 5 - BTM Ingestion": "05_btm_ingest.json",
        }[wf["name"]]
        path = OUT_DIR / filename
        path.write_text(json.dumps(wf, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        # Round-trip guard: the file must be parseable exactly as written.
        json.loads(path.read_text(encoding="utf-8"))
        written.append(f"  {path.relative_to(ROOT)}  ({len(wf['nodes'])} nodes)")

    print("Wrote n8n workflows:")
    print("\n".join(written))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
