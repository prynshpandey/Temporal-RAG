#!/usr/bin/env python3
"""Create (or inspect) the Qdrant collection used by the Business Time Machine.

    python3 scripts/setup_qdrant.py             # create if missing, verify size
    python3 scripts/setup_qdrant.py --recreate  # drop and rebuild it
    python3 scripts/setup_qdrant.py --legacy    # the pre-Temporal-RAG collection

Creates a Cosine collection sized for the configured embedding model. All three
embedding levels (document, section, chunk) share it, distinguished by the
``embedding_level`` payload field, so the payload indexes below are what retrieval
filters on.
"""

from __future__ import annotations

import argparse
import ast
import pathlib
import sys
import time

from common import GREEN, RED, YELLOW, RESET, bad, info, load_env, ok, request, strip_trailing_slash

BACKEND_QDRANT_SOURCE = (
    pathlib.Path(__file__).resolve().parent.parent / "backend" / "app" / "clients" / "qdrant.py"
)


def _payload_indexes_from_backend() -> list[tuple[str, str]]:
    """Read PAYLOAD_INDEXES out of the backend client without importing it.

    Importing would pull in the app's config and errors, which need the app's
    environment; this script runs standalone on the host. Parsing the assignment
    is enough to keep one source of truth for the list.
    """
    try:
        tree = ast.parse(BACKEND_QDRANT_SOURCE.read_text())
    except (OSError, SyntaxError):
        return []
    for node in tree.body:
        # The assignment is annotated (``PAYLOAD_INDEXES: dict[str, str] = ...``),
        # which makes it an AnnAssign rather than an Assign. Only handling Assign
        # would miss it and quietly fall back to the local list, which is the
        # drift this function exists to remove.
        if isinstance(node, ast.AnnAssign) and getattr(node.target, "id", "") == "PAYLOAD_INDEXES":
            try:
                value = ast.literal_eval(node.value)
            except ValueError:
                return []
            return [(str(k), str(v)) for k, v in value.items()]
        if isinstance(node, ast.Assign) and any(
            getattr(t_, "id", "") == "PAYLOAD_INDEXES" for t_ in node.targets
        ):
            try:
                value = ast.literal_eval(node.value)
            except ValueError:
                return []
            return [(str(k), str(v)) for k, v in value.items()]
    return []

# Every field retrieval filters on, with the schema Qdrant needs. The list lives
# in backend/app/clients/qdrant.py and is read out of that file rather than
# duplicated here, because a hand-copied list drifts: it did, and the drift was
# silent -- the filter gained conditions on fields that had no index, so they
# still worked but scanned the whole collection. The local list below is only a
# fallback for when the backend source is not present.
PAYLOAD_INDEXES = _payload_indexes_from_backend() or [
    ("embedding_level", "keyword"),
    ("document_id", "keyword"),
    ("document_name", "keyword"),
    ("section_id", "keyword"),
    ("chunk_id", "keyword"),
    ("parent_id", "keyword"),
    ("document_type", "keyword"),
    ("source", "keyword"),
    ("temporal_certainty", "keyword"),
    ("entity_names", "keyword"),
    ("page", "integer"),
    ("chunk_index", "integer"),
    ("level", "integer"),
    ("char_count", "integer"),
    ("doc_ts", "datetime"),
    ("event_ts", "datetime"),
    ("request_ts", "datetime"),
    ("valid_from", "datetime"),
    ("valid_until", "datetime"),
]

LEGACY_PAYLOAD_INDEXES = [
    ("document_id", "keyword"),
    ("document_name", "keyword"),
    ("chunk_id", "keyword"),
    ("page", "integer"),
]


def collection_url(config: dict, name: str) -> str:
    return f"{strip_trailing_slash(config['QDRANT_URL'])}/collections/{name}"


def wait_for_qdrant(config: dict, attempts: int = 10) -> bool:
    base = strip_trailing_slash(config["QDRANT_URL"])
    for attempt in range(attempts):
        try:
            status, _ = request("GET", f"{base}/readyz", timeout=5)
            if status == 200:
                return True
        except Exception:
            pass
        time.sleep(1)
    return False


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--recreate", action="store_true", help="delete the collection first")
    parser.add_argument("--collection", default=None, help="override QDRANT_COLLECTION")
    parser.add_argument(
        "--legacy", action="store_true", help="manage the pre-Temporal-RAG collection"
    )
    args = parser.parse_args()

    config = load_env()
    name = args.collection or config["QDRANT_COLLECTION"]
    indexes = LEGACY_PAYLOAD_INDEXES if args.legacy else PAYLOAD_INDEXES
    size = int(config["QDRANT_VECTOR_SIZE"])
    distance = config["QDRANT_DISTANCE"]
    url = collection_url(config, name)

    print(f"Qdrant   : {config['QDRANT_URL']}")
    print(f"Collection: {name}  ({size} dims, {distance})")
    print(f"Model    : {config['EMBEDDING_MODEL']}")

    if not wait_for_qdrant(config):
        print(f"{RED}Qdrant is not reachable at {config['QDRANT_URL']}{RESET}")
        print("Start it with:  docker compose up -d qdrant")
        return 1

    if args.recreate:
        status, _ = request("DELETE", url, timeout=30)
        if status in (200, 404):
            ok(f"dropped collection {name}", f"HTTP {status}")
        else:
            bad(f"could not drop {name}", f"HTTP {status}")
            return 1

    status, body = request("GET", url, timeout=15)
    if status == 200 and isinstance(body, dict) and body.get("result"):
        result = body["result"]
        params = result.get("config", {}).get("params", {})
        vectors = params.get("vectors")
        actual_size = vectors.get("size") if isinstance(vectors, dict) else None
        if actual_size is not None and actual_size != size:
            print(f"{RED}Collection exists with {actual_size} dims but QDRANT_VECTOR_SIZE is {size}.{RESET}")
            print(f"Fix one of the two, then re-run with --recreate:")
            print(f"  * keep the collection: set EMBEDDING_MODEL to the model that produced it")
            print(f"  * keep the model:      python3 scripts/setup_qdrant.py --recreate  (documents must be re-uploaded)")
            return 1
        ok(f"collection exists: {result.get('status')}", f"{result.get('points_count', 0)} points")
    else:
        payload = {"vectors": {"size": size, "distance": distance}}
        status, body = request("PUT", url, body=payload, timeout=30)
        if status not in (200, 201):
            print(f"{RED}could not create the collection (HTTP {status}){RESET}: {body}")
            return 1
        ok(f"created collection {name}", f"{size} dims, {distance}")

    for field, schema in indexes:
        status, _ = request(
            "PUT",
            f"{url}/index?wait=true",
            body={"field_name": field, "field_schema": schema},
            timeout=30,
        )
        if status in (200, 201):
            ok(f"payload index: {field} ({schema})")
        else:
            # An existing index answers 400/409 - that is fine, it is idempotent.
            info(f"payload index {field} already present (HTTP {status})")

    status, body = request("GET", url, timeout=15)
    if isinstance(body, dict) and body.get("result"):
        result = body["result"]
        print(f"\n{GREEN}ready{RESET}: {name} -> {result.get('points_count', 0)} points, "
              f"status={result.get('status')}, indexed={result.get('indexed_vectors_count', 0)}")
    else:
        print(f"{YELLOW}could not read the collection back: {body}{RESET}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
