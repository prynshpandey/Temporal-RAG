#!/usr/bin/env python3
"""Create .env from .env.example with freshly generated secrets.

    make init          # or: python3 scripts/init_env.py [--force]

Nothing is overwritten unless --force is given, and the file is created with
0600 permissions because it holds the n8n encryption key and the DB password.
"""

from __future__ import annotations

import argparse
import pathlib
import re
import secrets
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
EXAMPLE = ROOT / ".env.example"
TARGET = ROOT / ".env"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--force", action="store_true", help="overwrite an existing .env")
    args = parser.parse_args()

    if not EXAMPLE.exists():
        sys.exit(f"missing {EXAMPLE}")
    if TARGET.exists() and not args.force:
        print(f"{TARGET.name} already exists - keeping it (use --force to regenerate).")
        print("Reminder: changing N8N_ENCRYPTION_KEY makes stored n8n credentials unreadable.")
        return 0

    postgres_password = secrets.token_urlsafe(24)
    encryption_key = secrets.token_hex(24)  # 48 characters

    content = EXAMPLE.read_text(encoding="utf-8")
    content = re.sub(r"^POSTGRES_PASSWORD=.*$", f"POSTGRES_PASSWORD={postgres_password}", content, flags=re.M)
    content = re.sub(r"^N8N_ENCRYPTION_KEY=.*$", f"N8N_ENCRYPTION_KEY={encryption_key}", content, flags=re.M)

    TARGET.write_text(content, encoding="utf-8")
    TARGET.chmod(0o600)

    print(f"wrote {TARGET} (mode 600) with a random PostgreSQL password and n8n encryption key")
    print("These values are not recoverable: back up .env somewhere safe.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
