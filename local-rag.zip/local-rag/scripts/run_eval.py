#!/usr/bin/env python3
"""How well does the time machine actually work?

The other test scripts assert that specific things are true. This one measures
how often they are true, because a retrieval system that is 94% temporally
correct is not a time machine - it is a search engine that occasionally lies
about the date, and that failure is invisible per-case.

The dataset is `backend/eval/dataset.json`. Each case is scored on several
dimensions independently, which is the whole point:

  temporal_leakage   did any document dated after the window reach the caller?
                     This is the invariant the product exists to keep, so it
                     must be 1.0. There is no acceptable rate of future data.
  context_recall     was the expected value present in retrieved evidence?
  context_precision  was any *forbidden* value present in retrieved evidence?
                     Recall and precision are separate because a system can
                     score well on one while failing the other, and only one of
                     them is a temporal bug.
  answer_value       did the generated answer contain the expected value?
                     Threshold is below 1.0 on purpose: this measures the
                     model, not the corpus, and a flaky model should not fail
                     the temporal suite.
  abstention         did the system decline when the corpus could not answer?
  state_exact        was the reconstructed document set exactly right?
  compare            were the extracted before/after values right?

`/query` and `/answer` are scored separately, so "the right number was
retrieved but the model said the wrong one" is distinguishable from "a future
number was retrieved". Only the second is a temporal failure.

Run: make seed-corpus && make eval
"""
from __future__ import annotations

import json
import os
import pathlib
import re
import sys
import urllib.parse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from common import CYAN, DIM, GREEN, RED, RESET, YELLOW, bad, info, ok, request  # noqa: E402

ROOT = pathlib.Path(__file__).resolve().parents[1]
API = os.environ.get("API_URL", "http://127.0.0.1:8000").rstrip("/")
DATASET = ROOT / "backend" / "eval" / "dataset.json"
TIMEOUT = int(os.environ.get("EVAL_TIMEOUT", "120"))


def day(value) -> str | None:
    """Normalise a date or datetime to a calendar day string."""
    return str(value)[:10] if value else None


class Tally:
    """Accumulates pass/fail counts per dimension so rates mean something."""

    def __init__(self) -> None:
        self.scores: dict[str, list[int]] = {}
        self.failures: list[tuple[str, str]] = []

    def record(self, dimension: str, passed: bool, case_id: str, detail: str = "") -> None:
        self.scores.setdefault(dimension, []).append(1 if passed else 0)
        if not passed:
            self.failures.append((f"{case_id}:{dimension}", detail))

    def rate(self, dimension: str) -> float | None:
        vals = self.scores.get(dimension)
        return None if not vals else sum(vals) / len(vals)

    def count(self, dimension: str) -> int:
        return len(self.scores.get(dimension, []))


_NUM_TOKEN = re.compile(r"\d{1,3}(?:,\d{3})+(?:\.\d+)?|\d+(?:\.\d+)?")


def has_number(text: str, value) -> bool:
    """Whether a figure equal to `value` appears in the text.

    Compares parsed values, not characters. Every shortcut here has cost a
    false alarm: substring matching calls "36.5 million" a hit for 36, and a
    boundary-anchored pattern calls "47.0 percent" a miss for 47. Both are just
    the same figure written differently, and both read as a temporal fault when
    the document is in fact in scope.
    """
    try:
        target = float(str(value).strip().replace(",", ""))
    except (TypeError, ValueError):
        return str(value).lower() in text.lower()
    for match in _NUM_TOKEN.finditer(text):
        try:
            found = float(match.group(0).replace(",", ""))
        except ValueError:
            continue
        if abs(found - target) < 1e-9:
            return True
    return False


def as_text(payload) -> str:
    """All retrievable text from a /query response, lowercased for matching."""
    if not isinstance(payload, dict):
        return ""
    parts = []
    for hit in payload.get("hits") or []:
        for key in ("text", "parent_text", "document_name", "section_title"):
            value = hit.get(key)
            if value:
                parts.append(str(value))
    return "\n".join(parts).lower()


def hit_documents(payload) -> set[str]:
    if not isinstance(payload, dict):
        return set()
    return {str(h.get("document_name")) for h in (payload.get("hits") or []) if h.get("document_name")}


def hit_dates(payload, as_of: str) -> list[str]:
    """Documents in a response that are dated after the window."""
    late = []
    for hit in (payload.get("hits") or []) if isinstance(payload, dict) else []:
        when = day(hit.get("effective_date"))
        if when and when > as_of:
            late.append(f"{hit.get('document_name')} ({when})")
    return late


def citation_documents(payload) -> list[tuple[str, str | None]]:
    if not isinstance(payload, dict):
        return []
    return [
        (str(c.get("document_name")), day(c.get("effective_date")))
        for c in (payload.get("citations") or [])
        if c.get("document_name")
    ]


# ------------------------------------------------------------------ case types
def score_value(case, tally) -> None:
    as_of = case["as_of"]
    question = case["question"]
    expect = case.get("expect", {})

    status, query = request("POST", f"{API}/api/v1/query",
                            {"question": question, "as_of": as_of}, TIMEOUT)
    if status != 200:
        tally.record("context_recall", False, case["id"], f"/query returned {status}")
        return

    text = as_text(query)
    for value in expect.get("context_contains", []):
        present = has_number(text, value)
        tally.record("context_recall", present, case["id"],
                     "" if present else f"expected {value!r} in retrieved evidence")
    leaked = [v for v in expect.get("context_excludes", []) if has_number(text, v)]
    tally.record("context_precision", not leaked, case["id"],
                 "" if not leaked else f"forbidden value(s) {leaked} present in evidence")

    docs = hit_documents(query)
    wanted = expect.get("source_documents")
    if wanted:
        found = any(any(w in d for d in docs) for w in wanted)
        tally.record("source_document", found, case["id"],
                     "" if found else f"none of {wanted} cited; got {sorted(docs)}")

    # The invariant. Measured on evidence, so a model failure cannot mask it.
    late = hit_dates(query, as_of)
    tally.record("temporal_leakage", not late, case["id"],
                 "" if not late else f"future document(s) in evidence: {late}")

    # Generation quality, scored separately and on a looser threshold.
    status, answer = request("POST", f"{API}/api/v1/answer",
                             {"question": question, "as_of": as_of}, TIMEOUT)
    if status != 200:
        tally.record("answer_value", False, case["id"], f"/answer returned {status}")
        return
    body = str(answer.get("answer", "")).lower()
    missing = [v for v in expect.get("answer_contains", []) if not has_number(body, v)]
    tally.record("answer_value", not missing, case["id"],
                 "" if not missing else f"answer omitted {missing}: {body[:160]!r}")
    bad_answer = [v for v in expect.get("answer_excludes", []) if has_number(body, v)]
    tally.record("answer_precision", not bad_answer, case["id"],
                 "" if not bad_answer else f"forbidden value(s) {bad_answer} in the answer")
    cites = citation_documents(answer)
    late_cites = [f"{n} ({d})" for n, d in cites if d and d > as_of]
    tally.record("answer_leakage", not late_cites, case["id"],
                 "" if not late_cites else f"future document(s) cited: {late_cites}")


def score_abstain(case, tally) -> None:
    expect = case.get("expect", {})
    allowed = set(expect.get("modes", []))
    status, answer = request("POST", f"{API}/api/v1/answer",
                             {"question": case["question"], "as_of": case["as_of"]}, TIMEOUT)
    if status != 200:
        tally.record("abstention", False, case["id"], f"/answer returned {status}")
        return
    mode = answer.get("mode")
    tally.record("abstention", mode in allowed, case["id"],
                 "" if mode in allowed else f"mode {mode!r} not in {sorted(allowed)}")
    if case["as_of"]:
        cites = citation_documents(answer)
        late = [f"{n} ({d})" for n, d in cites if d and d > case["as_of"]]
        tally.record("answer_leakage", not late, case["id"],
                     "" if not late else f"future document(s) cited while abstaining: {late}")


def score_state(case, tally) -> None:
    import urllib.parse

    expect = case.get("expect", {})
    qs = urllib.parse.urlencode({"as_of": case["as_of"]})
    status, state = request("GET", f"{API}/api/v1/state?{qs}", None, TIMEOUT)
    if status != 200:
        tally.record("state_exact", False, case["id"], f"/state returned {status}")
        return
    got = {d.get("name") for d in (state.get("documents") or [])}
    want = set(expect.get("documents", []))
    tally.record("state_exact", got == want, case["id"],
                 "" if got == want else f"expected {sorted(want)}, got {sorted(got)}")
    excluded = sum(len(v) for v in (state.get("excluded") or {}).values() if isinstance(v, list))
    if "excluded_count" in expect:
        tally.record("state_exclusions", excluded == expect["excluded_count"], case["id"],
                     "" if excluded == expect["excluded_count"]
                     else f"expected {expect['excluded_count']} excluded, got {excluded}")
    for reason in expect.get("withheld_reasons", []):
        present = bool((state.get("excluded") or {}).get(reason))
        tally.record("state_reasons", present, case["id"],
                     "" if present else f"no documents withheld as {reason!r}")


def score_compare(case, tally) -> None:
    import urllib.parse

    expect = case.get("expect", {})
    qs = urllib.parse.urlencode({"from": case["from"], "to": case["to"]})
    status, cmp_result = request("GET", f"{API}/api/v1/compare?{qs}", None, TIMEOUT)
    if status != 200:
        tally.record("compare", False, case["id"], f"/compare returned {status}")
        return
    changes = cmp_result.get("changes") or []
    for want in expect.get("changes", []):
        needle = want.get("label_contains", "").lower()
        match = next((c for c in changes if needle in str(c.get("label", "")).lower()), None)
        if not match:
            tally.record("compare", False, case["id"],
                         f"no change matching {needle!r} in {[c.get('label') for c in changes]}")
            continue
        from_v = (match.get("from") or {}).get("value")
        to_v = (match.get("to") or {}).get("value")
        good = from_v == want.get("from") and to_v == want.get("to")
        tally.record("compare", good, case["id"],
                     "" if good else f"{needle}: expected {want.get('from')} -> {want.get('to')}, got {from_v} -> {to_v}")


SCORERS = {
    "value": score_value,
    "abstain": score_abstain,
    "no_context": score_abstain,
    "state": score_state,
    "compare": score_compare,
}

# Dimension -> how it maps onto the threshold table in the dataset.
#
# The asymmetry is deliberate and should not be "tidied up". answer_value sits
# below 1.0 because the model is rate-limited and, when it is, it says so and
# quotes the sources - that is correct behaviour and should not fail a build.
# answer_precision and temporal_leakage are held at exactly 1.0 because no
# amount of model unavailability justifies quoting a figure from a document that
# did not exist yet. Verified by injecting a wrong expectation: it fails the
# run with a non-zero exit.
THRESHOLD_KEY = {
    "temporal_leakage": "temporal_leakage",
    "answer_leakage": "temporal_leakage",
    "context_recall": "context_recall",
    "source_document": "context_recall",
    "context_precision": "context_precision",
    "answer_precision": "context_precision",
    "answer_value": "answer_value",
    "abstention": "abstention",
    "state_exact": "state_exact",
    "state_exclusions": "state_exact",
    "state_reasons": "state_exact",
    "compare": "compare",
}


def main() -> int:
    if not DATASET.exists():
        info(f"missing dataset: {DATASET}")
        return 1
    dataset = json.loads(DATASET.read_text(encoding="utf-8"))
    cases = dataset.get("cases", [])
    thresholds = dataset.get("thresholds", {})
    tally = Tally()

    status, health = request("GET", f"{API}/health", None, 15)
    if status != 200:
        bad("backend not reachable", f"{API} returned {status}")
        info("start the stack with: make up")
        return 1

    info(f"{len(cases)} cases from {DATASET.relative_to(ROOT)}")
    for case in cases:
        scorer = SCORERS.get(case.get("type"))
        if not scorer:
            bad(f"{case['id']}: unknown case type", str(case.get("type")))
            continue
        try:
            scorer(case, tally)
        except Exception as exc:  # one broken case must not hide the rest
            bad(f"{case['id']}: crashed", repr(exc))
            tally.record("harness", False, case["id"], repr(exc))

    # ------------------------------------------------------------- scorecard
    print()
    print(f"{CYAN}scorecard{RESET}")
    dims = sorted(tally.scores)
    for dim in dims:
        rate = tally.rate(dim)
        passed = sum(tally.scores[dim])
        total = len(tally.scores[dim])
        key = THRESHOLD_KEY.get(dim)
        floor = thresholds.get(key)
        mark = " "
        if floor is not None:
            mark = f"{GREEN}ok{RESET}" if rate >= floor else f"{RED}under{RESET}"
        colour = GREEN if (floor is None or rate >= floor) else RED
        print(f"  {dim:<20} {colour}{rate:>5.2f}{RESET}  ({passed}/{total})  {mark}")

    if tally.failures:
        print()
        print(f"{RED}failures{RESET}")
        for label, detail in tally.failures:
            print(f"  {label}")
            if detail:
                print(f"    {DIM}{detail}{RESET}")

    below = []
    for dim in dims:
        key = THRESHOLD_KEY.get(dim)
        if key is None or key not in thresholds:
            continue
        if tally.rate(dim) < thresholds[key]:
            below.append(f"{dim} {tally.rate(dim):.2f} < {thresholds[key]:.2f}")

    print()
    if below:
        bad(f"{len(tally.failures)} failing check(s) across {len(dims)} dimensions", "; ".join(below))
        return 1
    note = "" if all(tally.rate(d) == 1.0 for d in dims) else f" {YELLOW}(some dimensions are model-dependent){RESET}"
    ok(f"evaluation passed{note}", f"{len(cases)} cases, {len(dims)} dimensions")
    return 0


if __name__ == "__main__":
    sys.exit(main())
