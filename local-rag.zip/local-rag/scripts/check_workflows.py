#!/usr/bin/env python3
"""Static checks on the generated n8n workflows.

    python3 scripts/check_workflows.py

Verifies, without a running n8n:
  * the JSON parses, node names are unique, connections point at real nodes
  * every $('Node Name') reference inside a Code node exists in that workflow
  * every $env.KEY used by a Code node / HTTP node is defined in .env.example
  * the system prompt placeholder was substituted
  * every workflow has a Webhook and a Respond to Webhook node
"""

from __future__ import annotations

import json
import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
WORKFLOW_DIR = ROOT / "n8n" / "workflows"
ENV_EXAMPLE = ROOT / ".env.example"

GREEN = "\033[32m"
RED = "\033[31m"
DIM = "\033[2m"
RESET = "\033[0m"

NODE_REFERENCE = re.compile(r"\$\(\s*'([^']+)'\s*\)")
ENV_REFERENCE = re.compile(r"\$env\.([A-Z0-9_]+)")
PLACEHOLDER = "__SYSTEM_PROMPT__"

errors: list[str] = []
warnings: list[str] = []


def env_keys() -> set[str]:
    keys = set()
    for line in ENV_EXAMPLE.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            keys.add(line.split("=", 1)[0].strip())
    return keys


def check_workflow(path: pathlib.Path, known_env: set[str]) -> None:
    rel = path.relative_to(ROOT)
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        errors.append(f"{rel}: invalid JSON ({exc})")
        return

    nodes = data.get("nodes") or []
    names = [n.get("name") for n in nodes]
    duplicates = {name for name in names if names.count(name) > 1}
    if duplicates:
        errors.append(f"{rel}: duplicate node names {sorted(duplicates)}")

    name_set = set(names)
    types = {n.get("type", "") for n in nodes}

    if not any("webhook" in t for t in types):
        errors.append(f"{rel}: no Webhook node")
    if not any("respondToWebhook" in t for t in types):
        errors.append(f"{rel}: no Respond to Webhook node")

    for source, outputs in (data.get("connections") or {}).items():
        if source not in name_set:
            errors.append(f"{rel}: connection from unknown node '{source}'")
        for branch in outputs.get("main", []):
            for target in branch or []:
                if target.get("node") not in name_set:
                    errors.append(f"{rel}: '{source}' connects to unknown node '{target.get('node')}'")

    code_count = 0
    http_count = 0
    used_env: set[str] = set()

    for node in nodes:
        node_type = node.get("type", "")
        source = (node.get("parameters") or {}).get("jsCode")
        if node_type == "n8n-nodes-base.code":
            code_count += 1
            if not (source or "").strip():
                errors.append(f"{rel}: Code node '{node.get('name')}' is empty")
                source = source or ""
            for referenced in NODE_REFERENCE.findall(source):
                if referenced not in name_set:
                    errors.append(
                        f"{rel}: Code node '{node.get('name')}' references $('{referenced}') which is not a node in this workflow"
                    )
            if PLACEHOLDER in source:
                errors.append(f"{rel}: Code node '{node.get('name')}' still contains {PLACEHOLDER}")
            used_env.update(ENV_REFERENCE.findall(source))
        if node_type == "n8n-nodes-base.httpRequest":
            http_count += 1
            url = str((node.get("parameters") or {}).get("url", ""))
            used_env.update(ENV_REFERENCE.findall(url))
            used_env.update(ENV_REFERENCE.findall(str((node.get("parameters") or {}).get("jsonBody", ""))))
            if not url:
                errors.append(f"{rel}: HTTP Request node '{node.get('name')}' has no url")

    missing = sorted(key for key in used_env if key not in known_env)
    if missing:
        errors.append(f"{rel}: $env keys not defined in .env.example: {', '.join(missing)}")

    print(
        f"  {GREEN}PASS{RESET}  {rel}  {DIM}{len(nodes)} nodes, {code_count} code, "
        f"{http_count} http, {len(data.get('connections') or {})} connected{RESET}"
    )


def main() -> int:
    if not ENV_EXAMPLE.exists():
        sys.exit(f"missing {ENV_EXAMPLE}")
    known_env = env_keys()

    files = sorted(WORKFLOW_DIR.glob("*.json"))
    if not files:
        sys.exit(f"no workflows in {WORKFLOW_DIR} - run: make workflows")

    print(f"Checking {len(files)} workflow file(s) against .env.example "
          f"({len(known_env)} keys)\n")
    for path in files:
        check_workflow(path, known_env)

    expected = {
        "RAG 1 - PDF Ingestion",
        "RAG 2 - Question Answering",
        "RAG 3 - Document Library",
        "RAG 4 - Delete Document",
    }
    found = {json.loads(p.read_text(encoding="utf-8")).get("name") for p in files if p.exists()}
    for missing in sorted(expected - found):
        warnings.append(f"expected workflow '{missing}' was not found")

    if warnings:
        print()
        for warning in warnings:
            print(f"  {DIM}note: {warning}{RESET}")

    if errors:
        print()
        for error in errors:
            print(f"  {RED}FAIL{RESET}  {error}")
        print(f"\n{RED}{len(errors)} problem(s) in the workflow definitions{RESET}")
        return 1

    print(f"\n{GREEN}workflow definitions are consistent{RESET}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
