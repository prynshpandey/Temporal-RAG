#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# ONE-TIME host setup for local-rag.  Run it with sudo:
#
#     sudo bash scripts/bootstrap_host.sh
#
# It performs four things and is safe to re-run:
#   1. installs Docker Engine + the Compose v2 plugin (Fedora or Debian/Ubuntu)
#   2. starts the Docker daemon and adds your user to the `docker` group
#   3. rebinds the host Ollama server to 0.0.0.0 so containers can reach it
#   4. opens port 11434 to the Docker bridge network (firewalld only)
# ---------------------------------------------------------------------------
set -euo pipefail

TARGET_USER="${SUDO_USER:-${USER:-root}}"
OLLAMA_PORT=11434
BRIDGE_CIDRS="172.16.0.0/12 10.0.0.0/8"

log()  { printf '\n\033[1;36m==> %s\033[0m\n' "$*"; }
warn() { printf '\033[1;33m[warn]\033[0m %s\n' "$*"; }
die()  { printf '\033[1;31m[error]\033[0m %s\n' "$*" >&2; exit 1; }

[ "$(id -u)" -eq 0 ] || die "run this with sudo: sudo bash scripts/bootstrap_host.sh"

# --- 1. Docker --------------------------------------------------------------
if command -v docker >/dev/null 2>&1 && docker --version >/dev/null 2>&1; then
    log "Docker already installed: $(docker --version)"
else
    . /etc/os-release
    case "${ID:-}" in
        fedora|rhel|centos)
            log "Installing Docker from the Fedora repositories"
            dnf install -y docker-cli moby-engine docker-compose
            ;;
        debian|ubuntu)
            log "Installing Docker CE from download.docker.com"
            install -m 0755 -d /etc/apt/keyrings
            curl -fsSL https://download.docker.com/linux/${ID}/gpg \
                | gpg --dearmor --yes -o /etc/apt/keyrings/docker.gpg
            chmod a+r /etc/apt/keyrings/docker.gpg
            . /etc/os-release
            echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg]" \
                "https://download.docker.com/linux/${ID} ${VERSION_CODENAME} stable" \
                > /etc/apt/sources.list.d/docker.list
            apt-get update -qq
            apt-get install -y docker-ce docker-ce-cli containerd.io \
                docker-buildx-plugin docker-compose-plugin
            ;;
        arch|opensuse*)
            die "no automatic Docker install for ${ID}; install Docker manually, then re-run this script"
            ;;
        *)
            die "unsupported distribution '${ID:-unknown}'; install Docker manually, then re-run this script"
            ;;
    esac
fi

command -v docker >/dev/null 2>&1 || die "docker CLI still not found after installation"

# --- 2. daemon + group ------------------------------------------------------
log "Starting the Docker daemon"
if command -v systemctl >/dev/null 2>&1; then
    systemctl enable --now docker
    systemctl is-active --quiet docker || die "the docker service did not start (journalctl -u docker)"
else
    die "systemd is required to start dockerd"
fi

if id -nG "$TARGET_USER" | tr ' ' '\n' | grep -qx docker; then
    log "User '$TARGET_USER' is already in the docker group"
else
    usermod -aG docker "$TARGET_USER"
    log "Added '$TARGET_USER' to the docker group (takes effect on the next login)"
fi

# --- 3. expose the host Ollama --------------------------------------------
log "Making the host Ollama reachable from containers (OLLAMA_HOST=0.0.0.0:${OLLAMA_PORT})"
if systemctl list-unit-files ollama.service >/dev/null 2>&1 && systemctl cat ollama.service >/dev/null 2>&1; then
    mkdir -p /etc/systemd/system/ollama.service.d
    cat > /etc/systemd/system/ollama.service.d/10-expose.conf <<EOF
# Added by local-rag: allow the n8n container to reach the host Ollama.
[Service]
Environment="OLLAMA_HOST=0.0.0.0:${OLLAMA_PORT}"
EOF
    systemctl daemon-reload
    systemctl restart ollama
    sleep 2
    if curl -fsS "http://127.0.0.1:${OLLAMA_PORT}/api/tags" >/dev/null 2>&1; then
        log "Ollama is back up and listening on 0.0.0.0:${OLLAMA_PORT}"
    else
        warn "Ollama did not answer after the restart - check: journalctl -u ollama"
    fi
else
    warn "no ollama.service found; start Ollama yourself with OLLAMA_HOST=0.0.0.0:${OLLAMA_PORT}"
fi

# --- 4. firewall ------------------------------------------------------------
if systemctl is-active --quiet firewalld 2>/dev/null; then
    log "firewalld is active: allowing ${OLLAMA_PORT} from the container networks"
    for cidr in $BRIDGE_CIDRS; do
        firewall-cmd --permanent --add-rich-rule="rule family=ipv4 source address=${cidr} port port-number=${OLLAMA_PORT} protocol=tcp accept" >/dev/null
    done
    firewall-cmd --reload >/dev/null
else
    log "no active firewall: skipping the port ${OLLAMA_PORT} rule"
fi

log "Host bootstrap complete"
cat <<EOF

Next steps
  1. Log out and back in (or run 'newgrp docker') so the docker group applies.
  2. cd $(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
  3. make init        # create .env with random secrets
  4. make models      # pull llama3.1 and nomic-embed-text
  5. make up          # start postgres, qdrant, n8n, frontend
  6. make import      # import + activate the n8n workflows
  7. make qdrant && make sample && make test
EOF
