#!/usr/bin/env python3
"""Scripted demonstration of the Business Time Machine.

    python3 scripts/demo.py            # against a running stack
    make demo

Five movements, in the order that makes the argument:

  1. a question with a date, answered from what was known then
  2. the same question a year later, answered differently
  3. two guarantees: 2025 knowledge is unreachable from 2024, and a question
     from before any document is declined rather than approximated
  4. a company snapshot with exclusions and their reasons
  5. what changed between two dates, as deltas

Every step is a real API call. Nothing is mocked and nothing is pre-baked, so
the output is a demonstration of the running system rather than a replay. If the
model is unavailable the script still runs: the answer degrades to quoted
passages, which is the system behaving correctly, and the script says so rather
than failing.
"""

from __future__ import annotations

import json
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

BASE = os.environ.get("BTM_BASE_URL", "http://localhost:8000").rstrip("/")

BOLD, DIM, RESET = "\033[1m", "\033[2m", "\033[0m"
GREEN, RED, YELLOW, CYAN = "\033[32m", "\033[31m", "\033[33m", "\033[36m"


def _get(path: str, params: dict[str, str]) -> dict:
    url = f"{BASE}{path}?{urllib.parse.urlencode(params)}"
    with urllib.request.urlopen(url, timeout=60) as response:
        return json.load(response)


def _post(path: str, payload: dict) -> dict:
    request = urllib.request.Request(
        f"{BASE}{path}",
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=180) as response:
        return json.load(response)


def step(number: int, title: str, sub: str) -> None:
    print(f"\n{BOLD}{CYAN}[{number}] {title}{RESET}")
    print(f"{DIM}    {sub}{RESET}")


def say(text: str, indent: str = "    ") -> None:
    print(f"{indent}{text}")


def wrap(text: str, width: int = 88, indent: str = "    ") -> None:
    import textwrap

    for line in textwrap.wrap(text, width=width) or [""]:
        say(line, indent)


def first_line(text: str) -> str:
    for line in str(text).splitlines():
        if line.strip():
            return line.strip()
    return ""


def answer(question: str, as_of: str | None = None, note: str = "") -> dict:
    payload: dict = {"question": question}
    if as_of:
        payload["as_of"] = as_of
    started = time.perf_counter()
    result = _post("/api/v1/answer", payload)
    elapsed = time.perf_counter() - started

    mode = result.get("mode")
    colour = {"generated": GREEN, "extractive": YELLOW, "unsupported": YELLOW}.get(mode, YELLOW)
    say(f"{DIM}mode={colour}{mode}{RESET}  {DIM}{elapsed:.1f}s{RESET}")
    if note:
        say(f"{DIM}{note}{RESET}")
    answer_text = str(result.get("answer", ""))
    if mode == "extractive":
        # Lead with the passages, not the failure notice: a degraded answer is
        # still an answer, and the notice belongs above it, not as the headline.
        passages = " ".join(answer_text.splitlines()[1:]).strip()
        say(f"{YELLOW}{DIM}model unavailable - degraded to verbatim quotes{RESET}")
        wrap(first_line(passages) or first_line(answer_text))
    else:
        wrap(first_line(answer_text))
    citations = [c.get("document_name") for c in (result.get("citations") or [])]
    if citations:
        unique = list(dict.fromkeys(citations))
        say(f"{DIM}cited:{RESET} " + ", ".join(unique))
    return result


def main() -> int:
    print(f"{BOLD}Business Time Machine{RESET}")
    print(f"{DIM}point-in-time question answering over a document corpus{RESET}")
    print(f"{DIM}{BASE}{RESET}")

    # ---------------------------------------------------------------- 1
    step(
        1,
        "A question, pinned to a date",
        "Only knowledge that existed on 2023-12-31 may be used.",
    )
    answer("What was the customer churn rate?", as_of="2023-12-31")

    # ---------------------------------------------------------------- 2
    step(
        2,
        "The same question a year later",
        "Same corpus, same question, different as_of - a different true answer.",
    )
    answer("What was the customer churn rate?", as_of="2024-12-31")
    say("")
    say(f"{DIM}This is the whole point: the answer is a function of when you")
    say(f"ask, not just what you ask. Nothing was re-indexed or edited.{RESET}")

    # ---------------------------------------------------------------- 3
    step(
        3,
        "Knowledge that did not exist yet",
        "Two guarantees, both checked without the model in the loop.",
    )
    # Assert on retrieval, not on the model. /query has no model in the path, so
    # this holds when the quota is spent - and a refusal that depends on the LLM
    # is a request, not a guarantee.
    probe = _post(
        "/api/v1/query", {"question": "customer churn rate 2025", "as_of": "2024-12-31"}
    )
    probe_hits = probe.get("hits") or []
    dates = sorted({str(h.get("effective_date") or "undated") for h in probe_hits})
    say(f"{DIM}reached by a 2025 question, asked as of 2024-12-31:{RESET}")
    say(f"  {', '.join(dates) if dates else 'nothing'}")
    leaked = [d for d in dates if d.startswith("2025")]
    if leaked:
        say("")
        say(f"{RED}FUTURE KNOWLEDGE LEAKED: {', '.join(leaked)}{RESET}")
        say(f"{RED}This is a real defect. Run 'make eval' and read temporal_leakage.{RESET}")
    else:
        say(f"{GREEN}No 2025 source was reachable. The 2025 reports are in the")
        say(f"corpus and were correctly treated as inadmissible.{RESET}")

    say("")
    say(f"{DIM}And a question from before any document existed:{RESET}")
    early = _post(
        "/api/v1/answer", {"question": "What was the customer churn rate?", "as_of": "2023-01-01"}
    )
    if early.get("mode") == "no_context":
        say(f"  {GREEN}{early.get('mode')}{RESET}  {first_line(early.get('answer', ''))}")
        say(f"{DIM}It declines instead of reaching for the nearest available number.{RESET}")
    else:
        say(f"  {YELLOW}{early.get('mode')}{RESET}  {first_line(early.get('answer', ''))}")
        say(f"{YELLOW}Expected no_context here - check 'make eval', dimension abstention.{RESET}")

    # ---------------------------------------------------------------- 4
    step(
        4,
        "A snapshot of the company",
        "What the business looked like on a date, including what was left out.",
    )
    state = _get("/api/v1/state", {"as_of": "2024-12-31"})
    summary = state.get("summary") or {}
    say(
        f"{BOLD}{summary.get('documents_in_scope', '?')} documents in scope{RESET}"
        f"  {DIM}/{summary.get('documents_excluded', '?')} excluded{RESET}"
    )
    say(f"{DIM}evidence spanning {summary.get('oldest_evidence')} to {summary.get('newest_evidence')}{RESET}")
    for document in (state.get("documents") or [])[:5]:
        say(
            f"  {GREEN}in scope{RESET}  {document.get('name', '')[:44]:<44}"
            f" {DIM}{document.get('effective_date', 'undated')}{RESET}"
        )
    excluded = state.get("excluded") or {}
    if isinstance(excluded, dict):
        for reason, items in excluded.items():
            for item in items or []:
                say(
                    f"  {RED}excluded{RESET}  {str(item.get('name'))[:44]:<44}"
                    f" {DIM}{reason} (effective {item.get('effective_date')}){RESET}"
                )
    else:
        for item in excluded:
            say(
                f"  {RED}excluded{RESET}  {str(item.get('name'))[:44]:<44}"
                f" {DIM}{item.get('reason', '')}{RESET}"
            )
    say("")
    say(f"{DIM}Exclusions carry their reason, so a gap in an answer is explainable.{RESET}")

    # ---------------------------------------------------------------- 5
    step(
        5,
        "What changed",
        "Compare two dates and get the deltas, not two summaries.",
    )
    comparison = _get(
        "/api/v1/compare", {"from": "2023-06-30", "to": "2024-12-31"}
    )
    for change in (comparison.get("changes") or [])[:6]:
        say(f"  {GREEN}{change.get('rendered', '')}{RESET}")
    appeared = comparison.get("appeared") or []
    disappeared = comparison.get("disappeared") or []
    say(
        f"{DIM}{len(appeared)} metric(s) appeared, {len(disappeared)} disappeared, "
        f"{len(comparison.get('conflicts') or [])} conflict(s){RESET}"
    )
    if comparison.get("warnings"):
        for warning in comparison["warnings"]:
            say(f"{DIM}  note: {str(warning)[:80]}{RESET}")

    # ----------------------------------------------------------------
    print(f"\n{BOLD}What this demonstrates{RESET}")
    say("Answers depend on when you ask, not only what you ask.")
    say("Knowledge that did not exist yet is unreachable, and provably so.")
    say("Exclusions are reported with reasons, not hidden.")
    say("Changes are computed as deltas between two points in time.")
    print()
    print(f"{DIM}Interactive version: http://127.0.0.1:8080{RESET}")
    print(f"{DIM}  Ask / Library  - the legacy n8n path, unchanged")
    print(f"{DIM}  Time machine   - snapshots, answers and comparison by date")
    print(f"{DIM}Evidence: make eval   - 19 cases, 12 dimensions, currently 1.00{RESET}")
    print()
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except urllib.error.URLError as exc:
        print(f"{RED}cannot reach {BASE}: {exc}{RESET}")
        print(f"{DIM}start the stack first: docker compose up -d{RESET}")
        sys.exit(1)
    except KeyboardInterrupt:
        sys.exit(130)
