#!/usr/bin/env python3
"""Generate sample/sample.pdf - a small, deterministic PDF for testing.

    python3 scripts/make_sample_pdf.py [-o sample/sample.pdf]

Writes a valid PDF (no third-party library needed) containing facts that the
end-to-end test looks for, plus a running header/footer on every page so the
chunker's margin-stripping logic is exercised.
"""

from __future__ import annotations

import argparse
import pathlib
import zlib

ROOT = pathlib.Path(__file__).resolve().parents[1]
DEFAULT_OUT = ROOT / "sample" / "sample.pdf"

HEADER = "HELIOS ROBOTICS - CONFIDENTIAL FY2025"
FOOTER = "Page {page} of {total}"

PAGES = [
    [
        ("Helios Robotics N.V. - Annual Report FY2025", 18, True),
        ("", 11, False),
        ("1. Executive summary", 13, True),
        ("Revenue increased by 18% during FY2025 to 412 million euro.", 11, False),
        ("Operating margin improved to 14.2% compared with 11.8% in FY2024.", 11, False),
        ("The Helios division produced 63% of total group revenue.", 11, False),
        ("Free cash flow reached 57 million euro, the highest level since 2019.", 11, False),
    ],
    [
        ("2. Segments", 13, True),
        ("The Atlas division grew 9% and now contributes 27% of group revenue.", 11, False),
        ("Atlas ships the Corvus platform, which recorded 4,120 unit deliveries in FY2025.", 11, False),
        ("The Helios division remains the largest segment and employs 1,940 people.", 11, False),
        ("The internal project codenamed Lighthouse moved to closed pilot in March 2025.", 11, False),
        ("Lighthouse is scheduled for general availability in the second quarter of FY2026.", 11, False),
    ],
    [
        ("3. People and locations", 13, True),
        ("Helios Robotics was founded in 2011 by Elena Fischer and Rajan Mehta.", 11, False),
        ("The company is headquartered in Rotterdam, the Netherlands.", 11, False),
        ("Additional offices exist in Eindhoven, Leipzig and Austin, Texas.", 11, False),
        ("The number of employees at the end of FY2025 was 3,480.", 11, False),
        ("Research and development spending was 118 million euro, or 28.6% of revenue.", 11, False),
    ],
    [
        ("4. Risk factors", 13, True),
        ("The group depends on a single supplier for the Corvus power module.", 11, False),
        ("Currency movements between the euro and the US dollar affect reported revenue.", 11, False),
        ("The audit committee met 6 times during FY2025.", 11, False),
        ("There were no material post-balance-sheet events to report.", 11, False),
    ],
]


def escape(text: str) -> str:
    return text.replace("\\", r"\\").replace("(", r"\(").replace(")", r"\)")


def content_stream(lines: list[tuple[str, int, bool]], page_number: int, total: int) -> bytes:
    parts = ["BT"]
    y = 780
    for text, size, bold in [(HEADER, 8, False)] + lines + [(FOOTER.format(page=page_number, total=total), 8, False)]:
        parts.append(f"/{'F2' if bold else 'F1'} {size} Tf")
        parts.append(f"1 0 0 1 56 {y} Tm")
        parts.append(f"({escape(text)}) Tj")
        y -= size + 8
        if y < 60:
            y = 780
    parts.append("ET")
    return ("\n".join(parts) + "\n").encode("latin-1", errors="replace")


def build_pdf(pages: list[bytes]) -> bytes:
    """Assemble a minimal but valid PDF 1.4 document with a correct xref table."""
    total = len(pages)
    # Object numbering: 1 catalog, 2 pages, 3 F1, 4 F2, then page/content pairs.
    page_ids = [5 + 2 * i for i in range(total)]
    content_ids = [6 + 2 * i for i in range(total)]

    objects: dict[int, bytes] = {
        1: b"<< /Type /Catalog /Pages 2 0 R >>",
        2: (
            "<< /Type /Pages /Kids ["
            + " ".join(f"{pid} 0 R" for pid in page_ids)
            + f"] /Count {total} >>"
        ).encode(),
        3: b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
        4: b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>",
    }

    for index, stream in enumerate(pages):
        compressed = zlib.compress(stream)
        objects[page_ids[index]] = (
            f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] "
            f"/Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> "
            f"/Contents {content_ids[index]} 0 R >>"
        ).encode()
        objects[content_ids[index]] = (
            f"<< /Length {len(compressed)} /Filter /FlateDecode >>\nstream\n".encode()
            + compressed
            + b"\nendstream"
        )

    out = bytearray(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
    offsets: dict[int, int] = {}
    for number in sorted(objects):
        offsets[number] = len(out)
        out += f"{number} 0 obj\n".encode() + objects[number] + b"\nendobj\n"

    xref_offset = len(out)
    max_id = max(objects)
    out += f"xref\n0 {max_id + 1}\n".encode()
    out += b"0000000000 65535 f \n"
    for number in range(1, max_id + 1):
        out += f"{offsets[number]:010d} 00000 n \n".encode()
    out += (
        f"trailer\n<< /Size {max_id + 1} /Root 1 0 R >>\nstartxref\n{xref_offset}\n%%EOF\n"
    ).encode()
    return bytes(out)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("-o", "--output", default=str(DEFAULT_OUT))
    args = parser.parse_args()

    out_path = pathlib.Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    streams = [content_stream(lines, index + 1, len(PAGES)) for index, lines in enumerate(PAGES)]
    data = build_pdf(streams)
    out_path.write_bytes(data)

    print(f"wrote {out_path} ({len(data)} bytes, {len(PAGES)} pages)")
    print("facts the end-to-end test looks for: '18%', 'Rotterdam', 'Elena Fischer', '3,480', 'Lighthouse'")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
