#!/usr/bin/env bash
# Pull the generation and embedding models the pipeline needs.
#
#   make models       # or: bash scripts/pull_models.sh
#
# Ollama downloads only what is missing, so re-running is cheap.

set -euo pipefail
cd "$(dirname "$0")/.."

if [[ -f .env ]]; then
  set -a
  # shellcheck disable=SC1091
  . ./.env
  set +a
fi

LLM_MODEL="${LLM_MODEL:-llama3.1}"
EMBEDDING_MODEL="${EMBEDDING_MODEL:-nomic-embed-text}"
OLLAMA_BIN="${OLLAMA_BIN:-ollama}"

if ! command -v "$OLLAMA_BIN" >/dev/null 2>&1; then
  echo "error: '$OLLAMA_BIN' is not on PATH." >&2
  echo "       Install Ollama from https://ollama.com/download and enable the systemd service." >&2
  exit 1
fi

if ! "$OLLAMA_BIN" list >/dev/null 2>&1; then
  echo "error: the Ollama server is not answering on ${OLLAMA_URL:-http://localhost:11434}." >&2
  echo "       Start it with:  sudo systemctl start ollama" >&2
  exit 1
fi

pull() {
  local model="$1" role="$2"
  if "$OLLAMA_BIN" list 2>/dev/null | awk 'NR>1 {print $1}' | sed 's/:latest$//' | grep -qx "$model"; then
    echo "  already present: $model ($role)"
  else
    echo "  pulling $model ($role) - this downloads several GB on the first run..."
    "$OLLAMA_BIN" pull "$model"
  fi
}

echo "Ollama models"
pull "$EMBEDDING_MODEL" "embeddings, 768 dims"
pull "$LLM_MODEL" "question answering, 8B on CPU"

echo
echo "Installed models:"
"$OLLAMA_BIN" list
echo
echo "Note: answering on CPU is slow. 1-2 minutes per question is normal for an 8B model;"
echo "      for quick experiments set LLM_MODEL=llama3.2:3b or qwen3:4b in .env."
