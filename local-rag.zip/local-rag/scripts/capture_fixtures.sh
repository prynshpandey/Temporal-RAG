#!/usr/bin/env bash
# Refresh frontend/tests/fixtures from the live backend.
# Fixtures are committed so the renderer test needs no running services.
set -euo pipefail
cd "$(dirname "$0")/.."
API="${API:-http://localhost:8000/api/v1}"
OUT=frontend/tests/fixtures
mkdir -p "$OUT"
curl -sf "$API/state?as_of=2025-12-31" -o "$OUT/state_2025.json"
curl -sf "$API/state?as_of=2023-12-31" -o "$OUT/state_2023.json"
curl -sf "$API/compare?from=2023-12-31&to=2025-12-31" -o "$OUT/compare.json"
curl -sf -X POST "$API/answer" -H 'Content-Type: application/json' \
  -d '{"question":"What was the customer churn rate","as_of":"2024-06-30"}' -o "$OUT/answer.json"
echo "captured 4 fixtures into $OUT"
