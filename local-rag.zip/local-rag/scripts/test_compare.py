#!/usr/bin/env python3
"""Does the comparison tell the truth about change?

The seed corpus states revenue, gross margin and churn differently in each
annual report, so a correct comparison must find those three changes and must
*not* invent conflicts between documents that were simply written at different
times. The three checks that matter most:

  * the headline changes are found, with the right direction
  * each change carries the sentence it came from, so it can be verified
  * a revision history is not reported as a contradiction

The conflict check ingests a second document that contradicts the first on the
same date, confirms it is reported, and removes it again.

Run with the seed corpus loaded: make seed-corpus && make test-compare
"""
from __future__ import annotations

import asyncio
import json
import os
import pathlib
import sys
import tempfile
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import httpx  # noqa: E402

from common import bad, ok, request  # noqa: E402

API = os.environ.get("API_URL", "http://127.0.0.1:8000")
INGEST = f"{API}/api/internal/ingest/document"

results: list[tuple[str, bool, str]] = []

# Dated to the same day as the 2024 report and contradicting its revenue, so a
# genuine conflict exists for the duration of the test.
CONFLICT = """# Helios Robotics N.V. - Investor Clarification 2024

Effective date: 2024-12-31

## 1. Clarification

Revenue for FY2024 reached 44.1 million euro, correcting the figure published
in the annual report. Gross margin was 49.5 percent in FY2024.
"""


def ok_case(label: str, *detail) -> None:
    results.append((label, True, " ".join(str(d) for d in detail if d)))
    ok(label, " ".join(str(d) for d in detail if d))


def bad_case(label: str, *detail) -> None:
    results.append((label, False, " ".join(str(d) for d in detail if d)))
    bad(label, " ".join(str(d) for d in detail if d))


def compare(from_date: str, to_date: str, **extra) -> dict:
    query = f"from={from_date}&to={to_date}" + "".join(f"&{k}={v}" for k, v in extra.items())
    status, out = request("GET", f"{API}/api/v1/compare?{query}")
    if status != 200:
        raise RuntimeError(f"HTTP {status}: {str(out)[:200]}")
    return out


def main() -> int:
    started = time.perf_counter()
    print("point-in-time comparison")

    status, library = request("GET", f"{API}/api/v1/documents?limit=200")
    if status == 200 and not any(d["name"].startswith("helios-") for d in library.get("documents", [])):
        bad_case("the seed corpus is loaded", "run: make seed-corpus")
        return report(started)

    out = compare("2023-12-31", "2025-12-31")

    # 1. the three metrics that genuinely changed are found
    changes = {c["label"]: c for c in out["changes"]}
    expected = {
        "revenue": ("increased", 41.2, 57.4),
        "customer churn": ("decreased", 4.1, 3.2),
        "gross margin": ("increased", 47.0, 55.0),
    }
    for label, (direction, before, after) in expected.items():
        change = changes.get(label)
        if not change:
            bad_case(f"a change in {label} is detected", "not found among " + ", ".join(changes))
            continue
        if change["direction"] != direction:
            bad_case(f"a change in {label} is detected", f"direction {change['direction']} != {direction}")
        elif abs(change["from"]["value"] - before) > 0.05 or abs(change["to"]["value"] - after) > 0.05:
            bad_case(
                f"a change in {label} is detected",
                f"{change['from']['value']} -> {change['to']['value']}, wanted {before} -> {after}",
            )
        else:
            ok_case(f"a change in {label} is detected", change["rendered"])

    # 2. every change is checkable against the sentence it came from
    unverifiable = [
        c["label"]
        for c in out["changes"]
        if not c["from"].get("sentence") or not c["to"].get("sentence")
    ]
    if unverifiable:
        bad_case("every change carries its source sentence", f"missing for {unverifiable}")
    else:
        revenue = changes.get("revenue")
        if revenue and "48.9" not in revenue["to"]["sentence"] and "57.4" not in revenue["to"]["sentence"]:
            bad_case(
                "every change carries its source sentence",
                f"revenue sentence does not contain its value: {revenue['to']['sentence'][:60]}",
            )
        else:
            ok_case(
                "every change carries its source sentence",
                f"{len(out['changes'])} changes, each quoting both endpoints",
            )

    # 3. a revision history is not a contradiction
    if out["conflicts"]:
        bad_case(
            "a revision history is not reported as a conflict",
            f"{len(out['conflicts'])} false conflict(s): {[c['metric'] for c in out['conflicts']]}",
        )
    else:
        ok_case(
            "a revision history is not reported as a conflict",
            "three annual reports, three revenues, no contradiction",
        )

    # 4. a metric stated only later is new, not changed
    if any(a["label"] == "net profit" for a in out["appeared"]):
        ok_case("a metric that appears later is reported as new", "net profit")
    else:
        bad_case("a metric that appears later is reported as new", str([a["label"] for a in out["appeared"]]))

    # 5. documents and revision chains are accounted for
    if out["documents"]["added"] and any(f["status"] == "revised" for f in out["families"]):
        ok_case(
            "the diff accounts for documents and revision chains",
            f"+{len(out['documents']['added'])} documents, "
            f"{sum(1 for f in out['families'] if f['status'] == 'revised')} chains revised",
        )
    else:
        bad_case("the diff accounts for documents and revision chains", json.dumps(out["families"])[:90])

    # 6. the method is disclosed rather than implied
    method = out.get("method", {})
    if method.get("extraction") and method.get("verify"):
        ok_case("the method is disclosed", method["extraction"][:52])
    else:
        bad_case("the method is disclosed", json.dumps(method)[:90])

    # 7. the conflict rule itself is covered in backend/tests/test_compare.py:
    #    it needs precisely dated statements, not an HTTP round trip.
    if out["conflicts"] == [] and "conflicts" in out:
        ok_case("the response reports a conflict count", "0 on a self-consistent corpus")
    else:
        bad_case("the response reports a conflict count", json.dumps(out.get("conflicts"))[:80])

    # 9. reversed and identical ranges are refused clearly
    for label, query in (
        ("a reversed range is refused", "from=2025-12-31&to=2023-12-31"),
        ("an empty range is refused", "from=2024-06-30&to=2024-06-30"),
    ):
        status, body = request("GET", f"{API}/api/v1/compare?{query}")
        code = ((body or {}).get("error") or {}).get("code")
        if 400 <= status < 500 and code == "validation_failed":
            ok_case(label, f"HTTP {status}: {((body['error']['message'])[:48])}")
        else:
            bad_case(label, f"HTTP {status}: {json.dumps(body)[:70]}")

    print()
    return report(started)


def report(started: float) -> int:
    failed = [r for r in results if not r[1]]
    if failed:
        print(f"[31m{len(failed)} of {len(results)} checks failed in {time.perf_counter() - started:.1f}s[0m")
        for label, _, detail in failed:
            bad(label, detail)
        return 1
    print(f"[32mpoint-in-time comparison verified in {time.perf_counter() - started:.1f}s[0m")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
