#!/usr/bin/env python3
"""Shared helpers: .env loading, HTTP with JSON, small pretty printers.

Standard library only - the project must run without installing anything on
the host.
"""

from __future__ import annotations

import json
import os
import pathlib
import urllib.error
import urllib.request

ROOT = pathlib.Path(__file__).resolve().parents[1]
ENV_FILE = ROOT / ".env"

DEFAULT_CONFIG = {
    "QDRANT_URL": "http://localhost:6333",
    "QDRANT_COLLECTION": "btm_vectors",
    "QDRANT_VECTOR_SIZE": "768",
    "QDRANT_DISTANCE": "Cosine",
    "OLLAMA_URL": "http://localhost:11434",
    "LLM_MODEL": "llama3.1",
    "EMBEDDING_MODEL": "nomic-embed-text",
    "N8N_PORT": "5678",
    "BACKEND_PORT": "8000",
    "POSTGRES_HOST": "127.0.0.1",
    "POSTGRES_PORT": "5432",
    "POSTGRES_DB": "n8n",
    "POSTGRES_USER": "n8n",
    "FRONTEND_PORT": "8080",
    "MIN_SCORE": "0.25",
    "TOP_K": "8",
    "MAX_UPLOAD_MB": "100",
    "MAX_UPLOAD_SIZE_MB": "100",
}

GREEN = "\033[32m"
RED = "\033[31m"
YELLOW = "\033[33m"
CYAN = "\033[36m"
DIM = "\033[2m"
RESET = "\033[0m"


def load_env(path: pathlib.Path = ENV_FILE) -> dict[str, str]:
    """Read .env into a dict (missing file or key is not an error)."""
    config = dict(DEFAULT_CONFIG)
    if not path.exists():
        return config
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
            value = value[1:-1]
        config[key.strip()] = value
    return config


def strip_trailing_slash(url: str) -> str:
    return url.rstrip("/")


def request(
    method: str,
    url: str,
    body: dict | None = None,
    timeout: int = 60,
    headers: dict[str, str] | None = None,
    content_type: str | None = None,
    data: bytes | None = None,
) -> tuple[int, object]:
    """Return (status, parsed_body). Raises urllib errors for connection issues.

    `body` is JSON encoded. Pass `data` + `content_type` for anything else
    (multipart uploads, text/plain JSON).
    """
    all_headers = dict(headers or {})
    if body is not None:
        data = json.dumps(body).encode("utf-8")
        all_headers.setdefault("Content-Type", "application/json")
    if content_type:
        all_headers["Content-Type"] = content_type
    req = urllib.request.Request(url, data=data, method=method, headers=all_headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            raw = response.read().decode("utf-8", errors="replace")
            status = response.status
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8", errors="replace")
        status = exc.code
    try:
        return status, json.loads(raw) if raw.strip() else {}
    except json.JSONDecodeError:
        return status, raw


def multipart_body(field_name: str, file_bytes: bytes, file_name: str, extra: dict[str, str] | None = None) -> tuple[bytes, str]:
    """Build a multipart/form-data body without third-party libraries."""
    boundary = "----localragboundary" + os.urandom(8).hex()
    parts: list[bytes] = []
    for key, value in (extra or {}).items():
        parts.append(f"--{boundary}\r\n".encode())
        parts.append(f'Content-Disposition: form-data; name="{key}"\r\n\r\n'.encode())
        parts.append(f"{value}\r\n".encode())
    parts.append(f"--{boundary}\r\n".encode())
    parts.append(
        f'Content-Disposition: form-data; name="{field_name}"; filename="{file_name}"\r\n'.encode()
    )
    parts.append(b"Content-Type: application/pdf\r\n\r\n")
    parts.append(file_bytes)
    parts.append(b"\r\n")
    parts.append(f"--{boundary}--\r\n".encode())
    return b"".join(parts), f"multipart/form-data; boundary={boundary}"


def ok(label: str, detail: str = "") -> None:
    print(f"  {GREEN}PASS{RESET}  {label}" + (f"  {DIM}{detail}{RESET}" if detail else ""))


def bad(label: str, detail: str = "") -> None:
    print(f"  {RED}FAIL{RESET}  {label}" + (f"  {detail}" if detail else ""))


def info(message: str) -> None:
    print(f"  {CYAN}..{RESET}    {message}")


def warn(message: str) -> None:
    print(f"  {YELLOW}warn{RESET}  {message}")


def compose(*args: str) -> list[str]:
    """``docker compose`` invocation with the project's env file.

    Scripts that need the database or the containers use this instead of talking
    to ports directly, so they keep working when a service is not published.
    """
    return ["docker", "compose", "--env-file", str(ENV_FILE), *args]


def docker_env() -> dict[str, str]:
    env = dict(os.environ)
    env.setdefault("COMPOSE_PROJECT_NAME", "local-rag")
    return env
