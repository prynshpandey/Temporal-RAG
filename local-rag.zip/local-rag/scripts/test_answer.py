#!/usr/bin/env python3
"""Does the answer layer stay honest?

The generated text is not asserted word for word - that would test the model's
mood, not the system. What is asserted is every property the caller relies on,
and all of them hold in all four modes (generated, extractive, unsupported,
no_context):

  * a citation always points at a document that was actually retrieved
  * a document dated after the window can never be cited, in any mode
  * the expected value is present when the corpus supports it
  * a question with nothing in scope abstains rather than inventing
  * an answer that cites nothing is not presented as an answer

Run with the seed corpus loaded: make seed-corpus && make test-answer
"""
from __future__ import annotations

import json
import os
import pathlib
import re
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from common import bad, info, ok, request  # noqa: E402

API = os.environ.get("API_URL", "http://127.0.0.1:8000")

FY2023 = "helios-annual-report-2023.md"
FY2024 = "helios-annual-report-2024.md"
Q1_2025 = "helios-q1-2025-update.md"
FY2025 = "helios-annual-report-2025.md"

VALID_MODES = {"generated", "extractive", "unsupported", "no_context"}
MARKER = re.compile(r"\[(\d+)\]")

results: list[tuple[str, bool, str]] = []


def _text(*parts: str) -> str:
    return " ".join(str(p) for p in parts if p is not None)


def ok_case(label: str, *detail) -> None:
    results.append((label, True, _text(detail)))
    ok(label, _text(detail))


def bad_case(label: str, *detail) -> None:
    results.append((label, False, _text(detail)))
    bad(label, _text(detail))


def ask(question: str, **kwargs) -> dict:
    payload = {"question": question, "limit": 6}
    payload.update(kwargs)
    status, out = request(
        "POST",
        f"{API}/api/v1/answer",
        data=json.dumps(payload).encode(),
        content_type="application/json",
        timeout=900,
    )
    if status != 200:
        raise RuntimeError(f"HTTP {status}: {str(out)[:200]}")
    return out


def check_common(label: str, out: dict, *, forbidden: list[str], expect_value: str | None) -> None:
    """The invariants that must hold whatever mode the request landed in."""
    mode = out.get("mode")
    if mode not in VALID_MODES:
        bad_case(label, f"unknown mode {mode!r}")
        return

    answer_text = out.get("answer") or ""
    citations = out.get("citations") or []

    # 1. every citation is a real, retrieved chunk
    for citation in citations:
        if not citation.get("chunk_id") or not citation.get("document_name"):
            bad_case(label, f"citation {citation.get('number')} is missing its source")
            return

    # 2. nothing dated after the window may be cited
    window = out.get("as_of")
    cited = {c["document_name"] for c in citations}
    leaked = sorted(cited & set(forbidden))
    if leaked:
        bad_case(label, f"cited out-of-window {leaked} for as_of={window}")
        return

    # 3. inline markers all resolve to a citation
    numbers = {c["number"] for c in citations}
    dangling = [m for m in MARKER.findall(answer_text) if int(m) not in numbers]
    if dangling:
        bad_case(label, f"answer cites {sorted(set(dangling))} with no citation entry")
        return

    # 4. a rejected citation is never rendered as a source
    if out.get("rejected_citations") and not citations:
        bad_case(label, "rejected citations but nothing valid")
        return

    # 5. the value the corpus supports is present
    if expect_value and expect_value.lower() not in answer_text.lower():
        bad_case(label, f"expected {expect_value!r} in the answer (mode={mode})")
        return

    # 6. an uncited answer is not dressed up as an answer
    if mode == "generated" and not citations:
        bad_case(label, "generated answer with no citation")
        return

    ok_case(
        label,
        f"mode={mode}",
        f"citations={len(citations)}",
        f"docs={sorted(n[:26] for n in cited)}",
        f"llm={(out.get('llm') or {}).get('provider')}",
    )


def main() -> int:
    started = time.perf_counter()
    print("answer synthesis")

    status, library = request("GET", f"{API}/api/v1/documents?limit=200")
    if status == 200 and not any(d["name"].startswith("helios-") for d in library.get("documents", [])):
        bad_case("the seed corpus is loaded", "run: make seed-corpus")
        return report(started)

    # 1. a normal question, answered from the 2024 report only
    out = ask("What was revenue in 2024?", as_of="2024-12-31")
    check_common(
        "revenue for 2024 is answered from in-scope documents",
        out,
        forbidden=[Q1_2025, FY2025],
        expect_value="48.9",
    )

    # 2. a question about a year the window predates
    out = ask("What was revenue in 2025?", as_of="2023-12-31")
    cited = {c["document_name"] for c in out.get("citations", [])}
    if out.get("mode") == "no_context":
        ok_case("a question about the future abstains in a past window", out["answer"][:70])
    else:
        check_common(
            "a question about the future never cites the future report",
            out,
            forbidden=[Q1_2025, FY2025],
            expect_value=None,
        )

    # 3. the answer moves with the as-of date
    older = ask("What was customer churn?", as_of="2024-12-31")
    newer = ask("What was customer churn?", as_of="2025-12-31")
    if older.get("mode") == "no_context" or newer.get("mode") == "no_context":
        bad_case("both churn questions have context", "one abstained unexpectedly")
    else:
        old_has_36 = "3.6" in (older.get("answer") or "")
        new_has_32 = "3.2" in (newer.get("answer") or "")
        if newer.get("mode") == "generated" and older.get("mode") == "generated":
            if not (old_has_36 and new_has_32):
                bad_case(
                    "churn reflects the date it was asked for",
                    f"2024:{old_has_36} (3.6%) 2025:{new_has_32} (3.2%)",
                )
            else:
                ok_case("churn reflects the date it was asked for", "2024 -> 3.6%, 2025 -> 3.2%")
        else:
            # In a quoting mode the values come straight from passages, so the
            # check is simply that the two windows returned different documents.
            old_docs = {c["document_name"] for c in older.get("citations", [])}
            new_docs = {c["document_name"] for c in newer.get("citations", [])}
            (ok_case if old_docs != new_docs else bad_case)(
                "churn draws on different documents in different windows",
                f"2024:{sorted(d[:24] for d in old_docs)}",
                f"2025:{sorted(d[:24] for d in new_docs)}",
            )

    # 4. nothing in scope at all
    out = ask("What was the Rotterdam office seating plan?", as_of="2019-01-01")
    if out.get("mode") == "no_context":
        ok_case("a window with no documents abstains", out["answer"][:80])
    else:
        cited = {c["document_name"] for c in out.get("citations", [])}
        if cited:
            bad_case("a window with no documents cites nothing", f"cited {sorted(cited)}")
        else:
            ok_case("a window with no documents cites nothing", f"mode={out.get('mode')}")

    # 5. the response is auditable
    out = ask("Who founded Helios Robotics?")
    body = out.get("filters", {})
    if body.get("as_of") and body.get("source"):
        ok_case("the response echoes the window it used", f"{body.get('source')} as_of={body.get('as_of')}")
    else:
        bad_case("the response echoes the window it used", json.dumps(body)[:100])
    (ok_case if isinstance(out.get("stats"), dict) else bad_case)(
        "the response reports retrieval provenance",
        json.dumps(out.get("stats"))[:90],
    )
    (ok_case if isinstance(out.get("llm"), dict) else bad_case)(
        "the response reports which model answered, or that none did",
        json.dumps(out.get("llm"))[:90],
    )

    print()
    return report(started)


def report(started: float) -> int:
    failed = [r for r in results if not r[1]]
    if failed:
        print(f"[31m{len(failed)} of {len(results)} checks failed in {time.perf_counter() - started:.1f}s[0m")
        for label, _, detail in failed:
            bad(label, detail)
        return 1
    print(f"[32manswer synthesis verified in {time.perf_counter() - started:.1f}s[0m")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
