#!/usr/bin/env python3
"""Import documents into the Business Time Machine.

    python3 scripts/import_docs.py demo_docs/synthetic/nimbus-annual-2023.md
    python3 scripts/import_docs.py demo_docs/real/*.htm
    python3 scripts/import_docs.py --list demo_docs

Prints what was indexed and the effective date the system derived, because a
document with no date is the most common reason a temporal query looks wrong:
everything in it falls back to its ingest time, so it only ever answers
"as of today".
"""

from __future__ import annotations

import json
import mimetypes
import os
import sys
import time
import urllib.error
import urllib.request
import uuid
from pathlib import Path

N8N = os.environ.get("BTM_N8N_URL", "http://localhost:5678").rstrip("/")
BASE = os.environ.get("BTM_BASE_URL", "http://localhost:8000").rstrip("/")
INGEST = f"{N8N}/webhook/btm/ingest"

GREEN, RED, YELLOW, DIM, BOLD, RESET = (
    "\033[32m",
    "\033[31m",
    "\033[33m",
    "\033[2m",
    "\033[1m",
    "\033[0m",
)

# The parser reads the extension, and some of these types have no useful system
# mapping on a bare Linux host, so name them explicitly.
EXTRA_TYPES = {
    ".md": "text/markdown",
    ".markdown": "text/markdown",
    ".htm": "text/html",
    ".csv": "text/csv",
}


def mime_for(path: Path) -> str:
    return EXTRA_TYPES.get(path.suffix.lower()) or (
        mimetypes.guess_type(path.name)[0] or "application/octet-stream"
    )


def boundary() -> str:
    return f"----btm{uuid.uuid4().hex}"


def build_body(path: Path, sha: str) -> tuple[bytes, str]:
    bar = boundary()
    mime = mime_for(path)
    parts = [
        f"--{bar}\r\n".encode(),
        b'Content-Disposition: form-data; name="data"; filename="',
        path.name.encode(),
        b'"\r\n',
        f"Content-Type: {mime}\r\n\r\n".encode(),
        path.read_bytes(),
        f"\r\n--{bar}\r\n".encode(),
        b'Content-Disposition: form-data; name="sha256"\r\n\r\n',
        sha.encode(),
        f"\r\n--{bar}--\r\n".encode(),
    ]
    return b"".join(parts), f"multipart/form-data; boundary={bar}"


def ingest(path: Path) -> tuple[bool, str]:
    import hashlib

    data = path.read_bytes()
    body, content_type = build_body(path, hashlib.sha256(data).hexdigest())
    request = urllib.request.Request(
        INGEST, data=body, headers={"Content-Type": content_type}, method="POST"
    )
    try:
        with urllib.request.urlopen(request, timeout=900) as response:
            payload = json.loads(response.read() or b"{}")
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", "replace")[:200]
        return False, f"HTTP {exc.code} {detail}"
    except Exception as exc:  # noqa: BLE001 - report anything, do not crash the batch
        return False, str(exc)[:200]

    # Return the parsed payload, not a truncated dump: effective_date sits past
    # the 160th character, so a short summary made every document look undated.
    if payload.get("status") == "indexed" or payload.get("ok"):
        return True, payload
    return False, json.dumps(payload)[:200]


def effective_of(payload: object) -> str:
    if not isinstance(payload, dict):
        return ""
    data = payload
    for key in ("effective_date", "document_date"):
        value = data.get(key)
        if value:
            return str(value)
    extracted = data.get("extracted") or {}
    for key in ("effective_date", "document_date"):
        if extracted.get(key):
            return str(extracted[key])
    return ""


def main(argv: list[str]) -> int:
    args = [a for a in argv[1:] if a != "--list"]
    listing = "--list" in argv

    if "--delete" in argv:
        args = [a for a in argv[1:] if a != "--delete"]
        if not args:
            print(f"usage: {argv[0]} --delete <name-substring> [...]")
            return 2
        import subprocess

        for needle in args:
            rows = subprocess.run(
                [
                    "sg", "docker", "-c",
                    "docker compose exec -T postgres psql -U btm -d business_time_machine "
                    f"-tAc \"select document_id from documents where name ilike '%{needle}%'\"",
                ],
                capture_output=True, text=True,
            ).stdout.split()
            if not rows:
                print(f"  {YELLOW}no match{RESET}  {needle}")
                continue
            for document_id in rows:
                import urllib.request as u

                request = u.Request(f"{BASE}/api/v1/documents/{document_id}", method="DELETE")
                try:
                    with u.urlopen(request, timeout=120) as response:
                        print(f"  {GREEN}deleted{RESET}  {document_id}  {needle}")
                except Exception as exc:  # noqa: BLE001
                    print(f"  {RED}failed{RESET}   {document_id}  {exc}")
        return 0

    if listing:
        root = Path(args[0]) if args else Path("demo_docs")
        print(f"{BOLD}Files under {root}{RESET}")
        for path in sorted(Path(root).rglob("*")):
            if path.is_file():
                print(f"  {path.stat().st_size:>10,}  {path}")
        return 0

    if not args:
        print(f"usage: {argv[0]} <file|directory> [...]")
        print(f"       {argv[0]} --list [dir]")
        print(f"       {argv[0]} --delete <name-substring> [...]")
        return 2

    paths: list[Path] = []
    for arg in args:
        candidate = Path(arg)
        if candidate.is_dir():
            paths.extend(
                sorted(p for p in candidate.rglob("*") if p.is_file() and not p.name.startswith("."))
            )
        elif candidate.is_file():
            paths.append(candidate)
        else:
            print(f"{RED}  no such file: {arg}{RESET}")

    if not paths:
        print(f"{RED}nothing to import{RESET}")
        return 1

    print(f"{BOLD}Importing {len(paths)} document(s) into {INGEST}{RESET}\n")
    failures = 0
    undated = 0
    for path in paths:
        size = path.stat().st_size
        started = time.perf_counter()
        ok, detail = ingest(path)
        elapsed = time.perf_counter() - started
        if not ok:
            failures += 1
            print(f"{RED}FAIL{RESET}  {path.name:34} {DIM}{size:>10,}B  {elapsed:5.1f}s{RESET}")
            print(f"      {RED}{detail}{RESET}")
            continue
        effective = effective_of(detail if ok else None)
        flag = f"{GREEN}effective {effective}{RESET}" if effective else f"{YELLOW}UNDATED{RESET}"
        if not effective:
            undated += 1
        print(f"{GREEN}ok{RESET}    {path.name:34} {DIM}{size:>10,}B  {elapsed:5.1f}s{RESET}  {flag}")

    print()
    print(f"{GREEN}{len(paths) - failures} indexed{RESET}", end="")
    if failures:
        print(f", {RED}{failures} failed{RESET}", end="")
    if undated:
        print(f", {YELLOW}{undated} with no date{RESET}", end="")
    print()
    if undated:
        print(
            f"{YELLOW}An undated document only ever answers 'as of today' - it falls back"
            f"\nto its ingest time. Give it a date in the text, or pass one explicitly.{RESET}"
        )
    return 1 if failures else 0


if __name__ == "__main__":
    try:
        sys.exit(main(sys.argv))
    except KeyboardInterrupt:
        sys.exit(130)
