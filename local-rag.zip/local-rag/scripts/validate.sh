#!/usr/bin/env bash
# Offline validation: no Docker, no n8n, no Ollama required.
#
#   make validate     # or: bash scripts/validate.sh
#
# Parses every JSON file, syntax-checks the JavaScript, Python and shell,
# and cross-checks the workflow wiring against .env.example.

set -uo pipefail
cd "$(dirname "$0")/.."

GREEN=$'\033[32m'; RED=$'\033[31m'; YELLOW=$'\033[33m'; DIM=$'\033[2m'; CYAN=$'\033[36m'; RESET=$'\033[0m'
failures=0

section() { printf '\n%s--- %s%s\n' "$CYAN" "$1" "$RESET"; }
pass()    { printf '  %sPASS%s  %s %s%s\n' "$GREEN" "$RESET" "$1" "${2:+  $DIM$2$RESET}"; }
fail()    { printf '  %sFAIL%s  %s %s\n' "$RED" "$RESET" "$1" "$2"; failures=$((failures + 1)); }
warn()    { printf '  %swarn%s  %s\n' "$YELLOW" "$RESET" "$1"; }

# --------------------------------------------------------------- required files
section "project files"
required=(
  .env.example .gitignore docker-compose.yml Makefile
  nginx/default.conf.template prompts/system_prompt.txt
  frontend/index.html frontend/style.css frontend/app.js frontend/config.js
  scripts/build_workflows.py scripts/check_workflows.py scripts/common.py
  scripts/init_env.py scripts/setup_qdrant.py scripts/healthcheck.py
  scripts/make_sample_pdf.py scripts/test_pipeline.py
  scripts/bootstrap_host.sh scripts/pull_models.sh scripts/import_workflows.sh
  n8n/code/01_validate_upload.js n8n/code/01_validate_text.js n8n/code/01_chunk.js
  n8n/code/01_build_embed_batch.js n8n/code/01_normalize_embeddings.js
  n8n/code/01_load_chunks.js
  n8n/code/01_collect_points.js n8n/code/01_ingest_summary.js
  n8n/code/02_query_config.js n8n/code/02_normalize_query_embedding.js
  n8n/code/02_build_context.js n8n/code/02_build_prompt.js
  n8n/code/02_assemble_answer.js n8n/code/03_aggregate_documents.js
  n8n/code/03_delete_document_summary.js
)
for file in "${required[@]}"; do
  if [[ -s "$file" ]]; then pass "$file"; else fail "$file" "missing or empty"; fi
done

# ------------------------------------------------------------------------ json
section "JSON syntax"
shopt -s nullglob
for file in n8n/workflows/*.json ./*.json frontend/*.json; do
  if python3 -m json.tool "$file" >/dev/null 2>&1; then
    pass "$file"
  else
    fail "$file" "invalid JSON"
  fi
done
shopt -u nullglob

# -------------------------------------------------------------- compose sanity
section "docker-compose.yml"
compose_out="$(python3 - <<'PY' 2>&1
import pathlib
import sys

try:
    import yaml
except ModuleNotFoundError:
    print("PyYAML not installed - structural compose check skipped")
    sys.exit(0)

text = pathlib.Path("docker-compose.yml").read_text(encoding="utf-8")
data = yaml.safe_load(text)
services = data.get("services") or {}
required = {"postgres", "qdrant", "n8n", "frontend"}
missing = sorted(required - set(services))
if missing:
    print("missing services: " + ", ".join(missing))
    sys.exit(1)
for name in sorted(services):
    service = services[name]
    if "image" not in service:
        print(f"service {name} has no image")
        sys.exit(1)
    if name == "n8n":
        env = service.get("environment") or {}
        if env.get("DB_TYPE") != "postgresdb":
            print("n8n must use DB_TYPE=postgresdb")
            sys.exit(1)
        if "host.docker.internal:host-gateway" not in (service.get("extra_hosts") or []):
            print("n8n is missing extra_hosts host.docker.internal:host-gateway")
            sys.exit(1)
        if str(env.get("N8N_BLOCK_ENV_ACCESS_IN_NODE", "")).lower() != "false":
            print("n8n 2.x blocks $env; set N8N_BLOCK_ENV_ACCESS_IN_NODE=false")
            sys.exit(1)
        if str(env.get("N8N_DEFAULT_BINARY_DATA_MODE", "")).lower() != "filesystem":
            print("N8N_DEFAULT_BINARY_DATA_MODE must stay filesystem")
            sys.exit(1)
    for port in service.get("ports") or []:
        mapping = port if isinstance(port, str) else f"{port.get('published', '')}:{port.get('target', '')}"
        if not mapping.startswith("127.0.0.1:"):
            print(f"service {name} publishes {mapping} on all interfaces; the webhooks have no auth")
            sys.exit(1)
    volumes = list(service.get("volumes") or [])
    for volume in volumes:
        if not isinstance(volume, str):
            continue
        parts = volume.split(":")
        if len(parts) < 2:
            continue
        # only bind mounts (relative or absolute host paths) need an SELinux relabel;
        # named volumes are managed by Docker and are already labelled
        if not parts[0].startswith((".", "/", "~")):
            continue
        flags = parts[2].split(",") if len(parts) > 2 else []
        if not {"z", "Z"} & set(flags):
            print(f"service {name} bind-mounts {volume} without :z (SELinux denies unlabeled host paths)")
            sys.exit(1)
print("services: " + ", ".join(sorted(services)))
PY
)"
if [[ $? -eq 0 ]]; then pass "compose structure" "$compose_out"; else fail "compose structure" "$compose_out"; fi

# --------------------------------------------------------------------- nginx
section "nginx/default.conf.template"
if [[ -f nginx/default.conf.template ]] && grep -q "client_max_body_size \${MAX_UPLOAD_SIZE_MB}m" nginx/default.conf.template; then
  pass "client_max_body_size follows MAX_UPLOAD_SIZE_MB"
else
  fail "client_max_body_size not templated" "uploads above one layer's limit are rejected silently"
fi
if grep -q "proxy_pass http://backend:8000" nginx/default.conf.template; then
  pass "nginx proxies /api to the backend service"
else
  fail "missing /api proxy" "the browser UI cannot reach the backend"
fi

# ------------------------------------------------------------------ javascript
section "Code node JavaScript"
if command -v node >/dev/null 2>&1; then
  pass "node available" "$(node --version)"
  # n8n runs Code node sources inside an async function, so top-level await and
  # return are valid there. The sources are wrapped the same way before being
  # checked, otherwise `node --check` would reject them as CommonJS scripts.
  wrapped="$(mktemp -t local-rag-code-XXXXXX.js)"
  trap 'rm -f "$wrapped"' EXIT
  for file in n8n/code/*.js; do
    { printf 'async function __code_node__() {\n'; cat "$file"; printf '\n}\n'; } >"$wrapped"
    if node --check "$wrapped" >/dev/null 2>&1; then pass "$file"; else fail "$file" "$(node --check "$wrapped" 2>&1 | head -n 3)"; fi
  done
  rm -f "$wrapped"
  trap - EXIT
else
  warn "node is not installed - JavaScript Code nodes were not syntax-checked"
fi

# --------------------------------------------------------------------- python
section "Python scripts"
for file in scripts/*.py; do
  if python3 -m py_compile "$file" 2>/dev/null; then pass "$file"; else fail "$file" "$(python3 -m py_compile "$file" 2>&1 | head -n 3)"; fi
done

# ----------------------------------------------------------------------- shell
section "shell scripts"
for file in scripts/*.sh; do
  if bash -n "$file" 2>/dev/null; then pass "$file"; else fail "$file" "$(bash -n "$file" 2>&1 | head -n 3)"; fi
done

# ------------------------------------------------------------------ workflows
section "workflow wiring"
if python3 scripts/build_workflows.py >/dev/null 2>&1; then
  pass "build_workflows.py regenerated all workflows"
  if python3 scripts/check_workflows.py; then
    pass "workflow cross-references, env keys and placeholders"
  else
    fail "check_workflows.py" "see the report above"
  fi
else
  fail "build_workflows.py" "$(python3 scripts/build_workflows.py 2>&1 | tail -n 3)"
fi

# ----------------------------------------------------------------- env secrets
section ".env"
if [[ -f .env ]]; then
  pass ".env exists"
  if grep -qE '^POSTGRES_PASSWORD=change_me_postgres_password' .env; then
    fail "POSTGRES_PASSWORD still the example value" "run: make init --force"
  else
    pass "POSTGRES_PASSWORD was randomised"
  fi
  if grep -qE '^N8N_ENCRYPTION_KEY=change_me' .env; then
    fail "N8N_ENCRYPTION_KEY still the example value" "run: make init --force"
  else
    pass "N8N_ENCRYPTION_KEY was randomised"
  fi
  mode="$(stat -c '%a' .env)"
  if [[ "$mode" == "600" ]]; then pass ".env permissions 600"; else warn ".env permissions are $mode, expected 600"; fi
else
  warn ".env not created yet - run: make init"
fi

if grep -q '^\.env$' .gitignore; then pass ".env is git-ignored"; else fail ".env is missing from .gitignore"; fi

# -------------------------------------------------------------------- frontend
section "frontend wiring"
if [[ -f frontend/app.js ]] && grep -q 'CONFIG.ingestPath' frontend/app.js && [[ -f frontend/config.js ]]; then
  pass "app.js reads its endpoints from config.js"
else
  fail "frontend/config.js wiring" "app.js must use the CONFIG values"
fi
if grep -rq "crypto.subtle" frontend/app.js; then
  pass "document_id is hashed in the browser (sha256)"
else
  fail "sha256 hashing" "app.js must hash the file with crypto.subtle"
fi

echo
if (( failures )); then
  printf '%s%d validation failure(s)%s\n\n' "$RED" "$failures" "$RESET"
  exit 1
fi
printf '%svalidation passed%s\n' "$GREEN" "$RESET"
