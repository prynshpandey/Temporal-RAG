#!/usr/bin/env bash
# Build the workflow JSON, import it into n8n and publish (activate) it.
#
#   make import       # or: bash scripts/import_workflows.sh
#
# Importing is idempotent: workflows are matched on their stable node ids, so
# re-running updates the existing workflows instead of creating duplicates.
#
# n8n versions differ in how a workflow is activated:
#   * 2.x  : `n8n publish:workflow --id=…` (drafts vs published versions)
#   * 1.x  : `n8n update:workflow --id=… --active=true`
#   * 0.x  : neither; the flag is flipped in PostgreSQL
# Whichever works, n8n is restarted afterwards because webhooks are only
# registered at startup.

set -euo pipefail
cd "$(dirname "$0")/.."

DOCKER="${DOCKER:-docker}"
COMPOSE=("$DOCKER" compose --env-file .env)

info() { printf '\033[36m..\033[0m    %s\n' "$1"; }
good() { printf '\033[32mPASS\033[0m  %s\n' "$1"; }
die()  { printf '\033[31mFAIL\033[0m  %s\n' "$1" >&2; exit 1; }

[[ -f .env ]] || die "no .env found - run: make init"

info "regenerating workflows from n8n/code/*.js"
python3 scripts/build_workflows.py >/dev/null
good "n8n/workflows/*.json are up to date"

if ! "${COMPOSE[@]}" ps --status running n8n 2>/dev/null | grep -q n8n; then
  die "the n8n container is not running - start the stack with: make up"
fi

info "importing workflows with the n8n CLI"
"${COMPOSE[@]}" exec -T n8n n8n import:workflow --separate --input=/workflows >/tmp/local-rag-import.log 2>&1 || {
  tail -n 30 /tmp/local-rag-import.log >&2
  die "n8n import:workflow failed (see output above)"
}
grep -E "successfully imported|Imported" /tmp/local-rag-import.log | sed 's/^/    /' || true
good "workflows imported"

db() {
  "${COMPOSE[@]}" exec -T postgres psql -U "${POSTGRES_USER:-n8n}" -d "${POSTGRES_DB:-n8n}" \
    -tAF '|' -c "$1" 2>/dev/null | tr -d '\r'
}

info "workflow state in the database"
db "select name, id, active, coalesce(\"activeVersionId\" is not null, false) from workflow_entity where name like 'RAG %' order by name" | sed 's/^/    /'

inactive() {
  db "select count(*) from workflow_entity where name like 'RAG %' and (active is not true or \"activeVersionId\" is null)" | tr -d '[:space:]'
}

workflow_rows() {
  db "select name, id, active, coalesce(\"activeVersionId\" is not null, false) from workflow_entity where name like 'RAG %' order by name"
}

# `</dev/null` matters: docker compose exec would otherwise swallow the rest of
# the loop's stdin and only the first workflow would be published.
if [[ "$(inactive)" != "0" ]]; then
  info "publishing the workflows (n8n 2.x draft -> published)"
  while IFS='|' read -r _name wf_id _active _version; do
    [[ -z "${wf_id:-}" ]] && continue
    "${COMPOSE[@]}" exec -T n8n n8n publish:workflow --id="${wf_id}" >/dev/null 2>&1 </dev/null || true
  done < <(workflow_rows)
fi

if [[ "$(inactive)" != "0" ]]; then
  info "trying the 1.x activation command"
  while IFS='|' read -r _name wf_id _active _version; do
    [[ -z "${wf_id:-}" ]] && continue
    "${COMPOSE[@]}" exec -T n8n n8n update:workflow --id="${wf_id}" --active=true >/dev/null 2>&1 </dev/null || true
  done < <(workflow_rows)
fi

if [[ "$(inactive)" != "0" ]]; then
  info "no CLI activation available - flipping the flag in PostgreSQL"
  db "update workflow_entity set active = true where name like 'RAG %'" >/dev/null || true
fi

if [[ "$(inactive)" != "0" ]]; then
  die "$(inactive) workflow(s) could not be activated. Publish them by hand with:
    docker compose exec n8n n8n publish:workflow --id=<id>
  (find the ids with: docker compose exec postgres psql -U n8n -d n8n -c 'select name, id from workflow_entity')"
fi
good "all 4 workflows are published and active"

info "restarting n8n so the webhooks are registered"
"${COMPOSE[@]}" restart n8n >/dev/null
N8N_PORT="${N8N_PORT:-5678}"
for _ in $(seq 1 60); do
  if curl -fsS "http://localhost:${N8N_PORT}/healthz" >/dev/null 2>&1; then break; fi
  sleep 2
done

# /healthz answers before the webhooks are registered, so the probe is retried
# for a while instead of failing on the first 404.
probe() {
  curl -s -o /tmp/local-rag-probe.json -w '%{http_code}' \
    -X POST "http://localhost:${N8N_PORT}/webhook/rag/query" \
    -H 'Content-Type: text/plain' --data '{}'
}

status=000
for _ in $(seq 1 30); do
  status="$(probe)"
  [[ "$status" != "404" && "$status" != "000" ]] && break
  sleep 2
done

case "$status" in
  400|422)
    good "the query webhook answered the probe with HTTP ${status} - the pipeline is live"
    sed 's/^/    /' /tmp/local-rag-probe.json 2>/dev/null || true
    ;;
  404)
    die "the query webhook returned 404 - the workflow is not published or the path is wrong"
    ;;
  500)
    die "the query webhook returned 500 - inspect the failure with: make logs"
    ;;
  *)
    die "the query webhook probe returned HTTP ${status} - check: make logs"
    ;;
esac

echo
echo "Webhooks"
printf '    POST   http://localhost:%s/webhook/rag/ingest\n' "${N8N_PORT}"
printf '    POST   http://localhost:%s/webhook/rag/query\n' "${N8N_PORT}"
printf '    GET    http://localhost:%s/webhook/rag/documents\n' "${N8N_PORT}"
printf '    DELETE http://localhost:%s/webhook/rag/document?document_id=doc_xxx\n' "${N8N_PORT}"
echo
echo "Next:  make qdrant && make sample && make test"
