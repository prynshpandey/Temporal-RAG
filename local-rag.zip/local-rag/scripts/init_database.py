#!/usr/bin/env python3
"""Create the application database and role for the Business Time Machine.

n8n owns the ``n8n`` database. The temporal schema gets its own database and its
own role, created through the postgres superuser that compose already sets up.
Idempotent: re-running changes nothing.

    make db-init
"""

from __future__ import annotations

import pathlib
import subprocess
import sys

sys.path.insert(0, str(pathlib.Path(__file__).parent))
from common import compose, docker_env, load_env, ok, warn  # noqa: E402


def sql(db: str, user: str, password: str) -> str:
    """CREATE ROLE / CREATE DATABASE cannot run inside a transaction block."""
    return "\n".join(
        [
            "DO $$ BEGIN",
            "  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = "
            f"'{user}') THEN CREATE ROLE \"{user}\" LOGIN PASSWORD '{password}'; END IF;",
            "  ELSE ALTER ROLE \"{user}\" WITH LOGIN PASSWORD '{password}'; END IF;",
            "END $$;",
        ]
    ) + f'\nCREATE DATABASE "{db}" OWNER "{user}";\n'


def main() -> int:
    env = load_env()
    db = env.get("BTM_DB_NAME", "business_time_machine")
    user = env.get("BTM_DB_USER", "btm")
    password = env.get("BTM_DB_PASSWORD", "")
    superuser = env.get("POSTGRES_USER", "n8n")

    if not password:
        warn("BTM_DB_PASSWORD is empty - run: make init --force")
        return 1

    exists = run_psql(env, superuser, "postgres",
                      f"SELECT 1 FROM pg_database WHERE datname = '{db}';", quiet=True)
    if exists.strip() == "1":
        ok(f"database {db} already exists")
    else:
        # CREATE DATABASE cannot run inside DO $$ ... $$; do it in two steps.
        create_role = "\n".join([
            "DO $$ BEGIN",
            f"  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '{user}') THEN",
            f"    CREATE ROLE \"{user}\" LOGIN PASSWORD '{password}';",
            "  ELSE",
            f"    ALTER ROLE \"{user}\" WITH LOGIN PASSWORD '{password}';",
            "  END IF;",
            "END $$;",
        ])
        run_psql(env, superuser, "postgres", create_role)
        run_psql(env, superuser, "postgres", f'CREATE DATABASE "{db}" OWNER "{user}";')
        ok(f"created database {db} owned by {user}")

    # Extensions the temporal schema needs; the role owns its own database.
    for extension in ("pg_trgm",):
        run_psql(env, user, db, f'CREATE EXTENSION IF NOT EXISTS "{extension}";', quiet=True)
    ok("extensions pg_trgm available")

    # Prove the app role can actually connect with the password from .env.
    probe = subprocess.run(
        compose("exec", "-T", "postgres", "psql", f"postgresql://{user}:{password}@127.0.0.1:5432/{db}",
                "-tAc", "SELECT current_database() || ' as ' || current_user;"),
        env=docker_env(), capture_output=True, text=True,
    )
    if probe.returncode == 0 and db in probe.stdout:
        ok(f"{user} can connect to {db}: {probe.stdout.strip()}")
        return 0
    warn(f"connection probe failed: {probe.stderr.strip()[:200]}")
    return 1


def run_psql(env: dict, user: str, db: str, statement: str, quiet: bool = False) -> str:
    result = subprocess.run(
        compose("exec", "-T", "postgres", "psql", "-U", user, "-d", db, "-v", "ON_ERROR_STOP=1", "-tAc", statement),
        env=docker_env(), capture_output=True, text=True,
    )
    if result.returncode != 0 and not quiet:
        print(result.stderr.strip()[:400])
    return result.stdout


if __name__ == "__main__":
    raise SystemExit(main())
