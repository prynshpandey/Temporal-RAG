#!/usr/bin/env python3
"""Can you trust a snapshot?

The point-in-time guarantee is only worth anything if a snapshot says what it
left out. These checks run against the seed corpus, whose documents contradict
each other on purpose:

  * the 2023 snapshot contains the 2023 report and nothing later
  * later documents are reported as withheld, with a reason
  * a snapshot is byte-identical whether or not a model is reachable
  * every passage in a snapshot comes from an in-scope document
  * an empty window is reported as empty, not as an error

Run with the seed corpus loaded: make seed-corpus && make test-state
"""
from __future__ import annotations

import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from common import bad, ok, request  # noqa: E402

API = os.environ.get("API_URL", "http://127.0.0.1:8000")
FY2023, FY2024, Q1_2025, FY2025 = (
    "helios-annual-report-2023.md",
    "helios-annual-report-2024.md",
    "helios-q1-2025-update.md",
    "helios-annual-report-2025.md",
)

results: list[tuple[str, bool, str]] = []


def ok_case(label: str, *detail) -> None:
    results.append((label, True, " ".join(str(d) for d in detail if d)))
    ok(label, " ".join(str(d) for d in detail if d))


def bad_case(label: str, *detail) -> None:
    results.append((label, False, " ".join(str(d) for d in detail if d)))
    bad(label, " ".join(str(d) for d in detail if d))


def snapshot(**params) -> dict:
    query = "&".join(f"{k}={v}" for k, v in params.items())
    status, out = request("GET", f"{API}/api/v1/state?{query}")
    if status != 200:
        raise RuntimeError(f"HTTP {status}: {str(out)[:200]}")
    return out


def main() -> int:
    started = time.perf_counter()
    print("point-in-time state")

    status, library = request("GET", f"{API}/api/v1/documents?limit=200")
    if status == 200 and not any(d["name"].startswith("helios-") for d in library.get("documents", [])):
        bad_case("the seed corpus is loaded", "run: make seed-corpus")
        return report(started)

    # 1. a 2023 snapshot sees the 2023 world and nothing after it
    snap = snapshot(as_of="2023-12-31", include_passages="false")
    names = {d["name"] for d in snap["documents"]}
    leaked = sorted(names & {FY2024, Q1_2025, FY2025})
    if leaked:
        bad_case("a 2023 snapshot excludes later documents", f"leaked {leaked}")
    elif FY2023 not in names:
        bad_case("a 2023 snapshot includes the 2023 report", f"got {sorted(names)}")
    else:
        ok_case("a 2023 snapshot excludes later documents", f"in scope: {sorted(names)}")

    # 2. the withheld documents are named, with a reason
    withheld = snap["excluded"]["not_yet_known"]
    if not withheld:
        bad_case("withheld documents are reported", "excluded.not_yet_known is empty")
    else:
        missing_reason = [w["name"] for w in withheld if not w.get("reason")]
        if missing_reason:
            bad_case("every withheld document carries a reason", f"missing for {missing_reason}")
        else:
            ok_case(
                "every withheld document carries a reason",
                f"{len(withheld)} withheld: {withheld[0]['reason']}",
            )

    # 3. revision chains: three editions of one report, grouped
    annual = next(
        (f for f in snap["families"] if any(v["name"] == FY2023 for v in f["versions"])), None
    )
    if not annual:
        bad_case("annual report editions are grouped into one chain", "no family found")
    else:
        in_scope = [v for v in annual["versions"] if v["in_scope"]]
        withheld_versions = [v for v in annual["versions"] if not v["in_scope"]]
        if len(in_scope) == 1 and withheld_versions:
            ok_case(
                "annual report editions are grouped into one chain",
                f"{annual['key']}: {len(annual['versions'])} editions, 1 in scope",
            )
        else:
            bad_case(
                "annual report editions are grouped into one chain",
                f"in_scope={[v['name'] for v in in_scope]}",
            )

    # 4. a present-day snapshot admits the whole corpus
    now = snapshot(as_of="2026-06-30", include_passages="false")
    if now["summary"]["documents_in_scope"] < 4:
        bad_case(
            "a present-day snapshot includes the whole corpus",
            f"only {now['summary']['documents_in_scope']} documents",
        )
    else:
        ok_case(
            "a present-day snapshot includes the whole corpus",
            f"{now['summary']['documents_in_scope']} documents, "
            f"{now['summary']['families']} families",
        )

    # 5. passages only ever come from in-scope documents
    ev = snapshot(as_of="2024-12-31", passage_limit=40)
    in_scope_ids = {d["document_id"] for d in ev["documents"]}
    foreign = {p["document_id"] for p in ev["passages"]} - in_scope_ids
    if foreign:
        bad_case("passages come only from in-scope documents", f"{len(foreign)} foreign documents")
    elif not ev["passages"]:
        bad_case("passages come only from in-scope documents", "no passages returned")
    else:
        ok_case(
            "passages come only from in-scope documents",
            f"{len(ev['passages'])} passages from {len(in_scope_ids)} documents",
        )

    # 6. a stale corpus is flagged rather than presented as current
    if any("not keeping up" in w for w in now["warnings"]):
        ok_case("a stale corpus is flagged", f"stale_days={now['summary']['stale_days']}")
    else:
        bad_case("a stale corpus is flagged", f"warnings: {now['warnings']}")

    # 7. an empty window is reported as empty, with an explanation
    empty = snapshot(as_of="2015-01-01", include_passages="false")
    if empty["summary"]["documents_in_scope"] == 0 and empty["warnings"]:
        ok_case("an empty window is reported as empty", empty["warnings"][0][:64])
    else:
        bad_case(
            "an empty window is reported as empty",
            f"{empty['summary']['documents_in_scope']} documents, {len(empty['warnings'])} warnings",
        )

    # 8. the snapshot is model-independent: it needs no LLM to be correct
    body = {k: v for k, v in ev.items() if k != "passages"}
    again = {k: v for k, v in snapshot(as_of="2024-12-31", passage_limit=40).items() if k != "passages"}
    if body == again:
        ok_case("the snapshot is deterministic across calls", "identical responses")
    else:
        bad_case("the snapshot is deterministic across calls", "responses differed")

    # 9. entity scoping narrows the snapshot
    scoped = snapshot(as_of="2026-06-30", entity="Corvus", include_passages="false")
    if 0 < scoped["summary"]["documents_in_scope"] < now["summary"]["documents_in_scope"]:
        ok_case(
            "entity scoping narrows the snapshot",
            f"Corvus: {scoped['summary']['documents_in_scope']} of {now['summary']['documents_in_scope']}",
        )
    else:
        bad_case(
            "entity scoping narrows the snapshot",
            f"scoped={scoped['summary']['documents_in_scope']} all={now['summary']['documents_in_scope']}",
        )

    # 10. a bad date is a clear 422, not a silent fallback
    status, out = request("GET", f"{API}/api/v1/state?as_of=last-tuesday")
    code = ((out or {}).get("error") or {}).get("code")
    message = ((out or {}).get("error") or {}).get("message", "")
    # The project reports domain validation as 400 validation_failed; what
    # matters is that a bad date is refused with a usable message rather than
    # quietly falling back to today.
    if 400 <= status < 500 and code == "validation_failed" and "as_of" in message:
        ok_case("a malformed date is rejected clearly", f"HTTP {status} {code}: {message[:52]}")
    else:
        bad_case("a malformed date is rejected clearly", f"HTTP {status}: {json.dumps(out)[:80]}")

    print()
    return report(started)


def report(started: float) -> int:
    failed = [r for r in results if not r[1]]
    if failed:
        print(f"[31m{len(failed)} of {len(results)} checks failed in {time.perf_counter() - started:.1f}s[0m")
        for label, _, detail in failed:
            bad(label, detail)
        return 1
    print(f"[32mpoint-in-time state verified in {time.perf_counter() - started:.1f}s[0m")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
