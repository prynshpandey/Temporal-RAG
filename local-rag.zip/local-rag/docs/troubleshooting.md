# Troubleshooting

Start here: **`make health`**. It checks Ollama, both required models, the real
embedding dimension, Qdrant, the collection, PostgreSQL, n8n, and whether the n8n
container can actually reach the host Ollama. Then `make logs` to watch a failing run.

## Docker

**`docker: command not found` after `sudo make bootstrap`**
The script installs Docker, but the `docker` group only applies to new logins:

```bash
newgrp docker        # this shell only
# or log out and back in
docker ps            # must work without sudo
```

**`permission denied while trying to connect to the Docker daemon socket`**
You are not (yet) in the `docker` group: `sudo usermod -aG docker "$USER"` then log out
and back in. `sudo docker …` works around it for a single command but bypasses the
project's own `DOCKER` variable.

**`Cannot connect to the Docker daemon`**
`systemctl status docker` and `journalctl -u docker -n 50`. On a fresh Fedora install the
daemon is often masked; `sudo systemctl enable --now docker` fixes it.

**Port already in use**
Something else owns the port. Change the host side in `.env` (`N8N_PORT`, `QDRANT_PORT`,
`POSTGRES_PORT`, `FRONTEND_PORT`) and `make restart`.

**Another machine or a remote sandbox cannot reach the stack**
By design: every port is published as `127.0.0.1:<port>:<container port>`, so only this
host can talk to the app, the n8n editor and the databases. `ss -ltn` must show
`127.0.0.1:5678`, not `0.0.0.0:5678`. To reach it from elsewhere, drop the `127.0.0.1:`
prefix in `docker-compose.yml` and put a reverse proxy with TLS and authentication in
front of the n8n and frontend ports first — the webhooks and the n8n editor have no
login of their own.

**nginx exits immediately, the frontend is unreachable**
On SELinux systems (Fedora) a bind-mounted config or document root is not readable inside
the container unless it is relabelled. Every bind mount in `docker-compose.yml` therefore
carries the `:z` flag. If you add a mount, add `:ro,z` (or `:rw,z`) too, or check
`sudo ausearch -m avc -ts recent` for the denied path.

**`Postgres 16 is outside the supported range`**
n8n 2.x wants PostgreSQL 17 or newer. `POSTGRES_IMAGE` defaults to `postgres:17-alpine`;
after changing an existing installation's major version the data directory has to be
recreated (`docker compose down`, remove the `local-rag_pgdata` volume, `make up`,
`make import`).

## Ollama

**`connection refused` on 11434 from the host**
`systemctl status ollama` — the service is not running. `sudo systemctl start ollama`.

**The n8n run fails with `fetch failed` / `ollama_unreachable` but the host can answer**
The most common problem in this setup: the host Ollama listens on `127.0.0.1`, so
containers cannot reach it.

```bash
ss -ltnp | grep 11434          # must show 0.0.0.0:11434, not 127.0.0.1
curl http://host.docker.internal:11434/api/tags   # run inside the n8n container
```

Fix with `sudo bash scripts/bootstrap_host.sh` (writes a systemd drop-in setting
`OLLAMA_HOST=0.0.0.0:11434`, restarts Ollama, and opens the port to the Docker bridge
ranges on Fedora). `extra_hosts: host.docker.internal:host-gateway` in
`docker-compose.yml` must stay in place.

**`model not found` / `llama3.1` missing**
`ollama list`. Pull it with `make models`, or set `LLM_MODEL` in `.env` to a model you
already have (`llama3.2:3b` is much faster on CPU) and restart the stack.

**The first question takes minutes**
Normal on CPU: the model is loaded from disk and 8B parameters are decoded by the CPU.
The second question is faster. For interactive use set `LLM_MODEL=llama3.2:3b`, or
`qwen3:4b`. `NUM_CTX=8192` and `MAX_TOKENS=1200` are the main cost drivers.

**`llm_empty_response` / `done_reason: length`**
The answer was cut off at `MAX_TOKENS`. Raise it, or lower `MAX_CONTEXT_CHARS` so the
prompt leaves more room.

## Qdrant

**`Not found: Collection ... doesn't exist!`**
`make qdrant`. Collection creation is explicit so its vector size always matches
`QDRANT_VECTOR_SIZE`.

**`Wrong input: Vector dimension error`**
The collection and the model disagree. `make health` reports both. Either point
`EMBEDDING_MODEL` at the model that created the collection, or accept the new dimension:

```bash
# in .env, set QDRANT_VECTOR_SIZE to the real dimension, then:
make qdrant-reset     # destructive: re-upload all documents afterwards
```

**`qdrant_upsert_failed` in an n8n run**
Usually the collection is missing or the wrong size; `make qdrant` verifies both. If
Qdrant is up but the error persists, `make logs` shows the raw Qdrant response.

**Qdrant answers `missing field 'ids'` to the upsert**
The request used `POST /collections/…/points`, which is Qdrant's *batch update* format.
A full point list must go out as `PUT /collections/…/points?wait=true`
(`{"points":[{"id","vector","payload"}]}`). `scripts/build_workflows.py` emits the
correct method; Qdrant answered a POST with 400 while the DELETE-by-filter calls stayed
fine, which is a useful tell.

**Answers are nonsense after changing the embedding model**
Old vectors and new vectors in the same collection. Wipe it (`make qdrant-reset`) and
re-upload; mixed-model vectors are not comparable.

## n8n

**Webhooks return 404**
The workflow is not *published*. n8n 2.x keeps drafts and published versions apart:
`active = true` in PostgreSQL is not enough, the workflow needs an active version.

```bash
sg docker -c "make import"        # imports, publishes, restarts n8n, probes the webhook
```

`scripts/import_workflows.sh` does the full sequence: `n8n import:workflow --separate`,
then `n8n publish:workflow --id=<id>` for each workflow, then a restart (webhook paths are
registered at startup), then a retrying probe on `/healthz` followed by a real request to
the query webhook. A missing publish step is the single most likely cause of 404s on a
fresh import.

**`Make import` reports the webhook is not registered**
Publishing worked but the probe still gets 404: the probe retries for ~60 s because
`/healthz` answers *before* webhook registration finishes. If it still fails, publish
manually and restart:

```bash
docker compose exec -T n8n n8n publish:workflow --id=<workflowId>
docker compose restart n8n
```

Check the result with:

```bash
docker compose exec -T postgres psql -U n8n -d n8n \
  -c "select name, active, \"activeVersionId\" is not null as published from workflow_entity order by name;"
```

**A Code node fails with `access to env vars denied`**
n8n 2.x blocks `$env` in expressions unless `N8N_BLOCK_ENV_ACCESS_IN_NODE=false`. The
stack ships that setting (it is what lets the HTTP nodes build URLs and thresholds from
`.env`) and `make validate` fails if it is removed. The trade-off is that a workflow
author can read container environment variables — acceptable here because the workflows
are generated from this repository, not user-supplied.

**A Code node fails on a `Buffer` of the uploaded PDF** (`invalid_pdf` with a magic-byte
error showing garbage)
In filesystem binary mode `item.binary.data` holds the *compressed* payload, not the
file. Read the bytes with `$getBinaryDataBuffer(i, 'data')` (falling back to
`this.helpers.getBinaryDataBuffer`). `n8n/code/01_validate_upload.js` does this, with
base64/Buffer/latin1 fallbacks for other modes.

**A node type is missing from the import (`Cannot find node type ... aggregate` / `...extractPdf`)**
n8n 2.x removed the Aggregate node and the legacy Extract PDF operation. This project uses
`extractFromFile` with `operation: pdf` and the Code-node based **Collect Points** instead
of Aggregate. Regenerate with `make workflows`; a stale hand-edited JSON will keep
referencing the removed types.

**A loop looks like it runs forever / the "done" branch never fires**
In n8n 2.x `splitInBatches` emits `outputNames: ['done', 'loop']` — output 0 is done and
output 1 is the loop. Connections and node parameters use the *target's* input index, not
the source output index.

**An execution is stuck in "running"**
`docker compose restart n8n`. Executions are persisted (14 days) and can be inspected
after the restart. To read a stored payload, remember `execution_data.data` is Flatted:

```bash
docker compose cp n8n:/tmp/dump_exec.js .   # see scripts/ for a reusable dumper
```

Non-fatal warnings in `make logs` that are expected on this stack:
`standardFontDataUrl` (PDF font metrics for the Readability-ish helpers),
`@napi-rs/canvas` (image extraction) and the missing Python task runner.

**`n8n import:workflow` fails**
Check that `n8n/workflows/*.json` exist (`make workflows`) and that the n8n container is
running (`make ps`). The full CLI output is in `/tmp/local-rag-import.log`.

**The browser says "Could not reach n8n"**
The frontend calls `http://localhost:5678` (see `frontend/config.js`). If n8n is on
another port, change `N8N_PORT` in `.env` *and* `window.CONFIG.n8nBaseUrl` in
`frontend/config.js`, or open the UI with an override: `http://localhost:8080/?n8n=http://localhost:5679`.

**A CORS error in the browser console**
The Webhook nodes are built with `allowedOrigins: *`. If you changed that, set
`N8N_ALLOWED_ORIGINS` in `.env` to your frontend origin (`http://localhost:8080`) and
`make restart`. JSON is sent as `text/plain` precisely to keep requests "simple" and
avoid a preflight.

## PDFs

**`extraction_failed` (422)**
The PDF is encrypted, password protected or corrupt. Remove the password, or export it
again. n8n's Extract from File node supports text-based PDFs only.

**`no_text_layer` (422)**
The PDF is a scan: it has no embedded text. This stack has no OCR on purpose. Run
`ocrmypdf in.pdf out.pdf` (or any OCR tool) and upload the result.

**`page: null` in the citations**
The extractor returned one blob of text instead of per-page output, so page numbers
could not be assigned. Chunking still works, overlaps still work, and the UI says
`page_known: false`. Nothing to fix.

**A PDF with two columns reads in the wrong order**
Extraction is line-based. Keep one fact per paragraph; for heavily columned documents,
convert to a text-first PDF or split the document.

## Scripts

**`scripts/*.py: No module named common`**
Run them from the project root (`make test`, `make health`, …) so the sibling module is
on the path, or with `python3 scripts/test_pipeline.py` from anywhere after
`PYTHONPATH` includes `scripts/`.

**`make` cannot find a target**
Run it from the repository root, or use `make -C /path/to/local-rag …`.

**`make validate` fails on `.env` secrets**
`make init --force` regenerates the random password and encryption key. Warning: a new
`N8N_ENCRYPTION_KEY` makes credentials stored by n8n undecryptable. Nothing in this
project stores credentials in n8n (there are none), so regeneration is safe here.

## Reset recipes

```bash
make restart          # recreate containers, keep data
make qdrant-reset     # empty vector store, then re-upload documents
make import           # rebuild + re-import + activate workflows
docker compose down && docker compose up -d   # full restart of the stack
make clean            # DESTRUCTIVE: containers and all volumes (documents, n8n data)
```

## Language model

**`Groq HTTP 404: model does not exist or you do not have access`**
A model name in `GROQ_MODEL` is not available to your key. This is the normal state of
affairs: Groq retires models. `make llm-probe` lists what your key can actually reach and
runs the real extraction prompt against each candidate, so the fix is a measurement:

```bash
GROQ_MODELS="openai/gpt-oss-20b qwen/qwen3.8-27b" make llm-probe
```

Set `GROQ_MODEL` to a model printed as `ok`. As of this writing `qwen/qwen3.8-27b` is the
usable choice: it answers in JSON without a reasoning channel and its dates stay grounded
in the text.

**`spent its N tokens reasoning and returned no answer`**
`gpt-oss` models emit a reasoning channel that can consume the entire token budget, leaving
an empty answer. Either raise `max_tokens` or use a model without one, as above.

**`Groq rejected the request as too large`**
The on_demand tier answers HTTP 429 when prompt + `max_tokens` passes a few thousand tokens.
The message is a size complaint, not rate limiting, and it looks identical in the log. The
client shrinks `max_tokens` to fit `GROQ_MAX_REQUEST_TOKENS` (default 4096) rather than
retrying a body that cannot succeed. If your prompts are genuinely large, raise that value
or lower `DOCUMENT_SUMMARY_CHARS`.

**Extraction returns no entities but no error**
Look for `extraction_error` in the response: the document still ingested, it just carries
deterministic dates only. This is deliberate - a dead model must not cost you a document.

**A fallback makes ingest slow**
`LLM_FALLBACK_PROVIDER` defaults to `none`, on purpose. The local model is `llama3.1`, a
6 GB model that only runs on CPU here, and loading it evicts `nomic-embed-text` from
Ollama's memory: a single ingest went from 14s to 355s and still produced no usable JSON,
because the embedder and the chat model cannot both stay resident. Trading a few missing
entities for a 25x slower ingest is a bad deal, so a Groq quota blip now costs the document
its entities, not its latency.

Set `LLM_FALLBACK_PROVIDER=ollama` on a machine with enough memory (or a GPU) if you
prefer availability over speed; `LOCAL_LLM_TIMEOUT_S` (60s) bounds the attempt either way.
With Groq healthy, `llm_usage.fallbacks` stays at 0; anything above 0 means the primary
call failed.

**`llm_usage` shows all zeros**
That is a real outcome, not a bug: the model did not answer (`calls: 0`), so there is no
usage to report. `extraction_error` says why, and the document is still indexed with
deterministic dates, sections, chunks and vectors. Check
`metadata.extraction_error` before assuming the pipeline lost the document.


**A query returns nothing**
Check `stats` in the response first: `keyword_candidates: 0` means Postgres full
text found no matching chunk, `vector_candidates: 0` means Qdrant did. They fail
for different reasons.

`keyword_candidates: 0` with a question you know is answered usually means the
search terms were all stopwords. `_query_terms` in `app/services/retrieval.py`
keeps identifiers and numbers verbatim, but a question like "How many employees
does Helios have?" reduces to the single content word "helios", which now matches
via the `search_text` column (breadcrumb plus body, the same string that was
embedded). If you added columns by hand, re-run `make migrate` - the tsvector is
generated from `search_text`, not from `text`.

`vector_candidates: 0` is usually a filter problem, not an embedding problem. The
Qdrant filter is built in `temporal_filter`; its shape is version-sensitive.
This build wants `min_should` as a `{"conditions": [...], "min_count": 1}` object
and `is_null` as a plain boolean beside `key`. A malformed filter returns HTTP
400, which the retrieval layer deliberately swallows so keyword search still
works - look for `vector_search_failed` in `make logs` to tell the two apart.

**Recency reordered a result**
`RETRIEVAL_RECENCY_WEIGHT` (default 0.15) multiplies the fused score by up to
1.15 for the newest in-scope document. It is a tie-breaker between documents that
matched about equally well, which is what you want when a fact was restated, but
it can promote a fresher and slightly weaker source. Set it to `0` for pure RRF
ordering.

## A snapshot looks empty

`GET /api/v1/state` returns only documents that were valid on the requested date. A window
with no documents is a real answer, not a failure, and `warnings` says so explicitly. Check
`excluded.not_yet_known` first: usually the documents exist but are dated after the window.
An undated document is included on its upload date, so a snapshot taken before it was uploaded
will exclude it.

## Passages show section titles but no breadcrumb

Sections are stored in `document_sections`; `chunks_for_documents()` joins that table for
`section_title`. A chunk whose `section_id` does not resolve has a null title and still returns
its text. Only `document_chunks` columns are read — adding a column means updating that
query, and a missing column surfaces as a 500 with `UndefinedColumnError` in the backend log.

## An answer is extractive when you expected prose

`mode` is `extractive` whenever the model did not produce a citable answer, including when it
was unreachable. This is the designed behaviour: a quotation cannot misstate a number. Check
`llm.provider` and `llm.usage` — if the provider is null, the quota is the cause and
`make llm-probe` will show it. Retrieval itself is unaffected.

## A change is missing from the comparison

Metric extraction is deterministic and deliberately conservative. It reports a number only when a
label and a unit can be paired with it, so a figure written without either is skipped. Common
skips, all of them cases where a wrong pairing would be worse than none:

* a second number in the same sentence, when the real subject sits further back than a bare numeral
* a percentage that states a movement rather than a level ("up 18 percent")
* dates, including bare years and fiscal references
* sentences where every word before the number is a verb or a function word

`net loss` and `net profit` are tracked as two metrics rather than one metric that changed sign.
Relating them needs period-aware extraction, which is not implemented.

## A real contradiction is not reported as a conflict

Only statements dated within `CONFLICT_WINDOW_DAYS` (30) of each other are compared. Two documents
written years apart are a revision history, and treating that as a conflict would report the
normal case as the alarming one. Widen the window only if your corpus genuinely revises a figure
shortly after publishing it. Undated statements are compared only against other undated ones, so a
missing date never becomes a false conflict.

## The newest document is not ranked first

That is the relevance band working. Candidates further than `RERANK_RELEVANCE_BAND` (10%) below the
leader on relevance are ordered by relevance alone, and recency is never consulted for them — a
fresher document should not displace a stronger match. Inspect `ranking` on any hit to see
`base_score`, `rerank_quality`, `rerank_features` and `ranking_basis`. Inside the band,
`ranking_basis` is `recency_within_band`; outside it, `relevance`.

If a genuinely more relevant passage is losing, check the features before widening anything. A
low `coverage` usually means the section does not address the question; a low `heading` means the
query terms are in the body but not the section title. Widening the band trades precision for
freshness and is rarely the right fix — raise `RERANK_QUALITY_BONUS` instead, which strengthens the
features relative to fusion without letting date override relevance at all.

## A query mentioning a year matches everything from that year

Fiscal references are stripped from query terms, so "revenue in FY2024" ranks on "revenue" alone.
This is deliberate: a date narrows the *window*, which the temporal filter already applies, and
letting it influence lexical scoring would let a document match on its year alone. The temporal
decision is made once, in SQL and in Qdrant, and ranking never revisits it.

## The Time machine tab opens blank

It is a cross-origin problem, not a rendering one. The temporal tabs call the backend directly on
:8000 while the page is served from :8080, so the backend must allow the frontend's origin via
`ALLOWED_ORIGINS`. If the browser console shows a CORS error, that is the cause; the legacy Ask and
Library tabs keep working because they go through n8n and are unaffected.

To check which backend the page is using, look at the `api` query parameter or
`localStorage["local-rag-backend-url"]`. A stale override there silently points every temporal view
at an old host. Append `?api=http://localhost:8000` to force it back.

## `make test-frontend` says SKIP

It needs `node` on the host, and skips loudly rather than passing quietly when node is absent. The
suite renders `frontend/time.js` against API payloads captured in `frontend/tests/fixtures/`, using a
minimal DOM shim — no browser and no running services. Refresh the fixtures with
`make test-fixtures` whenever an endpoint response changes shape, and extend
`frontend/tests/test_time_ui.mjs` when a renderer starts reading a new field.

The fixtures are committed on purpose. A renderer test that needs a live backend stops being run
exactly when the response shape changes, which is the one moment it is worth running.

## `make eval` reports a dimension under its threshold

Read the dimension name before reading the score. `temporal_leakage`, `answer_leakage` and
`context_precision` mean future data reached the caller, and they are held at 1.0 on purpose - fix
the code. `answer_value` is allowed to sit at 0.8 because it measures the model, and a
rate-limited model that declines and quotes its sources is behaving correctly.

A `context_recall` miss with a `context_precision` pass usually means the right passage was not
retrieved, which is a reranking or fusion problem. Both failing at once on the same case usually
means the question retrieves the wrong document entirely - check `as_of` is being sent.

`compare` misses name every label it did find, so a missing metric is distinguishable from a
mismatched value. If a metric is missing from the diff entirely, the extractor did not recognise
the phrasing; `backend/tests/test_facts.py` is the place to add it, and the corpus-wide diff in
`make eval` is what tells you whether the change broke another document.
