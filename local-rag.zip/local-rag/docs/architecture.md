# Architecture

Four n8n workflows, no shared state between them except Qdrant. This document walks
through each node in execution order and explains why it is there.

```
┌────────────────┐
│ browser        │  static files from nginx:8080
│  index.html    │  uploads PDF, posts questions, lists + deletes documents
│  app.js        │
└───────┬────────┘
        │  multipart POST /webhook/rag/ingest
        │  text/plain POST /webhook/rag/query
        │  GET  /webhook/rag/documents
        │  DELETE /webhook/rag/document
┌───────▼────────┐        ┌──────────────────────────────────────────┐
│ n8n :5678      │───────▶│ Ollama (host) :11434                      │
│ 4 workflows    │        │  POST /api/embed   nomic-embed-text 768-d │
│ Code + HTTP    │───────▶│  POST /api/chat    llama3.1              │
│ nodes only     │        └──────────────────────────────────────────┘
│                │───────▶┌──────────────────────────────────────────┐
│ PostgreSQL     │        │ Qdrant :6333                             │
│ (workflows,    │        │  collection local_rag_chunks, Cosine 768  │
│  credentials,  │        │  payload indexes: document_id, page, …    │
│  executions)   │        └──────────────────────────────────────────┘
└────────────────┘
```

## Why n8n orchestrates this

The pipeline is a real graph: validation, branching, batching, looping, error handling.
In n8n each of those is a node you can open, edit, re-run and inspect — with the input
and output of every step recorded in the execution log (`EXECUTIONS_DATA_MAX_AGE=336`,
i.e. 14 days). The alternative — one Python file — is less code but far harder to debug
when an answer comes back wrong, because you have to guess which of the twelve steps
misbehaved.

Two deliberate choices:

* **No LangChain / vector-store subnodes.** Every external call is a plain HTTP Request
  node with a visible URL and JSON body, so every byte crossing the process boundary is
  visible on the canvas.
* **All logic in real `.js` files** (`n8n/code/`). n8n stores Code node source inside
  the workflow JSON, which makes it painful to review or lint. `scripts/build_workflows.py`
  injects those files into the generated JSON, so `node --check` and your editor work
  as expected.

## Workflow 1 — RAG 1: PDF Ingestion (27 nodes)

`POST /webhook/rag/ingest`, multipart with a `data` file field.

| # | Node | Type | What it does |
| --- | --- | --- | --- |
| 1 | Ingest Webhook | Webhook | `responseMode: responseNode` so the pipeline can answer with a real status code |
| 2 | Validate Upload | Code (`01_validate_upload.js`) | magic-byte check (`%PDF-`), size vs `MAX_UPLOAD_MB`, `document_id = doc_` + SHA-256, `started_at`. The bytes are read through `$getBinaryDataBuffer()` because in filesystem mode `binary.data` is the compressed payload |
| 3 | Upload Valid? | IF | false → **Reject Upload** 400 `invalid_pdf` / `file_too_large` |
| 4 | Extract PDF Text | Extract from File (`operation: pdf`) | binary → text with `joinPages: false` so every page stays a separate entry; `onError: continueRegularOutput` turns a corrupt PDF into a readable 422 |
| 5 | Extraction OK? | IF | false → **Extraction Failed** 422 `extraction_failed` |
| 6 | Validate Text | Code (`01_validate_text.js`) | turn the extractor output into a page list (array, `pages` object, `\f` or plain text), reject `no_text_layer` below `MIN_EXTRACT_CHARS` |
| 7 | Text Usable? | IF | false → **No Text Layer** 422 |
| 8 | Chunk Document | Code (`01_chunk.js`) | per page: normalize whitespace, drop repeated headers/footers, split on sentence boundaries, `CHUNK_SIZE` with `CHUNK_OVERLAP` tail overlap, drop chunks under `MIN_CHUNK_CHARS` |
| 9 | Chunks Produced? | IF | false → **No Chunks** 422 |
| 10 | Delete Existing Chunks | HTTP → Qdrant | delete-by-filter on `document_id`, so re-uploading a file replaces it instead of duplicating it |
| 11 | Load Chunks | Code (`01_load_chunks.js`) | take the chunk items back from **Chunk Document** — the delete request replaced them with its own response |
| 12 | Embed Chunk Batches | Loop Over Items | batches of `EMBED_BATCH_SIZE` (8). In n8n 2.x the outputs are `0 = done`, `1 = loop` |
| 13 | Build Embed Batch | Code | `{ model, input: [text…], truncate: true, keep_alive: '5m' }` |
| 14 | Ollama Embed Chunks | HTTP → Ollama | `POST /api/embed` — one request per batch |
| 15 | Normalize Embeddings | Code | checks vector count and dimension, assigns a deterministic Qdrant point id, builds the payload, parks the points in the execution's workflow static data keyed by point id |
| 16 | Collect Points | Code (`01_collect_points.js`) | runs on the loop's `done` output: reads the accumulated points back, orders them by chunk index, emits one item per `QDRANT_UPSERT_BATCH` (64) points |
| 17 | Ingest OK? | IF | false → **Ingest Failed** 502 |
| 18 | Qdrant Upsert Points | HTTP → Qdrant | `PUT /points?wait=true` once per item. Qdrant ≥ 1.10 uses `PUT` for the point list; `POST` is the batch *update* format |
| 19 | Check Upsert | Code | reduces the per-batch responses and turns a Qdrant error object into `qdrant_upsert_failed` with a fix hint |
| 20 | Qdrant Collection Info | HTTP → Qdrant | point counts for the response |
| 21 | Ingest Summary | Code | the JSON the browser receives |
| 22 | Ingest Result | Respond | 200 `status: indexed` |

**Why static data for the batches** — the loop's `done` output returns the *input* items of
the loop, not the results of its body, so batch results cannot be aggregated from there.
Each iteration therefore adds its points to `$getWorkflowStaticData('global')`, keyed by
point id: only one batch of embeddings is alive at a time, a failure in any batch is
reported by **Collect Points**, and re-running the same execution rewrites the same keys
instead of duplicating points.

**Point id** — Qdrant only accepts unsigned integers or UUIDs. `01_normalize_embeddings.js`
builds a 53-bit integer from the document id, chunk index and text hash with two seeded
FNV-1a passes: stable across re-imports, collision-free in practice, and the human
readable `chunk_id` (`doc_1a2b3c4d5e6f7890-p1-c2`, i.e. document, page, running index) is
stored in the payload.

**Payload per point** — `text`, `document_id`, `document_name`, `sha256`, `size_bytes`,
`chunk_id`, `chunk_index`, `char_count`, `page`, `page_known`, `indexed_at`,
`embedding_model`. The library and delete workflows filter on exactly these fields, which
is why the indexes created by `scripts/setup_qdrant.py` matter.

## Workflow 2 — RAG 2: Question Answering (20 nodes)

`POST /webhook/rag/query`, JSON body (accepted as `text/plain` too).

| # | Node | Type | What it does |
| --- | --- | --- | --- |
| 1 | Query Webhook | Webhook | — |
| 2 | Query Config | Code (`02_query_config.js`) | parse body, validate `question`, read config from `$env`, clamp `top_k` to 1–20, build the optional `document_id` filter |
| 3 | Request Valid? | IF | false → **Reject Request** 400 (`malformed_json`, `empty_question`, `question_too_long`) |
| 4 | Ollama Embed Question | HTTP → Ollama | `POST /api/embed` with a single-element `input` array |
| 5 | Normalize Query Embedding | Code | dimension check against `QDRANT_VECTOR_SIZE` → 503 `embedding_failed` |
| 6 | Qdrant Search | HTTP → Qdrant | `POST /points/search` with `limit: top_k`, `with_payload: true`, `score_threshold: min_score` |
| 7 | Build Context | Code (`02_build_context.js`) | map hits to source objects, enforce the `MAX_CONTEXT_CHARS` budget, render the numbered context block, decide `no_context` |
| 8 | Retrieval OK? | IF | false → **Retrieval Failed** 503 |
| 9 | Has Context? | IF | true → Build Prompt; false → **No Context Answer** 200, and **Llama is never called** |
| 10 | Build Prompt | Code (`02_build_prompt.js`) | system prompt (injected from `prompts/system_prompt.txt` at build time) + user prompt with the context and the question |
| 11 | Ollama Generate Answer | HTTP → Ollama | `POST /api/chat`, `stream: false`, `options: { temperature, num_ctx, num_predict }` |
| 12 | Assemble Answer | Code (`02_assemble_answer.js`) | extract `message.content`, build `sources[]` and `usage{}`, detect an empty completion |
| 13 | Generation OK? | IF | false → **Generation Failed** 502 `llm_failed` / `llm_empty_response` |
| 14 | Answer | Respond | 200 `status: answered` |

**The refusal path matters.** If retrieval returns nothing, or everything scores below
the threshold, the workflow answers `no_context` and the model is not invoked. An 8B
model asked an unanswerable question *with* an empty context will still produce a
fluent, confident, wrong answer — the only reliable defence is to not ask it.

**Citations** — each context block is prefixed with
`[Retrieved Chunk 1 | document: … | page: … | chunk_id: … | similarity: …]`, and the
system prompt requires the model to cite those numbers. The UI shows the passages
independently of the model, so a hallucinated citation is visible immediately.

## Workflow 3 — RAG 3: Document Library (6 nodes)

`GET /webhook/rag/documents`. One Qdrant scroll (`limit: 1000`, payloads only, no
vectors) and a Code node that groups the points by `document_id`, counts chunks, counts
distinct pages and keeps the newest `indexed_at`. This is what proves ingestion is
persistent across restarts — the UI can list documents long after the n8n execution is
gone.

## Workflow 4 — RAG 4: Delete Document (9 nodes)

`DELETE /webhook/rag/document?document_id=doc_…`. Reads the id from the query string
(or a JSON body), then one Qdrant delete-by-filter. No per-chunk loop: the payload index
on `document_id` makes this a single indexed range delete.

## Data model

One Qdrant collection, one point per chunk:

```
id       4712345678901234                # uint (deterministic)
vector   [0.021, -0.108, …]              # 768 floats, Cosine distance
payload
  document_id    "doc_1a2b3c4d5e6f7890"   # keyword index
  document_name  "sample.pdf"
  sha256         "3f786850e387550fdab…"
  size_bytes     2883
  chunk_id       "doc_1a2b3c4d5e6f7890-p1-c2" # human readable
  chunk_index    2
  char_count     1043
  page           1                       # integer index
  page_known     true
  indexed_at     "2026-09-25T10:04:11.000Z"
  embedding_model "nomic-embed-text"
  text           "Revenue increased by 18% …"
```

Re-uploading the same file yields the same `document_id` and the same point ids, and the
old points are deleted first — so ingestion is idempotent rather than additive.

## Failure modes and how they surface

| Failure | Where it is caught | Response |
| --- | --- | --- |
| Not a PDF / too large | Validate Upload | 400 `invalid_pdf`, `file_too_large` |
| Encrypted or corrupt PDF | Extraction OK? | 422 `extraction_failed` |
| Scanned image PDF | Text Usable? | 422 `no_text_layer` |
| Chunking produced nothing | Chunks Produced? | 422 `no_chunks_produced` |
| Ollama down / model missing | Normalize Embeddings | 502 `embedding_failed` |
| Qdrant down or dimension mismatch | Check Upsert | 502 `qdrant_upsert_failed` |
| Empty question | Request Valid? | 400 `empty_question` |
| No relevant chunk | Has Context? | 200 `no_context` (model not called) |
| Model empty / timeout | Generation OK? | 502 `llm_empty_response`, `llm_failed` |
| n8n execution crashed | — | the browser sees HTTP 500 from the webhook; `make logs` shows the node |

Every HTTP Request node uses `neverError` + `onError: continueRegularOutput`, so an API
error arrives as data in the next Code node instead of aborting the execution with an
opaque message. That is why each failure has a stable `code` and a `hint`.

## Evaluation as an architectural component

`backend/eval/dataset.json` is treated as part of the system rather than as a
test fixture. The corpus is built so the documents contradict one another on
purpose — churn is 4.1, then 3.6, then 3.2 — which makes "which document did
this come from" a question with a right answer.

Two decisions shape it:

**Retrieval and generation are scored separately.** `context_recall` and
`temporal_leakage` are measured on `/query`, with no model in the path.
`answer_value` is measured on `/answer`. A wrong answer built on correct
evidence is a generation problem; a correct answer built on a future document is
a temporal failure that looks fine. One pass/fail conflates them and hides the
second.

**Figures are compared as numbers, not characters.** Every shortcut here
produced a false temporal alarm before being replaced: substring matching reads
`"36.5 million"` as the figure 36, and boundary anchoring reads `"47.0 percent"`
as a miss for 47. Both are the same number written differently, and both read as
leakage when the document was in scope.

Adding a metric phrase that the extractor misses is a normal outcome here rather
than a regression. `make eval` names the metrics it did find, which distinguishes
"not extracted" from "extracted wrong".
