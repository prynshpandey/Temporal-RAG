# Chunking

Chunking decides what a single "fact" looks like to the retriever: every chunk becomes
one vector, and `TOP_K` chunks are what the model gets to read. Get it wrong and no
amount of prompt tuning rescues the answers.

All of it happens in `n8n/code/01_chunk.js`, per page, in this order:

1. **Normalize** — CRLF → LF, non-breaking spaces → spaces, curly quotes → straight
   quotes, dashes → `-`, bullets → `*`, runs of spaces collapsed, three or more
   newlines collapsed to two. Offsets and hash-based point ids stay stable only if the
   text is deterministic.
2. **Strip repeated margins** — with `STRIP_REPEATED_MARGINS=true`, short identical
   lines that appear at the top or bottom of at least 60% of pages (and on at least 3
   pages) are deleted from every page. Running headers, "Page 3 of 12" footers and
   confidentiality banners eat 15–30% of the chunk budget and match almost every query,
   which pushes real content out of the retrieved set.
3. **Pack paragraphs** — paragraphs are appended to the current buffer until adding
   another would exceed `CHUNK_SIZE * 1.35` (the slack lets one normal paragraph
   overshoot slightly instead of being split needlessly).
4. **Split oversized paragraphs** — a paragraph longer than the limit (a wide table row,
   an unbroken column) is split on sentence boundaries, and sentences longer than the
   limit are hard-cut.
5. **Overlap** — when a chunk is flushed, its last `CHUNK_OVERLAP` characters, snapped
   forward to a sentence start (or a word start), are prepended to the next chunk of the
   *same page*. Overlap is never carried across pages, because a page break is a real
   boundary in a document.
6. **Drop noise** — chunks shorter than `MIN_CHUNK_CHARS` are discarded, unless that
   would leave a page with nothing.

## Defaults and why

| Setting | Default | Reason |
| --- | --- | --- |
| `CHUNK_SIZE` | `1200` characters | ~300 English tokens. Small enough that a chunk is about one topic, large enough that a sentence and its table row usually stay together. `nomic-embed-text` has an 8192-token window, so there is no pressure to use bigger chunks. |
| `CHUNK_OVERLAP` | `200` characters | ~17% of a chunk. Enough to carry the sentence that straddles a cut, small enough that near-duplicate vectors do not crowd out the other top-5 hits. |
| `MIN_CHUNK_CHARS` | `120` | Kills orphan footer fragments and one-line stubs that embed into noise vectors. |
| `STRIP_REPEATED_MARGINS` | `true` | See above. Set `false` if the header actually carries meaning (e.g. a section title on each page). |

## Tuning guide

**"The answer is right but cites the wrong page."** Usually a fact split across two
chunks. Raise `CHUNK_OVERLAP` to 300–400, or `CHUNK_SIZE` to 1600. Re-upload the
document (ingestion is not incremental).

**"It says it cannot find something that is clearly in the document."**
1. Was the passage retrieved at all? Look at `sources[]` in the response, or in
   `GET /collections/local_rag_chunks/points/search` in the Qdrant dashboard. If the
   chunk is missing, raise `TOP_K` (5 → 8) and lower `MIN_SCORE` (0.25 → 0.15).
2. If the chunk *is* retrieved but the answer is missing it, the context was truncated
   by `MAX_CONTEXT_CHARS`. Raise it (and `NUM_CTX` to match) or lower `TOP_K` so the
   strongest chunks fit instead of five mediocre ones.
3. If the chunk is retrieved and present but ignored, the chunk may be too big and
   dominated by one topic — lower `CHUNK_SIZE`.

**"Answers mix up documents / one document poisons the rest."** Pass `document_id` with
the question to scope retrieval, or check the `document_name` values in `sources[]`.
Duplicate uploads with slightly different bytes produce different `document_id`s; delete
the old one from the Library tab.

**"Retrieval keeps returning the same chunk for every question."** Almost always
overlap that is too large relative to `CHUNK_SIZE` (overlap ≥ 50% makes the index
mostly duplicates) or a `MIN_SCORE` far below the top score. Try overlap 100–200.

**"Tables and numbers are wrong."** PDF table extraction flattens cells into running
text, so a row can lose its header. Chunk boundaries at paragraph level keep rows
together; if a table spans pages, keep the source page in the citation and check the
extracted text in the n8n execution log (`Chunk Document` node output) before blaming
the model.

**"Scanned PDF returns no text."** There is no OCR in this stack by design.
`no_text_layer` means the PDF has no embedded text layer. Run OCR first
(`ocrmypdf in.pdf out.pdf` adds one) and upload the result.

## Cost of a change

Changing any chunking setting requires re-uploading the document: the old vectors keep
the old boundaries. `make qdrant-reset` wipes the collection entirely — use it when
switching embedding models (the vector size changes) or when you want a clean slate.
