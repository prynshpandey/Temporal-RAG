# Operations runbook

What to do when something is wrong, and what "wrong" means here. Written for
the failure modes this system actually has, not the ones a template lists.

## First move

```bash
make health          # are all six services up and answering
make logs            # n8n runs
make backend-logs    # backend
make validate        # config sanity
```

`make health` checks each container, not just that the port is open. Start
there. A service that is up but returning errors is the common case, and a port
check will call that healthy.

## Is the system working at all?

```bash
make seed-corpus     # six documents that change over time
make eval            # 19 cases, 12 dimensions, prints a scorecard
```

`make eval` is the fastest honest answer to "is this thing working". It reports
`temporal_leakage` and `abstention` at 1.0 on a healthy system. If those drop,
something is genuinely wrong rather than merely degraded. A drop in
`answer_value` alone usually means the model is rate-limited, which is not a
fault.

Every gate:

| target | proves |
|---|---|
| `make test` | the original 20 checks, unchanged |
| `make test-backend` | 136 unit checks |
| `make test-parsers` | all nine formats plus rejection paths |
| `make test-ingest` | atomic registration, temporal metadata |
| `make test-n8n-ingest` | the legacy webhook path end to end |
| `make test-retrieval` | as-of correctness, hybrid, reranking |
| `make test-answer` | citations, abstention, degradation |
| `make test-state` | snapshots, exclusions, revision chains |
| `make test-compare` | change detection, conflicts |
| `make test-frontend` | UI renderers against captured payloads |
| `make eval` | the scorecard above |

Run them all: `make validate health test test-backend test-parsers test-ingest
test-n8n-ingest test-retrieval test-answer test-state test-compare
test-frontend eval`

## Answers cite documents from the future

This is the failure that matters. Check in this order:

1. `make eval`. If `temporal_leakage` is below 1.0, it reproduces — do not debug
   from a single manual query.
2. Every returned hit carries `effective_date`. `POST /api/v1/query` with the
   same `as_of` shows exactly what was in scope, without a model in the path.
3. The year is in the question, not the window. "What was revenue in FY2025"
   with no `as_of` means *now*, not 2025. Set `as_of` explicitly.
4. Upload date is not effective date. A document uploaded today about 2023 is
   valid for any `as_of` after its `effective_date`. A document with no date at
   all falls back to upload time, and is reported as `unknown` in a snapshot.

## The model is unavailable

Expected, and designed for. `mode` becomes `extractive` and the answer is the
passages quoted verbatim with the reason stated. `llm.provider` is `null` and
`usage.calls` is `0`, so an unavailable model is never reported as a used one.

```bash
curl -s localhost:8000/api/v1/answer -X POST -H 'Content-Type: application/json' \
  -d '{"question":"...","as_of":"2024-06-30"}' | python3 -m json.tool | head -20
```

Distinguish the causes, because one of them is not a fault:

| symptom | cause | action |
|---|---|---|
| `429 ... tokens per day (TPD)` | daily token budget spent | wait for the reset, given in the message |
| `429 ... tokens per minute (TPM)` | short-window rate | wait; `GROQ_MAX_RETRIES` already backs off |
| `429 ... Request too large for model` | **read the rest of the message** | see below |
| `401 Invalid API Key` | key revoked or rotated | see the rotation section |
| empty answer, no error | model returned nothing | check `make backend-logs` |

`Request too large` is not a diagnosis, it is a phrase Groq uses for several
quota conditions at once, and with the daily budget spent it appears *instead of*
the TPD message. It is not evidence that the prompt is too long: the same request
succeeds once the budget resets, at the same size.

Read the whole message before changing anything. It names the limit, the amount
used, the amount requested, and when it resets. Lowering `TOP_K` or
`MAX_CONTEXT_CHARS` shrinks the request by a few hundred tokens against a
200,000-token daily budget, so it changes nothing and costs you context you
needed. A genuine size problem is one where a small request also fails, and it
says so in the message with a token count and a context limit.

Retrieval, state and comparison never touch the model and keep working. A total
outage degrades the product to a search engine, not to an error page.

## Rotating the Groq key

The key lives only in `.env` (`0600`, gitignored). It appears in no committed
file, no n8n workflow, and no log. Confirmed by scanning the tree for
`gsk_`-prefixed strings.

```bash
# 1. create a new key in the Groq console, then revoke the old one
# 2. write it into .env
sed -i 's/^GROQ_API_KEY=.*/GROQ_API_KEY=gsk_…/' .env

# 3. apply it
sg docker -c "docker compose up -d backend"

# 4. confirm the new key is live and the old one is gone
sg docker -c "curl -s -X POST localhost:8000/api/v1/answer \
  -H 'Content-Type: application/json' \
  -d '{\"question\":\"What was the customer churn rate?\",\"as_of\":\"2024-06-30\"}'" \
  | python3 -c 'import json,sys; print(json.load(sys.stdin)["llm"])'
```

A working key gives `provider: "groq"` with `calls >= 1`. A revoked one gives
`provider: null` and an `extractive` answer. Both are safe states; only the
second means the key needs attention.

Rotation needs no rebuild and no restart of anything except the backend. The
frontend, n8n and the database are unaffected.

## A document is missing from a snapshot

`GET /api/v1/state?as_of=…` lists what was withheld and why. The reason is the
diagnosis:

| reason | meaning | usually |
|---|---|---|
| `dated_after_window` | `effective_date` is after `as_of` | correct |
| `expired_before_window` | `valid_until` already passed | correct |
| `unknown` | no date on the document | check ingestion metadata |

If a document should be in scope and is not, compare its stored dates against
the window before touching code:

```bash
sg docker -c "docker compose exec -T postgres psql -U btm -d business_time_machine \
  -c \"select name, effective_date, valid_from, valid_until, uploaded_at from documents order by effective_date\""
```

## Qdrant and the database disagree

Retrieval fuses a SQL row with a Qdrant hit, so both have to agree about which
knowledge exists at a point in time. A correct filter in only one of them is not
enough — the other can still admit knowledge that should not be there.

The Qdrant filter is pinned to the SQL clauses in `services/retrieval.py`:

| SQL clause | Qdrant condition |
|---|---|
| `effective_date <= as_of`, else `uploaded_at <= as_of` | `doc_ts <= as_of` else (`doc_ts` null and `request_ts <= as_of`) |
| `valid_until IS NULL OR valid_until > as_of` | `must_not` `valid_until <= as_of` |
| `valid_from IS NULL OR valid_from <= end` | `must_not` `valid_from > end` |

The validity conditions only work because `valid_from` and `valid_until` are in
the point payload. They were not, which meant the vector path silently ignored
expiry while the SQL path enforced it — the exact failure this system exists to
prevent, and invisible to `make eval` because no corpus document had a validity
bound.

If you add a field that the filter reads, three things have to move together:
the payload in `n8n/workflows/05_btm_ingest.json` and
`backend/tests/seed_corpus.py`, `PAYLOAD_INDEXES` in
`backend/app/clients/qdrant.py`, and a real index on the collection:

```bash
python3 scripts/setup_qdrant.py          # reconciles indexes, safe to re-run
```

`setup_qdrant.py` reads the index list out of the backend source rather than
keeping its own copy. It used to keep its own copy, with a comment saying the two
were kept in sync, and the drift was silent — the filter gained conditions on
fields that had no index, so they still returned correct results while scanning
the whole collection. An unindexed date field is a performance cliff, not a
correctness bug, which is what makes it easy to leave behind.

To confirm the filter against live Qdrant rather than by reading it, insert a
point with a `valid_until` in the past and count it through
`temporal_filter()` at three dates: before it was known, while valid, and after
expiry. Expect 0, 1, 0. `backend/tests/test_qdrant_filters.py` pins the clauses;
only a live count proves Qdrant agrees with them.

## The frontend temporal tabs are blank

`frontend/time.js` calls the backend on `:8000` while the page is served from
`:8080`, so it depends on `ALLOWED_ORIGINS`. A CORS error in the console is the
cause. The legacy Ask and Library tabs go through n8n and are unaffected — that
separation is deliberate.

`make test-frontend` skips rather than passes when `node` is absent. A skip is
not a green result. Refresh its fixtures with `make test-fixtures` after any
change to a response shape.

## Recovering state

Everything is derived; nothing is precious except the documents.

```bash
make seed-corpus      # reset to the six-document evaluation corpus
```

To wipe all data and start clean, drop and recreate the database, empty the
Qdrant collection, then `make seed-corpus`. Document blobs live on the ingest
container's volume, so a rebuild drops them; re-upload from source.

`document_id` is derived from a sha256 of the content, so re-ingesting the same
file is idempotent and the identifiers are stable across a rebuild.

## What is not covered by any check

State these plainly rather than letting a green suite imply otherwise.

- **The evaluation corpus is six synthetic documents.** Nineteen cases over it
  is a floor. It demonstrates the temporal logic is correct, not that it
  generalises.
- **No OCR.** Scanned PDFs are rejected at upload, not silently mangled. Real
  scans need OCR before ingestion.
- **Reranking features are English-tuned.** A passage in another language scores
  near-zero coverage and will lose to ties.
- **The corpus is English and the extractor is regex-based.** Metric extraction
  handles the phrasings in the seed corpus and the shapes in
  `backend/tests/test_facts.py`. It will not generalise to arbitrary prose, and
  `net loss` / `net profit` are tracked as separate metrics with no sign-flip
  correlation.
- **Conflict detection needs contemporaneous evidence.** Two documents more than
  `CONFLICT_WINDOW_DAYS` apart never conflict, by design.
- **The DOM shim is not a browser.** `make test-frontend` verifies data binding
  and degradation, not layout or CSS. The visual result needs a human.
- **The corpus has no validity bounds.** Every seed document has `valid_until`
  and `valid_from` null, so the expiry path is verified by filter tests and a
  live Qdrant probe rather than by the evaluation. If you add expiring knowledge
  to `seed_corpus.py`, add evaluation cases for it too.
