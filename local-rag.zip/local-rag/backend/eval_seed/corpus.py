"""The seed corpus: a small company whose facts change over time.

Every retrieval guarantee this project claims is only meaningful against data
that *contradicts itself over time*. A corpus where one document holds the
current answer cannot show whether an as-of query really excluded the newer
knowledge, because there is nothing newer to exclude.

So the corpus is built as revisions of the same six facts, each restated at a
later date:

    revenue            41.2 -> 48.9 -> 57.4 million euro
    headcount          180 -> 214 -> 260 people
    headquarters       Utrecht -> Rotterdam
    flagship product   in pilot -> general availability
    churn              4.1% -> 3.2%
    segment share      Atlas 22% -> 31%

Questions in ``eval`` then have exactly one correct answer *per point in time*,
which is what makes an as-of query checkable rather than merely plausible.
"""

from __future__ import annotations

import pathlib
import textwrap

# The corpus lives as real files in the repo: the backend directory is mounted
# read-only in the container, so a seeding script cannot write its own input.
# Run ``python3 scripts/write_corpus.py`` after editing DOCUMENTS to refresh them.
SEED_DIR = pathlib.Path(__file__).resolve().parent / "data"

# date, name, body. Written as plain text so the deterministic parser and the
# date extractor both see plain sentences rather than PDF layout noise.
DOCUMENTS: list[tuple[str, str, str]] = [
    (
        "2023-06-30",
        "helios-annual-report-2023.md",
        """
        # Helios Robotics N.V. - Annual Report 2023

        Report date: 30 June 2023. Fiscal year 2023.

        ## 1. Financial summary

        Revenue for FY2023 reached 41.2 million euro, up from 36.5 million euro
        in FY2022. Gross margin was 47.0 percent. The company reported a net
        loss of 3.1 million euro.

        ## 2. People

        Helios Robotics was founded in 2011 by Elena Fischer and Rajan Mehta.
        The company is headquartered in Utrecht, the Netherlands. At the end of
        FY2023 the number of employees was 180, of whom 64 work in research and
        development.

        ## 3. Products

        The Atlas division grew 14 percent and contributes 22 percent of group
        revenue. Atlas ships the Corvus platform, which is still in closed pilot
        with three enterprise customers. General availability is scheduled for
        FY2025.

        ## 4. Risk factors

        Customer churn was 4.1 percent in FY2023. The company depends on a
        single contract manufacturer in Eindhoven.
        """,
    ),
    (
        "2024-06-30",
        "helios-annual-report-2024.md",
        """
        # Helios Robotics N.V. - Annual Report 2024

        Report date: 30 June 2024. Fiscal year 2024.

        ## 1. Financial summary

        Revenue for FY2024 reached 48.9 million euro, an increase of 19 percent
        over FY2023. Gross margin improved to 51.0 percent and the company moved
        from a net loss to a net profit of 2.4 million euro.

        ## 2. People

        Helios Robotics was founded in 2011 by Elena Fischer and Rajan Mehta.
        The company relocated its headquarters to Rotterdam, the Netherlands,
        in March 2024. At the end of FY2024 the number of employees was 214.

        ## 3. Products

        The Atlas division grew 26 percent and contributes 31 percent of group
        revenue. Atlas ships the Corvus platform, which entered general
        availability in April 2024 after two years of closed pilot.

        ## 4. Risk factors

        Customer churn fell to 3.6 percent in FY2024. Supply chain concentration
        remains a risk, with a second contract manufacturer qualified in 2024.
        """,
    ),
    (
        "2025-03-31",
        "helios-q1-2025-update.md",
        """
        # Helios Robotics N.V. - Q1 2025 Update

        Report date: 31 March 2025.

        ## 1. Financial summary

        Revenue in Q1 2025 was 13.8 million euro, against 11.4 million euro in
        Q1 2024. Management confirms full year 2025 guidance of 57.4 million
        euro.

        ## 2. People

        The company is headquartered in Rotterdam, the Netherlands. Headcount at
        the end of March 2025 was 241, with hiring focused on research and
        development.

        ## 3. Products

        The Atlas division contributes 34 percent of group revenue. The Corvus
        platform is in general availability and now has eleven enterprise
        customers. The Lighthouse project moved to closed pilot in March 2025.
        """,
    ),
    (
        "2025-06-30",
        "helios-annual-report-2025.md",
        """
        # Helios Robotics N.V. - Annual Report 2025

        Report date: 30 June 2025. Fiscal year 2025.

        ## 1. Financial summary

        Revenue for FY2025 reached 57.4 million euro, up 18 percent on FY2024.
        Gross margin improved to 55.0 percent and net profit was 6.2 million
        euro.

        ## 2. People

        Helios Robotics was founded in 2011 by Elena Fischer and Rajan Mehta.
        The company is headquartered in Rotterdam, the Netherlands. The number of
        employees at the end of FY2025 was 260, and the Rotterdam site is now
        the largest in the group.

        ## 3. Products

        The Atlas division grew 9 percent and contributes 36 percent of group
        revenue. The Corvus platform reached general availability in 2024 and
        had nineteen enterprise customers by the end of FY2025.

        ## 4. Risk factors

        Customer churn fell further to 3.2 percent in FY2025. The Lighthouse
        project remains in closed pilot, with general availability scheduled for
        the second quarter of FY2026.
        """,
    ),
    (
        "2024-01-31",
        "helios-corvus-launch-note.md",
        """
        # Helios Robotics N.V. - Corvus Launch Note

        Note date: 31 January 2024.

        ## Announcement

        Helios Robotics announced that the Corvus platform, built by the Atlas
        division, has completed its closed pilot and will reach general
        availability in April 2024. Three design partners signed multi-year
        contracts.

        The company, headquartered in Rotterdam, the Netherlands, expects
        Corvus to account for roughly a quarter of group revenue by 2025.
        """,
    ),
    (
        "2023-09-15",
        "helios-utrecht-office-closure.md",
        """
        # Helios Robotics N.V. - Office Closure Note

        Note date: 15 September 2023.

        ## Announcement

        Helios Robotics will close its Utrecht office on 31 December 2023 and
        move the remaining staff to Rotterdam, the Netherlands. The company
        remains headquartered in Utrecht until the relocation is complete in
        March 2024.

        The closure affects 24 employees, who will all be relocated. Revenue for
        FY2023 is unchanged at 41.2 million euro.
        """,
    ),
]


def write_corpus(directory: pathlib.Path) -> list[pathlib.Path]:
    """(Re)write the corpus to ``directory``. Host-side only; see SEED_DIR."""
    directory.mkdir(parents=True, exist_ok=True)
    written: list[pathlib.Path] = []
    for _date, name, body in DOCUMENTS:
        path = directory / name
        path.write_text(textwrap.dedent(body).strip() + "\n", encoding="utf-8")
        written.append(path)
    return written


def corpus_paths(directory: pathlib.Path | None = None) -> list[pathlib.Path]:
    """The corpus files, in chronological order. Fails loudly if they are gone."""
    target = directory or SEED_DIR
    missing = [name for _d, name, _b in DOCUMENTS if not (target / name).exists()]
    if missing:
        raise FileNotFoundError(
            f"seed corpus files are missing from {target}: {', '.join(missing)}"
            "\nRun: python3 scripts/write_corpus.py"
        )
    return [target / name for _d, name, _b in DOCUMENTS]
