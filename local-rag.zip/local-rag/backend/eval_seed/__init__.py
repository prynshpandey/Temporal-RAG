"""Seed dataset generator for the Business Time Machine.

The Acme Corp corpus is generated here (multi-format business documents with a
deliberate information arc) and pushed through the real ingest webhook, so the
evaluation suite exercises the production path rather than a fixture loader.
"""
