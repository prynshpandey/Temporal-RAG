# Helios Robotics N.V. - Office Closure Note

Note date: 15 September 2023.

## Announcement

Helios Robotics will close its Utrecht office on 31 December 2023 and
move the remaining staff to Rotterdam, the Netherlands. The company
remains headquartered in Utrecht until the relocation is complete in
March 2024.

The closure affects 24 employees, who will all be relocated. Revenue for
FY2023 is unchanged at 41.2 million euro.
