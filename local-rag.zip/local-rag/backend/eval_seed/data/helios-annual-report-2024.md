# Helios Robotics N.V. - Annual Report 2024

Report date: 30 June 2024. Fiscal year 2024.

## 1. Financial summary

Revenue for FY2024 reached 48.9 million euro, an increase of 19 percent
over FY2023. Gross margin improved to 51.0 percent and the company moved
from a net loss to a net profit of 2.4 million euro.

## 2. People

Helios Robotics was founded in 2011 by Elena Fischer and Rajan Mehta.
The company relocated its headquarters to Rotterdam, the Netherlands,
in March 2024. At the end of FY2024 the number of employees was 214.

## 3. Products

The Atlas division grew 26 percent and contributes 31 percent of group
revenue. Atlas ships the Corvus platform, which entered general
availability in April 2024 after two years of closed pilot.

## 4. Risk factors

Customer churn fell to 3.6 percent in FY2024. Supply chain concentration
remains a risk, with a second contract manufacturer qualified in 2024.
