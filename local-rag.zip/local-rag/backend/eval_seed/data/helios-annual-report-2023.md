# Helios Robotics N.V. - Annual Report 2023

Report date: 30 June 2023. Fiscal year 2023.

## 1. Financial summary

Revenue for FY2023 reached 41.2 million euro, up from 36.5 million euro
in FY2022. Gross margin was 47.0 percent. The company reported a net
loss of 3.1 million euro.

## 2. People

Helios Robotics was founded in 2011 by Elena Fischer and Rajan Mehta.
The company is headquartered in Utrecht, the Netherlands. At the end of
FY2023 the number of employees was 180, of whom 64 work in research and
development.

## 3. Products

The Atlas division grew 14 percent and contributes 22 percent of group
revenue. Atlas ships the Corvus platform, which is still in closed pilot
with three enterprise customers. General availability is scheduled for
FY2025.

## 4. Risk factors

Customer churn was 4.1 percent in FY2023. The company depends on a
single contract manufacturer in Eindhoven.
