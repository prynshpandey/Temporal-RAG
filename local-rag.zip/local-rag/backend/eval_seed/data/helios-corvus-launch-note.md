# Helios Robotics N.V. - Corvus Launch Note

Note date: 31 January 2024.

## Announcement

Helios Robotics announced that the Corvus platform, built by the Atlas
division, has completed its closed pilot and will reach general
availability in April 2024. Three design partners signed multi-year
contracts.

The company, headquartered in Rotterdam, the Netherlands, expects
Corvus to account for roughly a quarter of group revenue by 2025.
