# Helios Robotics N.V. - Q1 2025 Update

Report date: 31 March 2025.

## 1. Financial summary

Revenue in Q1 2025 was 13.8 million euro, against 11.4 million euro in
Q1 2024. Management confirms full year 2025 guidance of 57.4 million
euro.

## 2. People

The company is headquartered in Rotterdam, the Netherlands. Headcount at
the end of March 2025 was 241, with hiring focused on research and
development.

## 3. Products

The Atlas division contributes 34 percent of group revenue. The Corvus
platform is in general availability and now has eleven enterprise
customers. The Lighthouse project moved to closed pilot in March 2025.
