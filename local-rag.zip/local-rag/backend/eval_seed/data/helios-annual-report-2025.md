# Helios Robotics N.V. - Annual Report 2025

Report date: 30 June 2025. Fiscal year 2025.

## 1. Financial summary

Revenue for FY2025 reached 57.4 million euro, up 18 percent on FY2024.
Gross margin improved to 55.0 percent and net profit was 6.2 million
euro.

## 2. People

Helios Robotics was founded in 2011 by Elena Fischer and Rajan Mehta.
The company is headquartered in Rotterdam, the Netherlands. The number of
employees at the end of FY2025 was 260, and the Rotterdam site is now
the largest in the group.

## 3. Products

The Atlas division grew 9 percent and contributes 36 percent of group
revenue. The Corvus platform reached general availability in 2024 and
had nineteen enterprise customers by the end of FY2025.

## 4. Risk factors

Customer churn fell further to 3.2 percent in FY2025. The Lighthouse
project remains in closed pilot, with general availability scheduled for
the second quarter of FY2026.
