"""Internal ingest API - the contract between n8n and this backend.

These endpoints are not for browsers. They require ``X-Ingest-Token`` and exist
so the n8n workflow can orchestrate ingest while the backend keeps ownership of
parsing, chunking and every database write::

    POST /api/internal/parse             multipart upload  -> plan (no writes)
    POST /api/internal/embed             texts             -> vectors
    POST /api/internal/ingest/register   plan + extraction  -> one transaction
    POST /api/internal/ingest/finalize   document_id       -> status flip
    POST /api/internal/ingest/fail       document_id + why -> status=failed
    DELETE /api/internal/ingest/document document_id       -> cascade delete

The upload is streamed to disk, parsed, and the file is deleted again inside the
same request: the durable copy of the text is PostgreSQL, not the filesystem.
"""

from __future__ import annotations

import hmac
import json
import time
from datetime import date
from typing import Any

from fastapi import APIRouter, Depends, File, Header, UploadFile

from app.config import settings
from app.errors import Unauthorized, ValidationFailed
from app.logging import get_logger, log_event
from app.services import ingestion

logger = get_logger("btm.api.internal")
router = APIRouter(prefix="/api/internal", tags=["internal"])


async def require_ingest_token(x_ingest_token: str = Header(default="")) -> None:
    """Shared-secret auth for the ingest surface.

    Compared with :func:`hmac.compare_digest` so a wrong token cannot be
    discovered by timing the response.
    """
    if not settings.ingest_token:
        raise ValidationFailed(
            "INGEST_TOKEN is not set, so the internal API is disabled.",
            hint="Generate one in .env (make init does this) and restart the backend",
            code="ingest_token_missing",
        )
    if not hmac.compare_digest(x_ingest_token, settings.ingest_token):
        raise Unauthorized()


@router.post("/parse", dependencies=[Depends(require_ingest_token)])
async def parse_upload_endpoint(file: UploadFile = File(...)) -> dict[str, Any]:
    """Parse one upload and return the ingest plan. Writes nothing."""
    if not file.filename:
        raise ValidationFailed("The upload has no filename.", hint="Send the file as 'file'")
    request_id = ingestion.new_request_id()
    started = time.perf_counter()

    async def body_stream():
        # FastAPI already spooled the multipart body to a temporary file, so the
        # request stream is spent. Reading it in blocks keeps memory bounded
        # (Starlette spills to disk past 1 MB) instead of loading 100 MB at once.
        while True:
            block = await file.read(1024 * 1024)
            if not block:
                return
            yield block

    path, sha256, size, safe_name = await ingestion.save_upload(body_stream(), file.filename)
    try:
        plan = await ingestion.build_plan(path, safe_name, file.content_type, sha256, size)
    finally:
        ingestion.cleanup_upload(path)

    plan["request_id"] = request_id
    # When this knowledge entered the system. Retrieval needs it for the undated
    # case: a document with no extractable date is known from its ingest date, not
    # from the epoch. The Qdrant payload carries the same value as request_ts.
    plan["request_ts"] = date.today().isoformat()
    plan["elapsed_ms"] = int((time.perf_counter() - started) * 1000)
    log_event(
        logger,
        "parsed",
        request_id=request_id,
        document_id=plan["document_id"],
        name=safe_name,
        document_type=plan["document_type"],
        vectors=plan["counts"]["vectors"],
    )
    return plan


@router.post("/extract", dependencies=[Depends(require_ingest_token)])
async def extract_endpoint(payload: dict[str, Any]) -> dict[str, Any]:
    """Temporal metadata for a parsed plan: dates, entities, events, facts.

    Dates come from the deterministic pass (regex, always) and the model only
    fills in the language-shaped parts. The result is what
    ``/ingest/register`` expects as ``extracted``.
    """
    from app.llm.provider import GroqUsage
    from app.services import extraction

    plan = payload.get("plan")
    if not isinstance(plan, dict) or not plan.get("document_id"):
        raise ValidationFailed("Send the 'plan' object returned by /api/internal/parse.")

    usage = GroqUsage()
    started = time.perf_counter()
    extracted = await extraction.extract(plan, usage=usage)
    extracted["llm_usage"] = usage.as_dict()
    # None means no model answered at all: deterministic extraction only.
    extracted["llm_provider"] = usage.provider
    extracted["extract_ms"] = int((time.perf_counter() - started) * 1000)
    return extracted


@router.post("/embed", dependencies=[Depends(require_ingest_token)])
async def embed_endpoint(payload: dict[str, Any]) -> dict[str, Any]:
    """Batched local embeddings for the units of a plan.

    The batching lives here because the backend can reuse one connection and one
    event loop; n8n sends the texts, gets the vectors back, and stays the
    orchestrator of what happens next.
    """
    from app.clients.ollama import embed_batch

    texts = payload.get("texts")
    if not isinstance(texts, list) or not texts:
        raise ValidationFailed("Send a non-empty 'texts' array.", hint='{"texts": ["..."]}')
    if len(texts) > 512:
        raise ValidationFailed(
            f"{len(texts)} texts in one call; the limit is 512.",
            hint="Split the request, or raise the batch size in settings",
        )
    vectors = await embed_batch([str(t) for t in texts])

    # The caller may pass the point ids it expects back. An HTTP node replaces the
    # item it was given, so without this echo an orchestrator can only pair a
    # vector with its chunk by assuming the response kept the request's order.
    ids = payload.get("ids")
    if ids is not None:
        if not isinstance(ids, list) or len(ids) != len(texts):
            raise ValidationFailed(
                f"'ids' has {len(ids) if isinstance(ids, list) else '?'} entries but "
                f"'texts' has {len(texts)}; they must line up.",
                hint="Send one id per text, in the same order.",
            )
        ids = [int(i) for i in ids]

    return {
        "count": len(vectors),
        "dimensions": len(vectors[0]) if vectors else 0,
        "vectors": vectors,
        "ids": ids,
    }


@router.post("/ingest/register", dependencies=[Depends(require_ingest_token)])
async def register_endpoint(payload: dict[str, Any]) -> dict[str, Any]:
    """Persist a parsed document with its extracted temporal metadata."""
    plan = payload.get("plan")
    if not isinstance(plan, dict) or not plan.get("document_id") or not plan.get("units"):
        raise ValidationFailed(
            "Send the 'plan' object returned by /api/internal/parse.",
            hint="Do not rebuild it by hand - the chunk ids must match the parser output",
        )
    extracted = payload.get("extracted") or {}
    if not isinstance(extracted, dict):
        raise ValidationFailed("'extracted' must be an object.")
    ingestion.validate_extracted(extracted)
    result = await ingestion.register(plan, extracted)
    result["request_id"] = payload.get("request_id")
    return result


@router.post("/ingest/finalize", dependencies=[Depends(require_ingest_token)])
async def finalize_endpoint(payload: dict[str, Any]) -> dict[str, Any]:
    """Flip a document to ``indexed`` once its vectors are in Qdrant."""
    from app.db.pool import execute

    document_id = payload.get("document_id")
    if not document_id:
        raise ValidationFailed("Send 'document_id'.")
    status = "indexed" if payload.get("ready", True) else "pending"
    await execute(
        "UPDATE documents SET status = $2, updated_at = now() WHERE document_id = $1",
        document_id,
        status,
    )
    return {"document_id": document_id, "status": status}


@router.post("/ingest/fail", dependencies=[Depends(require_ingest_token)])
async def fail_endpoint(payload: dict[str, Any]) -> dict[str, Any]:
    """Record a failed ingest so the library can show why a document is missing."""
    from app.db.pool import execute

    document_id = payload.get("document_id")
    if not document_id:
        raise ValidationFailed("Send 'document_id'.")
    reason = str(payload.get("error") or "unknown error")[:500]
    await execute(
        """
        INSERT INTO documents (document_id, name, document_type, status, metadata, updated_at)
        VALUES ($1, $2, 'unknown', 'failed', $3::jsonb, now())
        ON CONFLICT (document_id) DO UPDATE SET
            status = 'failed',
            metadata = documents.metadata || $3::jsonb,
            updated_at = now()
        """,
        document_id,
        payload.get("name") or document_id,
        json.dumps({"error": reason}),
    )
    return {"document_id": document_id, "status": "failed", "error": reason}


@router.delete("/ingest/document", dependencies=[Depends(require_ingest_token)])
async def delete_document_endpoint(payload: dict[str, Any]) -> dict[str, Any]:
    """Delete a document and its vectors, ignoring Qdrant failures.

    PostgreSQL is the source of truth: if the vector store is unreachable the row
    still goes, and the leftover points are removed by
    ``scripts/cleanup_orphans.py``.
    """
    from app.clients.qdrant import delete_document_vectors
    from app.repositories.documents import delete_document

    document_id = payload.get("document_id")
    if not document_id:
        raise ValidationFailed("Send 'document_id'.")
    deleted = await delete_document(document_id)
    vectors = await delete_document_vectors(document_id)
    return {"document_id": document_id, "deleted": deleted, "vectors_deleted": vectors}
