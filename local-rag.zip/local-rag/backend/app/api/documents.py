"""Document library: list, inspect, chunk-level detail, delete.

``GET /api/v1/documents`` replaces the old "library" webhook for new clients and
adds the temporal metadata (document date, effective date, events) the Time
Machine UI needs.
"""

from __future__ import annotations

from datetime import date
from typing import Any

from fastapi import APIRouter, Query

from app.clients import qdrant
from app.config import settings
from app.errors import BtmError
from app.logging import get_logger, log_event
from app.repositories import documents as repo

logger = get_logger("btm.api.documents")
router = APIRouter(tags=["documents"])


@router.get("/documents")
async def list_documents(
    limit: int = Query(50, ge=1, le=500),
    offset: int = Query(0, ge=0),
    entity: str | None = None,
    document_type: str | None = None,
    as_of: str | None = Query(
        None, description="Only documents that were already known on this ISO date"
    ),
    start: str | None = Query(None, description="Range start (ISO date); needs 'end'"),
    end: str | None = Query(None, description="Range end (ISO date); needs 'start'"),
) -> dict[str, Any]:
    """The library. Pass ``as_of`` to see it as it was on a past date."""
    if as_of:
        window = await repo.documents_in_window(as_of=_iso(as_of), entity=entity)
        return {
            "ok": True,
            "collection": settings.qdrant_collection,
            "as_of": as_of,
            "total": len(window),
            "documents": window,
        }
    if bool(start) != bool(end):
        raise BtmError(
            "Give both 'start' and 'end' for a range, or only 'as_of' for a single date.",
            code="invalid_date_range",
            status_code=400,
            hint="e.g. /api/v1/documents?start=2024-01-01&end=2024-12-31",
        )
    if start and end:
        window = await repo.documents_in_window(
            start=_iso(start), end=_iso(end), entity=entity
        )
        return {
            "ok": True,
            "collection": settings.qdrant_collection,
            "start": start,
            "end": end,
            "total": len(window),
            "documents": window,
        }
    result = await repo.list_documents(
        limit=limit, offset=offset, entity=entity, document_type=document_type
    )
    return {
        "ok": True,
        "collection": settings.qdrant_collection,
        "total": result["total"],
        "documents": result["documents"],
    }


def _iso(value: str) -> date:
    try:
        return date.fromisoformat(value[:10])
    except ValueError as exc:
        raise BtmError(
            f"{value!r} is not an ISO date.",
            code="invalid_date",
            status_code=400,
            hint="Use YYYY-MM-DD",
        ) from exc


@router.get("/documents/{document_id}")
async def get_document(document_id: str) -> dict[str, Any]:
    document = await repo.get_document(document_id)
    if not document:
        raise BtmError(
            f"No document with id {document_id}.",
            code="document_not_found",
            status_code=404,
            hint="List what is indexed with GET /api/v1/documents",
        )
    document["sections"] = await _sections(document_id)
    document["events"] = await _events(document_id)
    # The UI shows entity chips on a document, and the entity filter in the
    # library resolves through the same table, so one query serves both.
    return {
        "ok": True,
        "document": document,
        "entities": await _entities(document_id),
        "facts": await _facts(document_id),
    }


@router.get("/documents/{document_id}/chunks")
async def get_chunks(
    document_id: str, level: str = Query("chunk", pattern="^(chunk|section)$")
) -> dict[str, Any]:
    document = await repo.get_document(document_id)
    if not document:
        raise BtmError(
            f"No document with id {document_id}.",
            code="document_not_found",
            status_code=404,
            hint="List what is indexed with GET /api/v1/documents",
        )
    chunks = await repo.get_chunks(document_id)
    if level == "section":
        chunks = await _sections(document_id)
    return {"ok": True, "document_id": document_id, "level": level, "items": chunks}


@router.delete("/documents/{document_id}")
async def delete_document(document_id: str) -> dict[str, Any]:
    document = await repo.get_document(document_id)
    if not document:
        raise BtmError(
            f"No document with id {document_id}.",
            code="document_not_found",
            status_code=404,
            hint="List what is indexed with GET /api/v1/documents",
        )
    # Every embedding level of the document goes, not just the chunk vectors.
    await qdrant.delete_by_filter(
        {"must": [{"key": "document_id", "match": {"value": document_id}}]}
    )
    await repo.delete_document(document_id)
    log_event(logger, "document_deleted", document_id=document_id)
    return {"status": "deleted", "document_id": document_id}


async def _sections(document_id: str) -> list[dict[str, Any]]:
    from app.db.pool import fetch

    rows = await fetch(
        """
        SELECT section_id, parent_section_id, title, level, ordinal, page, text,
               char_count, qdrant_point_id
        FROM document_sections WHERE document_id = $1 ORDER BY ordinal
        """,
        document_id,
    )
    return [dict(row) for row in rows]


async def _events(document_id: str) -> list[dict[str, Any]]:
    from app.db.pool import fetch

    rows = await fetch(
        """
        SELECT event_id, event_date, date_text, event_type, title, description,
               entity_names, confidence
        FROM events WHERE document_id = $1
        ORDER BY event_date NULLS LAST, event_id
        """,
        document_id,
    )
    events = []
    for row in rows:
        item = dict(row)
        item["event_date"] = item["event_date"].isoformat() if item.get("event_date") else None
        events.append(item)
    return events


async def _entities(document_id: str) -> list[dict[str, Any]]:
    from app.db.pool import fetch

    rows = await fetch(
        """
        SELECT e.name, e.entity_type, em.role, em.chunk_id, em.event_id
        FROM entity_mentions em
        JOIN entities e ON e.entity_id = em.entity_id
        WHERE em.document_id = $1
        ORDER BY e.name, em.chunk_id NULLS LAST
        """,
        document_id,
    )
    return [dict(row) for row in rows]


async def _facts(document_id: str) -> list[dict[str, Any]]:
    from app.db.pool import fetch

    rows = await fetch(
        """
        SELECT subject, predicate, object_value, event_date, confidence, entity_names
        FROM facts WHERE document_id = $1
        ORDER BY event_date NULLS LAST, subject
        """,
        document_id,
    )
    facts = []
    for row in rows:
        item = dict(row)
        item["event_date"] = item["event_date"].isoformat() if item.get("event_date") else None
        facts.append(item)
    return facts
