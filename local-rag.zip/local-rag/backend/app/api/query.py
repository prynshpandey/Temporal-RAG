"""The query surface: point-in-time search with a citation for every claim.

The response is shaped so a caller can check the system's work rather than trust
it: ``filters`` echoes the window that was applied, ``stats`` shows which of the
two retrieval systems actually contributed, and every hit carries the document
and date it came from. A temporal RAG that cannot show its work is just a RAG
with extra confidence.
"""

from __future__ import annotations

import re
import time
from datetime import date, timedelta
from typing import Any

from fastapi import APIRouter, Query
from pydantic import BaseModel, Field

from app.errors import ValidationFailed
from app.logging import get_logger, log_event
from app.services import answering, retrieval

logger = get_logger("btm.api")

router = APIRouter(tags=["query"])

# "as of 2024-06-01", "in Q2 2025", "between 2024-01-01 and 2024-06-30"
_AS_OF = re.compile(
    r"\b(?:as\s+of|as\s+at|on)\s+(\d{4}-\d{2}-\d{2})\b", re.IGNORECASE
)
_QUARTER = re.compile(r"\bq([1-4])\s+(20\d{2})\b", re.IGNORECASE)
_YEAR = re.compile(r"\b(?:in|during)\s+(20\d{2})\b", re.IGNORECASE)
_BETWEEN = re.compile(
    r"\b(?:between|from)\s+(\d{4}-\d{2}-\d{2})\s+(?:and|to|-)\s+(\d{4}-\d{2}-\d{2})\b",
    re.IGNORECASE,
)
# What the caller explicitly asked about, which the question itself is not.
_STOP_PREFIX = re.compile(
    r"^\s*(?:as\s+of|as\s+at|in|during|between|from|between\s+.*?\s+and)\s+[^,?.]*[,?.]\s*",
    re.IGNORECASE,
)

_QUARTER_MONTHS = {"q1": (1, 1), "q2": (4, 1), "q3": (7, 1), "q4": (10, 1)}


class QueryRequest(BaseModel):
    question: str = Field(min_length=1, max_length=2000)
    as_of: str | None = Field(default=None, description="ISO date, or null for today")
    start: str | None = None
    end: str | None = None
    document_ids: list[str] | None = None
    document_types: list[str] | None = None
    entity: str | None = None
    limit: int = Field(default=8, ge=1, le=50)
    with_parents: bool = True


class ParsedWindow:
    def __init__(self) -> None:
        self.as_of: date | None = None
        self.start: date | None = None
        self.end: date | None = None
        self.source = "default"
        self.text_question: str = ""


def _quarter_window(quarter: str, year: int) -> tuple[date, date]:
    start_month, _ = _QUARTER_MONTHS[quarter.lower()]
    start = date(year, start_month, 1)
    end_month = start_month + 3
    if end_month > 12:
        return start, date(year, 12, 31)
    return start, date(year, end_month, 1) - timedelta(days=1)


def parse_window(text: str) -> ParsedWindow:
    """Pull a temporal window out of the question when the caller gave none.

    This is a small, explicit parser rather than a model call: the answer to
    "what did we know in Q2 2025" must be reproducible, and a language model
    guessing at dates is exactly the failure mode this project exists to avoid.
    Unrecognised phrasing falls through to today, and the response says so.
    """
    parsed = ParsedWindow()
    parsed.text_question = _STOP_PREFIX.sub("", text or "").strip() or (text or "").strip()

    match = _BETWEEN.search(text)
    if match:
        parsed.start, parsed.end = date.fromisoformat(match.group(1)), date.fromisoformat(match.group(2))
        parsed.source = "question:range"
        return parsed

    match = _AS_OF.search(text)
    if match:
        parsed.as_of = date.fromisoformat(match.group(1))
        parsed.source = "question:as_of"
        return parsed

    match = _QUARTER.search(text)
    if match:
        # The regex captures the digit only; the lookup is keyed on "q1".."q4".
        parsed.start, parsed.end = _quarter_window("q" + match.group(1), int(match.group(2)))
        parsed.source = f"question:q{match.group(1)}{match.group(2)}"
        return parsed

    match = _YEAR.search(text)
    if match:
        year = int(match.group(1))
        parsed.start, parsed.end = date(year, 1, 1), date(year, 12, 31)
        parsed.source = f"question:{year}"
        return parsed

    return parsed


def _iso(value: str | None, field_name: str) -> date | None:
    if not value:
        return None
    try:
        return date.fromisoformat(value)
    except ValueError as exc:
        raise ValidationFailed(f"{field_name} must be an ISO date (YYYY-MM-DD).") from exc


@router.post("/query")
async def run_query(payload: QueryRequest) -> dict[str, Any]:
    window = parse_window(payload.question) if not payload.start and not payload.as_of else None
    as_of = _iso(payload.as_of, "as_of")
    start = _iso(payload.start, "start")
    end = _iso(payload.end, "end")

    if as_of is None and start is None and window is not None:
        as_of, start, end = window.as_of, window.start, window.end
        source = window.source
        question = window.text_question
    else:
        source = "request"
        question = payload.question

    if (start is None) != (end is None):
        raise ValidationFailed("start and end must be sent together.")

    result = await retrieval.search(
        question or payload.question,
        as_of=as_of,
        start=start,
        end=end,
        document_ids=payload.document_ids,
        document_types=payload.document_types,
        entity=payload.entity,
        limit=payload.limit,
        with_parents=payload.with_parents,
    )
    log_event(
        logger,
        "query",
        as_of=str(as_of) if as_of else None,
        hits=len(result["hits"]),
        window_source=source,
    )
    return {
        "question": payload.question,
        "searched_question": question,
        "filters": {
            "as_of": as_of.isoformat() if as_of else None,
            "start": start.isoformat() if start else None,
            "end": end.isoformat() if end else None,
            "document_ids": payload.document_ids,
            "document_types": payload.document_types,
            "entity": payload.entity,
            "source": source,
        },
        "hits": [hit.as_dict(with_parent=payload.with_parents) for hit in result["hits"]],
        "stats": result["stats"],
    }


class AnswerRequest(QueryRequest):
    max_context_chars: int | None = Field(default=None, ge=500, le=20000)


@router.post("/answer")
async def run_answer(payload: AnswerRequest) -> dict[str, Any]:
    """Answer a question from what was known on a date, with checkable citations.

    Same retrieval as /query, plus synthesis. The difference a caller cares
    about: /query hands back passages, /answer hands back a claim it can verify.
    When the model is unavailable the response is a verbatim quotation rather
    than a paraphrase, and ``mode`` says which happened.
    """
    window = parse_window(payload.question) if not payload.start and not payload.as_of else None
    as_of = _iso(payload.as_of, "as_of")
    start = _iso(payload.start, "start")
    end = _iso(payload.end, "end")
    if as_of is None and start is None and window is not None:
        as_of, start, end = window.as_of, window.start, window.end
        source = window.source
    else:
        source = "request"
    if (start is None) != (end is None):
        raise ValidationFailed("start and end must be sent together.")

    result = await answering.answer(
        window.text_question if window and window.text_question else payload.question,
        as_of=as_of,
        start=start,
        end=end,
        document_ids=payload.document_ids,
        document_types=payload.document_types,
        entity=payload.entity,
        limit=payload.limit,
        max_context_chars=payload.max_context_chars,
    )
    body = result.as_dict()
    body["question"] = payload.question
    # Echo the window that was actually applied, not the one that was sent. With
    # no as_of in the request, retrieval used today, and a response that reports
    # as_of: null reads as "no temporal filter" rather than "today".
    effective_as_of = as_of or result.as_of
    body["filters"] = {
        "as_of": effective_as_of.isoformat() if effective_as_of else None,
        "start": start.isoformat() if start else None,
        "end": end.isoformat() if end else None,
        "document_ids": payload.document_ids,
        "document_types": payload.document_types,
        "entity": payload.entity,
        "source": source,
    }
    return body
