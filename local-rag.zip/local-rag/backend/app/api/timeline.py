"""Timeline: the dated spine of the knowledge base.

The UI needs three things to draw a timeline: which entities exist, which dates
carry events, and the window in which knowledge is actually covered. All three
come from the same two tables, so the timeline can never disagree with the
documents it points at.
"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Query

from app.db.pool import fetch, fetchrow
from app.logging import get_logger

logger = get_logger("btm.api.timeline")
router = APIRouter(tags=["timeline"])


@router.get("/timeline")
async def timeline_overview(limit: int = Query(200, ge=1, le=2000)) -> dict[str, Any]:
    """Everything: entities, dated events, and the overall knowledge window."""
    entities = await fetch(
        """
        SELECT e.name, e.entity_type, e.mention_count, e.first_seen, e.last_seen,
               (SELECT count(DISTINCT m.document_id) FROM entity_mentions m
                 WHERE m.entity_id = e.entity_id) AS document_count
        FROM entities e
        WHERE e.mention_count > 0
        ORDER BY e.mention_count DESC, e.name
        LIMIT $1
        """,
        limit,
    )
    event_rows = await fetch(
        """
        SELECT e.event_id, e.document_id, d.name AS document_name, e.event_date,
               e.event_type, e.title, e.description, e.entity_names
        FROM events e
        JOIN documents d ON d.document_id = e.document_id
        WHERE e.event_date IS NOT NULL
        ORDER BY e.event_date
        LIMIT $1
        """,
        limit,
    )
    bounds = await fetchrow(
        """
        SELECT min(coalesce(effective_date, uploaded_at::date)) AS first_date,
               max(coalesce(effective_date, uploaded_at::date)) AS last_date,
               count(*) AS document_count
        FROM documents WHERE status = 'indexed'
        """
    )
    return {
        "ok": True,
        "window": {
            "first_date": bounds["first_date"].isoformat() if bounds and bounds["first_date"] else None,
            "last_date": bounds["last_date"].isoformat() if bounds and bounds["last_date"] else None,
            "document_count": int(bounds["document_count"]) if bounds else 0,
        },
        "entities": [_entity_row(row) for row in entities],
        "events": [_event_row(row) for row in event_rows],
    }


@router.get("/timeline/{entity}")
async def timeline_for_entity(entity: str) -> dict[str, Any]:
    """One entity's dated history plus the documents that mention it."""
    events = await fetch(
        """
        SELECT e.event_id, e.document_id, d.name AS document_name, d.document_type,
               e.event_date, e.event_type, e.title, e.description, e.entity_names
        FROM events e
        JOIN documents d ON d.document_id = e.document_id
        WHERE lower(e.entity_names::text) LIKE '%' || lower($1) || '%'
           OR lower(d.name) LIKE '%' || lower($1) || '%'
        ORDER BY e.event_date NULLS LAST, e.event_id
        """,
        entity,
    )
    documents = await fetch(
        """
        SELECT d.document_id, d.name, d.document_type, d.effective_date, d.document_date,
               d.temporal_certainty, d.chunk_count, d.section_count, d.event_count
        FROM documents d
        WHERE lower(d.name) LIKE '%' || lower($1) || '%'
           OR EXISTS (
                SELECT 1 FROM entity_mentions m
                JOIN entities e ON e.entity_id = m.entity_id
                WHERE m.document_id = d.document_id AND e.normalized_name = lower($1)
           )
        ORDER BY coalesce(d.effective_date, d.uploaded_at::date) DESC
        """,
        entity,
    )
    if not events and not documents:
        return {"ok": True, "entity": entity, "events": [], "documents": [], "found": False}
    return {
        "ok": True,
        "entity": entity,
        "found": True,
        "events": [_event_row(row) for row in events],
        "documents": [_document_row(row) for row in documents],
    }


@router.get("/timeline/{entity}/window")
async def coverage_window(entity: str) -> dict[str, Any]:
    """How far back knowledge about an entity goes (drives the date slider)."""
    row = await fetchrow(
        """
        SELECT min(coalesce(d.effective_date, d.uploaded_at::date)) AS first_date,
               max(coalesce(d.effective_date, d.uploaded_at::date)) AS last_date,
               count(*) AS documents
        FROM documents d
        WHERE lower(d.name) LIKE '%' || lower($1) || '%'
           OR EXISTS (
                SELECT 1 FROM entity_mentions m
                JOIN entities e ON e.entity_id = m.entity_id
                WHERE m.document_id = d.document_id AND e.normalized_name = lower($1)
           )
        """,
        entity,
    )
    return {
        "ok": True,
        "entity": entity,
        "first_date": row["first_date"].isoformat() if row and row["first_date"] else None,
        "last_date": row["last_date"].isoformat() if row and row["last_date"] else None,
        "documents": int(row["documents"]) if row else 0,
    }


def _entity_row(row) -> dict[str, Any]:
    item = dict(row)
    item["first_seen"] = item["first_seen"].isoformat() if item.get("first_seen") else None
    item["last_seen"] = item["last_seen"].isoformat() if item.get("last_seen") else None
    return item


def _event_row(row) -> dict[str, Any]:
    item = dict(row)
    item["event_date"] = item["event_date"].isoformat() if item.get("event_date") else None
    return item


def _document_row(row) -> dict[str, Any]:
    item = dict(row)
    for key in ("effective_date", "document_date"):
        item[key] = item[key].isoformat() if item.get(key) else None
    return item
