"""Read-only APIs for browsing what was known on a date."""

from __future__ import annotations

from datetime import date
from typing import Any

from fastapi import APIRouter, Query

from app.errors import ValidationFailed
from app.logging import get_logger, log_event
from app.services import compare as compare_service
from app.services import state as state_service

logger = get_logger("btm.api.state")

router = APIRouter(tags=["state"])


def _as_of(value: str | None) -> date | None:
    if not value:
        return None
    try:
        return date.fromisoformat(value)
    except ValueError as exc:
        raise ValidationFailed(f"as_of must be an ISO date (YYYY-MM-DD): {exc}") from exc


@router.get("/state")
async def get_state(
    as_of: str | None = Query(
        default=None,
        description="ISO date. Defaults to today, which is a snapshot of the corpus as uploaded.",
    ),
    entity: str | None = Query(default=None, description="Scope to one entity, e.g. 'Helios Robotics'"),
    document_types: str | None = Query(default=None, description="Comma-separated document types"),
    include_passages: bool = Query(default=True, description="Include in-scope passages as evidence"),
    passage_limit: int = Query(default=60, ge=1, le=200),
) -> dict[str, Any]:
    """Reconstruct what was known on a date.

    A bookmarkable read: ``/api/v1/state?as_of=2023-12-31`` returns the corpus as
    it stood then, and reports which later documents were withheld. The response
    is built entirely from stored dates, so it is identical whether or not a
    language model is reachable.
    """
    types = [t.strip() for t in document_types.split(",") if t.strip()] if document_types else None
    snapshot = await state_service.reconstruct(
        as_of=_as_of(as_of),
        entity=entity,
        document_types=types,
        include_passages=include_passages,
        passage_limit=passage_limit,
    )
    log_event(
        logger,
        "state",
        as_of=snapshot.as_of.isoformat(),
        entity=entity,
        documents=len(snapshot.documents),
    )
    return snapshot.as_dict()


@router.get("/compare")
async def get_compare(
    from_date: str = Query(alias="from", description="ISO date: the earlier snapshot"),
    to_date: str = Query(alias="to", description="ISO date: the later snapshot"),
    entity: str | None = Query(default=None),
    passage_limit: int = Query(default=80, ge=1, le=400),
) -> dict[str, Any]:
    """What changed between two dates.

    Both sides are reconstructed with the same temporal rules as /state, so a
    document the query path would refuse to admit cannot appear on either side of
    the diff. Metrics are matched by name and unit and compared as levels only -
    'up 18 percent' is never diffed against a level. Every change carries the
    sentence it came from, so each row can be checked against the source.
    """
    start, end = _as_of(from_date), _as_of(to_date)
    if not start or not end:
        raise ValidationFailed("from and to must both be ISO dates (YYYY-MM-DD).")
    if start == end:
        raise ValidationFailed("from and to must be different dates.")
    if start > end:
        raise ValidationFailed("from must be earlier than to; a time machine does not run backwards.")
    return await compare_service.compare(
        from_date=start, to_date=end, entity=entity, passage_limit=passage_limit
    )
