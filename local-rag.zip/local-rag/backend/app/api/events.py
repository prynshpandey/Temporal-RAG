"""Events and entities: the extracted temporal substrate the timeline draws."""

from __future__ import annotations

from datetime import date
from typing import Any

from fastapi import APIRouter, Query

from app.db.pool import fetch
from app.logging import get_logger

logger = get_logger("btm.api.events")
router = APIRouter(tags=["events"])


@router.get("/events")
async def list_events(
    entity: str | None = None,
    date_from: date | None = Query(None, alias="from"),
    date_to: date | None = Query(None, alias="to"),
    document_id: str | None = None,
    event_type: str | None = None,
    limit: int = Query(200, ge=1, le=2000),
) -> dict[str, Any]:
    """Events, newest first, optionally restricted to a window or an entity."""
    clauses, params = ["1 = 1"], []
    if entity:
        params.append(entity)
        clauses.append(f"lower(e.entity_names::text) LIKE '%' || lower(${len(params)}) || '%'")
    if date_from:
        params.append(date_from)
        clauses.append(f"(e.event_date IS NULL OR e.event_date >= ${len(params)})")
    if date_to:
        params.append(date_to)
        clauses.append(f"(e.event_date IS NULL OR e.event_date <= ${len(params)})")
    if document_id:
        params.append(document_id)
        clauses.append(f"e.document_id = ${len(params)}")
    if event_type:
        params.append(event_type)
        clauses.append(f"e.event_type = ${len(params)}")
    where = " AND ".join(clauses)

    rows = await fetch(
        f"""
        SELECT e.event_id, e.document_id, d.name AS document_name, e.event_date, e.date_text,
               e.event_type, e.title, e.description, e.entity_names, e.confidence,
               e.evidence_text
        FROM events e
        JOIN documents d ON d.document_id = e.document_id
        WHERE {where}
        ORDER BY e.event_date DESC NULLS LAST, e.event_id DESC
        LIMIT ${len(params) + 1}
        """,
        *params,
        limit,
    )
    events = []
    for row in rows:
        item = dict(row)
        item["event_date"] = item["event_date"].isoformat() if item.get("event_date") else None
        events.append(item)
    return {"ok": True, "count": len(events), "events": events}


@router.get("/entities")
async def list_entities(
    limit: int = Query(100, ge=1, le=1000), min_mentions: int = Query(1, ge=1)
) -> dict[str, Any]:
    """Entities with their mention counts, for the entity picker in the UI."""
    rows = await fetch(
        """
        SELECT e.entity_id, e.name, e.normalized_name, e.entity_type, e.mention_count,
               e.first_seen, e.last_seen,
               (SELECT count(DISTINCT m.document_id) FROM entity_mentions m
                 WHERE m.entity_id = e.entity_id) AS document_count
        FROM entities e
        WHERE e.mention_count >= $1
        ORDER BY e.mention_count DESC, e.name
        LIMIT $2
        """,
        min_mentions,
        limit,
    )
    entities = []
    for row in rows:
        item = dict(row)
        item["first_seen"] = item["first_seen"].isoformat() if item.get("first_seen") else None
        item["last_seen"] = item["last_seen"].isoformat() if item.get("last_seen") else None
        entities.append(item)
    return {"ok": True, "entities": entities}
