"""FastAPI application for the Business Time Machine.

Responsibilities, and nothing else:

* ingest      - receive a parsed upload from n8n and persist it (documents,
                sections, chunks, entities, events) plus register Qdrant point ids
* query       - temporal query engine: parse the question, enforce the temporal
                window in SQL, hybrid retrieval, parent-child expansion, rerank,
                context building, generation with the configured provider,
                citations and confidence
* timeline    - the dated spine the UI draws and the user clicks
* compare     - "what changed between date A and date B"
* legacy      - the pre-existing /webhook/rag/* contract, unchanged
"""

from __future__ import annotations

import time
from collections.abc import Awaitable, Callable

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app import config, errors, logging as btm_logging
from app.api import documents, events, internal, query, state, timeline
from app.db.pool import close_pool, get_pool, init_pool
from app.logging import new_request_id, request_id_var

settings = config.settings
logger = btm_logging.get_logger("btm.api")


def create_app() -> FastAPI:
    btm_logging.configure_logging(settings.log_level, settings.log_format)
    app = FastAPI(
        title="Business Time Machine",
        version="1.0.0",
        description=(
            "Temporal RAG: reconstructs the state of knowledge at a historical date, "
            "detects what changed, and cites real evidence. Embeddings are local "
            "(Ollama); generation runs on the configured provider (Groq by default)."
        ),
        docs_url="/api/docs",
        openapi_url="/api/openapi.json",
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.allowed_origin_list,
        allow_credentials=False,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    @app.middleware("http")
    async def request_context(
        request: Request, call_next: Callable[[Request], Awaitable]
    ):
        rid = request.headers.get("x-request-id") or new_request_id()
        token = request_id_var.set(rid)
        started = time.perf_counter()
        try:
            response = await call_next(request)
        finally:
            request_id_var.reset(token)
        elapsed_ms = int((time.perf_counter() - started) * 1000)
        response.headers["x-request-id"] = rid
        response.headers["x-response-time-ms"] = str(elapsed_ms)
        btm_logging.log_event(
            logger,
            "request",
            method=request.method,
            path=request.url.path,
            status=response.status_code,
            latency_ms=elapsed_ms,
        )
        return response

    @app.on_event("startup")
    async def _startup() -> None:
        await init_pool()
        btm_logging.log_event(
            logger,
            "startup",
            provider=settings.llm_provider,
            groq_key=settings.fingerprint(),
            model=settings.groq_model if settings.llm_provider == "groq" else settings.local_llm_model,
            embedding_model=settings.embedding_model,
            collection=settings.qdrant_collection,
        )

    @app.on_event("shutdown")
    async def _shutdown() -> None:
        await close_pool()

    @app.get("/health", tags=["ops"])
    async def health() -> dict:
        """Liveness plus dependency reachability (used by compose + make health)."""
        from app.deps import check_dependencies

        report = await check_dependencies()
        healthy = all(v.get("status") == "up" for k, v in report.items() if k != "config")
        return JSONResponse(
            status_code=200 if healthy else 503,
            content={
                "status": "ok" if healthy else "degraded",
                "service": settings.app_name,
                "version": app.version,
                "dependencies": report,
            },
        )

    @app.get("/", include_in_schema=False)
    async def root() -> dict:
        return {
            "service": settings.app_name,
            "docs": "/api/docs",
            "endpoints": [
                "POST   /api/v1/query",
                "GET    /api/v1/documents",
                "GET    /api/v1/documents/{document_id}",
                "GET    /api/v1/documents/{document_id}/chunks",
                "DELETE /api/v1/documents/{document_id}",
                "POST   /api/v1/timeline/query",
                "GET    /api/v1/timeline/{entity}",
                "POST   /api/v1/compare",
                "GET    /api/v1/events",
                "POST   /webhook/rag/*                (legacy contract)",
            ],
        }

    app.include_router(documents.router, prefix="/api/v1")
    app.include_router(events.router, prefix="/api/v1")
    app.include_router(query.router, prefix="/api/v1")
    app.include_router(state.router, prefix="/api/v1")
    app.include_router(timeline.router, prefix="/api/v1")
    app.include_router(internal.router)
    errors.install_error_handlers(app)
    return app


app = create_app()
