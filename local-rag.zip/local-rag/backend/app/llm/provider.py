"""One interface for text and JSON completions, Groq first and Ollama second.

Call sites import :func:`complete_json` / :func:`complete_text` and never learn
which provider answered. ``LLM_FALLBACK_PROVIDER=none`` makes a Groq outage a
visible error instead of a silent slow local call, which is what the tests want.
"""

from __future__ import annotations

from typing import Any

from app.config import settings
from app.errors import LlmFailed, LlmUnavailable
from app.llm.groq import GroqUsage, chat, chat_json
from app.logging import get_logger, log_event

logger = get_logger("btm.llm")

__all__ = ["GroqUsage", "complete_json", "complete_text", "provider_report"]


async def _ollama_json(system_prompt: str, user_prompt: str, *, temperature: float, max_tokens: int) -> Any:
    """Local JSON mode. ``ollama.chat`` returns the raw completion in ``text``,
    so it needs the same tolerant parsing Groq output gets."""
    from app.clients.ollama import chat as ollama_chat
    from app.llm.groq import parse_json_text

    result = await ollama_chat(
        system_prompt,
        user_prompt,
        temperature=temperature,
        num_predict=max_tokens,
        json_mode=True,
    )
    return parse_json_text(result.get("text") or "")


async def complete_json(
    system_prompt: str,
    user_prompt: str,
    *,
    temperature: float = 0.0,
    max_tokens: int = 1400,
    usage: GroqUsage | None = None,
    expect: type | tuple[type, ...] | None = None,
) -> Any:
    """Structured completion, falling back to the local model on failure."""
    if settings.llm_provider == "groq":
        try:
            answer = await chat_json(
                system_prompt,
                user_prompt,
                temperature=temperature,
                max_tokens=max_tokens,
                usage=usage,
                expect=expect,
            )
            if usage is not None:
                usage.provider = "groq"
            return answer
        except (LlmUnavailable, LlmFailed) as exc:
            if settings.llm_fallback_provider != "ollama":
                raise
            log_event(logger, "fallback_to_ollama", stage="json", error=str(exc)[:200])
            if usage is not None:
                usage.fallbacks += 1
    else:
        if usage is not None:
            usage.fallbacks += 1
    value = await _ollama_json(system_prompt, user_prompt, temperature=temperature, max_tokens=max_tokens)
    if usage is not None:
        usage.provider = "ollama"
    # Groq's path checks `expect`; the fallback has to honour it too, or a caller
    # that asked for a dict gets a bare string and fails somewhere far away.
    if expect is not None and not isinstance(value, expect):
        raise LlmFailed(f"expected {expect}, got {type(value).__name__}")
    return value


async def complete_text(
    system_prompt: str,
    user_prompt: str,
    *,
    temperature: float = 0.1,
    max_tokens: int = 900,
    usage: GroqUsage | None = None,
) -> str:
    """Free-text completion, falling back to the local model on failure."""
    if settings.llm_provider == "groq":
        try:
            answer = await chat(
                system_prompt,
                user_prompt,
                temperature=temperature,
                max_tokens=max_tokens,
                usage=usage,
            )
            if usage is not None:
                usage.provider = "groq"
            return answer
        except (LlmUnavailable, LlmFailed) as exc:
            if settings.llm_fallback_provider != "ollama":
                raise
            log_event(logger, "fallback_to_ollama", stage="text", error=str(exc)[:200])
            if usage is not None:
                usage.fallbacks += 1
    else:
        if usage is not None:
            usage.fallbacks += 1
    from app.clients.ollama import chat as ollama_chat

    result = await ollama_chat(
        system_prompt, user_prompt, temperature=temperature, num_predict=max_tokens
    )
    if usage is not None:
        usage.provider = "ollama"
    return result.get("text") or ""


def provider_report() -> dict[str, Any]:
    """What is configured, for /health and the UI footer."""
    return {
        "provider": settings.llm_provider,
        "model": settings.groq_model if settings.llm_provider == "groq" else settings.local_llm_model,
        "fallback": settings.llm_fallback_provider,
        "embedding_model": settings.embedding_model,
        "groq_key": settings.fingerprint(),
    }
