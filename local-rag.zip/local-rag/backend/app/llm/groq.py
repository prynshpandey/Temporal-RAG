"""Groq client: chat completions with JSON mode, retries and a local fallback.

Groq is the fast path. The local Ollama model is the fallback, so a bad key or a
rate limit degrades the answer quality instead of failing the request. Every call
is logged with token counts, never with the key.
"""

from __future__ import annotations

import asyncio
import json
import random
import re
import time
from typing import Any

import httpx

from app.config import settings
from app.errors import LlmFailed, LlmUnavailable
from app.logging import get_logger, log_event

logger = get_logger("btm.llm.groq")

_JSON_FENCE = re.compile(r"^\s*```(?:json)?\s*|\s*```\s*$", re.IGNORECASE)


class GroqUsage:
    """Token accounting for one execution, surfaced in the API response."""

    def __init__(self) -> None:
        self.prompt_tokens = 0
        self.completion_tokens = 0
        self.calls = 0
        self.fallbacks = 0
        # Which provider produced the answer. `calls == 0` means nobody did, and
        # that is different from "groq answered": a caller that hardcodes the
        # primary provider reports a model credit it never earned.
        self.provider: str | None = None

    def add(self, usage: dict[str, Any]) -> None:
        self.calls += 1
        self.prompt_tokens += int(usage.get("prompt_tokens") or 0)
        self.completion_tokens += int(usage.get("completion_tokens") or 0)

    def as_dict(self) -> dict[str, int]:
        return {
            "calls": self.calls,
            "prompt_tokens": self.prompt_tokens,
            "completion_tokens": self.completion_tokens,
            "fallbacks": self.fallbacks,
        }


def _strip_fence(text: str) -> str:
    return _JSON_FENCE.sub("", text.strip())


async def chat(
    system_prompt: str,
    user_prompt: str,
    *,
    model: str | None = None,
    temperature: float = 0.0,
    max_tokens: int = 1400,
    json_mode: bool = False,
    usage: GroqUsage | None = None,
    timeout: float | None = None,
) -> str:
    """One chat completion. Raises :class:`LlmUnavailable` / :class:`LlmFailed`."""
    return (await _complete(
        system_prompt, user_prompt, model=model, temperature=temperature,
        max_tokens=max_tokens, json_mode=json_mode, usage=usage, timeout=timeout,
    ))[0]


async def _complete(
    system_prompt: str,
    user_prompt: str,
    *,
    model: str | None = None,
    temperature: float = 0.0,
    max_tokens: int = 1400,
    json_mode: bool = False,
    usage: GroqUsage | None = None,
    timeout: float | None = None,
) -> tuple[str, str | None]:
    """The completion text plus the model's ``finish_reason``."""
    if not settings.groq_configured:
        raise LlmUnavailable("GROQ_API_KEY is not set or malformed.")
    model = model or settings.groq_model
    body: dict[str, Any] = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        "temperature": temperature,
        "max_tokens": max_tokens,
    }
    if json_mode:
        body["response_format"] = {"type": "json_object"}
    body["max_tokens"] = _fit_request(body, system_prompt, user_prompt)

    last_error: Exception | None = None
    for attempt in range(settings.groq_max_retries + 1):
        try:
            async with httpx.AsyncClient(timeout=timeout or settings.groq_timeout_s) as client:
                response = await client.post(
                    f"{settings.groq_base_url}/chat/completions",
                    headers={
                        "Authorization": f"Bearer {settings.groq_api_key}",
                        "Content-Type": "application/json",
                    },
                    json=body,
                )
        except httpx.HTTPError as exc:
            last_error = exc
            await _backoff(attempt)
            continue

        if response.status_code == 200:
            payload = response.json()
            choices = payload.get("choices") or []
            message = (choices[0].get("message") or {}) if choices else {}
            content = message.get("content") or ""
            if not content:
                # gpt-oss and friends emit a reasoning channel; when it eats the
                # whole budget the answer is truncated to nothing. Say so, instead
                # of failing later as "no JSON in the completion".
                if message.get("reasoning"):
                    raise LlmFailed(
                        f"{model} spent its {max_tokens} tokens reasoning and returned no answer; "
                        "raise max_tokens or use a model without a reasoning channel."
                    )
                raise LlmFailed("Groq returned an empty completion.")
            if usage is not None:
                usage.add(payload.get("usage") or {})
            finish_reason = choices[0].get("finish_reason") if choices else None
            log_event(
                logger,
                "chat",
                model=model,
                json_mode=json_mode,
                prompt_chars=len(user_prompt),
                completion_chars=len(content),
                finish_reason=finish_reason,
            )
            return content, finish_reason

        # A 429 is not always a rate limit. Groq answers 429 "Request too large"
        # both for a genuinely oversized request (retrying cannot help) and for a
        # token-per-minute quota (waiting does help), and the two are told apart by
        # the message: the first blames the context length, the second the rate.
        if response.status_code == 429 and _is_size_error(response.text):
            raise LlmFailed(f"Groq rejected the request as too large: {_body(response.text)}")

        if response.status_code in (429, 500, 502, 503, 504):
            last_error = LlmFailed(f"Groq HTTP {response.status_code}: {_body(response.text)}")
            await _backoff(attempt)
            continue
        raise LlmFailed(f"Groq HTTP {response.status_code}: {_body(response.text)}")

    raise LlmUnavailable(f"Groq did not answer after {settings.groq_max_retries + 1} attempts: {last_error}")


async def chat_json(
    system_prompt: str,
    user_prompt: str,
    *,
    model: str | None = None,
    temperature: float = 0.0,
    max_tokens: int = 1400,
    usage: GroqUsage | None = None,
    expect: type | tuple[type, ...] | None = None,
) -> Any:
    """Chat completion that must come back as JSON.

    Models wrap JSON in prose more often than they should, so the text is
    cleaned (fences removed, first balanced object taken) before parsing, and a
    second attempt is made with a stricter instruction if the first fails.
    """
    json_system = system_prompt.strip() + "\n\nAnswer with a single JSON object and nothing else."
    last_error: Exception | None = None
    budget = max_tokens
    for attempt in range(3):
        text, finish_reason = await _complete(
            json_system,
            user_prompt,
            model=model,
            temperature=temperature,
            max_tokens=budget,
            # Groq rejects response_format for some hosted models (gpt-oss), and
            # the tolerant parser below handles prose-wrapped JSON anyway.
            json_mode=False,
            usage=usage,
        )
        # A response cut off at the token limit is missing whatever came after
        # the cut. Silently accepting it loses facts, so grow the budget instead.
        if finish_reason == "length":
            last_error = LlmFailed(f"truncated at {budget} tokens")
            log_event(logger, "json_truncated", attempt=attempt, max_tokens=budget)
            # Bounded: a bigger retry is likelier to hit a per-minute quota, and a
            # truncated extraction is recoverable while an empty one is not.
            budget = min(budget * 2, max(budget, 2400))
            continue
        try:
            value = parse_json_text(text)
        except ValueError as exc:
            last_error = exc
            log_event(logger, "json_retry", attempt=attempt, preview=text[:160])
            continue
        if expect is not None and not isinstance(value, expect):
            last_error = LlmFailed(f"expected {expect}, got {type(value).__name__}")
            continue
        return value
    raise LlmFailed(f"The model did not return valid JSON: {last_error}")


def parse_json_text(text: str) -> Any:
    """Tolerant JSON reader: handles fenced blocks and leading prose."""
    cleaned = _strip_fence(text)
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        pass
    start = min((i for i in (cleaned.find("{"), cleaned.find("[")) if i >= 0), default=-1)
    if start < 0:
        raise ValueError("no JSON object in the completion")
    opener, closer = ("{", "}") if cleaned[start] == "{" else ("[", "]")
    depth = 0
    in_string = escaped = False
    for index in range(start, len(cleaned)):
        char = cleaned[index]
        if in_string:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                in_string = False
            continue
        if char == '"':
            in_string = True
        elif char == opener:
            depth += 1
        elif char == closer:
            depth -= 1
            if depth == 0:
                return json.loads(cleaned[start : index + 1])
    raise ValueError("unbalanced JSON in the completion")


# Provider errors are JSON envelopes. Cutting one at an arbitrary offset can
# land inside the quoted message, leaving a fragment that is both ugly to read
# and impossible to parse. Keep enough of the body for the display layer to find
# the message field, and let it decide how much to show.
_ERROR_BODY_LIMIT = 4000


def _body(text: str) -> str:
    return text[:_ERROR_BODY_LIMIT]


def _is_size_error(body: str) -> bool:
    """True when a 429 means "this request cannot ever fit"."""
    lowered = body.lower()
    if "per minute" in lowered or "per day" in lowered or "rate limit" in lowered:
        return False
    return "too large" in lowered


def _fit_request(body: dict[str, Any], system_prompt: str, user_prompt: str) -> int:
    """Shrink ``max_tokens`` so prompt + answer fits the provider's ceiling.

    The prompt size is estimated from characters (~3.2 chars per token, which
    over-estimates for prose) because no tokenizer is available offline and being
    over-cautious costs a few hundred tokens of answer, while being over the limit
    costs the whole request.
    """
    ceiling = settings.groq_max_request_tokens
    prompt_chars = len(system_prompt) + len(user_prompt)
    estimated_prompt = int(prompt_chars / 3.2) + 64
    room = ceiling - estimated_prompt
    if room < 256:
        raise LlmFailed(
            f"Prompt of about {estimated_prompt} tokens leaves no room under the "
            f"{ceiling}-token request limit; send less text or raise GROQ_MAX_REQUEST_TOKENS."
        )
    allowed = min(int(body.get("max_tokens", ceiling)), room)
    if allowed != body.get("max_tokens"):
        log_event(
            logger, "request_trimmed",
            requested=body.get("max_tokens"), allowed=allowed, prompt_estimate=estimated_prompt,
        )
    return allowed


async def _backoff(attempt: int) -> None:
    delay = min(2**attempt, 8) + random.uniform(0, 0.4)
    await asyncio.sleep(delay)
