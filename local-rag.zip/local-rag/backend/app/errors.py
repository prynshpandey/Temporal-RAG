"""Error taxonomy.

The legacy n8n API answers ``{"status":"error","error":{"code","message","hint"}}``
and the frontend renders that shape. The backend keeps the identical contract so
old and new clients share one error path (see :mod:`app.api.legacy`).
"""

from __future__ import annotations

from typing import Any

from fastapi import Request
from fastapi.responses import JSONResponse


class BtmError(Exception):
    """Base class: every failure the API reports deliberately."""

    code = "internal_error"
    status_code = 500
    message = "The request could not be completed."
    hint = "Check the backend logs with: make logs"

    def __init__(
        self,
        message: str | None = None,
        *,
        hint: str | None = None,
        code: str | None = None,
        status_code: int | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        self.message = message or self.message
        self.hint = hint or self.hint
        self.code = code or self.code
        self.status_code = status_code or self.status_code
        self.details = details or {}
        super().__init__(self.message)

    def to_payload(self) -> dict[str, Any]:
        return {
            "status": "error",
            "error": {
                "code": self.code,
                "message": self.message,
                "hint": self.hint,
                **({"details": self.details} if self.details else {}),
            },
        }


# ------------------------------------------------------------- upload / parse
class UnsupportedFileType(BtmError):
    code = "unsupported_file"
    status_code = 415
    message = "That file type is not supported."
    hint = "Supported: PDF, DOCX, TXT, CSV, PPTX, HTML, MD, JSON, XLSX"


class FileTooLarge(BtmError):
    code = "file_too_large"
    status_code = 413
    message = "The upload exceeds the configured size limit."
    hint = "Raise MAX_UPLOAD_SIZE_MB (and the nginx/n8n limits) to accept bigger files"


class EmptyUpload(BtmError):
    code = "empty_file"
    status_code = 400
    message = "The uploaded file is empty."
    hint = "Check that the file was copied completely before uploading"


class CorruptDocument(BtmError):
    code = "corrupt_document"
    status_code = 422
    message = "The document could not be read."
    hint = "Re-export the file; password-protected or damaged documents are rejected"


class ParseFailed(BtmError):
    code = "parse_failed"
    status_code = 422
    message = "Parsing the document failed."
    hint = "make logs shows the parser error for this upload"


class NoTextLayer(BtmError):
    code = "no_text_layer"
    status_code = 422
    message = "No extractable text was found (scanned or image-only document)."
    hint = "Run OCR (ocrmypdf) and upload the result"


class UnsafeArchive(BtmError):
    code = "unsafe_archive"
    status_code = 422
    message = "The office file looks like a malformed or hostile archive."
    hint = "DOCX/PPTX/XLSX are ZIP containers; re-save the file from its original app"


# --------------------------------------------------------------- dependencies
class Unauthorized(BtmError):
    code = "unauthorized"
    status_code = 401
    message = "The ingest token is missing or wrong."
    hint = "Send the value of INGEST_TOKEN in the X-Ingest-Token header"


class OllamaUnavailable(BtmError):
    code = "ollama_unavailable"
    status_code = 503
    message = "The local embedding service (Ollama) is not reachable."
    hint = "Start it on the host and confirm: make health"


class EmbeddingFailed(BtmError):
    code = "embedding_failed"
    status_code = 502
    message = "The embedding model returned an error."
    hint = "Check EMBEDDING_MODEL and QDRANT_VECTOR_SIZE with: make health"


class QdrantUnavailable(BtmError):
    code = "qdrant_unavailable"
    status_code = 503
    message = "The vector store is not reachable."
    hint = "docker compose up -d qdrant && make qdrant"


class DatabaseUnavailable(BtmError):
    code = "database_unavailable"
    status_code = 503
    message = "The metadata database is not reachable."
    hint = "make db-init && make migrate"


class LlmUnavailable(BtmError):
    code = "llm_unavailable"
    status_code = 503
    message = "The language model provider is not reachable."
    hint = "Check GROQ_API_KEY/GROQ_MODEL, or set LLM_PROVIDER=ollama for a fully local run"


class LlmFailed(BtmError):
    code = "llm_failed"
    status_code = 502
    message = "The language model returned an unusable response."
    hint = "Retry; if it persists, inspect the provider response in make logs"


# ------------------------------------------------------------------- querying
class MalformedQuery(BtmError):
    code = "malformed_query"
    status_code = 400
    message = "The query could not be interpreted."
    hint = 'Ask e.g. "What did we know about Acme Corp on March 15, 2025?"'


class EmptyQuestion(BtmError):
    code = "empty_question"
    status_code = 400
    message = "The question is empty."
    hint = "Ask a question, or use /api/v1/timeline to browse a date"


class NoResults(BtmError):
    code = "no_results"
    status_code = 200
    message = "No documents match that date range."
    hint = "Widen the range, or ingest more documents"


class InvalidTemporalQuery(BtmError):
    code = "invalid_temporal_query"
    status_code = 400
    message = "The requested date range is not valid."
    hint = "Use ISO dates (2025-03-15) or natural language like 'as of June 2024'"


class ValidationFailed(BtmError):
    code = "validation_failed"
    status_code = 400
    message = "Request validation failed."
    hint = "Check the required fields and value ranges in the API docs"


def install_error_handlers(app) -> None:
    """Map exceptions to the project's single error shape."""

    @app.exception_handler(BtmError)
    async def _btm_error(_: Request, exc: BtmError) -> JSONResponse:
        return JSONResponse(status_code=exc.status_code, content=exc.to_payload())

    @app.exception_handler(Exception)
    async def _unhandled(_: Request, exc: Exception) -> JSONResponse:  # pragma: no cover
        err = BtmError("An unexpected backend error occurred.", code="internal_error")
        return JSONResponse(status_code=500, content=err.to_payload())
