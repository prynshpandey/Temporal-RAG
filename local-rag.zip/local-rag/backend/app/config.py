"""Central configuration.

Every tunable of the Business Time Machine is read from the environment exactly
once, here. Nothing in the codebase reads ``os.environ`` directly, so the set of
knobs is greppable and testable. Secrets (GROQ_API_KEY, BTM_DB_PASSWORD) are only
ever read through this module and are redacted in logs by :mod:`app.logging`.
"""

from __future__ import annotations

import functools
from typing import Literal

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    # Env keys are UPPER_SNAKE (DATABASE_URL, GROQ_API_KEY, ...) and map onto the
    # snake_case fields below, which requires case-insensitive matching. Turning
    # it off makes every field pick up its .env entry instead of its default.
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    # -------------------------------------------------------------- runtime
    app_name: str = "business-time-machine"
    log_level: str = "INFO"
    log_format: str = Field(default="json", description="json | text")

    # ---------------------------------------------------------------- storage
    storage_dir: str = "/data/uploads"
    max_upload_size_mb: int = 100
    max_parse_seconds: int = 300
    max_zip_entries: int = 4000
    max_zip_uncompressed_mb: int = 400
    max_document_chars: int = 4_000_000

    # ------------------------------------------------------------- database
    database_url: str = "postgresql://btm:btm@postgres:5432/business_time_machine"
    db_pool_min: int = 2
    db_pool_max: int = 10
    db_statement_timeout_ms: int = 20_000

    # -------------------------------------------------------------- qdrant
    qdrant_url: str = "http://qdrant:6333"
    qdrant_collection: str = "btm_vectors"
    qdrant_vector_size: int = 768
    qdrant_distance: str = "Cosine"
    qdrant_timeout_s: float = 30.0
    legacy_qdrant_collection: str = "local_rag_chunks"

    # -------------------------------------------------------------- ollama
    ollama_base_url: str = "http://host.docker.internal:11434"
    embedding_model: str = "nomic-embed-text"
    embedding_batch_size: int = 8
    embedding_timeout_s: float = 180.0
    embed_truncate: bool = True
    document_summary_chars: int = 4000
    # How much a newer in-scope document outranks an older one that matched
    # equally well. 0 disables the bias and leaves pure RRF ordering.
    retrieval_recency_weight: float = 0.15
    # How much a relevance band's edge may be crossed by recency. Candidates
    # within this margin of the leader are treated as tied on relevance; past it,
    # relevance decides alone. This is what stops a fresher but weaker document
    # from displacing a stronger match.
    rerank_relevance_band: float = 0.10
    # Strength of the deterministic relevance features relative to the fused
    # rank score. Kept below 1 so fusion still dominates recall.
    rerank_quality_bonus: float = 0.60
    # Off switches the whole two-stage path, restoring the pre-rerank behaviour.
    rerank_enabled: bool = True
    # A snapshot carrying more passages than this is unreadable as evidence and
    # slow to render; the documents themselves are always listed in full.
    state_passage_limit: int = 60
    # Days of silence after which a snapshot warns that the corpus has fallen
    # behind. A snapshot built from stale evidence is still correct, but the
    # reader should not mistake it for current.
    state_stale_after_days: int = 180
    # Days apart that two documents still count as contemporaneous. Wider than
    # this and a revision history starts being reported as a contradiction.
    conflict_window_days: int = 30

    # ----------------------------------------------------------------- groq
    llm_provider: Literal["groq", "ollama"] = "groq"
    # "none" by default on purpose. The local model is a 6 GB CPU-only llama, and
    # loading it evicts the embedding model: a fallback that makes an ingest six
    # minutes slower while producing no usable JSON is worse than degrading to the
    # deterministic extraction, which always works and needs no model at all.
    llm_fallback_provider: Literal["groq", "ollama", "none"] = "none"
    groq_api_key: str = ""
    groq_base_url: str = "https://api.groq.com/openai/v1"
    # Overridden per key; run `make llm-probe` to see what yours can reach.
    groq_model: str = "qwen/qwen3.8-27b"
    groq_timeout_s: float = 60.0
    groq_max_retries: int = 2
    # Groq's on_demand tier rejects a request once prompt + max_tokens passes a few
    # thousand tokens, with a 429 that looks exactly like rate limiting. Keeping the
    # total under the ceiling is cheaper than discovering it at ingest time.
    groq_max_request_tokens: int = 4096
    local_llm_model: str = "llama3.1"
    # The local model is a fallback, not the primary: it must fail fast enough
    # that an ingest request does not sit for minutes.
    local_llm_timeout_s: float = 60.0

    # ------------------------------------------------------------ retrieval
    top_k: int = 8
    rerank_top_k: int = 5
    rerank_enabled: bool = True
    vector_weight: float = 0.60
    keyword_weight: float = 0.25
    temporal_weight: float = 0.15
    fusion_method: Literal["weighted", "rrf"] = "weighted"
    temporal_decay_half_life_days: float = 180.0
    min_score: float = 0.15
    max_context_chars: int = 8000
    parent_context_chars: int = 2500
    max_allowed_documents: int = 400

    # ----------------------------------------------------------------- http
    backend_url: str = "http://127.0.0.1:8000"
    backend_url_internal: str = "http://backend:8000"
    n8n_url_internal: str = "http://n8n:5678"
    ingest_token: str = ""
    allowed_origins: str = "*"
    max_question_chars: int = 2000
    max_upload_name_chars: int = 180

    @field_validator("storage_dir")
    @classmethod
    def _abs_storage(cls, v: str) -> str:
        if not v.startswith("/"):
            raise ValueError("STORAGE_DIR must be an absolute path")
        return v

    @property
    def max_upload_bytes(self) -> int:
        return self.max_upload_size_mb * 1024 * 1024

    @property
    def groq_configured(self) -> bool:
        return self.groq_api_key.startswith("gsk_")

    @property
    def allowed_origin_list(self) -> list[str]:
        if self.allowed_origins.strip() in ("*", ""):
            return ["*"]
        return [o.strip() for o in self.allowed_origins.split(",") if o.strip()]

    def fingerprint(self) -> str:
        """Non-reversible identifier for the API key, safe to log."""
        if not self.groq_api_key:
            return "unset"
        return f"gsk_...{self.groq_api_key[-4:]} (len={len(self.groq_api_key)})"


@functools.lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
