"""Repositories: explicit SQL for the temporal knowledge base."""
