"""Documents: the write path (ingest) and the read path (library, temporal window).

The temporal window query in :func:`documents_in_window` is the heart of the
no-future-leakage rule. A document may enter a point-in-time answer when either

* its effective date (event date, else document date) is at or before the target
  date, or
* its date could not be determined at all, in which case we fall back to proving
  it was already in the system: ``uploaded_at <= as_of``.

A document whose effective date is *after* the target date can never be returned,
no matter how well it scores. That decision is made here, in SQL - the language
model never sees the excluded rows.
"""

from __future__ import annotations

import json
from contextlib import asynccontextmanager
from datetime import date
from typing import Any

import asyncpg

from app.config import settings
from app.db.pool import execute, fetch, fetchrow, fetchval
from app.logging import get_logger, log_event

logger = get_logger("btm.repo.documents")

# A document counts as known at ``as_of`` if its own date is old enough, or - when
# no date could be extracted - if it was uploaded before the target date.
_POINT_IN_TIME_SQL = """
    WHERE d.status = 'indexed'
      AND (
            (d.effective_date IS NOT NULL AND d.effective_date <= $1::date)
         OR (d.effective_date IS NULL     AND d.uploaded_at::date <= $1::date)
          )
      AND (d.valid_until IS NULL OR d.valid_until > $1::date)
"""

_RANGE_SQL = """
    WHERE d.status = 'indexed'
      AND (
            (d.effective_date IS NOT NULL AND d.effective_date > $1::date AND d.effective_date <= $2::date)
         OR (d.effective_date IS NULL     AND d.uploaded_at::date > $1::date AND d.uploaded_at::date <= $2::date)
          )
      AND (d.valid_from IS NULL OR d.valid_from <= $2::date)
"""


def _entity_clause(entity: str | None, param_index: int) -> tuple[str, int]:
    """Scope documents to an entity: indexed mention first, then a name match."""
    if not entity:
        return "", param_index
    clause = f"""
      AND (
            EXISTS (
                SELECT 1 FROM entity_mentions em
                JOIN entities e ON e.entity_id = em.entity_id
                WHERE em.document_id = d.document_id
                  AND e.normalized_name = lower($%d)
            )
         OR lower(d.name) LIKE '%%' || lower($%d) || '%%'
         OR lower(coalesce(d.title, '')) LIKE '%%' || lower($%d) || '%%'
         OR lower(d.summary) LIKE '%%' || lower($%d) || '%%'
         OR EXISTS (
                SELECT 1 FROM document_chunks c
                WHERE c.document_id = d.document_id
                  AND lower(c.text) LIKE '%%' || lower($%d) || '%%'
            )
      )
    """ % (param_index, param_index, param_index, param_index, param_index)
    return clause, param_index + 1


async def documents_in_window(
    *,
    as_of: date | None = None,
    start: date | None = None,
    end: date | None = None,
    entity: str | None = None,
    document_types: list[str] | None = None,
) -> list[dict[str, Any]]:
    """Documents whose knowledge is valid for the requested point/range."""
    params: list[Any] = []
    if as_of is not None:
        params.append(as_of)
    elif start is not None and end is not None:
        params.extend([start, end])
    else:  # pragma: no cover - guarded by the query parser
        params.extend([date.today(), date.today()])

    entity_sql, next_index = _entity_clause(entity, len(params) + 1)
    entity_value = entity
    if entity_sql:
        params.append(entity_value)

    type_sql, type_params = "", []
    if document_types:
        placeholders = []
        for doc_type in document_types:
            placeholders.append(f"${len(params) + 1 + len(type_params)}")
            type_params.append(doc_type)
        type_sql = f" AND d.document_type = ANY({', '.join(placeholders)}::text[])"
        params.extend(type_params)

    where = _POINT_IN_TIME_SQL if as_of is not None else _RANGE_SQL
    sql = f"""
        SELECT d.document_id, d.name, d.document_type, d.source, d.effective_date,
               d.document_date, d.temporal_certainty, d.uploaded_at, d.chunk_count,
               d.section_count, d.event_count, d.page_count
        FROM documents d
        {where}
        {entity_sql}
        {type_sql}
        ORDER BY d.effective_date DESC NULLS LAST, d.uploaded_at DESC
        LIMIT {int(settings.max_allowed_documents)}
    """
    rows = await fetch(sql, *params)
    log_event(
        logger,
        "temporal_window",
        as_of=str(as_of) if as_of else None,
        start=str(start) if start else None,
        end=str(end) if end else None,
        entity=entity,
        documents=len(rows),
    )
    return [dict(row) for row in rows]


async def documents_outside_window(
    *,
    as_of: date,
    entity: str | None = None,
    document_types: list[str] | None = None,
) -> list[dict[str, Any]]:
    """Documents deliberately kept out of a snapshot, each with the reason why.

    A snapshot that silently drops half the corpus is indistinguishable from a
    snapshot of a smaller company. The caller needs to be able to show what was
    left out and on what grounds, so this returns the exclusions with a
    ``reason`` the UI can render directly.
    """
    params: list[Any] = [as_of]
    entity_sql, next_index = _entity_clause(entity, len(params) + 1)
    if entity_sql:
        params.append(entity)

    type_sql, type_params = "", []
    if document_types:
        placeholders = []
        for doc_type in document_types:
            placeholders.append(f"${next_index + len(type_params)}")
            type_params.append(doc_type)
        type_sql = f" AND d.document_type = ANY({', '.join(placeholders)}::text[])"
        params.extend(type_params)

    sql = f"""
        SELECT d.document_id, d.name, d.document_type, d.effective_date,
               d.document_date, d.uploaded_at, d.valid_from, d.valid_until,
               d.temporal_certainty,
               CASE
                   WHEN d.effective_date IS NOT NULL AND d.effective_date > $1::date
                       THEN 'dated_after_window'
                   WHEN d.valid_until IS NOT NULL AND d.valid_until <= $1::date
                       THEN 'expired_before_window'
                   ELSE 'unknown'
               END AS reason
        FROM documents d
        WHERE d.status = 'indexed'
          AND (
                (d.effective_date IS NOT NULL AND d.effective_date > $1::date)
             OR (d.effective_date IS NULL     AND d.uploaded_at::date > $1::date)
             OR (d.valid_until IS NOT NULL  AND d.valid_until <= $1::date)
              )
          {entity_sql}
          {type_sql}
        ORDER BY d.effective_date DESC NULLS LAST, d.uploaded_at DESC
        LIMIT {int(settings.max_allowed_documents)}
    """
    rows = await fetch(sql, *params)
    return [dict(row) for row in rows]


async def chunks_for_documents(
    document_ids: list[str],
    *,
    level: int = 2,
    limit: int = 60,
) -> list[dict[str, Any]]:
    """Passages for a set of documents, in document and reading order."""
    if not document_ids:
        return []
    sql = """
        SELECT c.chunk_id, c.document_id, d.name AS document_name, c.level,
               c.section_id, s.title AS section_title, c.text, c.page, c.chunk_index,
               c.effective_date
        FROM document_chunks c
        JOIN documents d ON d.document_id = c.document_id
        LEFT JOIN document_sections s ON s.section_id = c.section_id
        WHERE c.document_id = ANY($1::text[]) AND c.level = $2::int
        ORDER BY d.effective_date DESC NULLS LAST, c.chunk_index
        LIMIT $3::int
    """
    rows = await fetch(sql, list(document_ids), level, limit)
    return [dict(row) for row in rows]


# ------------------------------------------------------------------ write path
async def upsert_document(doc: dict[str, Any], conn: asyncpg.Connection | None = None) -> None:
    """Insert or refresh a document row. Pass ``conn`` to join a caller's transaction."""
    metadata = doc.get("metadata") or {}
    if not isinstance(metadata, str):
        metadata = json.dumps(metadata)
    args = (
        """
        INSERT INTO documents (
            document_id, name, storage_key, source, document_type, mime_type, size_bytes,
            sha256, document_date, event_date, effective_date, valid_from, valid_until,
            temporal_certainty, status, summary, qdrant_point_id, page_count, section_count,
            chunk_count, event_count, title, authors, metadata, uploaded_at, updated_at
        ) VALUES (
            $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,
            $24::jsonb,
            coalesce($25::timestamptz, now()), now()
        )
        ON CONFLICT (document_id) DO UPDATE SET
            name = EXCLUDED.name,
            source = EXCLUDED.source,
            document_type = EXCLUDED.document_type,
            mime_type = EXCLUDED.mime_type,
            size_bytes = EXCLUDED.size_bytes,
            sha256 = EXCLUDED.sha256,
            document_date = EXCLUDED.document_date,
            event_date = EXCLUDED.event_date,
            effective_date = EXCLUDED.effective_date,
            valid_from = EXCLUDED.valid_from,
            valid_until = EXCLUDED.valid_until,
            temporal_certainty = EXCLUDED.temporal_certainty,
            status = EXCLUDED.status,
            summary = EXCLUDED.summary,
            qdrant_point_id = EXCLUDED.qdrant_point_id,
            page_count = EXCLUDED.page_count,
            section_count = EXCLUDED.section_count,
            chunk_count = EXCLUDED.chunk_count,
            event_count = EXCLUDED.event_count,
            title = EXCLUDED.title,
            authors = EXCLUDED.authors,
            metadata = EXCLUDED.metadata,
            updated_at = now()
        """,
        doc["document_id"],
        doc.get("name"),
        doc.get("storage_key"),
        doc.get("source", "upload"),
        doc["document_type"],
        doc.get("mime_type"),
        int(doc.get("size_bytes") or 0),
        doc.get("sha256"),
        doc.get("document_date"),
        doc.get("event_date"),
        doc.get("effective_date"),
        doc.get("valid_from"),
        doc.get("valid_until"),
        doc.get("temporal_certainty", "unknown"),
        doc.get("status", "indexed"),
        doc.get("summary"),
        doc.get("qdrant_point_id"),
        doc.get("page_count"),
        int(doc.get("section_count") or 0),
        int(doc.get("chunk_count") or 0),
        int(doc.get("event_count") or 0),
        doc.get("title"),
        doc.get("authors"),
        metadata,
        doc.get("uploaded_at"),
    )
    if conn is not None:
        await conn.execute(*args)
    else:
        await execute(*args)


@asynccontextmanager
async def _writer(conn: asyncpg.Connection | None):
    """Yield a connection inside one transaction.

    Passing ``conn`` lets :mod:`app.services.ingestion` write a document, its
    sections, chunks, entities and events atomically; without it each helper is
    independently transactional, which is what the read-only callers rely on.
    """
    if conn is not None:
        yield conn
        return
    async with _acquire() as own:
        async with own.transaction():
            yield own


async def replace_sections(
    document_id: str, sections: list[dict[str, Any]], conn: asyncpg.Connection | None = None
) -> None:
    async with _writer(conn) as writer:
        await writer.execute("DELETE FROM document_sections WHERE document_id = $1", document_id)
        for section in sections:
            await writer.execute(
                """
                INSERT INTO document_sections (
                    section_id, document_id, parent_section_id, title, level, ordinal,
                    page, text, char_count, effective_date, qdrant_point_id
                ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
                ON CONFLICT (section_id) DO UPDATE SET
                    title = EXCLUDED.title, level = EXCLUDED.level,
                    ordinal = EXCLUDED.ordinal, page = EXCLUDED.page,
                    text = EXCLUDED.text, char_count = EXCLUDED.char_count,
                    effective_date = EXCLUDED.effective_date,
                    qdrant_point_id = EXCLUDED.qdrant_point_id
                """,
                section["section_id"],
                document_id,
                section.get("parent_section_id"),
                section.get("title"),
                int(section.get("level") or 1),
                int(section.get("ordinal") or 0),
                section.get("page"),
                section["text"],
                len(section["text"]),
                section.get("effective_date"),
                section.get("qdrant_point_id"),
            )


async def replace_chunks(
    document_id: str, chunks: list[dict[str, Any]], conn: asyncpg.Connection | None = None
) -> None:
    async with _writer(conn) as writer:
        await writer.execute("DELETE FROM document_chunks WHERE document_id = $1", document_id)
        for chunk in chunks:
            await writer.execute(
                """
                INSERT INTO document_chunks (
                    chunk_id, document_id, section_id, parent_id, chunk_index, page, text,
                    char_count, identifiers, event_date, effective_date,
                    temporal_certainty, qdrant_point_id, level, search_text
                ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)
                ON CONFLICT (chunk_id) DO UPDATE SET
                    section_id = EXCLUDED.section_id, parent_id = EXCLUDED.parent_id,
                    chunk_index = EXCLUDED.chunk_index, page = EXCLUDED.page,
                    text = EXCLUDED.text, char_count = EXCLUDED.char_count,
                    identifiers = EXCLUDED.identifiers, event_date = EXCLUDED.event_date,
                    effective_date = EXCLUDED.effective_date,
                    temporal_certainty = EXCLUDED.temporal_certainty,
                    qdrant_point_id = EXCLUDED.qdrant_point_id,
                    level = EXCLUDED.level,
                    search_text = EXCLUDED.search_text
                """,
                chunk["chunk_id"],
                document_id,
                chunk.get("section_id"),
                chunk.get("parent_id"),
                int(chunk.get("chunk_index") or 0),
                chunk.get("page"),
                chunk["text"],
                len(chunk["text"]),
                chunk.get("identifiers") or [],
                chunk.get("event_date"),
                chunk.get("effective_date"),
                chunk.get("temporal_certainty", "unknown"),
                chunk.get("qdrant_point_id"),
                int(chunk.get("level") if chunk.get("level") is not None else (3 if chunk.get("parent_id") else 2)),
                # The breadcrumb plus the body, which is what got embedded. Keyword
                # search has to see the same string the vector index did.
                chunk.get("search_text") or chunk["text"],
            )


async def insert_events(
    events: list[dict[str, Any]], conn: asyncpg.Connection | None = None
) -> list[int]:
    ids: list[int] = []
    async with _writer(conn) as writer:
        for event in events:
            row = await writer.fetchrow(
                """
                INSERT INTO events (
                    document_id, chunk_id, event_date, date_text, event_type, title,
                    description, entity_names, confidence, extraction, evidence_text, metadata
                ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12::jsonb)
                RETURNING event_id
                """,
                event["document_id"],
                event.get("chunk_id"),
                event.get("event_date"),
                event.get("date_text"),
                event.get("event_type", "event"),
                event.get("title"),
                event.get("description"),
                event.get("entity_names") or [],
                float(event.get("confidence", 0.5)),
                event.get("extraction", "deterministic"),
                event.get("evidence_text"),
                json.dumps(event.get("metadata") or {}),
            )
            ids.append(row["event_id"])
    return ids


async def upsert_entities(
    document_id: str,
    entities: list[dict[str, Any]],
    conn: asyncpg.Connection | None = None,
) -> list[int]:
    """Insert/refresh entities and link them to the document (+ optional chunk)."""
    ids: list[int] = []
    async with _writer(conn) as writer:
        for entity in entities:
            name = (entity.get("name") or "").strip()
            if not name:
                continue
            normalized = normalize_entity(name)
            row = await writer.fetchrow(
                """
                INSERT INTO entities (name, normalized_name, entity_type, first_seen, last_seen)
                VALUES ($1, $2, $3, $4, $4)
                ON CONFLICT (normalized_name) DO UPDATE SET
                    entity_type = CASE WHEN entities.entity_type = 'unknown'
                                       THEN EXCLUDED.entity_type ELSE entities.entity_type END,
                    last_seen = greatest(entities.last_seen, EXCLUDED.last_seen),
                    mention_count = entities.mention_count + 1
                RETURNING entity_id
                """,
                name,
                normalized,
                entity.get("entity_type", "unknown"),
                entity.get("seen_date"),
            )
            entity_id = row["entity_id"]
            ids.append(entity_id)
            await writer.execute(
                """
                INSERT INTO entity_mentions (entity_id, document_id, chunk_id, role)
                VALUES ($1, $2, $3, $4)
                ON CONFLICT (entity_id, document_id, (coalesce(chunk_id, '')), (coalesce(event_id, 0)))
                DO NOTHING
                """,
                entity_id,
                document_id,
                entity.get("chunk_id"),
                entity.get("role", "mentioned"),
            )
    return ids


def normalize_entity(name: str) -> str:
    return " ".join(name.lower().split())


async def insert_facts(
    facts: list[dict[str, Any]], conn: asyncpg.Connection | None = None
) -> int:
    if not facts:
        return 0
    async with _writer(conn) as writer:
        for fact in facts:
            await writer.execute(
                """
                INSERT INTO facts (
                    document_id, chunk_id, subject, predicate, object_value, entity_names,
                    event_date, valid_from, valid_until, confidence, extraction
                ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
                """,
                fact["document_id"],
                fact.get("chunk_id"),
                fact["subject"],
                fact["predicate"],
                fact.get("object_value"),
                fact.get("entity_names") or [],
                fact.get("event_date"),
                fact.get("valid_from"),
                fact.get("valid_until"),
                float(fact.get("confidence", 0.5)),
                fact.get("extraction", "deterministic"),
            )
    return len(facts)


def _acquire():
    from app.db.pool import get_pool

    return get_pool().acquire()


# ------------------------------------------------------------------- read path
async def list_documents(
    *, limit: int = 100, offset: int = 0, entity: str | None = None, document_type: str | None = None
) -> dict[str, Any]:
    clauses, params = ["1 = 1"], []
    if entity:
        params.append(entity)
        clauses.append(
            f"""(lower(d.name) LIKE '%' || lower(${len(params)}) || '%'
                 OR EXISTS (SELECT 1 FROM entity_mentions em JOIN entities e
                            ON e.entity_id = em.entity_id
                           WHERE em.document_id = d.document_id AND e.normalized_name = lower(${len(params)}))))"""
        )
    if document_type:
        params.append(document_type)
        clauses.append(f"d.document_type = ${len(params)}")
    where = " AND ".join(clauses)

    total = await fetchval(f"SELECT count(*) FROM documents d WHERE {where}", *params)
    rows = await fetch(
        f"""
        SELECT d.*,
               (SELECT array_agg(json_build_object('event_date', e.event_date, 'type', e.event_type,
                                                   'title', e.title, 'description', e.description)
                                 ORDER BY e.event_date NULLS LAST)
                  FROM events e WHERE e.document_id = d.document_id) AS events
        FROM documents d
        WHERE {where}
        ORDER BY coalesce(d.effective_date, d.uploaded_at::date) DESC, d.document_id
        LIMIT ${len(params) + 1} OFFSET ${len(params) + 2}
        """,
        *params,
        limit,
        offset,
    )
    documents = []
    for row in rows:
        item = dict(row)
        raw_events = item.pop("events", None) or []
        item["events"] = raw_events
        item["uploaded_at"] = item["uploaded_at"].isoformat() if item.get("uploaded_at") else None
        for key in ("document_date", "event_date", "effective_date", "valid_from", "valid_until"):
            item[key] = item[key].isoformat() if item.get(key) else None
        documents.append(item)
    return {"total": int(total or 0), "documents": documents}


async def get_document(document_id: str) -> dict[str, Any] | None:
    row = await fetchrow("SELECT * FROM documents WHERE document_id = $1", document_id)
    if not row:
        return None
    item = dict(row)
    for key in ("document_date", "event_date", "effective_date", "valid_from", "valid_until"):
        item[key] = item[key].isoformat() if item.get(key) else None
    item["uploaded_at"] = item["uploaded_at"].isoformat() if item.get("uploaded_at") else None
    return item


async def get_chunks(document_id: str) -> list[dict[str, Any]]:
    rows = await fetch(
        """
        SELECT c.*, s.title AS section_title
        FROM document_chunks c
        LEFT JOIN document_sections s ON s.section_id = c.section_id
        WHERE c.document_id = $1
        ORDER BY c.chunk_index
        """,
        document_id,
    )
    chunks = []
    for row in rows:
        item = dict(row)
        for key in ("event_date", "effective_date"):
            item[key] = item[key].isoformat() if item.get(key) else None
        chunks.append(item)
    return chunks


async def delete_document(document_id: str) -> bool:
    deleted = await execute("DELETE FROM documents WHERE document_id = $1", document_id)
    return deleted.endswith("1")
