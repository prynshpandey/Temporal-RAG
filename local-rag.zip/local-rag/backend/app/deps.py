"""Shared dependencies and the health report used by /health and make health."""

from __future__ import annotations

import time
from typing import Any

import asyncpg
import httpx

from app.config import settings
from app.logging import get_logger

logger = get_logger("btm.deps")


async def check_dependencies() -> dict[str, Any]:
    """Every dependency with an up/down status; the API stays up while degraded."""
    report: dict[str, Any] = {}
    report["postgres"] = await _check_postgres()
    report["qdrant"] = await _check_qdrant()
    report["ollama"] = await _check_ollama()
    report["groq"] = await _check_groq()
    report["config"] = {
        "status": "up" if settings.groq_configured or settings.llm_provider == "ollama" else "degraded",
        "provider": settings.llm_provider,
        "groq_key": settings.fingerprint(),
        "model": settings.groq_model if settings.llm_provider == "groq" else settings.local_llm_model,
        "embedding_model": settings.embedding_model,
        "collection": settings.qdrant_collection,
        "vector_size": settings.qdrant_vector_size,
    }
    return report


async def _timed(coro) -> tuple[Any, float]:
    started = time.perf_counter()
    try:
        return await coro, time.perf_counter() - started
    except Exception as exc:  # noqa: BLE001 - health must never raise
        return exc, time.perf_counter() - started


async def _check_postgres() -> dict[str, Any]:
    try:
        started = time.perf_counter()
        conn = await asyncpg.connect(settings.database_url, timeout=5)
        try:
            version = await conn.fetchval("SHOW server_version")
            chunks = await conn.fetchval("SELECT count(*) FROM document_chunks")
        finally:
            await conn.close()
        return {
            "status": "up",
            "server": version,
            "chunks": chunks,
            "latency_ms": int((time.perf_counter() - started) * 1000),
        }
    except Exception as exc:  # noqa: BLE001
        return {"status": "down", "error": str(exc)[:200]}


async def _check_qdrant() -> dict[str, Any]:
    try:
        started = time.perf_counter()
        async with httpx.AsyncClient(base_url=settings.qdrant_url, timeout=5) as client:
            response = await client.get(f"/collections/{settings.qdrant_collection}")
        if response.status_code != 200:
            return {"status": "degraded", "error": f"collection {settings.qdrant_collection} missing"}
        info = response.json()["result"]
        return {
            "status": "up",
            "collection": settings.qdrant_collection,
            "points": info.get("points_count"),
            "status_qdrant": info.get("status"),
            "latency_ms": int((time.perf_counter() - started) * 1000),
        }
    except Exception as exc:  # noqa: BLE001
        return {"status": "down", "error": str(exc)[:200]}


async def _check_ollama() -> dict[str, Any]:
    try:
        started = time.perf_counter()
        async with httpx.AsyncClient(base_url=settings.ollama_base_url, timeout=5) as client:
            response = await client.get("/api/tags")
        models = [m["name"] for m in response.json().get("models", [])] if response.is_success else []
        has_embedding = any(m.split(":")[0] == settings.embedding_model for m in models)
        return {
            "status": "up" if has_embedding else "degraded",
            "models": models,
            "embedding_model": settings.embedding_model,
            "latency_ms": int((time.perf_counter() - started) * 1000),
        }
    except Exception as exc:  # noqa: BLE001
        return {"status": "down", "error": str(exc)[:200]}


async def _check_groq() -> dict[str, Any]:
    if settings.llm_provider != "groq":
        return {"status": "skipped", "reason": f"provider={settings.llm_provider}"}
    if not settings.groq_configured:
        return {"status": "degraded", "error": "GROQ_API_KEY is not set"}
    try:
        started = time.perf_counter()
        async with httpx.AsyncClient(base_url=settings.groq_base_url, timeout=10) as client:
            response = await client.get("/models", headers={"Authorization": f"Bearer {settings.groq_api_key}"})
        return {
            "status": "up" if response.status_code == 200 else "down",
            "model": settings.groq_model,
            "http": response.status_code,
            "latency_ms": int((time.perf_counter() - started) * 1000),
        }
    except Exception as exc:  # noqa: BLE001
        return {"status": "down", "error": str(exc)[:200]}
