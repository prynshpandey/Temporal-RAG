"""PostgreSQL access: one asyncpg pool, no ORM.

The temporal schema is queried with explicit SQL because the no-future-leakage rule
has to be visible in the query, not hidden behind a query builder.
"""

from __future__ import annotations

import asyncpg

from app.config import settings
from app.errors import DatabaseUnavailable
from app.logging import get_logger, log_event

logger = get_logger("btm.db")

_pool: asyncpg.Pool | None = None


async def init_pool() -> None:
    global _pool
    if _pool is not None:
        return
    try:
        _pool = await asyncpg.create_pool(
            dsn=settings.database_url,
            min_size=settings.db_pool_min,
            max_size=settings.db_pool_max,
            command_timeout=30,
            server_settings={"application_name": settings.app_name},
        )
    except Exception as exc:  # pragma: no cover - startup diagnostics
        raise DatabaseUnavailable(f"Could not connect to PostgreSQL: {exc}") from exc
    log_event(logger, "pool_ready", min=settings.db_pool_min, max=settings.db_pool_max)


async def close_pool() -> None:
    global _pool
    if _pool is not None:
        await _pool.close()
        _pool = None


def get_pool() -> asyncpg.Pool:
    if _pool is None:
        raise DatabaseUnavailable("The database pool is not initialised.")
    return _pool


async def fetch(query: str, *args) -> list[asyncpg.Record]:
    async with get_pool().acquire() as conn:
        return await conn.fetch(query, *args)


async def fetchrow(query: str, *args) -> asyncpg.Record | None:
    async with get_pool().acquire() as conn:
        return await conn.fetchrow(query, *args)


async def fetchval(query: str, *args):
    async with get_pool().acquire() as conn:
        return await conn.fetchval(query, *args)


async def execute(query: str, *args) -> str:
    async with get_pool().acquire() as conn:
        return await conn.execute(query, *args)


async def transaction():
    """``async with transaction() as conn:`` - a single connection, one commit."""
    return get_pool().acquire()
