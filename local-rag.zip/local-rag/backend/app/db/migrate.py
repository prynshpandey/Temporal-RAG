"""Schema migrations.

Numbered SQL files applied in lexical order, tracked in ``schema_migrations`` and
guarded by a Postgres advisory lock so two containers can never race.
Run with: make migrate   (or: python -m app.db.migrate)
"""

from __future__ import annotations

import asyncio
import pathlib
import re
import sys

import asyncpg

from app.config import settings

LOCK_ID = 4_712_001
MIGRATIONS_DIR = pathlib.Path(__file__).parent / "migrations"


async def _applied(conn: asyncpg.Connection) -> set[str]:
    rows = await conn.fetch("SELECT name FROM schema_migrations")
    return {row["name"] for row in rows}


async def _pending(conn: asyncpg.Connection) -> list[pathlib.Path]:
    applied = await _applied(conn)
    files = sorted(MIGRATIONS_DIR.glob("*.sql"))
    return [f for f in files if f.name not in applied]


async def migrate(dsn: str | None = None, verbose: bool = True) -> list[str]:
    dsn = dsn or settings.database_url
    conn = await asyncpg.connect(dsn)
    try:
        await conn.execute(
            """
            CREATE TABLE IF NOT EXISTS schema_migrations (
                name        text PRIMARY KEY,
                applied_at  timestamptz NOT NULL DEFAULT now()
            )
            """
        )
        await conn.execute("SELECT pg_advisory_lock($1)", LOCK_ID)
        done: list[str] = []
        for path in await _pending(conn):
            sql = path.read_text(encoding="utf-8")
            async with conn.transaction():
                await conn.execute(sql)
                await conn.execute(
                    "INSERT INTO schema_migrations(name) VALUES($1) ON CONFLICT DO NOTHING",
                    path.name,
                )
            done.append(path.name)
            if verbose:
                print(f"  applied  {path.name}")
        if not done and verbose:
            print("  schema already up to date")
        return done
    finally:
        await conn.execute("SELECT pg_advisory_unlock($1)", LOCK_ID)
        await conn.close()


def main() -> int:
    if len(sys.argv) > 1 and sys.argv[1] == "--dsn":
        settings.database_url = sys.argv[2]
    try:
        asyncio.run(migrate())
    except Exception as exc:
        print(f"migration failed: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
