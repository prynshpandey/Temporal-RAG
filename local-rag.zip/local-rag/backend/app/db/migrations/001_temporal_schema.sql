-- ---------------------------------------------------------------------------
-- 001 - temporal knowledge schema for the Business Time Machine.
--
-- Design rules encoded here:
--   * three distinct clocks: event_date (it happened), document_date (it was
--     written), uploaded_at (it entered the system). effective_date is their
--     COALESCE and is what temporal filtering uses.
--   * never fabricate a date: any of the three may be NULL and the row records
--     how certain the date is in temporal_certainty.
--   * validity intervals (valid_from / valid_until) are half-open and are closed,
--     never deleted, when a fact is superseded.
--   * full text and trigram indexes live next to the text so hybrid search is
--     one SQL round trip.
-- ---------------------------------------------------------------------------

CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- ------------------------------------------------------------------ documents
CREATE TABLE IF NOT EXISTS documents (
    document_id        text PRIMARY KEY,
    name               text        NOT NULL,
    storage_key        text,
    source             text        NOT NULL DEFAULT 'upload',
    document_type      text        NOT NULL,
    mime_type          text,
    size_bytes         bigint      NOT NULL DEFAULT 0,
    sha256             text,
    document_date      date,
    event_date         date,
    effective_date     date,
    valid_from         date,
    valid_until        date,
    temporal_certainty text        NOT NULL DEFAULT 'unknown',
    uploaded_at        timestamptz NOT NULL DEFAULT now(),
    status             text        NOT NULL DEFAULT 'indexed',
    summary            text,
    qdrant_point_id    bigint,
    page_count         int,
    section_count      int         NOT NULL DEFAULT 0,
    chunk_count        int         NOT NULL DEFAULT 0,
    event_count        int         NOT NULL DEFAULT 0,
    title              text,
    authors            text,
    metadata           jsonb       NOT NULL DEFAULT '{}'::jsonb,
    created_at         timestamptz NOT NULL DEFAULT now(),
    updated_at         timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS documents_effective_date_idx ON documents (effective_date);
CREATE INDEX IF NOT EXISTS documents_document_date_idx  ON documents (document_date);
CREATE INDEX IF NOT EXISTS documents_valid_from_idx     ON documents (valid_from);
CREATE INDEX IF NOT EXISTS documents_valid_until_idx    ON documents (valid_until);
CREATE INDEX IF NOT EXISTS documents_type_idx           ON documents (document_type);
CREATE INDEX IF NOT EXISTS documents_sha256_idx         ON documents (sha256);
CREATE INDEX IF NOT EXISTS documents_uploaded_at_idx    ON documents (uploaded_at DESC);
CREATE INDEX IF NOT EXISTS documents_metadata_idx       ON documents USING gin (metadata jsonb_path_ops);

-- ------------------------------------------------------------------- sections
CREATE TABLE IF NOT EXISTS document_sections (
    section_id         text PRIMARY KEY,
    document_id        text     NOT NULL REFERENCES documents(document_id) ON DELETE CASCADE,
    parent_section_id  text     REFERENCES document_sections(section_id) ON DELETE CASCADE,
    title              text,
    level              int      NOT NULL DEFAULT 1,
    ordinal            int      NOT NULL,
    page               int,
    text               text     NOT NULL,
    char_count         int      NOT NULL DEFAULT 0,
    effective_date     date,
    qdrant_point_id    bigint,
    tsv tsvector GENERATED ALWAYS AS (
        to_tsvector('english', coalesce(title, '') || ' ' || text)
    ) STORED,
    created_at         timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS document_sections_document_idx ON document_sections (document_id, ordinal);
CREATE INDEX IF NOT EXISTS document_sections_parent_idx   ON document_sections (parent_section_id);
CREATE INDEX IF NOT EXISTS document_sections_tsv_idx      ON document_sections USING gin (tsv);
CREATE INDEX IF NOT EXISTS document_sections_title_trgm   ON document_sections USING gin (title gin_trgm_ops);

-- --------------------------------------------------------------------- chunks
CREATE TABLE IF NOT EXISTS document_chunks (
    chunk_id           text PRIMARY KEY,
    document_id        text     NOT NULL REFERENCES documents(document_id) ON DELETE CASCADE,
    section_id         text     REFERENCES document_sections(section_id) ON DELETE SET NULL,
    parent_id          text,
    chunk_index        int      NOT NULL,
    page               int,
    text               text     NOT NULL,
    char_count         int      NOT NULL DEFAULT 0,
    identifiers        text[]   NOT NULL DEFAULT '{}',
    event_date         date,
    effective_date     date,
    temporal_certainty text     NOT NULL DEFAULT 'unknown',
    qdrant_point_id    bigint,
    tsv tsvector GENERATED ALWAYS AS (to_tsvector('english', text)) STORED,
    created_at         timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS document_chunks_document_idx   ON document_chunks (document_id, chunk_index);
CREATE INDEX IF NOT EXISTS document_chunks_section_idx    ON document_chunks (section_id);
CREATE INDEX IF NOT EXISTS document_chunks_parent_idx     ON document_chunks (parent_id);
CREATE INDEX IF NOT EXISTS document_chunks_effective_idx  ON document_chunks (effective_date);
CREATE INDEX IF NOT EXISTS document_chunks_tsv_idx        ON document_chunks USING gin (tsv);
CREATE INDEX IF NOT EXISTS document_chunks_trgm_idx       ON document_chunks USING gin (text gin_trgm_ops);
CREATE INDEX IF NOT EXISTS document_chunks_identifiers_idx ON document_chunks USING gin (identifiers);

-- ------------------------------------------------------------------- entities
CREATE TABLE IF NOT EXISTS entities (
    entity_id       bigserial PRIMARY KEY,
    name            text NOT NULL,
    normalized_name text NOT NULL UNIQUE,
    entity_type     text NOT NULL DEFAULT 'unknown',
    mention_count   int  NOT NULL DEFAULT 0,
    first_seen      date,
    last_seen       date,
    metadata        jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at      timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS entities_name_trgm_idx ON entities USING gin (normalized_name gin_trgm_ops);
CREATE INDEX IF NOT EXISTS entities_type_idx     ON entities (entity_type);

CREATE TABLE IF NOT EXISTS entity_mentions (
    mention_id   bigserial PRIMARY KEY,
    entity_id    bigint NOT NULL REFERENCES entities(entity_id) ON DELETE CASCADE,
    document_id  text   NOT NULL REFERENCES documents(document_id) ON DELETE CASCADE,
    chunk_id     text,
    event_id     bigint,
    role         text   NOT NULL DEFAULT 'mentioned',
    created_at   timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS entity_mentions_entity_idx   ON entity_mentions (entity_id);
CREATE INDEX IF NOT EXISTS entity_mentions_document_idx ON entity_mentions (document_id);
CREATE UNIQUE INDEX IF NOT EXISTS entity_mentions_unique_idx
    ON entity_mentions (entity_id, document_id, coalesce(chunk_id, ''), coalesce(event_id, 0));

-- --------------------------------------------------------------------- events
CREATE TABLE IF NOT EXISTS events (
    event_id     bigserial PRIMARY KEY,
    document_id  text NOT NULL REFERENCES documents(document_id) ON DELETE CASCADE,
    chunk_id     text,
    event_date   date,
    date_text    text,
    event_type   text NOT NULL DEFAULT 'event',
    title        text,
    description  text,
    entity_names text[] NOT NULL DEFAULT '{}',
    confidence   real NOT NULL DEFAULT 0.5,
    extraction   text NOT NULL DEFAULT 'deterministic',
    evidence_text text,
    metadata     jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at   timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS events_date_idx       ON events (event_date);
CREATE INDEX IF NOT EXISTS events_document_idx  ON events (document_id);
CREATE INDEX IF NOT EXISTS events_type_idx      ON events (event_type);
CREATE INDEX IF NOT EXISTS events_entities_idx  ON events USING gin (entity_names);
CREATE INDEX IF NOT EXISTS events_title_trgm    ON events USING gin (title gin_trgm_ops);

-- ---------------------------------------------------------------------- facts
CREATE TABLE IF NOT EXISTS facts (
    fact_id       bigserial PRIMARY KEY,
    document_id   text   NOT NULL REFERENCES documents(document_id) ON DELETE CASCADE,
    chunk_id      text,
    subject       text   NOT NULL,
    predicate     text   NOT NULL,
    object_value  text,
    entity_names  text[] NOT NULL DEFAULT '{}',
    event_date    date,
    valid_from    date,
    valid_until   date,
    confidence    real   NOT NULL DEFAULT 0.5,
    extraction    text   NOT NULL DEFAULT 'deterministic',
    superseded_by bigint REFERENCES facts(fact_id) ON DELETE SET NULL,
    created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS facts_subject_idx     ON facts (lower(subject));
CREATE INDEX IF NOT EXISTS facts_valid_from_idx  ON facts (valid_from);
CREATE INDEX IF NOT EXISTS facts_valid_until_idx ON facts (valid_until);
CREATE INDEX IF NOT EXISTS facts_event_date_idx  ON facts (event_date);
CREATE INDEX IF NOT EXISTS facts_entities_idx    ON facts USING gin (entity_names);
CREATE INDEX IF NOT EXISTS facts_document_idx    ON facts (document_id);

-- -------------------------------------------------------------- relationships
CREATE TABLE IF NOT EXISTS relationships (
    relationship_id bigserial PRIMARY KEY,
    from_entity      text NOT NULL,
    to_entity        text NOT NULL,
    relation_type    text NOT NULL DEFAULT 'related_to',
    document_id      text REFERENCES documents(document_id) ON DELETE CASCADE,
    valid_from       date,
    valid_until      date,
    confidence       real NOT NULL DEFAULT 0.5,
    created_at       timestamptz NOT NULL DEFAULT now(),
    UNIQUE (from_entity, to_entity, relation_type, document_id)
);

CREATE INDEX IF NOT EXISTS relationships_from_idx ON relationships (from_entity);
CREATE INDEX IF NOT EXISTS relationships_to_idx   ON relationships (to_entity);
