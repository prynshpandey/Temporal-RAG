-- 002: the chunk level, which retrieval needs to separate leaves from context.
--
-- document_chunks stores every level of the hierarchy (document, section,
-- parent, child) in one table so a parent can be joined to its children without
-- a second table. Nothing recorded which one a row was, so retrieval could not
-- tell "this is a leaf that may answer" from "this is a parent that only gives
-- context". parent_id being NULL is not enough: document and section units also
-- have no parent.
--
-- Existing rows are backfilled by shape: a chunk with a parent is a leaf (3),
-- otherwise it is the highest unit of its section (2).

ALTER TABLE document_chunks ADD COLUMN IF NOT EXISTS level smallint NOT NULL DEFAULT 3;

UPDATE document_chunks SET level = 3 WHERE parent_id IS NOT NULL;
UPDATE document_chunks SET level = 2 WHERE parent_id IS NULL;

-- Parents are the most asked-for rows, because every hit is expanded to one.
CREATE INDEX IF NOT EXISTS document_chunks_level_idx ON document_chunks (level);

-- Retrieval ranks by date within a level, and the temporal filter runs on it.
CREATE INDEX IF NOT EXISTS document_chunks_level_date_idx ON document_chunks (level, effective_date DESC NULLS LAST);
