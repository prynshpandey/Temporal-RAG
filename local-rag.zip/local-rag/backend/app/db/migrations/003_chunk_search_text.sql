-- 003: keyword search over the same text the vector index saw.
--
-- A leaf chunk's body is a bare paragraph: "The number of employees at the end
-- of FY2024 was 214." Its section title lives in level_path, which only the
-- embedding saw. So a question containing only the document or section name -
-- "How many employees does Helios have?", where every other word is a stopword -
-- matched nothing in Postgres while matching plenty in Qdrant. Keyword and
-- vector search were looking at different text.
--
-- search_text is the same breadcrumb-plus-body string that was embedded, and the
-- tsvector is generated from it. text stays the bare body, because that is what
-- a citation should quote.

ALTER TABLE document_chunks ADD COLUMN IF NOT EXISTS search_text text;

UPDATE document_chunks SET search_text = text WHERE search_text IS NULL;

ALTER TABLE document_chunks ALTER COLUMN search_text SET NOT NULL;

ALTER TABLE document_chunks DROP COLUMN IF EXISTS tsv;

ALTER TABLE document_chunks
    ADD COLUMN tsv tsvector GENERATED ALWAYS AS (to_tsvector('english', search_text)) STORED;

CREATE INDEX IF NOT EXISTS document_chunks_tsv_idx ON document_chunks USING gin (tsv);
