"""Structured logging with secret redaction and a request id.

Every pipeline stage (parse, chunk, embed, store, retrieve, rerank, generate)
emits one structured line so a single query can be reconstructed end to end:
``GET /api/v1/query 12ms  retrieved=12 reranked=5 provider=groq``.
"""

from __future__ import annotations

import json
import logging
import re
import sys
import time
import uuid
from contextvars import ContextVar
from typing import Any

request_id_var: ContextVar[str] = ContextVar("request_id", default="-")

_SECRET_PATTERNS = [
    re.compile(r"gsk_[A-Za-z0-9_\-]{10,}"),
    re.compile(r"(?i)(password|api[_-]?key|secret|token)(\"?\s*[:=]\s*\"?)([^\s\"',}]+)"),
]


def redact(value: str) -> str:
    out = value
    for pattern in _SECRET_PATTERNS:
        if pattern.groups:
            out = pattern.sub(lambda m: f"{m.group(1)}{m.group(2)}***", out)
        else:
            out = pattern.sub("gsk_***", out)
    return out


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "ts": time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(record.created)),
            "level": record.levelname.lower(),
            "logger": record.name,
            "msg": redact(record.getMessage()),
            "request_id": request_id_var.get(),
        }
        for key, value in getattr(record, "extra_fields", {}).items():
            payload[key] = value
        if record.exc_info:
            payload["exc"] = redact(self.formatException(record.exc_info))[-2000:]
        return json.dumps(payload, default=str)


class TextFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        rid = request_id_var.get()
        fields = getattr(record, "extra_fields", {})
        tail = " ".join(f"{k}={v}" for k, v in fields.items())
        base = f"{time.strftime('%H:%M:%S')} {record.levelname[:4]:<4} [{rid}] {redact(record.getMessage())}"
        return f"{base} {redact(tail)}".rstrip()


def configure_logging(level: str = "INFO", fmt: str = "json") -> None:
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(JsonFormatter() if fmt == "json" else TextFormatter())
    root = logging.getLogger()
    root.handlers = [handler]
    root.setLevel(level.upper())
    for noisy in ("httpx", "httpcore", "asyncio", "uvicorn.access"):
        logging.getLogger(noisy).setLevel(logging.WARNING)
    logging.getLogger("openai").setLevel(logging.WARNING)


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)


def log_event(logger: logging.Logger, msg: str, level: int = logging.INFO, **fields: Any) -> None:
    """Log one structured event: ``log_event(log, "stored", chunks=4)``."""
    logger.log(level, msg, extra={"extra_fields": fields})


def new_request_id() -> str:
    return uuid.uuid4().hex[:12]
