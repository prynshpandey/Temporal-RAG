"""Answer synthesis: turn retrieved chunks into an answer that can be checked.

Three rules shape this module, and all three exist because a language model will
happily write a confident sentence that the sources do not support.

**The model only ever sees chunks that already passed the temporal filter.** A
chunk dated after ``as_of`` is not retrieved, so it cannot be quoted, paraphrased
or leaked into an answer. The no-future-leakage guarantee is enforced in SQL and
in Qdrant; this module never gets the chance to break it.

**Citations are validated against the retrieved set, not trusted.** A model that
cites ``[7]`` when only four chunks were supplied has invented a source. Those
citations are dropped and recorded in ``rejected_citations`` rather than being
passed through to a reader who would go looking for document 7.

**Failing to answer is a valid outcome.** If the model is unavailable, or the
retrieved context does not answer the question, the response says so and says
which. An extractive fallback quotes the passages instead of paraphrasing them,
because a quote cannot misstate a number. Pretending an absence of knowledge is
an answer is the one failure mode a time machine cannot have: it would put a
confident claim about the past into a system whose whole purpose is to be
reliable about the past.
"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from datetime import date
from typing import Any

from app.config import settings
from app.llm.groq import GroqUsage
from app.llm.provider import complete_json
from app.logging import get_logger, log_event
from app.services import retrieval

logger = get_logger("btm.answer")

_CITATION = re.compile(r"\[(\d+)\]")

SYSTEM_PROMPT = """You answer questions about a company using only the numbered context passages.

Rules, in order of importance:
1. Use only facts stated in the passages. Never use outside knowledge, and never
   guess a number, name or date that is not written in a passage.
2. Cite every claim with the passage number in square brackets, like [2]. A
   sentence with no citation will be discarded.
3. If the passages do not answer the question, say so plainly and set
   "supported" to false. Do not fill the gap with a likely-sounding answer.
4. The passages are a snapshot of what was known at a specific date. Treat them
   as the complete state of knowledge at that date, not as a sample.
5. Be brief. Short factual sentences, no preamble, no restating the question.

Return JSON: {"answer": string, "supported": boolean, "citations": [int], "as_of": string|null}"""


@dataclass
class Citation:
    number: int
    chunk_id: str
    document_id: str
    document_name: str
    effective_date: date | None
    page: int | None = None
    quote: str = ""

    def as_dict(self) -> dict[str, Any]:
        return {
            "number": self.number,
            "chunk_id": self.chunk_id,
            "document_id": self.document_id,
            "document_name": self.document_name,
            "effective_date": self.effective_date.isoformat() if self.effective_date else None,
            "page": self.page,
            "quote": self.quote,
        }


@dataclass
class Answer:
    text: str
    mode: str  # generated | extractive | no_context
    supported: bool = True
    citations: list[Citation] = field(default_factory=list)
    rejected_citations: list[int] = field(default_factory=list)
    llm: dict[str, Any] = field(default_factory=dict)
    stats: dict[str, Any] = field(default_factory=dict)
    as_of: date | None = None
    elapsed_ms: int = 0

    def as_dict(self) -> dict[str, Any]:
        return {
            "answer": self.text,
            "mode": self.mode,
            "supported": self.supported,
            "as_of": self.as_of.isoformat() if self.as_of else None,
            "citations": [c.as_dict() for c in self.citations],
            "rejected_citations": self.rejected_citations,
            "llm": self.llm,
            "stats": self.stats,
            "elapsed_ms": self.elapsed_ms,
        }


def _quote(hit: retrieval.Hit, limit: int = 400) -> str:
    """A short passage for a citation: the leaf, trimmed to whole sentences."""
    text = (hit.text or "").strip()
    if len(text) <= limit:
        return text
    cut = text[:limit]
    stop = max(cut.rfind(". "), cut.rfind(".\n"))
    return (cut[: stop + 1] if stop > limit * 0.5 else cut).strip() + "…"


_ERROR_MESSAGE = re.compile(r'"message"\s*:\s*"((?:[^"\\]|\\.)*)"')


def _brief_reason(text: object, limit: int = 140) -> str:
    """A provider error, short enough to read and clean enough to quote.

    Providers wrap the useful part in a JSON envelope whose tail is noise. The
    message inside is a complete sentence; the envelope around it is a fragment
    that any hard character cut leaves malformed - stray backticks, an unclosed
    brace - and this text is shown to the user on the single most common failure
    path, a rate limit. Prefer the message, and only fall back to the raw text
    when there is nothing better to show.
    """
    flat = " ".join(str(text).split())
    match = _ERROR_MESSAGE.search(flat)
    if match:
        inner = match.group(1).replace('\\"', '"').replace("\\\\", "\\").strip()
        if inner:
            flat = inner
    flat = flat.replace("`", "").replace("\n", " ").strip()
    if len(flat) > limit:
        cut = flat[:limit].rsplit(" ", 1)[0].rstrip(",;:.-")
        flat = (cut or flat[:limit]) + "\u2026"
    return flat.strip("\"' ")



def _extractive(hits: list[retrieval.Hit], as_of: date | None, reason: str) -> Answer:
    """Quote the passages instead of paraphrasing them.

    A quote cannot misstate a number. When the model is unavailable this is the
    honest answer, not a degraded one.
    """
    when = f"as of {as_of.isoformat()}" if as_of else "in the current snapshot"
    parts = [
        f"No generated answer was produced ({_brief_reason(reason)}). The passages below are the "
        f"most relevant knowledge available {when}, quoted verbatim:"
    ]
    citations: list[Citation] = []
    for number, hit in enumerate(hits[:3], start=1):
        quote = _quote(hit)
        if not quote:
            continue
        parts.append(f"[{number}] {quote}")
        citations.append(
            Citation(
                number=number,
                chunk_id=hit.chunk_id,
                document_id=hit.document_id,
                document_name=hit.document_name,
                effective_date=hit.effective_date,
                page=hit.page,
                quote=quote,
            )
        )
    return Answer(
        text="\n\n".join(parts),
        mode="extractive",
        supported=True,
        citations=citations,
        as_of=as_of,
    )


def _no_context(as_of: date | None, question: str) -> Answer:
    when = f"as of {as_of.isoformat()}" if as_of else "in the current snapshot"
    return Answer(
        text=(
            f"Nothing in the corpus answers this question {when}. No document "
            f"was available on that date, so there is no evidence to answer from."
        ),
        mode="no_context",
        supported=False,
        as_of=as_of,
    )


def _build_context(hits: list[retrieval.Hit], as_of: date | None) -> str:
    blocks: list[str] = []
    for number, hit in enumerate(hits, start=1):
        # The parent gives the model the surrounding section; the leaf is what
        # was actually matched, and the citation points at it.
        body = hit.parent_text or hit.text
        date_label = hit.effective_date.isoformat() if hit.effective_date else "undated"
        header = f"[{number}] {hit.document_name} (effective {date_label}"
        if hit.page is not None:
            header += f", page {hit.page}"
        header += ")"
        blocks.append(f"{header}\n{body.strip()}")
    return "\n\n".join(blocks)


def _validate_citations(
    raw: Any, hits: list[retrieval.Hit]
) -> tuple[list[Citation], list[int], str]:
    """Turn the model's citation numbers into citations, or throw them away."""
    numbers: list[int] = []
    if isinstance(raw, list):
        for item in raw:
            if isinstance(item, int):
                numbers.append(item)
            elif isinstance(item, str) and item.strip().isdigit():
                numbers.append(int(item.strip()))
    for match in _CITATION.findall(str(raw or "")):
        value = int(match)
        if value not in numbers:
            numbers.append(value)

    citations: list[Citation] = []
    rejected: list[int] = []
    for number in numbers:
        if 1 <= number <= len(hits):
            hit = hits[number - 1]
            citations.append(
                Citation(
                    number=number,
                    chunk_id=hit.chunk_id,
                    document_id=hit.document_id,
                    document_name=hit.document_name,
                    effective_date=hit.effective_date,
                    page=hit.page,
                    quote=_quote(hit, 200),
                )
            )
        else:
            # A source that was never supplied. Reported, never rendered.
            rejected.append(number)
    citations.sort(key=lambda c: c.number)
    return citations, rejected, ""


async def answer(
    question: str,
    *,
    as_of: date | None = None,
    start: date | None = None,
    end: date | None = None,
    document_ids: list[str] | None = None,
    document_types: list[str] | None = None,
    entity: str | None = None,
    limit: int = 6,
    max_context_chars: int | None = None,
) -> Answer:
    """Retrieve, then answer from the retrieved passages only."""
    started = time.perf_counter()
    question = (question or "").strip()
    if as_of is None and not (start and end):
        as_of = date.today()

    result = await retrieval.search(
        question,
        as_of=as_of,
        start=start,
        end=end,
        document_ids=document_ids,
        document_types=document_types,
        entity=entity,
        limit=limit,
    )
    hits: list[retrieval.Hit] = result["hits"]

    if not hits:
        log_event(logger, "answer_no_context", question=question[:80], as_of=str(as_of))
        return _no_context(as_of, question)

    usage = GroqUsage()
    context = _build_context(hits, as_of)
    budget = max_context_chars or settings.document_summary_chars
    truncated = False
    if len(context) > budget:
        # Keep whole passages: a cut-off passage invites a wrong answer more
        # reliably than a shorter context does.
        kept: list[str] = []
        total = 0
        for block in context.split("\n\n"):
            if total + len(block) > budget and kept:
                truncated = True
                break
            kept.append(block)
            total += len(block)
        context = "\n\n".join(kept)

    window = as_of.isoformat() if as_of else f"{start} to {end}"
    user_prompt = (
        f"Question: {question}\n\n"
        f"Knowledge snapshot: {window}\n\n"
        f"Context passages:\n{context}"
    )

    try:
        raw = await complete_json(
            SYSTEM_PROMPT,
            user_prompt,
            temperature=0.0,
            max_tokens=1200,
            usage=usage,
            expect=dict,
        )
    except Exception as exc:  # noqa: BLE001 - a missing answer is not a crash
        log_event(logger, "answer_llm_failed", question=question[:80], error=str(exc)[:200])
        # No pre-truncation here: cutting the provider envelope at an arbitrary
        # offset can land inside the quoted message, which is then impossible to
        # parse. _brief_reason does the trimming once it has the whole string.
        fallback = _extractive(hits, as_of, reason=f"the model was unavailable: {exc}")
        fallback.stats = result["stats"]
        fallback.llm = {"provider": usage.provider, "usage": usage.as_dict()}
        fallback.elapsed_ms = int((time.perf_counter() - started) * 1000)
        return fallback

    text = str(raw.get("answer") or "").strip()
    supported = bool(raw.get("supported", bool(text)))
    citations, rejected, _ = _validate_citations(raw.get("citations"), hits)

    if not text:
        fallback = _extractive(hits, as_of, reason="the model returned no answer text")
        fallback.stats = result["stats"]
        fallback.llm = {"provider": usage.provider, "usage": usage.as_dict()}
        fallback.elapsed_ms = int((time.perf_counter() - started) * 1000)
        return fallback

    # An answer that cites nothing is an unsourced claim. Demote it to a quote
    # rather than present it as an answer.
    if not citations:
        text = re.sub(r"\[\d+\]", "", text)
        answer_obj = _extractive(hits, as_of, reason="the model's answer cited no source")
        answer_obj.text = text + "\n\n" + answer_obj.text
        answer_obj.mode = "unsupported"
        answer_obj.supported = False
    else:
        answer_obj = Answer(text=text, mode="generated", supported=supported, citations=citations)

    answer_obj.rejected_citations = rejected
    answer_obj.as_of = as_of
    answer_obj.stats = {**result["stats"], "context_chars": len(context), "context_truncated": truncated}
    answer_obj.llm = {"provider": usage.provider, "usage": usage.as_dict()}
    answer_obj.elapsed_ms = int((time.perf_counter() - started) * 1000)
    log_event(
        logger,
        "answer",
        mode=answer_obj.mode,
        supported=answer_obj.supported,
        citations=len(citations),
        rejected=len(rejected),
        as_of=str(as_of),
        ms=answer_obj.elapsed_ms,
    )
    return answer_obj
