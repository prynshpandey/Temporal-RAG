"""Point-in-time state reconstruction.

A snapshot answers a question retrieval cannot: not "which passages are
relevant to this wording" but "what did we know on this date, and what has
happened since".

Two decisions shape the output.

**It never calls a model.** Extraction is LLM-dependent, and the LLM is not
always available - during a quota outage the fact tables are nearly empty. A
snapshot that returns nothing when the model is down is useless for its one job,
which is establishing what was true on a date. So the structure comes from SQL:
which documents existed, when they were dated, how they supersede each other,
and what was deliberately withheld. Facts can be summarised on top of this; the
skeleton never depends on it.

**It shows its own omissions.** ``excluded`` lists every document kept out of
the snapshot and the ground for exclusion, and ``warnings`` flags a corpus that
has gone quiet. A time machine that quietly shows you three documents when it
holds six is worse than useless - it looks complete. The caller can render
``not_yet_known`` behind a "3 later documents exist" toggle; the snapshot they
are reading is still exactly what was known on the date.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date
from typing import Any

from app.config import settings
from app.logging import get_logger, log_event
from app.repositories import documents as repo

logger = get_logger("btm.state")

# Digits and the words that vary between editions of the same report. Stripped
# to group revisions: "annual report 2023" and "annual report 2024" are the same
# document in two states, not two documents.
_NOISE = re.compile(r"(\d+|_|-|\s+)", re.IGNORECASE)
_QUARTER = re.compile(r"\bq[1-4]\b|\bfy\b|\bfiscal\b|\bhalf\b|\bannual\b|\breport\b", re.IGNORECASE)

# Words that describe *when* an edition was published rather than *what* it is
# about. A family key made only of these carries no identity: "fy v" would group
# every fiscal filing in the corpus into one bogus chain.
PERIOD_WORDS = {
    "fy", "q1", "q2", "q3", "q4", "h1", "h2",
    "annual", "report", "fiscal", "half", "year", "v", "version", "final", "draft",
}

REASON_TEXT = {
    "dated_after_window": "dated after this date, so it was not yet known",
    "expired_before_window": "no longer valid at this date",
    "unknown": "could not be placed in time",
}


@dataclass
class State:
    as_of: date
    entity: str | None = None
    documents: list[dict[str, Any]] = field(default_factory=list)
    excluded: list[dict[str, Any]] = field(default_factory=list)
    passages: list[dict[str, Any]] = field(default_factory=list)
    families: list[dict[str, Any]] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.warnings = self._derive_warnings()

    def _derive_warnings(self) -> list[str]:
        """Everything a reader needs in order to not over-trust this snapshot.

        Derived from the snapshot's own contents rather than accumulated during
        construction, so a State assembled by any route carries the same
        caveats. A warning that only appears on one code path is a warning that
        will eventually be missing.
        """
        warnings: list[str] = []
        dates = [d["effective_date"] for d in self.documents if d.get("effective_date")]
        if not self.documents:
            warnings.append(
                f"No indexed document was valid on {self.as_of.isoformat()}. The snapshot is "
                "empty because nothing was known then, not because retrieval failed."
            )
        elif dates:
            stale = (self.as_of - max(dates)).days
            if stale > settings.state_stale_after_days:
                warnings.append(
                    f"The most recent evidence is dated {max(dates).isoformat()}, {stale} days "
                    "before this snapshot. Facts may have changed since; the corpus is not "
                    "keeping up."
                )
        undated = [d["name"] for d in self.documents if not d.get("effective_date")]
        if undated:
            warnings.append(
                f"{len(undated)} document(s) in this snapshot have no date and are included on "
                f"upload date alone: {', '.join(undated[:3])}" + (" ..." if len(undated) > 3 else "")
            )
        later = sum(1 for e in self.excluded if e.get("reason") == "dated_after_window")
        if later:
            warnings.append(
                f"{later} later document(s) are excluded from this snapshot. They are listed "
                "under excluded.not_yet_known and were not used."
            )
        return warnings

    def as_dict(self) -> dict[str, Any]:
        in_scope_dates = [d["effective_date"] for d in self.documents if d.get("effective_date")]
        not_yet = [e for e in self.excluded if e.get("reason") == "dated_after_window"]
        expired = [e for e in self.excluded if e.get("reason") == "expired_before_window"]
        newest = max(in_scope_dates) if in_scope_dates else None
        stale_days = (self.as_of - newest).days if newest else None
        return {
            "as_of": self.as_of.isoformat(),
            "entity": self.entity,
            "summary": {
                "documents_in_scope": len(self.documents),
                "documents_excluded": len(self.excluded),
                "passages": len(self.passages),
                "families": len(self.families),
                "oldest_evidence": min(in_scope_dates).isoformat() if in_scope_dates else None,
                "newest_evidence": newest.isoformat() if newest else None,
                "stale_days": stale_days,
            },
            "documents": self.documents,
            "families": self.families,
            "passages": self.passages,
            "excluded": {
                "not_yet_known": [e for e in not_yet],
                "expired": [e for e in expired],
            },
            "exclusion_reasons": REASON_TEXT,
            "warnings": self.warnings,
        }


def family_key(name: str) -> str:
    """Group successive editions of one document into a revision chain.

    The aggressive key drops the words that change between editions, so three
    annual reports share one family. It is accepted only if at least one real
    word survives: stripping "Report FY2023 v2" down to its content leaves
    "fy v", which is made entirely of period scaffolding and would merge every
    fiscal filing in the corpus into a single meaningless chain. When that
    happens the key falls back to the filename with only digits and separators
    removed, which is unique enough to be useful.
    """
    stem = re.sub(r"\.[a-z0-9]{1,5}$", "", name, flags=re.IGNORECASE)
    conservative = re.sub(r"\s+", " ", _NOISE.sub(" ", stem)).strip().lower()
    aggressive = re.sub(r"\s+", " ", _NOISE.sub(" ", _QUARTER.sub(" ", stem))).strip().lower()

    words = [w for w in re.findall(r"[a-z]+", aggressive) if len(w) >= 3]
    if words and not all(w in PERIOD_WORDS for w in words):
        return aggressive
    if len(re.sub(r"[^a-z]", "", conservative)) >= 3:
        return conservative
    # Nothing in the filename identifies the document. Label it plainly rather
    # than letting a bare "a" or "2024" read as a meaningful family name.
    return f"file-{conservative}" if conservative else "ungrouped"


def _group_families(
    in_scope: list[dict[str, Any]], excluded: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    """One entry per document family, with every edition and which are in scope.

    The editions after ``as_of`` appear here, marked ``in_scope: false``. They
    are metadata about the corpus, not knowledge: they carry no text into the
    snapshot.
    """
    families: dict[str, dict[str, Any]] = {}
    for doc in in_scope:
        key = family_key(doc["name"])
        entry = families.setdefault(key, {"key": key, "versions": []})
        entry["versions"].append(
            {
                "document_id": doc["document_id"],
                "name": doc["name"],
                "effective_date": doc.get("effective_date"),
                "temporal_certainty": doc.get("temporal_certainty"),
                "in_scope": True,
            }
        )
    for doc in excluded:
        if doc.get("reason") == "expired_before_window":
            continue
        key = family_key(doc["name"])
        entry = families.setdefault(key, {"key": key, "versions": []})
        entry["versions"].append(
            {
                "document_id": doc["document_id"],
                "name": doc["name"],
                "effective_date": doc.get("effective_date"),
                "temporal_certainty": doc.get("temporal_certainty"),
                "in_scope": False,
            }
        )
    for entry in families.values():
        entry["versions"].sort(key=lambda v: (v["effective_date"] is None, v["effective_date"] or date.min))
        entry["in_scope_count"] = sum(1 for v in entry["versions"] if v["in_scope"])
        entry["current_version"] = next(
            (v["document_id"] for v in reversed(entry["versions"]) if v["in_scope"]), None
        )
    return sorted(families.values(), key=lambda e: e["key"])


async def reconstruct(
    *,
    as_of: date | None = None,
    entity: str | None = None,
    document_types: list[str] | None = None,
    include_passages: bool = True,
    passage_limit: int | None = None,
) -> State:
    """The knowledge base as it stood on ``as_of``."""
    as_of = as_of or date.today()
    in_scope = await repo.documents_in_window(
        as_of=as_of, entity=entity, document_types=document_types
    )
    excluded = await repo.documents_outside_window(
        as_of=as_of, entity=entity, document_types=document_types
    )

    passages: list[dict[str, Any]] = []
    if include_passages and in_scope:
        passages = await repo.chunks_for_documents(
            [d["document_id"] for d in in_scope],
            level=2,
            limit=passage_limit or settings.state_passage_limit,
        )

    state = State(
        as_of=as_of,
        entity=entity,
        documents=in_scope,
        excluded=excluded,
        passages=passages,
        families=_group_families(in_scope, excluded),
    )

    log_event(
        logger,
        "state_reconstructed",
        as_of=as_of.isoformat(),
        entity=entity,
        in_scope=len(in_scope),
        excluded=len(excluded),
        passages=len(passages),
        warnings=len(state.warnings),
    )
    return state
