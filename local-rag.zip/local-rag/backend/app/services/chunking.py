"""Hierarchical chunking.

One document becomes four kinds of unit, each embedded separately so retrieval
can start broad and get specific:

======== =======================================================================
level    unit            size    used for
======== =======================================================================
0        document        1.2k    "what is this file about" - a single vector
1        section         0.6k    one per structural section
2        parent chunk    1.2k    retrieval unit: enough context to answer
3        child chunk     350     sent to the LLM after a parent is chosen
======== =======================================================================

Children keep a ``parent_id``: the LLM never sees a 350-character fragment
without its parent, and the child embeddings are only used to *locate* the
parent. Splits happen at paragraph, then sentence, then word boundaries - never
mid-sentence, and never inside a table row.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from app.parsers.base import ParsedDocument, Section

# Tuned for nomic-embed-text: 768 dims, ~8192 token context, but retrieval
# quality drops well before that, so chunks stay small on purpose.
DOC_SUMMARY_CHARS = 1200
SECTION_SUMMARY_CHARS = 600
PARENT_TARGET_CHARS = 1200
PARENT_MAX_CHARS = 1800
CHILD_TARGET_CHARS = 350
CHILD_MAX_CHARS = 550
CHILD_OVERLAP_CHARS = 60
MIN_CHILD_CHARS = 40

_SENTENCE_END = re.compile(r"(?<=[.!?])[\s\u00a0]+(?=[\"'\u201c\u201d)\]]*[A-Z0-9])")
_BULLET = re.compile(r"^\s*(?:[-*\u2022]|\d+[.)])\s+")


@dataclass
class Chunk:
    """One embeddable unit, at any level."""

    level: int                      # 0 document, 1 section, 2 parent, 3 child
    ordinal: int                    # position within its level
    text: str                       # what gets embedded
    context_text: str               # title + breadcrumb prefix, for the LLM
    section_id: str | None = None
    parent_id: str | None = None
    page: int | None = None
    level_path: str = ""            # e.g. "Handbook > Policy"
    char_count: int = 0
    chunk_index: int = 0
    kind: str = "text"

    def embed_text(self) -> str:
        """Vector input: breadcrumb + body, never the raw body alone."""
        return f"{self.level_path}\n{self.text}".strip() if self.level_path else self.text

    def display(self) -> str:
        return self.context_text or self.text


@dataclass
class ChunkSet:
    document_summary: Chunk
    section_summaries: list[Chunk] = field(default_factory=list)
    parents: list[Chunk] = field(default_factory=list)
    children: list[Chunk] = field(default_factory=list)

    @property
    def all_chunks(self) -> list[Chunk]:
        return [self.document_summary, *self.section_summaries, *self.parents, *self.children]

    def stats(self) -> dict[str, int]:
        return {
            "document": 1,
            "sections": len(self.section_summaries),
            "parents": len(self.parents),
            "children": len(self.children),
            "total": len(self.all_chunks),
        }


def _split_paragraphs(text: str) -> list[str]:
    return [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]


def _split_sentences(paragraph: str) -> list[str]:
    return [s.strip() for s in _SENTENCE_END.split(paragraph) if s.strip()]


def _pack(units: list[str], target: int, hard_max: int) -> list[str]:
    """Greedy packing that never exceeds ``hard_max`` and prefers paragraph
    boundaries, falling back to sentence and then word boundaries."""
    groups: list[str] = []
    current: list[str] = []
    length = 0

    def flush() -> None:
        nonlocal current, length
        if current:
            groups.append("\n\n".join(current))
            current, length = [], 0

    for unit in units:
        while len(unit) > hard_max:
            # A single oversized paragraph: cut on word boundaries.
            head, tail = unit[:hard_max], unit[hard_max:]
            if current:
                flush()
            groups.append(head)
            unit = tail.lstrip()
        if length and length + len(unit) + 2 > target:
            flush()
        current.append(unit)
        length += len(unit) + 2
        if length >= hard_max:
            flush()
    flush()
    return groups


def _breadcrumb(sections: list[Section], index: int) -> str:
    """Heading path of section ``index``, e.g. "Handbook > Policy"."""
    trail: list[str] = []
    for candidate in sections[: index + 1]:
        if not candidate.title:
            continue
        level = max(candidate.level, 1)
        # Replace deeper-or-equal trailing entries, then append.
        while trail and trail[-1][0] >= level:
            trail.pop()
        trail.append((level, candidate.title))
    return " > ".join(title for _, title in trail[-4:])


def build_chunks(document: ParsedDocument, document_id: str) -> ChunkSet:
    """Turn a parsed document into its four levels of embeddable units."""
    sections = [s for s in document.sections if s.text.strip()]
    if not sections:
        sections = [
            Section(key="s0", title=document.title, level=1, ordinal=0, text=document.text)
        ]

    doc_chunk = Chunk(
        level=0,
        ordinal=0,
        text=_document_summary(document, sections),
        context_text=document.title or f"document {document_id}",
        level_path=document.title or "",
        kind="document",
    )

    chunk_set = ChunkSet(document_summary=doc_chunk)
    parent_ordinal = 0
    child_ordinal = 0

    for position, section in enumerate(sections):
        section_id = f"{document_id}-s{section.ordinal:04d}"
        breadcrumb = _breadcrumb(sections, position)
        section_title = section.title or f"Section {position + 1}"

        chunk_set.section_summaries.append(
            Chunk(
                level=1,
                ordinal=position,
                text=_section_summary(section_title, section.text, breadcrumb),
                context_text=section_title,
                section_id=section_id,
                page=section.page,
                level_path=breadcrumb,
                kind="section",
            )
        )

        for group in _pack(_split_paragraphs(section.text), PARENT_TARGET_CHARS, PARENT_MAX_CHARS):
            parent_id = f"{document_id}-p{parent_ordinal:04d}"
            parent = Chunk(
                level=2,
                ordinal=parent_ordinal,
                text=group,
                context_text=_context(breadcrumb, section_title, group),
                section_id=section_id,
                page=section.page,
                level_path=breadcrumb,
                char_count=len(group),
                kind="parent",
            )
            chunk_set.parents.append(parent)

            for child_text in _split_children(group):
                if len(child_text) < MIN_CHILD_CHARS and chunk_set.children:
                    previous = chunk_set.children[-1]
                    if previous.parent_id == parent_id and len(previous.text) + len(child_text) <= CHILD_MAX_CHARS:
                        previous.text = f"{previous.text}\n{child_text}".strip()
                        previous.char_count = len(previous.text)
                        continue
                chunk_set.children.append(
                    Chunk(
                        level=3,
                        ordinal=child_ordinal,
                        text=child_text,
                        context_text=_context(breadcrumb, section_title, child_text),
                        section_id=section_id,
                        parent_id=parent_id,
                        page=section.page,
                        level_path=breadcrumb,
                        char_count=len(child_text),
                        chunk_index=child_ordinal,
                        kind="child",
                    )
                )
                child_ordinal += 1
            parent_ordinal += 1

    if not chunk_set.children:
        # Degenerate input (one tiny section): the parent doubles as the child so
        # retrieval always has something to point at.
        for parent in chunk_set.parents:
            chunk_set.children.append(
                Chunk(
                    level=3,
                    ordinal=len(chunk_set.children),
                    text=parent.text,
                    context_text=parent.context_text,
                    section_id=parent.section_id,
                    parent_id=f"{document_id}-p{parent.ordinal:04d}",
                    page=parent.page,
                    level_path=parent.level_path,
                    char_count=parent.char_count,
                    chunk_index=len(chunk_set.children),
                    kind="child",
                )
            )

    return chunk_set


def _split_children(parent_text: str) -> list[str]:
    """Split a parent into overlapping child windows on sentence boundaries."""
    if len(parent_text) <= CHILD_MAX_CHARS:
        return [parent_text]

    sentences: list[str] = []
    for paragraph in _split_paragraphs(parent_text):
        for sentence in _split_sentences(paragraph):
            sentences.extend(_split_long_sentence(sentence))
    if not sentences:
        return [parent_text]

    children: list[str] = []
    window: list[str] = []
    length = 0
    for sentence in sentences:
        if length and length + len(sentence) + 1 > CHILD_TARGET_CHARS:
            children.append(" ".join(window).strip())
            # Overlap: carry whole sentences over until the budget is spent.
            overlap: list[str] = []
            overlap_len = 0
            for carried in reversed(window):
                if overlap_len + len(carried) > CHILD_OVERLAP_CHARS:
                    break
                overlap.insert(0, carried)
                overlap_len += len(carried) + 1
            window = overlap
            length = overlap_len
        window.append(sentence)
        length += len(sentence) + 1
        if length >= CHILD_MAX_CHARS:
            children.append(" ".join(window).strip())
            window, length = [], 0
    if window:
        tail = " ".join(window).strip()
        if children and len(tail) < MIN_CHILD_CHARS:
            children[-1] = f"{children[-1]} {tail}".strip()
        elif tail:
            children.append(tail)
    return [c for c in children if c.strip()]


def _split_long_sentence(sentence: str, hard_max: int = CHILD_MAX_CHARS) -> list[str]:
    if len(sentence) <= hard_max:
        return [sentence]
    words, pieces, current = sentence.split(), [], []
    length = 0
    for word in words:
        if length + len(word) + 1 > hard_max and current:
            pieces.append(" ".join(current))
            current, length = [], 0
        current.append(word)
        length += len(word) + 1
    if current:
        pieces.append(" ".join(current))
    return pieces


def _context(breadcrumb: str, title: str, body: str) -> str:
    """What the LLM is shown: where the text came from, then the text."""
    head = body.strip().split("\n", 1)[0]
    where = breadcrumb or title
    return f"[{where}] {head}" if head else f"[{where}]"


def _document_summary(document: ParsedDocument, sections: list[Section]) -> str:
    """Bounded whole-document description - one vector, never the whole file."""
    titles = [s.title for s in sections if s.title]
    # A numbered heading ("2. Segments") is a poor document name, so the real
    # title wins, then the filename, and only then a section heading.
    name = document.title or document.metadata.get("filename") or f"{document.document_type} document"
    facts = [f"- {t}" for t in titles[:25]]
    meta: list[str] = []
    if document.page_count:
        meta.append(f"{document.page_count} pages")
    if document.authors:
        meta.append("by " + ", ".join(document.authors[:3]))
    meta.append(f"type: {document.document_type}")
    body = document.text.strip()
    excerpt = body[: DOC_SUMMARY_CHARS]
    if len(body) > DOC_SUMMARY_CHARS:
        excerpt = excerpt.rsplit(" ", 1)[0]
    parts = [f"{name} ({', '.join(meta)})"]
    if facts:
        parts.append("Sections:\n" + "\n".join(facts))
    if excerpt:
        parts.append("Excerpt:\n" + excerpt)
    return "\n\n".join(parts)


def _section_summary(title: str, text: str, breadcrumb: str) -> str:
    where = breadcrumb or title
    body = _strip_leading_heading(text, title)
    excerpt = body[:SECTION_SUMMARY_CHARS]
    if len(body) > SECTION_SUMMARY_CHARS:
        excerpt = excerpt.rsplit(" ", 1)[0]
    return f"{where}\n{excerpt}".strip()


def _strip_leading_heading(text: str, title: str | None) -> str:
    """Drop the heading line when the body already starts with it.

    PDF and DOCX parsers keep the heading as the first line of the section body;
    repeating it in the summary wastes a third of a 600-character budget.
    """
    body = re.sub(r"^#+\s*", "", text.strip())
    if not title:
        return body
    first, _, rest = body.partition("\n")
    if first.strip().casefold() == title.strip().casefold():
        return rest.strip() or body
    return body


def chunk_preview(chunks: ChunkSet, width: int = 70) -> str:
    lines: list[str] = []
    for chunk in chunks.all_chunks:
        head = chunk.text.replace("\n", " ")[:width]
        marker = {"document": "DOC", "section": "SEC", "parent": "PAR", "child": "CHI"}[chunk.kind]
        lines.append(f"  {marker} L{chunk.level} #{chunk.ordinal:<4} {head}")
    return "\n".join(lines)
