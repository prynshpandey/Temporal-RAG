"""Temporal metadata extraction.

Two passes, in this order on purpose:

1. **Deterministic dates** (:func:`find_dates`). A regex finds ISO dates, month
   and year, quarters and fiscal years. This is precise, free, and auditable, so
   the dates that decide point-in-time visibility never come from a model.
2. **Model extraction** of entities, events and facts, which is genuinely a
   language task. The model is told to return JSON with a fixed shape and to
   leave dates it cannot pin down empty rather than guessing.

The result feeds :func:`app.services.ingestion.register`. Two rules matter more
than anything the model produces:

* A *relative* date ("next quarter", "in the coming weeks") is recorded with
  ``temporal_certainty='relative'`` and never becomes an effective date - a
  forward-looking mention must not make a document visible in the past.
* ``effective_date`` is the document's own date when known (that is the earliest
  moment its knowledge existed), and only falls back to an event date.
"""

from __future__ import annotations

import calendar
import re
from dataclasses import dataclass
from datetime import date, datetime, timezone
from typing import Any

from app.config import settings
from app.llm.provider import GroqUsage, complete_json
from app.logging import get_logger, log_event

logger = get_logger("btm.extract")

MONTHS = {
    name: number
    for number, name in enumerate(
        [
            "january", "february", "march", "april", "may", "june",
            "july", "august", "september", "october", "november", "december",
        ],
        start=1,
    )
}
for _name, _number in list(MONTHS.items()):
    MONTHS[_name[:3]] = _number
MONTHS["sept"] = 9

_ISO = re.compile(r"\b(\d{4})-(\d{2})-(\d{2})\b")
_SLASHED = re.compile(r"\b(\d{1,2})/(\d{1,2})/(\d{4})\b")
_MONTH_YEAR = re.compile(
    r"\b(" + "|".join(sorted(MONTHS, key=len, reverse=True)) + r")\.?\s+(\d{4})\b", re.IGNORECASE
)
# "2025-07" on its own, but not the first half of "2025-07-15".
_YEAR_MONTH = re.compile(r"\b(\d{4})-(\d{2})\b(?!\s*-?\d{2})")
_MONTH_DAY_YEAR = re.compile(
    r"\b(" + "|".join(sorted(MONTHS, key=len, reverse=True)) + r")\.?\s+(\d{1,2})(?:st|nd|rd|th)?,?\s+(\d{4})\b",
    re.IGNORECASE,
)
_DAY_MONTH_YEAR = re.compile(
    r"\b(\d{1,2})(?:st|nd|rd|th)?\s+(" + "|".join(sorted(MONTHS, key=len, reverse=True)) + r")\.?,?\s+(\d{4})\b",
    re.IGNORECASE,
)
_QUARTER = re.compile(
    r"\b(?:Q([1-4])\s*[-/]?\s*(\d{4})|FY\s*(\d{4})\s*[-/]?\s*Q([1-4])|(\d{4})\s*[-/]?\s*Q([1-4]))\b",
    re.IGNORECASE,
)
_FISCAL = re.compile(r"\bFY\s*(\d{4})\b", re.IGNORECASE)
_RELATIVE = re.compile(
    r"\b(next|last|this|coming|previous|following|upcoming)\s+(quarter|month|year|week|sprint|release)\b"
    r"|\bin\s+(the\s+)?(near|coming|immediate)\s+(future|term|weeks?|months?)\b"
    r"|\bby\s+(the\s+)?end\s+of\s+(the\s+)?(year|quarter|month)\b",
    re.IGNORECASE,
)
_LAST_PASSED = re.compile(
    r"\b(yesterday|last\s+(week|month|quarter|year)|previously|a\s+(day|week|month|year)\s+ago)\b",
    re.IGNORECASE,
)

PRECISE, MONTH, QUARTER, YEAR, YEAR_REF, RELATIVE_KIND = (
    "iso", "month", "quarter", "year", "year_ref", "relative",
)
# "founded in 2011", "since 2019". Business prose is full of bare years, and a
# model that resolves one to 2011-01-01 is grounding correctly, not inventing.
# But a bare year is a historical reference far more often than it is the
# document's own date, so it may ground an event and never date the document.
_BARE_YEAR = re.compile(r"\b((?:19|20)\d{2})\b")


@dataclass(frozen=True)
class DateMention:
    value: date | None
    precision: str
    text: str
    position: int
    relative: bool = False

    @property
    def span(self) -> tuple[int, int]:
        return self.position, self.position + len(self.text)

    def as_dict(self) -> dict[str, Any]:
        return {
            "date": self.value.isoformat() if self.value else None,
            "precision": self.precision,
            "text": self.text,
            "relative": self.relative,
        }


def find_dates(text: str, *, reference: date | None = None) -> list[DateMention]:
    """Every date-ish mention, most precise first. Never raises on bad input."""
    reference = reference or datetime.now(timezone.utc).date()
    mentions: list[DateMention] = []

    for match in _ISO.finditer(text):
        parsed = _safe_date(int(match[1]), int(match[2]), int(match[3]))
        if parsed:
            mentions.append(DateMention(parsed, PRECISE, match.group(0), match.start()))

    for match in _SLASHED.finditer(text):
        day, month, year = int(match[1]), int(match[2]), int(match[3])
        parsed = _safe_date(year, month, day) or _safe_date(year, day, month)  # d/m vs m/d
        if parsed:
            mentions.append(DateMention(parsed, PRECISE, match.group(0), match.start()))

    for match in _MONTH_YEAR.finditer(text):
        month = MONTHS.get(match[1].lower())
        parsed = _safe_date(int(match[2]), month, 1) if month else None
        if parsed:
            mentions.append(DateMention(parsed, MONTH, match.group(0), match.start()))

    for match in _MONTH_DAY_YEAR.finditer(text):
        month = MONTHS.get(match[1].lower())
        parsed = _safe_date(int(match[3]), month, int(match[2])) if month else None
        if parsed:
            mentions.append(DateMention(parsed, PRECISE, match.group(0), match.start()))

    for match in _DAY_MONTH_YEAR.finditer(text):
        month = MONTHS.get(match[2].lower())
        parsed = _safe_date(int(match[3]), month, int(match[1])) if month else None
        if parsed:
            mentions.append(DateMention(parsed, PRECISE, match.group(0), match.start()))

    for match in _YEAR_MONTH.finditer(text):
        parsed = _safe_date(int(match[1]), int(match[2]), 1)
        if parsed:
            mentions.append(DateMention(parsed, MONTH, match.group(0), match.start()))

    for match in _QUARTER.finditer(text):
        # Three shapes: "Q2 2024", "FY2024 Q2", "2024 Q2".
        quarter, year = (match[1], match[2]) if match[1] else (match[4], match[3]) if match[4] else (match[6], match[5])
        parsed = _quarter_date(int(quarter), int(year)) if quarter and year else None
        if parsed:
            mentions.append(DateMention(parsed, QUARTER, match.group(0), match.start()))

    for match in _FISCAL.finditer(text):
        year = int(match[1])
        # A fiscal year is usually reported in the year it ends.
        parsed = _safe_date(year, 12, 31) or date(year, 12, 31)
        mentions.append(DateMention(parsed, YEAR, match.group(0), match.start()))

    for match in _BARE_YEAR.finditer(text):
        year = int(match[1])
        mentions.append(DateMention(date(year, 12, 31), YEAR_REF, match.group(0), match.start()))

    for match in _RELATIVE.finditer(text):
        mentions.append(DateMention(None, RELATIVE_KIND, match.group(0), match.start(), relative=True))

    for match in _LAST_PASSED.finditer(text):
        mentions.append(DateMention(None, "past_relative", match.group(0), match.start(), relative=True))

    return _resolve(mentions)


def _resolve(mentions: list[DateMention]) -> list[DateMention]:
    """Drop matches that live inside a stronger one, then duplicates.

    "2025-03-15" is one date, not an ISO day and a year-month; "March 2025"
    mentioned twice is one date. The most precise match of a span wins, because
    a weaker reading of the same text can only add noise to the index.
    """
    kept: list[DateMention] = []
    # Best match first at any given start: rank ascending, then longest. Sorting
    # by -rank here would let a bare "2025" win over "2025-03-15" and both would
    # survive, which is how a precise date silently degrades into a year.
    for mention in sorted(
        mentions, key=lambda m: (m.position, _rank(m.precision), -len(m.text))
    ):
        start, end = mention.span
        if any(
            other.span != mention.span and other.span[0] <= start and end <= other.span[1]
            for other in kept
        ):
            continue
        if any(k.value == mention.value and k.precision == mention.precision for k in kept):
            continue
        kept.append(mention)
    return sorted(kept, key=lambda m: (m.relative, -_rank(m.precision), m.position))


def _rank(precision: str) -> int:
    return {
        PRECISE: 0, MONTH: 1, QUARTER: 2, YEAR: 3,
        YEAR_REF: 4, "past_relative": 5, RELATIVE_KIND: 6,
    }.get(precision, 9)


def _safe_date(year: int, month: int, day: int) -> date | None:
    try:
        return date(year, month, day)
    except ValueError:
        return None


def _quarter_date(quarter: int, year: int) -> date | None:
    months = {1: (1, 1), 2: (4, 1), 3: (7, 1), 4: (10, 1)}
    month, day = months.get(quarter, (1, 1))
    return _safe_date(year, month, day)


def document_date_from(
    mentions: list[DateMention], *, fallback: date | None = None
) -> tuple[date | None, str]:
    """The date the document itself was written, plus how sure we are.

    Documents describe the past, so among mentions of the same precision the
    *latest* one is the best evidence of authorship: a report covering 2019-2025
    is not a 2019 document. Precision outranks recency, because an exact date
    mentioned anywhere beats a fiscal year printed in a footer.
    """
    concrete = [
        m for m in mentions if m.value is not None and not m.relative and m.precision != YEAR_REF
    ]
    if not concrete:
        return fallback, "unknown"
    best_rank = min(_rank(m.precision) for m in concrete)
    candidates = [m for m in concrete if _rank(m.precision) == best_rank]
    winner = max(candidates, key=lambda m: m.value)  # type: ignore[arg-type,return-value]
    return _period_end(winner.value, winner.precision), winner.precision  # type: ignore[arg-type]


def _period_end(value: date, precision: str) -> date:
    """Round a coarse date to the end of the period it names.

    "March 2025" means the document was written *at or after* March. Using March 1
    would make it visible in early March, before anyone could have read it, which
    is the same anachronism as indexing future content and is the one thing this
    system must not do. Rounding up costs a few days of recall in the safe
    direction; ``temporal_certainty='inferred'`` tells the UI the date is fuzzy.
    """
    if precision == MONTH:
        return _end_of_month(value.year, value.month)
    if precision == QUARTER:
        # The stored value is the quarter's first month (Jan/Apr/Jul/Oct), and a
        # quarter runs three months, so the end is start+2.
        return _end_of_month(value.year, min(value.month + 2, 12))
    if precision == YEAR:
        return date(value.year, 12, 31)
    return value


def _end_of_month(year: int, month: int) -> date:
    return date(year, month, calendar.monthrange(year, month)[1])


SYSTEM_PROMPT = """You extract structured business facts from a document for a temporal \
knowledge base. You never invent dates, names or numbers.

Rules:
- Only use dates that are written in the text. If a date is relative ("next quarter", \
"in coming weeks") leave event_date null and say so in date_text.
- An event is something that happened: an acquisition closed, a person started, a \
product launched, a number was reported. A plan or forecast is NOT an event; put it in \
facts with the predicate "planned_<what>" instead.
- entity_type is one of: organization, person, product, team, location, metric, other.
- Quote numbers exactly as written. Keep the unit ("412 million euro").
- subject is a short noun phrase, predicate is snake_case, object_value is the value.
"""


def _user_prompt(text: str, hint: dict[str, Any]) -> str:
    return f"""Document name: {hint.get('name')}
Detected document date: {hint.get('document_date') or 'unknown'}
Format: {hint.get('document_type')}

Text:
\"\"\"
{text}
\"\"\"

Return JSON with exactly these keys:
{{
  "summary": "2-3 sentences describing what this document establishes",
  "entities": [{{"name": "...", "entity_type": "organization|person|product|team|location|metric|other"}}],
  "events": [{{"title": "...", "event_date": "YYYY-MM-DD or null", "date_text": "the exact phrase \
used in the text", "event_type": "acquisition|hiring|launch|report|change|departure|other", \
"description": "one sentence", "entity_names": ["..."], "confidence": 0.0}}],
  "facts": [{{"subject": "...", "predicate": "snake_case", "object_value": "...", \
"entity_names": ["..."], "event_date": "YYYY-MM-DD or null", "confidence": 0.0}}]
}}"""


async def extract(plan: dict[str, Any], *, usage: GroqUsage | None = None) -> dict[str, Any]:
    """Extract the ``extracted`` payload for a parse plan.

    The text sent to the model is bounded (the document summary plus as many
    parent chunks as ``settings.document_summary_chars`` allows) so a 300-page
    PDF does not become a 400k-token request.
    """
    text = _bounded_text(plan)
    mentions = find_dates(text, reference=date.today())
    document_date, precision = document_date_from(mentions)

    payload: dict[str, Any] = {
        "source": plan.get("source", "upload"),
        "temporal_certainty": _certainty(precision, mentions),
        "document_date": document_date.isoformat() if document_date else None,
        "event_date": None,
        "valid_from": None,
        "valid_until": None,
        "summary": _deterministic_summary(plan),
        "entities": [],
        "events": [],
        "facts": [],
        "chunk_overrides": {},
        "metadata": {
            "dates_detected": [m.as_dict() for m in mentions[:40]],
            "date_precision": precision,
            "relative_mentions": sum(1 for m in mentions if m.relative),
        },
    }
    if not text.strip():
        return payload

    model_result: Any = None
    try:
        model_result = await complete_json(
            SYSTEM_PROMPT,
            _user_prompt(
                text,
                {
                    "name": plan.get("name"),
                    "document_date": payload["document_date"],
                    "document_type": plan.get("document_type"),
                },
            ),
            temperature=0.0,
            max_tokens=1600,
            usage=usage,
            expect=dict,
        )
    except Exception as exc:  # noqa: BLE001 - a document must still ingest
        log_event(logger, "extraction_failed", document_id=plan.get("document_id"), error=str(exc)[:200])
        payload["metadata"]["extraction_error"] = str(exc)[:200]
        return payload

    if not isinstance(model_result, dict):
        # A refusal, an apology or a bare string is not an extraction. Whatever
        # the caller promised, the document still ingests with its dates.
        payload["metadata"]["extraction_error"] = (
            f"model returned {type(model_result).__name__}, not an object"
        )
        log_event(
            logger, "extraction_unusable",
            document_id=plan.get("document_id"), got=type(model_result).__name__,
        )
        return payload

    _merge(payload, model_result, plan, document_date, mentions)
    log_event(
        logger,
        "extracted",
        document_id=plan.get("document_id"),
        entities=len(payload["entities"]),
        events=len(payload["events"]),
        facts=len(payload["facts"]),
        document_date=payload["document_date"],
    )
    return payload


def _bounded_text(plan: dict[str, Any]) -> str:
    """Summary first, then parent chunks, up to the configured budget."""
    budget = settings.document_summary_chars
    parts: list[str] = []
    for unit in plan.get("units") or []:
        if unit.get("level") == 0:
            parts.append(unit["text"])
        elif unit.get("level") == 2:
            parts.append(unit["text"])
        if sum(len(p) for p in parts) >= budget:
            break
    return "\n\n".join(parts)[:budget]


def _certainty(precision: str, mentions: list[DateMention]) -> str:
    if any(m.relative for m in mentions) and precision not in (PRECISE, MONTH):
        return "relative"
    if precision == PRECISE:
        return "explicit"
    if precision in (MONTH, QUARTER):
        return "inferred"
    return "unknown"


def _deterministic_summary(plan: dict[str, Any]) -> str:
    first = next((u for u in plan.get("units") or [] if u.get("level") == 0), None)
    if not first:
        return f"{plan.get('name')} ({plan.get('document_type')})"
    return first["text"][:1200]


def _merge(
    payload: dict[str, Any],
    result: dict[str, Any],
    plan: dict[str, Any],
    document_date: date | None,
    mentions: list[DateMention],
) -> None:
    summary = (result.get("summary") or "").strip()
    if summary:
        payload["summary"] = summary[:2000]

    seen: set[str] = set()
    entities: list[dict[str, Any]] = []
    for entity in result.get("entities") or []:
        name = (entity.get("name") or "").strip()
        if not name:
            continue
        key = name.lower()
        if key in seen:
            continue
        seen.add(key)
        entities.append(
            {
                "name": name,
                "entity_type": (entity.get("entity_type") or "other").lower()[:32],
                "seen_date": payload["document_date"],
                "role": "mentioned",
            }
        )
    payload["entities"] = entities[:100]

    known_dates = {m.value for m in mentions if m.value}
    events: list[dict[str, Any]] = []
    for event in result.get("events") or []:
        title = (event.get("title") or "").strip()
        if not title:
            continue
        parsed = _parse_model_date(event.get("event_date"), known_dates)
        confidence = _clamp(event.get("confidence", 0.5))
        # A date the model produced that the text never contained is dropped.
        if parsed and parsed not in known_dates:
            parsed = None
        events.append(
            {
                "title": title[:300],
                "event_date": parsed.isoformat() if parsed else None,
                "date_text": (event.get("date_text") or "")[:120] or None,
                "event_type": (event.get("event_type") or "other").lower()[:32],
                "description": (event.get("description") or "")[:600] or None,
                "entity_names": [str(n)[:120] for n in (event.get("entity_names") or [])][:20],
                "confidence": confidence,
                "extraction": "llm",
                "chunk_id": _chunk_for_text(plan, f"{title} {event.get('description') or ''}"),
            }
        )
    payload["events"] = events[:200]

    facts: list[dict[str, Any]] = []
    for fact in result.get("facts") or []:
        subject = (fact.get("subject") or "").strip()
        predicate = (fact.get("predicate") or "").strip()
        if not subject or not predicate:
            continue
        parsed = _parse_model_date(fact.get("event_date"), known_dates)
        if parsed and parsed not in known_dates:
            parsed = None
        facts.append(
            {
                "subject": subject[:200],
                "predicate": predicate.lower().replace(" ", "_")[:80],
                "object_value": str(fact.get("object_value") or "")[:400] or None,
                "entity_names": [str(n)[:120] for n in (fact.get("entity_names") or [])][:20],
                "event_date": parsed.isoformat() if parsed else None,
                "confidence": _clamp(fact.get("confidence", 0.5)),
                "extraction": "llm",
            }
        )
    payload["facts"] = facts[:200]

    # A dated event that the document itself predates by a wide margin is the
    # document's own news; use it as the document date when the deterministic pass
    # found nothing reliable.
    if payload["document_date"] is None and events:
        dated = [e for e in events if e["event_date"]]
        if dated:
            latest = max(e["event_date"] for e in dated)
            payload["event_date"] = latest
            payload["temporal_certainty"] = "inferred"


def _parse_model_date(value: Any, known: set[date]) -> date | None:
    if not value or not isinstance(value, str):
        return None
    parsed = _safe_date(*(int(p) for p in value[:10].split("-"))) if value.count("-") == 2 else None
    return parsed


def _clamp(value: Any, low: float = 0.0, high: float = 1.0) -> float:
    try:
        return max(low, min(high, float(value)))
    except (TypeError, ValueError):
        return 0.5


def _chunk_for_text(plan: dict[str, Any], needle: str, limit: int = 120) -> str | None:
    """Best-effort link from an event to the chunk that mentions it."""
    probe = [word for word in re.findall(r"[A-Za-z0-9]{4,}", needle.lower())][:12]
    if not probe:
        return None
    best_id, best_score = None, 0
    for unit in plan.get("units") or []:
        if unit.get("level") != 3:
            continue
        haystack = unit["text"].lower()
        score = sum(1 for word in probe if word in haystack)
        if score > best_score:
            best_id, best_score = unit["chunk_id"], score
    return best_id if best_score >= max(2, len(probe) // 3) else None
