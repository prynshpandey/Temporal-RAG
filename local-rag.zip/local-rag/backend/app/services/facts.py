"""Metric extraction: pull comparable numbers out of prose, without a model.

Change detection needs to answer one question - "was 3.6 the same quantity as 4.1?"
- and that means pairing a number with what it measures. Two documents that both
mention a percentage are not comparable; "gross margin 47.0 percent" and
"up 18 percent on FY2024" are not the same fact.

The pairing is heuristic, so the result is deliberately transparent. Every fact
carries the sentence it came from, and the comparison endpoints show that
sentence with every change. A reader can check each one against the source in a
few seconds. That is a stronger guarantee than a confident-looking extracted
triple nobody can audit, and it costs nothing when a language model is
unreachable - which, in this deployment, is often.

Two distinctions do the real work:

*Levels and deltas are not comparable.* "churn fell to 3.6 percent" states a new
level; "revenue up 18 percent" states a change. A change word with no "to"
between it and the number marks a delta, which is dropped rather than compared
against a level from another year.

*Labels are the nearest content words.* Walking back from the number and stopping
at the first stopword or verb yields "customer churn" and "gross margin" rather
than a fragment. Units that name their own quantity - employees - supply the
label when the surrounding words are all function words.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date
from typing import Any

# Function words, and verbs that report a movement rather than a quantity.
_STOPWORDS = {
    "a", "an", "the", "of", "to", "in", "on", "at", "for", "from", "by", "with",
    "and", "or", "as", "is", "was", "were", "are", "be", "been", "that", "this",
    "it", "its", "has", "have", "had", "which", "who", "than", "then", "over",
    "under", "after", "before", "during", "while", "about", "up", "down", "out",
    "into", "onto", "per", "within", "across", "since", "until", "am", "s",
    "reached", "rose", "fell", "increas", "decreas", "grew", "grow", "improv",
    "contribut", "ship", "add", "stand", "represent", "equal", "mean", "reach",
    "employ",
    # Verbs that describe a metric rather than name one: "margin remained
    # unchanged at 52 percent" is a margin, and the walk must pass "unchanged"
    # to reach it.
    "chang", "unchang", "affect", "impact", "expand", "contract", "cover",
    "declin", "dropp", "jump", "surg", "climb", "slid", "remain", "stay",
    "report", "total", "totall", "stood", "came", "went", "hit", "ed", "ing",
    # Connectors and adverbs. These end up as metric names when a sentence puts
    # them next to a number, and "increase" is not a quantity.
    "against", "further", "increase", "decrease", "growth", "following",
    "compared", "versus", "vs", "whilst", "whereas", "although", "though",
    "such", "same", "other", "another", "each", "every", "all", "both", "only",
    "just", "even", "still", "also", "well", "back", "forward", "together",
}
_MOVEMENT = {
    "up", "down", "rose", "fell", "increase", "increased", "decrease",
    "decreased", "grew", "grows", "growth", "improved", "declined", "dropped",
    "jumped", "surged", "climbed", "higher", "lower", "more", "less", "fewer",
}
_FISCAL = re.compile(
    r"^(?:fy|q[1-4]|h[12]|half|annual|year|years|month|months|week|weeks|day|days)$"
    r"|^(?:fy|q[1-4])[\s-]?\d{2,4}$",
    re.IGNORECASE,
)
_MONTHS = re.compile(
    r"^(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*$", re.IGNORECASE
)

_NUMBER = r"(?<![\w.])(\d{1,3}(?:,\d{3})+(?:\.\d+)?|\d+(?:\.\d+)?)(?![\w])"
_UNITS = [
    (r"percentage\s+points?|pp\b", "percentage_points"),
    (r"percent|%|pct", "percent"),
    (r"million\s+(?:euros?|dollars?)|(?:euros?|dollars?)\s+million|m\b", "million_currency"),
    (r"billion\s+(?:euros?|dollars?)|(?:euros?|dollars?)\s+billion|bn\b", "billion_currency"),
    (r"thousand\s+(?:euros?|dollars?)|k\b", "thousand_currency"),
    (r"euros?|dollars?", "currency"),
    (r"employees?|staff|headcount|people|headcount", "headcount"),
    (r"customers?|clients?", "count"),
    (r"days?|weeks?|months?|years?", "duration"),
]
_UNIT_RE = re.compile(
    r"\s*(" + "|".join(pattern for pattern, _ in _UNITS) + r")\b", re.IGNORECASE
)
_UNIT_NAMES = {name for _, name in _UNITS}
_UNIT_CANONICAL = {re.compile(pattern, re.IGNORECASE): name for pattern, name in _UNITS}

# "up 18 percent" is a delta; "fell to 3.6 percent" is a new level. The presence of
# a "to" between the movement word and the number is what separates them.
_MOVEMENT_BEFORE = re.compile(
    r"\b(" + "|".join(sorted(_MOVEMENT, key=len, reverse=True)) + r")\s+"
    r"(?:further\s+|also\s+|approximately\s+|roughly\s+|about\s+|c\.?a\.?\s+)*$",
    re.IGNORECASE,
)
# A unit word or a number ends the label: in "reached 41.2 million euro, up from
# 36.4 million euro" the second figure belongs to the same metric, and letting the
# walk continue would turn "euro million 41 2" into its name.
# Words that mark a reporting period rather than name a metric. Walking back
# from a figure in "employees at the end of FY2025 was 260" stops at "end",
# which names nothing, so the walk has to step over it to reach "employees".
_PERIOD_WORDS = {
    "end", "start", "beginning", "close", "closing", "period", "quarter",
}

_UNIT_WORDS = {
    "million", "billion", "thousand", "euro", "euros", "dollar", "dollars",
    "percent", "pct", "percentage", "point", "points",
}
# Words that name an organisation rather than a quantity. Headcount measured
# "at the company" is headcount, not a metric called "company".
_GENERIC = {
    "company", "employ", "staff", "headcount", "total", "group", "organisation",
    "organization", "firm", "business", "businesses", "workforce", "teams",
    # "the number of employees was 180" - "number" is a determiner here, not a
    # quantity, and leaving it in produces a metric called "number employees".
    "number", "count", "figure", "level",
    # The unit nouns themselves, so every phrasing canonicalises to one label.
    # "has 260 employees" and "employees was 260" must not become two metrics,
    # or a comparison between them reports no change.
    "employee", "employees", "person", "people", "worker", "workers",
    "customer", "customers", "client", "clients", "user", "users",
}

# Nouns that name a countable quantity and can appear *before* the number, as in
# "the number of employees was 180". Without this, extraction required a unit
# after the figure and silently dropped the commonest phrasing of a headcount.
# Deliberately narrow: an arbitrary noun before a number is usually a date or a
# coincidence, and guessing would manufacture comparisons that do not exist.
_QUANTITY_NOUNS = {
    "employee": "headcount", "employees": "headcount",
    "staff": "headcount", "headcount": "headcount",
    "person": "headcount", "people": "headcount",
    "worker": "headcount", "workers": "headcount",
    "customer": "count", "customers": "count",
    "client": "count", "clients": "count",
    "user": "count", "users": "count",
    "subscriber": "count", "subscribers": "count",
    "account": "count", "accounts": "count",
    "store": "count", "stores": "count",
    "site": "count", "sites": "count",
    "office": "count", "offices": "count",
    "location": "count", "locations": "count",
    "patent": "count", "patents": "count",
}


def _quantity_noun(label: str) -> tuple[str, int] | None:
    """The trailing quantity noun in a label, and its index.

    "employees at the end of FY2025" must yield "employees", not
    "employees end" - so the noun's position matters, and callers truncate there.
    """
    words = label.split()
    for index in range(len(words) - 1, -1, -1):
        unit = _QUANTITY_NOUNS.get(words[index])
        if unit:
            return unit, index
    return None


def _is_stopword(word: str) -> bool:
    """Match inflections: the stopword list stores stems ("contribut")."""
    low = word.lower()
    if low in _STOPWORDS:
        return True
    for suffix in ("es", "s", "ed", "ing"):
        if low.endswith(suffix):
            stem = low[: -len(suffix)]
            if stem in _STOPWORDS:
                return True
    return False


_ISO_DATE = re.compile(r"\d{4}-\d{2}-\d{2}")
_SENTENCE = re.compile(r"(?<=[.!?])\s+|\n+")


@dataclass
class Fact:
    """One number, what it measures, and the sentence that proves it."""

    label: str
    value: float
    unit: str
    kind: str = "level"
    sentence: str = ""
    document_id: str = ""
    document_name: str = ""
    chunk_id: str = ""
    effective_date: date | None = None
    confidence: float = 0.5

    @property
    def key(self) -> str:
        return f"{self.label}|{self.unit}"

    def as_dict(self) -> dict[str, Any]:
        return {
            "label": self.label,
            "value": self.value,
            "unit": self.unit,
            "kind": self.kind,
            "sentence": self.sentence,
            "document_id": self.document_id,
            "document_name": self.document_name,
            "chunk_id": self.chunk_id,
            "effective_date": self.effective_date.isoformat() if self.effective_date else None,
            "confidence": round(self.confidence, 2),
        }


def _normalise_label(words: list[str]) -> str:
    out: list[str] = []
    for word in words:
        cleaned = re.sub(r"[^a-z0-9%]+", "", word.lower())
        if not cleaned or _FISCAL.match(cleaned):
            continue
        if _is_stopword(cleaned) or len(cleaned) < 2:
            continue
        out.append(cleaned)
    return " ".join(out)


def _label_before(text: str, match_start: int) -> tuple[str, bool]:
    """The nearest content words before a number, and whether it is a delta.

    Two passes, because the word nearest a number is usually a separator rather
    than part of the name: "Gross margin was 47.0" needs the stopword "was"
    stepped over before "margin" is reached. Stopping at the first one instead
    discards every metric that is introduced by a verb.
    """
    before = text[:match_start].rstrip()
    words = re.findall(r"[\w%'-]+", before)
    is_delta = bool(_MOVEMENT_BEFORE.search(before + " ")) and not re.search(
        r"\bto\b\s*$", before, re.IGNORECASE
    )

    index = len(words) - 1
    while index >= 0:
        low = words[index].lower()
        if re.match(r"^\d", words[index]):
            # A different figure sits in between. In "employs 465 employees at
            # the end of 2024" the word "employees" belongs to 465, and letting
            # the walk cross the number lends 2024 a metric it does not have.
            break
        if (
            _is_stopword(words[index])
            or _FISCAL.match(words[index])
            or low in _UNIT_WORDS
            or low in _PERIOD_WORDS
        ):
            index -= 1
            continue
        break

    collected: list[str] = []
    while index >= 0 and len(collected) < 4:
        word = words[index]
        low = word.lower()
        if _is_stopword(low) or _FISCAL.match(low) or low in _UNIT_WORDS or low in _PERIOD_WORDS:
            break
        if re.match(r"^\d", word):
            break
        collected.append(word)
        index -= 1
    collected.reverse()
    return _normalise_label(collected), is_delta


def _is_date_context(text: str, match: re.Match[str]) -> bool:
    start = match.start()
    window = text[max(0, start - 40) : match.end() + 24]
    raw = match.group(1)
    if _ISO_DATE.search(window):
        return True
    if re.match(r"^(19|20)\d{2}$", raw.replace(",", "")):
        # A bare year is a date unless something measures it.
        if _MONTHS.search(re.sub(r"^[^a-zA-Z]+|[^a-zA-Z]+$", "", window) or ""):
            return True
        if re.search(r"\b(fy|q[1-4]|since|until|during|in|on|by)\s*$", text[max(0, start - 12) : start], re.IGNORECASE):
            return True
        # "at the end of 2024" / "by the close of 2023" is a date reference, and
        # nothing else in the sentence gives it away.
        if re.search(
            r"\b(end|start|beginning|close|closing|outset)\s+(of\s+)?$",
            text[max(0, start - 20) : start], re.IGNORECASE,
        ):
            return True
    if re.search(r"(fiscal year|calendar year|year ended|as of)\s*$", text[max(0, start - 30) : start], re.IGNORECASE):
        return True
    # "will close its Utrecht office on 31 December 2023" - a day of the month is
    # not a count of anything, whatever noun happens to precede it.
    if re.match(
        r"\s*(january|february|march|april|may|june|july|august|september|october|"
        r"november|december|jan|feb|mar|apr|jun|jul|aug|sep|sept|oct|nov|dec)\b",
        text[match.end():], re.IGNORECASE,
    ):
        return True
    return False


def _unit_after(text: str, match: re.Match[str]) -> tuple[str, re.Match[str] | None]:
    unit_match = _UNIT_RE.match(text[match.end() :])
    if not unit_match:
        return "", None
    for pattern, name in _UNIT_CANONICAL.items():
        if pattern.fullmatch(unit_match.group(0).strip()) or pattern.match(unit_match.group(0).strip()):
            return name, unit_match
    return "", unit_match


def extract_facts(text: str) -> list[Fact]:
    """Every measurable level in one passage, each with its sentence."""
    if not text:
        return []
    facts: list[Fact] = []
    for sentence in _SENTENCE.split(text):
        if not sentence or len(sentence) > 400:
            continue
        for match in re.finditer(_NUMBER, sentence):
            if _is_date_context(sentence, match):
                continue
            unit, unit_match = _unit_after(sentence, match)
            label, is_delta = _label_before(sentence, match.start())
            try:
                value = float(match.group(1).replace(",", ""))
            except ValueError:
                continue
            if is_delta and unit in ("percent", "percentage_points"):
                # The size of a movement, not a level. Never comparable to one.
                continue
            if not unit and label:
                # "the number of employees was 180": the quantity is named before
                # the figure, not after it, so _unit_after finds nothing. This has
                # to run before the canonicalisation below, or the two phrasings
                # of one metric end up under different labels and a comparison
                # between them reports no change.
                found = _quantity_noun(label)
                if found:
                    unit, index = found
                    label = " ".join(label.split()[: index + 1])
            if unit == "headcount":
                # Stem-tolerant: "employs" is as generic as "employ".
                meaningful = [
                    w for w in label.split() if (w[:-1] if w.endswith("s") else w) not in _GENERIC
                ]
                label = " ".join(meaningful) or "headcount"
            if not label:
                continue
            if not unit:
                # A bare number with no unit and no name is not a metric.
                continue
            confidence = 0.9 if unit != "count" else 0.7
            if unit == "headcount" and label == "headcount":
                confidence = 0.8
            if is_delta:
                confidence = 0.4
            end = match.end() + (unit_match.end() if unit_match else 0)
            facts.append(
                Fact(
                    label=label,
                    value=value,
                    unit=unit,
                    kind="delta" if is_delta else "level",
                    sentence=sentence.strip(),
                    confidence=confidence,
                )
            )
            del end
    return facts


def facts_from_passages(passages: list[dict[str, Any]]) -> list[Fact]:
    """Attach provenance to the facts found in a snapshot's passages."""
    out: list[Fact] = []
    for passage in passages:
        for fact in extract_facts(passage.get("text") or ""):
            fact.document_id = passage.get("document_id", "")
            fact.document_name = passage.get("document_name", "")
            fact.chunk_id = passage.get("chunk_id", "")
            effective = passage.get("effective_date")
            if isinstance(effective, str):
                try:
                    effective = date.fromisoformat(effective)
                except ValueError:
                    effective = None
            fact.effective_date = effective if isinstance(effective, date) else None
            out.append(fact)
    return out


def deduplicate(facts: list[Fact]) -> list[Fact]:
    """One fact per (label, unit) per document: the most confident, then the latest.

    A document restating its own figure in a summary and a footnote is one fact
    stated twice, not two facts that happen to agree.
    """
    best: dict[tuple[str, str, str], Fact] = {}
    for fact in facts:
        if fact.kind != "level":
            continue
        key = (fact.key, fact.document_id, fact.chunk_id)
        current = best.get(key)
        if current is None or fact.confidence > current.confidence:
            best[key] = fact
    return list(best.values())


def index_by_metric(facts: list[Fact]) -> dict[str, list[Fact]]:
    """Group by comparable metric, newest evidence first."""
    grouped: dict[str, list[Fact]] = {}
    for fact in facts:
        grouped.setdefault(fact.key, []).append(fact)
    for values in grouped.values():
        values.sort(key=lambda f: (f.effective_date or date.min, f.confidence), reverse=True)
    return grouped
