"""Reranking: recover the ordering signal that rank fusion throws away.

Reciprocal Rank Fusion is good at recall and weak at precision, because it can
only see *where* a document was ranked, never *why* it matched. Two passages both
ranked 8th outrank nothing about a passage ranked 1st, even if the first names
every term in the question and the second mentions one of them in passing. The
ranked positions are also on an arbitrary scale: at k=60 a document ranked 1st by
both retrievers leads one ranked 8th by both by only 10%, which is less than the
recency bonus. A fresher, weaker document therefore used to displace a stronger
one, and the retrieval docstring claimed the opposite.

This stage scores the passages themselves, then applies recency only where it is
allowed to matter.

**Relevance first.** Four deterministic features, all computed from text that is
already stored:

``coverage``
    How much of the question the passage actually addresses. A passage matching
    "revenue" but ignoring "churn" is not an answer to a question about both.
``proximity``
    Whether the matched terms sit together. Terms in one sentence beat the same
    terms scattered across a page.
``heading``
    Whether the section title matches. Asking about revenue and retrieving
    "1. Financial summary" is the right answer, and rank fusion cannot see it.
``density``
    Matched terms per unit of length, so a long passage cannot dilute a short
    precise one.

No model, no embedding call, no network: reranking must work when the model does
not, for the same reason snapshots and comparisons do.

**Recency second, and bounded.** Recency is applied *within a relevance band* -
only to candidates whose relevance is already within a small margin of the
leader. It can reorder near-ties, which is what a time machine needs, and it can
never promote a genuinely weaker match. The invariant is explicit and tested:
past the band, relevance decides.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

from app.config import settings
from app.logging import get_logger

logger = get_logger("btm.rerank")

# Words that carry no intent in a question. Kept small on purpose: over-stripping
# makes coverage look artificially high and destroys the signal.
_STOPWORDS = {
    "what", "when", "where", "who", "whom", "whose", "which", "why", "how",
    "is", "are", "was", "were", "be", "been", "being", "do", "does", "did",
    "the", "a", "an", "of", "in", "on", "at", "for", "to", "from", "by",
    "with", "and", "or", "as", "that", "this", "these", "those", "it", "its",
    "we", "our", "they", "their", "he", "she", "you", "your", "i", "me",
    "tell", "show", "give", "find", "about", "any", "some", "there", "here",
    "as", "at", "latest", "current", "currently", "now", "then",
}
_TERM = re.compile(r"[a-z0-9][a-z0-9'%.-]{1,}")
# A fiscal reference dates the question; it does not narrow it. Left in, every
# query mentioning a year scores higher against any passage containing that year
# than it should.
_FISCAL_TERM = re.compile(r"^(?:fy|q[1-4]|h[12])[\s-]?\d{2,4}$|^\d{4}$", re.IGNORECASE)
_WORD_BOUNDARY = re.compile(r"\W+", re.UNICODE)


def query_terms(query: str) -> list[str]:
    """Distinct content terms, longest first so 'customer churn' beats 'churn'."""
    seen: list[str] = []
    for match in _TERM.finditer((query or "").lower()):
        term = match.group(0).strip(".-'")
        if len(term) < 2 or term in _STOPWORDS or term in seen or _FISCAL_TERM.match(term):
            continue
        seen.append(term)
    return sorted(seen, key=len, reverse=True)


def _positions(terms: list[str], text: str) -> list[tuple[int, int, str]]:
    """Every occurrence of every term, as (start, end, term)."""
    lowered = text.lower()
    found: list[tuple[int, int, str]] = []
    for term in terms:
        for match in re.finditer(r"(?<!\w)" + re.escape(term) + r"(?!\w)", lowered):
            found.append((match.start(), match.end(), term))
    return found


def coverage(terms: list[str], text: str) -> float:
    """Fraction of the question's terms the passage mentions at all."""
    if not terms:
        return 0.0
    lowered = text.lower()
    present = sum(1 for term in terms if re.search(r"(?<!\w)" + re.escape(term) + r"(?!\w)", lowered))
    return present / len(terms)


def proximity(terms: list[str], text: str) -> float:
    """1.0 when the terms sit in one sentence, decaying as they spread apart.

    Measured on each term's *first* occurrence. A minimal-window search is the
    obvious approach and is wrong: given a passage that repeats "Revenue" twenty
    times before mentioning "Churn" once, the tightest window around the two is
    the one bridging the last "Revenue" and the "Churn", which scores as adjacent
    for a passage where the terms are in fact nowhere near each other.
    """
    if len(terms) < 2 or not text:
        return 0.0
    lowered = text.lower()
    firsts: list[tuple[int, int, str]] = []
    missing = 0
    for term in terms:
        match = re.search(r"(?<!\w)" + re.escape(term) + r"(?!\w)", lowered)
        if match:
            firsts.append((match.start(), match.end(), term))
        else:
            missing += 1
    if not firsts:
        return 0.0
    if missing:
        # Not every term is present, so no window can hold them all. Partial
        # credit, scaled by how many are.
        return 0.3 * ((len(terms) - missing) / len(terms))

    start = min(s for s, _, _ in firsts)
    end = max(e for _, e, _ in firsts)
    between = text[start:end]
    if not re.search(r"[.!?\n]", between):
        return 1.0
    return max(0.0, 1.0 - (end - start) / max(len(text), 1))


def heading(terms: list[str], heading_text: str) -> float:
    """Whether the section title addresses the question."""
    if not heading_text or not terms:
        return 0.0
    lowered = heading_text.lower()
    hits = sum(1 for term in terms if re.search(r"(?<!\w)" + re.escape(term) + r"(?!\w)", lowered))
    return hits / len(terms)


def density(terms: list[str], text: str) -> float:
    """Matched terms per 100 characters, capped: long passages dilute."""
    if not terms or not text:
        return 0.0
    covered = coverage(terms, text)
    length = max(len(text), 1)
    return min(1.0, covered * (200.0 / min(length, 1200.0)))


@dataclass
class RerankWeights:
    coverage: float = 0.45
    proximity: float = 0.30
    heading: float = 0.15
    density: float = 0.10

    def as_dict(self) -> dict[str, float]:
        return {
            "coverage": self.coverage,
            "proximity": self.proximity,
            "heading": self.heading,
            "density": self.density,
        }


def _heading_text(hit: Any) -> str:
    """The section title, taken from the parent breadcrumb.

    Retrieval carries the parent for citation context; the leading segment of its
    breadcrumb is the heading the reader sees, and it is the one place a
    question's subject is named without appearing in the body text.
    """
    parent = getattr(hit, "parent_text", "") or ""
    first = parent.splitlines()[0] if parent else ""
    if ">" in first:
        first = first.rsplit(">", 1)[-1]
    return first.strip(" .-")


def quality_score(query: str, hit: Any, weights: RerankWeights) -> tuple[float, dict[str, float]]:
    """The deterministic relevance features for one passage, and their values."""
    terms = query_terms(query)
    body = getattr(hit, "text", "") or ""
    # Parent context is included because a leaf chunk can be a single sentence
    # whose section carries the subject.
    searchable = body if len(body) > 40 else f"{_heading_text(hit)} {body}"
    parts = {
        "coverage": coverage(terms, searchable),
        "proximity": proximity(terms, searchable),
        "heading": heading(terms, _heading_text(hit)),
        "density": density(terms, searchable),
    }
    total = sum(getattr(weights, name) * value for name, value in parts.items())
    return total, parts


def _recency_key(hit: Any) -> tuple:
    """Newest first, then most relevant, then stable.

    Undated passages sort last: with no date there is no evidence one supersedes
    another, so a dated passage is the better default and an undated one must not
    win a tie it did not earn.
    """
    effective = getattr(hit, "effective_date", None)
    return (
        0 if effective else 1,
        -(effective.toordinal() if effective else 0),
        -getattr(hit, "score", 0.0),
        getattr(hit, "chunk_id", ""),
    )


def rerank(
    query: str,
    hits: list[Any],
    *,
    weights: RerankWeights | None = None,
    band: float | None = None,
    recency_weight: float | None = None,
) -> list[Any]:
    """Reorder fused hits by relevance, then break near-ties by recency.

    Returns the same list, sorted, with ``rerank_score`` and its components
    recorded on each hit so a reader can see why a passage was chosen.
    """
    if not hits:
        return hits
    weights = weights or RerankWeights()
    band = settings.rerank_relevance_band if band is None else band
    recency_weight = (
        settings.retrieval_recency_weight if recency_weight is None else recency_weight
    )

    base = max((h.score for h in hits), default=0.0) or 1.0
    for hit in hits:
        quality, parts = quality_score(query, hit, weights)
        # Blend rather than replace: rank fusion is reliable about what was
        # retrieved, these features are reliable about why it matched.
        hit.extra["rerank_quality"] = round(quality, 6)
        hit.extra["rerank_features"] = {k: round(v, 4) for k, v in parts.items()}
        hit.extra["base_score"] = round(hit.score, 6)
        hit.score = hit.score * (1.0 + settings.rerank_quality_bonus * quality)
    logger.debug("reranked", extra={"hits": len(hits), "query_terms": len(query_terms(query))})

    hits.sort(key=lambda h: (-h.score, h.chunk_id))
    leader = hits[0].score
    threshold = leader * (1.0 - band)

    # Only candidates already within the band are eligible to be reordered by
    # recency. Past the band, relevance decides alone.
    contenders = [h for h in hits if h.score >= threshold]
    others = [h for h in hits if h.score < threshold]

    if recency_weight > 0 and len(contenders) > 1:
        dates = [h.effective_date for h in contenders if h.effective_date]
        if len(dates) > 1:
            oldest, newest = min(dates), max(dates)
            span = (newest - oldest).days
            for hit in contenders:
                if hit.effective_date and span:
                    ratio = (hit.effective_date - oldest).days / span
                    hit.extra["recency_ratio"] = round(ratio, 4)
            # Inside the band, recency is the *deciding key* rather than a small
            # multiplier. Two passages that are tied on relevance should be
            # ordered by which document is newer - adding a percentage to the
            # score instead would leave the residual base-score difference in
            # charge of the decision, which is the bug this replaced.
            contenders.sort(key=_recency_key)
            for hit in contenders:
                hit.extra["ranking_basis"] = "recency_within_band"

    for hit in others:
        hit.extra["outside_relevance_band"] = True
        hit.extra.setdefault("ranking_basis", "relevance")
    return contenders + others
