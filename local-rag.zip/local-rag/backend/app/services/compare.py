"""Compare two points in time: what changed, what was retracted, what disagrees.

Retrieval can tell you what a document said on one date. This module answers the
question that makes a time machine worth having: between 2023 and 2025, what
does the organisation now say that it did not say then?

Both windows are reconstructed through :mod:`app.services.state`, so the
comparison inherits exactly the same temporal rules as a single snapshot - if
retrieval would not have admitted a document, it cannot appear on either side of
a diff. That is deliberate: a comparison that used different scoping from the
query path would be free to contradict it.

Three outcomes are reported separately, because they mean different things:

``changes``
    A metric is stated in both windows with a different value. This is a change.
``appeared`` / ``disappeared``
    A metric is stated on one side only. A disappearance is *not* evidence the
    fact stopped being true - far more often the later document simply did not
    repeat it. The response says so rather than declaring the fact obsolete.
``conflicts``
    The same metric carries different values inside a single window, in
    documents that were all in scope at once. No time filter can explain this,
    and it is the one case where a snapshot is genuinely misleading, so it is
    surfaced at the top rather than buried in the changes.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from typing import Any

from app.errors import ValidationFailed
from app.logging import get_logger, log_event
from app.services import facts as facts_service
from app.services import state as state_service

logger = get_logger("btm.compare")


@dataclass
class Window:
    """One side of the comparison, with its facts resolved to a current value."""

    as_of: date
    snapshot: state_service.State
    metrics: dict[str, list[facts_service.Fact]] = field(default_factory=dict)

    @property
    def documents(self) -> list[dict[str, Any]]:
        return self.snapshot.documents

    def current(self, key: str) -> facts_service.Fact | None:
        """The value a reader would have believed on this date.

        The most recent statement wins. Where a document restates a figure in a
        summary and a footnote, the newest is the operative one.
        """
        values = self.metrics.get(key)
        return values[0] if values else None

    def values(self, key: str) -> list[facts_service.Fact]:
        return self.metrics.get(key, [])


async def _build(as_of: date, entity: str | None, passage_limit: int | None) -> Window:
    snapshot = await state_service.reconstruct(
        as_of=as_of,
        entity=entity,
        include_passages=True,
        passage_limit=passage_limit,
    )
    extracted = facts_service.deduplicate(facts_service.facts_from_passages(snapshot.passages))
    return Window(as_of=as_of, snapshot=snapshot, metrics=facts_service.index_by_metric(extracted))


def _describe(fact: facts_service.Fact | None) -> dict[str, Any] | None:
    return fact.as_dict() if fact else None


def _delta(before: float, after: float) -> tuple[str, float | None, str]:
    """Direction, percentage change, and a rendered form that names the unit."""
    if before == after:
        return "unchanged", 0.0, "unchanged"
    direction = "increased" if after > before else "decreased"
    percent = None
    if before:
        percent = round((after - before) / abs(before) * 100, 1)
    return direction, percent, direction


def _format_value(value: float, unit: str) -> str:
    if unit == "percent":
        return f"{value:g}%"
    if unit == "million_currency":
        return f"{value:g}M"
    if unit == "billion_currency":
        return f"{value:g}B"
    if unit == "thousand_currency":
        return f"{value:g}k"
    if unit == "currency":
        return f"{value:g}"
    if unit == "headcount":
        return f"{value:g} people"
    return f"{value:g}"


def _conflicts(window: Window) -> list[dict[str, Any]]:
    """Metrics stated two ways at the same time.

    Only *contemporaneous* disagreement counts. Three annual reports in scope
    giving three different revenue figures is a revision history, not a
    contradiction - that is the whole point of the corpus. A conflict is two
    documents that were valid at once and still disagree, which no date filter
    can reconcile and which would otherwise be presented as settled history.

    Undated statements are compared only against other undated ones: without a
    date there is no evidence they were written at the same time, and assuming
    so would manufacture conflicts out of unknown ordering.
    """
    from app.config import settings

    found: list[dict[str, Any]] = []
    window_days = settings.conflict_window_days
    for key, values in window.metrics.items():
        dated = [f for f in values if f.effective_date]
        undated = [f for f in values if not f.effective_date]
        clashing: list[list[facts_service.Fact]] = []

        for i, left in enumerate(dated):
            group = [
                right
                for right in dated[i + 1 :]
                if abs((right.effective_date - left.effective_date).days) <= window_days
                and right.value != left.value
            ]
            if group:
                clashing.append([left, *group])
        if len({f.value for f in undated}) > 1:
            clashing.append(undated)

        for group in clashing:
            ordered = sorted(group, key=lambda f: (f.effective_date or date.min, f.confidence), reverse=True)
            label, _, unit = key.partition("|")
            found.append(
                {
                    "metric": f"{label} ({unit})" if unit else label,
                    "label": label,
                    "unit": unit,
                    "as_of": window.as_of.isoformat(),
                    "value_count": len({f.value for f in group}),
                    "resolution": "most_recent_wins",
                    "resolved_value": _describe(ordered[0]),
                    "statements": [_describe(f) for f in ordered],
                    "explanation": (
                        f"Documents dated within {window_days} days of each other give "
                        f"{len({f.value for f in group})} different values for this metric, and all were "
                        f"in scope on {window.as_of.isoformat()}. No date filter can reconcile them; the "
                        "most recent is shown and the rest should be reviewed."
                    ),
                }
            )
    return found


def _family_changes(before: Window, after: Window) -> list[dict[str, Any]]:
    old = {f["key"]: f for f in before.snapshot.families}
    new = {f["key"]: f for f in after.snapshot.families}
    rows: list[dict[str, Any]] = []
    for key in sorted(set(old) | set(new)):
        a, b = old.get(key), new.get(key)
        if a and b and a.get("current_version") == b.get("current_version"):
            continue
        rows.append(
            {
                "key": key,
                "status": "added" if not a else "removed" if not b else "revised",
                "from_version": _family_version(a),
                "to_version": _family_version(b),
            }
        )
    return rows


def _family_version(family: dict[str, Any] | None) -> dict[str, Any] | None:
    if not family:
        return None
    current = family.get("current_version")
    if not current:
        return None
    for version in family["versions"]:
        if version["document_id"] == current:
            return {
                "document_id": current,
                "name": version["name"],
                "effective_date": version["effective_date"].isoformat() if version["effective_date"] else None,
            }
    return None


async def compare(
    *,
    from_date: date,
    to_date: date,
    entity: str | None = None,
    passage_limit: int | None = None,
) -> dict[str, Any]:
    """Diff what was known on two dates."""
    if from_date == to_date:
        raise ValidationFailed("from and to must be different dates.")
    if from_date > to_date:
        raise ValidationFailed("from must be earlier than to.")

    before = await _build(from_date, entity, passage_limit)
    after = await _build(to_date, entity, passage_limit)

    old_docs = {d["document_id"] for d in before.documents}
    new_docs = {d["document_id"] for d in after.documents}
    by_id = {d["document_id"]: d for d in before.documents + after.documents}

    def _doc_rows(ids: set[str]) -> list[dict[str, Any]]:
        return [
            {
                "document_id": i,
                "name": by_id[i]["name"],
                "effective_date": by_id[i].get("effective_date").isoformat()
                if by_id[i].get("effective_date")
                else None,
                "document_type": by_id[i].get("document_type"),
            }
            for i in sorted(ids, key=lambda x: (by_id[x].get("effective_date") or date.min, by_id[x]["name"]))
        ]

    changes: list[dict[str, Any]] = []
    appeared: list[dict[str, Any]] = []
    disappeared: list[dict[str, Any]] = []

    for key in sorted(set(before.metrics) | set(after.metrics)):
        label, _, unit = key.partition("|")
        old_fact, new_fact = before.current(key), after.current(key)
        if old_fact and new_fact:
            if old_fact.value == new_fact.value:
                continue
            direction, percent, _ = _delta(old_fact.value, new_fact.value)
            changes.append(
                {
                    "label": label,
                    "unit": unit,
                    "direction": direction,
                    "percent_change": percent,
                    "rendered": (
                        f"{_format_value(old_fact.value, unit)} -> {_format_value(new_fact.value, unit)}"
                        + (f" ({direction} {abs(percent):g}%)" if percent is not None else "")
                    ),
                    "from": _describe(old_fact),
                    "to": _describe(new_fact),
                    "confidence": min(old_fact.confidence, new_fact.confidence),
                }
            )
        elif new_fact and not old_fact:
            appeared.append({"label": label, "unit": unit, "now": _describe(new_fact)})
        elif old_fact and not new_fact:
            disappeared.append({"label": label, "unit": unit, "was": _describe(old_fact)})

    warnings: list[str] = []

    for row in disappeared:
        fact = row["was"]
        restated = any(
            f.label == fact["label"] for f in after.metrics.values() for f in f
        )
        if not restated:
            warnings.append(
                f"'{fact['label']}' was known on {from_date.isoformat()} but no document in scope on "
                f"{to_date.isoformat()} mentions it. That is missing evidence, not a retraction - "
                "the fact may still be true."
            )

    if not before.documents:
        warnings.append(
            f"Nothing was in scope on {from_date.isoformat()}, so every current metric appears as new. "
            "This is an empty starting point, not a finding."
        )
    if not after.documents:
        warnings.append(
            f"Nothing was in scope on {to_date.isoformat()}. The later window is empty, so every metric "
            "appears to have been retracted."
        )

    unconfirmed = [
        fact.label
        for key in set(before.metrics) & set(after.metrics)
        if (fact := before.current(key)) is not None
        and after.current(key) is not None
        and fact.chunk_id == after.current(key).chunk_id
    ]
    if unconfirmed:
        warnings.append(
            f"{len(unconfirmed)} metric(s) have the same value in both windows, quoted from the same "
            f"passage: {', '.join(sorted(set(unconfirmed)))}. No later document restates them, so the "
            "figures are unconfirmed rather than unchanged."
        )

    conflicts = _conflicts(after) + _conflicts(before)
    for conflict in conflicts:
        warnings.append(
            f"Conflicting values for '{conflict['metric']}' in the {conflict['as_of']} snapshot."
        )

    result = {
        "from": {
            "as_of": from_date.isoformat(),
            "documents_in_scope": len(before.documents),
            "metrics": len(before.metrics),
        },
        "to": {
            "as_of": to_date.isoformat(),
            "documents_in_scope": len(after.documents),
            "metrics": len(after.metrics),
        },
        "entity": entity,
        "documents": {
            "added": _doc_rows(new_docs - old_docs),
            "removed": _doc_rows(old_docs - new_docs),
            "unchanged": len(old_docs & new_docs),
        },
        "families": _family_changes(before, after),
        "changes": changes,
        "appeared": appeared,
        "disappeared": disappeared,
        "conflicts": conflicts,
        "warnings": warnings,
        "method": {
            "extraction": "deterministic numeric patterns; no language model is involved",
            "value_at_date": "the most recent statement of a metric among documents in scope",
            "levels_only": "percentage movements ('up 18 percent') are excluded, never compared to levels",
            "verify": "every change carries the source sentence in from.sentence and to.sentence",
        },
    }
    log_event(
        logger,
        "compared",
        **{"from": from_date.isoformat(), "to": to_date.isoformat()},
        changes=len(changes),
        appeared=len(appeared),
        disappeared=len(disappeared),
        conflicts=len(conflicts),
    )
    return result
