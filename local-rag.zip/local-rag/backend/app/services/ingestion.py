"""Ingest orchestration: upload -> parse plan -> atomic database write.

The pipeline is deliberately split so n8n can drive it while the backend stays
the only owner of parsing and of the database:

1. ``POST /internal/parse``       - stream the upload, parse it, chunk it, return
                                    the plan (ids, texts, metadata). No writes.
2. ``POST /internal/embed``       - batched local embeddings for the plan's chunks.
3. ``POST /internal/ingest/register`` - one transaction writes the document, its
                                    sections, chunks, entities, events and facts.
4. ``POST /internal/ingest/finalize`` - optional status flip once the vectors are
                                    in Qdrant.

Ids are derived from the content, never from a random uuid, so re-uploading the
same bytes is idempotent: same ``document_id``, same chunk ids, same Qdrant point
ids, and the vectors are overwritten rather than duplicated.
"""

from __future__ import annotations

import hashlib
import os
import tempfile
import time
import uuid
from datetime import date, datetime, timezone
from typing import Any, Iterable

from app.config import settings
from app.db.pool import get_pool
from app.errors import CorruptDocument, EmptyUpload, FileTooLarge, ValidationFailed
from app.logging import get_logger, log_event
from app.parsers import parse_upload, sanitize_filename
from app.parsers.detect import SUPPORTED
from app.repositories import documents as repo
from app.services.chunking import build_chunks

logger = get_logger("btm.ingest")

LEVEL_CODES = {0: "d", 1: "s", 2: "p", 3: "c"}
READ_BLOCK = 1024 * 1024


def chunk_id_for(document_id: str, level: int, ordinal: int) -> str:
    """Canonical id for a chunk at any level: ``<doc>-<level code><ordinal>``."""
    return f"{document_id}-{LEVEL_CODES[level]}{ordinal:04d}"


def point_id_for(unit_id: str) -> int:
    """Deterministic 63-bit Qdrant point id derived from the unit id.

    Qdrant ids must be unsigned; ``bigint`` in PostgreSQL tops out one bit lower,
    so the top bit is masked off. Deriving instead of counting means a re-ingest
    overwrites the old vector instead of leaving an orphan.
    """
    digest = hashlib.sha256(unit_id.encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "big") & ((1 << 63) - 1)


async def save_upload(stream: Iterable[bytes], filename: str | None) -> tuple[str, str, int, str]:
    """Stream an upload to a temp file. Returns ``(path, sha256, size, safe_name)``.

    The size is enforced while streaming, so a wrong or missing
    ``Content-Length`` cannot fill the disk.
    """
    safe_name = sanitize_filename(filename)
    os.makedirs(settings.storage_dir, exist_ok=True)
    handle = tempfile.NamedTemporaryFile(  # noqa: SIM115 - closed explicitly below
        dir=settings.storage_dir, prefix="ingest-", suffix=os.path.splitext(safe_name)[1][:12], delete=False
    )
    digest = hashlib.sha256()
    size = 0
    try:
        async for block in stream:
            size += len(block)
            if size > settings.max_upload_bytes:
                raise FileTooLarge(
                    f"The upload exceeds the {settings.max_upload_size_mb} MB limit."
                )
            digest.update(block)
            handle.write(block)
    finally:
        handle.close()
    if size == 0:
        os.unlink(handle.name)
        raise EmptyUpload()
    return handle.name, digest.hexdigest(), size, safe_name


def cleanup_upload(path: str) -> None:
    """Uploads are temporary: the text lives in PostgreSQL, not on disk."""
    try:
        os.unlink(path)
    except FileNotFoundError:
        pass


async def build_plan(path: str, filename: str, content_type: str | None, sha256: str, size: int) -> dict[str, Any]:
    """Parse and chunk one stored upload into the plan n8n will act on."""
    document = parse_upload(
        path,
        filename,
        content_type,
        max_bytes=settings.max_upload_bytes,
        max_zip_entries=settings.max_zip_entries,
        max_uncompressed_mb=settings.max_zip_uncompressed_mb,
    )
    if document.char_count > settings.max_document_chars:
        raise CorruptDocument(
            f"The document has {document.char_count} characters; the limit is "
            f"{settings.max_document_chars}."
        )

    document_id = f"doc-{sha256[:16]}"
    chunks = build_chunks(document, document_id)

    # The chunker may drop empty sections, so pair summaries with the sections
    # they were actually built from - position for position.
    source_sections = [s for s in document.sections if s.text.strip()]
    sections: list[dict[str, Any]] = []
    for position, chunk in enumerate(chunks.section_summaries):
        source = source_sections[position] if position < len(source_sections) else None
        section_id = chunk.section_id or chunk_id_for(document_id, 1, chunk.ordinal)
        text = source.text if source is not None else document.text
        sections.append(
            {
                "section_id": section_id,
                "title": chunk.context_text,
                "level": chunk.level,
                "ordinal": chunk.ordinal,
                "page": chunk.page,
                "text": text,
                "char_count": len(text),
                "point_id": point_id_for(section_id),
            }
        )

    units: list[dict[str, Any]] = []
    doc_point = point_id_for(chunk_id_for(document_id, 0, 0))
    units.append(
        {
            "chunk_id": chunk_id_for(document_id, 0, 0),
            "level": 0,
            "ordinal": 0,
            "text": chunks.document_summary.text,
            "context": chunks.document_summary.context_text,
            "section_id": None,
            "parent_id": None,
            "page": None,
            "char_count": len(chunks.document_summary.text),
            "chunk_index": 0,
            "level_path": chunks.document_summary.level_path,
            "point_id": doc_point,
        }
    )
    for section in sections:
        summary = chunks.section_summaries[section["ordinal"]]
        units.append(
            {
                "chunk_id": section["section_id"],
                "level": 1,
                "ordinal": section["ordinal"],
                "text": summary.text,
                "context": summary.context_text,
                "section_id": section["section_id"],
                "parent_id": None,
                "page": section["page"],
                "char_count": section["char_count"],
                "chunk_index": section["ordinal"],
                "level_path": summary.level_path,
                "point_id": section["point_id"],
            }
        )
    for chunk in chunks.parents:
        units.append(_unit(document_id, 2, chunk))
    for chunk in chunks.children:
        units.append(_unit(document_id, 3, chunk))

    counts = {
        "document": 1,
        "sections": len(sections),
        "parents": len(chunks.parents),
        "children": len(chunks.children),
        "vectors": len(units),
    }
    plan = {
        "document_id": document_id,
        "sha256": sha256,
        "name": filename,
        "document_type": document.document_type,
        "mime_type": document.mime_type,
        "size_bytes": size,
        "page_count": document.page_count,
        "char_count": document.char_count,
        "title": document.title,
        "authors": document.authors,
        "metadata": {
            k: v for k, v in document.metadata.items() if isinstance(v, (str, int, float, bool, list, type(None)))
        },
        "parse_ms": document.metadata.get("parse_ms"),
        "counts": counts,
        "document_point_id": doc_point,
        "sections": sections,
        "units": units,
        "supported_types": list(SUPPORTED),
    }
    log_event(
        logger,
        "plan_built",
        document_id=document_id,
        document_type=document.document_type,
        **counts,
    )
    return plan


def _unit(document_id: str, level: int, chunk) -> dict[str, Any]:
    # One rule for every level: id = document + level code + ordinal. It is the
    # same string the chunker puts in a child's parent_id, so the graph in
    # PostgreSQL and in Qdrant uses identical keys.
    unit_id = chunk_id_for(document_id, level, chunk.ordinal)
    return {
        "chunk_id": unit_id,
        "level": level,
        "ordinal": chunk.ordinal,
        "text": chunk.embed_text(),
        "context": chunk.display(),
        "section_id": chunk.section_id,
        "parent_id": chunk.parent_id,
        "page": chunk.page,
        "char_count": len(chunk.text),
        "chunk_index": chunk.chunk_index,
        "level_path": chunk.level_path,
        "point_id": point_id_for(unit_id),
    }


def as_date(value: Any) -> date | None:
    """Coerce an ISO string to ``datetime.date``.

    n8n sends JSON, so every date arrives as text; asyncpg refuses to encode a
    ``str`` into a ``date`` column, and this is the one place that converts.
    """
    if value in (None, ""):
        return None
    if isinstance(value, date):
        return value
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, str):
        try:
            return date.fromisoformat(value[:10])
        except ValueError:
            return None
    return None


def as_timestamp(value: Any) -> datetime | None:
    """Coerce an ISO timestamp (or date) to an aware ``datetime``."""
    if value in (None, ""):
        return None
    if isinstance(value, datetime):
        return value if value.tzinfo else value.replace(tzinfo=timezone.utc)
    if isinstance(value, date):
        return datetime(value.year, value.month, value.day, tzinfo=timezone.utc)
    if isinstance(value, str):
        try:
            parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            parsed_date = as_date(value)
            return datetime(parsed_date.year, parsed_date.month, parsed_date.day, tzinfo=timezone.utc) if parsed_date else None
        return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
    return None


async def register(plan: dict[str, Any], extracted: dict[str, Any]) -> dict[str, Any]:
    """Write the whole document in one transaction.

    ``plan`` is what ``/internal/parse`` returned; ``extracted`` is what the LLM
    extraction step produced (dates, entities, events, facts). Either may be
    partial - a document with no extractable dates is still ingested, with
    ``temporal_certainty='unknown'`` so retrieval falls back to ``uploaded_at``.
    """
    document_id = plan["document_id"]
    document_date = as_date(extracted.get("document_date"))
    event_date = as_date(extracted.get("event_date"))
    uploaded_at = as_timestamp(extracted.get("uploaded_at"))
    units = plan.get("units") or []
    sections = plan.get("sections") or []
    counts = plan.get("counts") or {}

    document_row = {
        "document_id": document_id,
        "name": plan.get("name") or document_id,
        "source": extracted.get("source", "upload"),
        "document_type": plan.get("document_type", "txt"),
        "mime_type": plan.get("mime_type"),
        "size_bytes": plan.get("size_bytes", 0),
        "sha256": plan.get("sha256"),
        "document_date": document_date,
        "event_date": event_date,
        "effective_date": as_date(extracted.get("effective_date")) or event_date or document_date,
        "valid_from": as_date(extracted.get("valid_from")),
        "valid_until": as_date(extracted.get("valid_until")),
        "temporal_certainty": extracted.get("temporal_certainty", "unknown"),
        "status": extracted.get("status", "indexed"),
        "summary": extracted.get("summary") or _default_summary(plan),
        "qdrant_point_id": plan.get("document_point_id"),
        "page_count": plan.get("page_count"),
        "section_count": counts.get("sections", len(sections)),
        "chunk_count": counts.get("parents", 0) + counts.get("children", 0),
        "title": plan.get("title"),
        "authors": ", ".join(plan.get("authors") or []) or None,
        "metadata": {
            **(plan.get("metadata") or {}),
            **{k: v for k, v in (extracted.get("metadata") or {}).items()},
        },
        "uploaded_at": uploaded_at,
    }

    section_rows = [
        {
            "section_id": section["section_id"],
            "title": section.get("title"),
            "level": section.get("level", 1),
            "ordinal": section.get("ordinal", index),
            "page": section.get("page"),
            "text": section["text"],
            "effective_date": as_date(extracted.get("effective_date")) or document_row["effective_date"],
            "qdrant_point_id": section.get("point_id"),
        }
        for index, section in enumerate(sections)
    ]

    chunk_dates = _chunk_dates(units, extracted)
    chunk_rows = [
        {
            "chunk_id": unit["chunk_id"],
            "section_id": unit.get("section_id"),
            "parent_id": unit.get("parent_id"),
            "chunk_index": unit.get("chunk_index", 0),
            "page": unit.get("page"),
            "text": unit["text"],
            "identifiers": _identifiers(unit.get("text", "")),
            "event_date": chunk_dates.get(unit["chunk_id"], (None, None, "unknown"))[0],
            "effective_date": chunk_dates.get(unit["chunk_id"], (None, None, "unknown"))[1]
            or document_row["effective_date"],
            "temporal_certainty": chunk_dates.get(unit["chunk_id"], (None, None, "unknown"))[2],
            "qdrant_point_id": unit.get("point_id"),
        }
        for unit in units
        if unit.get("level", 0) in (2, 3)
    ]

    events = [
        {
            "document_id": document_id,
            "chunk_id": event.get("chunk_id"),
            "event_date": as_date(event.get("event_date")),
            "date_text": event.get("date_text"),
            "event_type": event.get("event_type", "event"),
            "title": event.get("title"),
            "description": event.get("description"),
            "entity_names": event.get("entity_names") or [],
            "confidence": float(event.get("confidence", 0.5)),
            "extraction": event.get("extraction", "llm"),
            "evidence_text": event.get("evidence_text"),
            "metadata": event.get("metadata") or {},
        }
        for event in (extracted.get("events") or [])
    ]
    facts = [
        {
            "document_id": document_id,
            "chunk_id": fact.get("chunk_id"),
            "subject": fact["subject"],
            "predicate": fact["predicate"],
            "object_value": fact.get("object_value"),
            "entity_names": fact.get("entity_names") or [],
            "event_date": as_date(fact.get("event_date")),
            "valid_from": as_date(fact.get("valid_from")),
            "valid_until": as_date(fact.get("valid_until")),
            "confidence": float(fact.get("confidence", 0.5)),
            "extraction": fact.get("extraction", "llm"),
        }
        for fact in (extracted.get("facts") or [])
    ]
    entities = [
        {
            "name": entity["name"],
            "entity_type": entity.get("entity_type", "unknown"),
            "seen_date": as_date(entity.get("seen_date")) or document_row["effective_date"],
            "chunk_id": entity.get("chunk_id"),
            "role": entity.get("role", "mentioned"),
        }
        for entity in (extracted.get("entities") or [])
        if (entity.get("name") or "").strip()
    ]

    started = time.perf_counter()
    pool = get_pool()
    async with pool.acquire() as conn:
        async with conn.transaction():
            await repo.upsert_document(document_row, conn=conn)
            if section_rows:
                await repo.replace_sections(document_id, section_rows, conn=conn)
            if chunk_rows:
                await repo.replace_chunks(document_id, chunk_rows, conn=conn)
            if entities:
                await repo.upsert_entities(document_id, entities, conn=conn)
            event_ids = await repo.insert_events(events, conn=conn)
            await repo.insert_facts(facts, conn=conn)

    document_row["event_count"] = len(event_ids)
    await repo.upsert_document(document_row)  # keep the event counter accurate
    result = {
        "document_id": document_id,
        "status": document_row["status"],
        "sections": len(section_rows),
        "chunks": len(chunk_rows),
        "vectors": counts.get("vectors", len(units)),
        "entities": len(entities),
        "events": len(event_ids),
        "facts": len(facts),
        "effective_date": document_row["effective_date"],
        "temporal_certainty": document_row["temporal_certainty"],
        "register_ms": int((time.perf_counter() - started) * 1000),
    }
    log_event(logger, "document_registered", **result)
    return result


def _chunk_dates(units: list[dict[str, Any]], extracted: dict[str, Any]) -> dict[str, tuple]:
    """Per-chunk temporal hints: explicit ones from the LLM beat the document default."""
    hints: dict[str, tuple] = {}
    for unit in units:
        override = (extracted.get("chunk_overrides") or {}).get(unit["chunk_id"])
        if override:
            hints[unit["chunk_id"]] = (
                as_date(override.get("event_date")),
                as_date(override.get("effective_date")),
                override.get("temporal_certainty", "explicit"),
            )
    for event in extracted.get("events") or []:
        chunk_id = event.get("chunk_id")
        if not chunk_id or chunk_id in hints:
            continue
        event_date = as_date(event.get("event_date"))
        hints[chunk_id] = (event_date, event_date, "explicit")
    return hints


_IDENTIFIER_CHARS = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_.@")


def _identifiers(text: str, limit: int = 12) -> list[str]:
    """Pull identifiers (E-101, v2.3, JIRA-99) out of a chunk for exact filtering."""
    found: list[str] = []
    current: list[str] = []
    for char in text:
        if char in _IDENTIFIER_CHARS:
            current.append(char)
            continue
        token = "".join(current)
        current = []
        if 2 <= len(token) <= 24 and any(ch.isdigit() for ch in token) and any(
            ch.isalpha() for ch in token
        ):
            if token not in found:
                found.append(token)
                if len(found) >= limit:
                    break
    return found


def _default_summary(plan: dict[str, Any]) -> str:
    first = next((u for u in plan.get("units") or [] if u.get("level") == 0), None)
    if first:
        return first["text"][:2000]
    return f"{plan.get('name')} ({plan.get('document_type')})"


def new_request_id() -> str:
    return uuid.uuid4().hex[:12]


def clear_uploads_older_than(hours: int = 6) -> int:
    """Housekeeping: nothing should linger in the upload directory."""
    if not os.path.isdir(settings.storage_dir):
        return 0
    removed = 0
    cutoff = time.time() - hours * 3600
    for name in os.listdir(settings.storage_dir):
        path = os.path.join(settings.storage_dir, name)
        try:
            if os.path.isfile(path) and os.path.getmtime(path) < cutoff:
                os.unlink(path)
                removed += 1
        except OSError:  # pragma: no cover - best effort
            continue
    return removed


def validate_extracted(extracted: dict[str, Any]) -> None:
    """Reject shapes that would corrupt the temporal index."""
    for key in ("document_date", "event_date", "effective_date", "valid_from", "valid_until"):
        value = extracted.get(key)
        if value in (None, ""):
            continue
        if not _is_iso_date(value):
            raise ValidationFailed(f"{key} must be an ISO date (YYYY-MM-DD), got {value!r}.")
    certainty = extracted.get("temporal_certainty")
    if certainty and certainty not in {"explicit", "inferred", "unknown", "relative"}:
        raise ValidationFailed(
            f"temporal_certainty must be explicit, inferred, relative or unknown; got {certainty!r}."
        )


def _is_iso_date(value: Any) -> bool:
    if not isinstance(value, str):
        return False
    try:
        from datetime import date

        date.fromisoformat(value)
        return True
    except ValueError:
        return False
