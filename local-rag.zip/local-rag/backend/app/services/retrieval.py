"""Hybrid retrieval: keyword and vector search fused, then expanded to context.

The design decisions worth stating, because they are the ones that make answers
trustworthy rather than merely plausible:

**The temporal filter is applied in SQL and in the vector filter, never after
scoring.** A chunk whose document is not yet known at ``as_of`` is excluded
before it can compete. This is the no-future-leakage rule, and it is the reason
this module is allowed to talk to Postgres and Qdrant directly instead of
filtering a merged result set afterwards.

**Ranking uses Reciprocal Rank Fusion, not a weighted sum of scores.** BM25
scores and cosine similarities are not on the same scale and are not comparable
across query phrasings. RRF only looks at *positions*, so a chunk ranked 3rd by
both systems is treated fairly regardless of whether its raw scores are 0.9 or
41.0. Trying to calibrate them is where hybrid search usually goes wrong.

**Only leaf chunks compete; parents are attached afterwards.** A child that won
a search is expanded to its parent for context, but a parent is never returned on
its own - a section header with no body is a bad answer, and letting it compete
would let one long section crowd out specific findings.
"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from datetime import date
from typing import Any

from app.clients import ollama, qdrant
from app.config import settings
from app.db.pool import fetch
from app.errors import EmptyQuestion, MalformedQuery
from app.services import rerank
from app.logging import get_logger, log_event

logger = get_logger("btm.retrieval")

# Reciprocal rank fusion: score = sum(1 / (k + rank)). k=60 is the constant from
# the original RRF paper and damps the top of the list enough that a single
# system's #1 does not automatically win.
_RRF_K = 60

_WORD = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]*")
_STOPWORDS = frozenset(
    """
    a an and are as at be been but by can did do does for from had has have
    he her his how i in into is it its of on or our out she that the their them
    then there these they this to was we were what when where which who why
    will with would you your
    """.split()
)


@dataclass
class Hit:
    """One retrieved chunk, with the provenance needed to explain the ranking."""

    chunk_id: str
    document_id: str
    document_name: str
    text: str
    score: float = 0.0
    level: int = 3
    section_id: str | None = None
    parent_id: str | None = None
    page: int | None = None
    effective_date: date | None = None
    temporal_certainty: str = "unknown"
    vector_rank: int | None = None
    keyword_rank: int | None = None
    parent_text: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def as_dict(self, *, with_parent: bool = True) -> dict[str, Any]:
        out: dict[str, Any] = {
            "chunk_id": self.chunk_id,
            "document_id": self.document_id,
            "document_name": self.document_name,
            "text": self.text,
            "score": round(self.score, 6),
            "level": self.level,
            "page": self.page,
            "effective_date": self.effective_date.isoformat() if self.effective_date else None,
            "temporal_certainty": self.temporal_certainty,
            "matched": {
                "keyword": self.keyword_rank is not None,
                "vector": self.vector_rank is not None,
            },
        }
        # Why this passage was chosen, when the ranking is not simply rank order.
        # Reranking that cannot be inspected is indistinguishable from an
        # arbitrary reordering, so the features travel with the hit.
        ranking = {
            key: self.extra[key]
            for key in ("base_score", "rerank_quality", "rerank_features", "recency_ratio", "recency_boost", "outside_relevance_band")
            if key in self.extra
        }
        if ranking:
            out["ranking"] = ranking
        if with_parent and self.parent_text:
            out["context"] = self.parent_text
        return out


def _query_terms(question: str) -> list[str]:
    """Content words, plus the numbers and codes that survive tokenization.

    Postgres's ``english`` dictionary stems words but keeps nothing that looks
    like an identifier. "FY2025", "4,120" and "2.1" are exactly the terms a
    business question turns on, so they are kept verbatim and quoted.
    """
    seen: list[str] = []
    for raw in _WORD.findall(question or ""):
        term = raw.strip("._-")
        if not term:
            continue
        if term.isdigit() or re.fullmatch(r"[A-Za-z]*\d[\w.-]*", term):
            if term.lower() not in seen:
                seen.append(term.lower())
        elif term.lower() not in _STOPWORDS and len(term) > 2:
            if term.lower() not in seen:
                seen.append(term.lower())
    return seen


def _tsquery(terms: list[str]) -> str:
    """A websearch-style OR query, so a missing word narrows nothing away."""
    if not terms:
        return ""
    parts = []
    for term in terms[:12]:
        if any(ch in term for ch in " .-"):
            parts.append(f'"{term}"')
        else:
            parts.append(term)
    return " | ".join(parts)


# ------------------------------------------------------------------ keyword side
async def keyword_search(
    question: str,
    *,
    as_of: date | None = None,
    start: date | None = None,
    end: date | None = None,
    document_ids: list[str] | None = None,
    document_types: list[str] | None = None,
    entity: str | None = None,
    limit: int = 40,
) -> list[Hit]:
    """BM25-ranked keyword search over chunk text, with the temporal gate in SQL."""
    terms = _query_terms(question)
    if not terms:
        return []

    params: list[Any] = []
    filters: list[str] = ["c.level = 3", "d.status = 'indexed'"]

    if as_of is not None:
        params.append(as_of)
        point = f"${len(params)}"
        filters.append(
            f"((d.effective_date IS NOT NULL AND d.effective_date <= {point}::date)"
            f" OR (d.effective_date IS NULL AND d.uploaded_at::date <= {point}::date))"
        )
        filters.append(f"(d.valid_until IS NULL OR d.valid_until > {point}::date)")
    elif start is not None and end is not None:
        params.extend([start, end])
        low, high = f"${len(params) - 1}", f"${len(params)}"
        filters.append(
            f"((d.effective_date IS NOT NULL AND d.effective_date > {low}::date AND d.effective_date <= {high}::date)"
            f" OR (d.effective_date IS NULL AND d.uploaded_at::date > {low}::date AND d.uploaded_at::date <= {high}::date))"
        )
        filters.append(f"(d.valid_from IS NULL OR d.valid_from <= {high}::date)")

    if document_ids:
        params.append(sorted(set(document_ids))[:200])
        filters.append(f"d.document_id = ANY(${len(params)}::text[])")

    if document_types:
        params.append(sorted(set(document_types)))
        filters.append(f"d.document_type = ANY(${len(params)}::text[])")

    if entity:
        params.append(entity)
        idx = len(params)
        filters.append(
            f"EXISTS (SELECT 1 FROM entity_mentions m WHERE m.chunk_id = c.chunk_id"
            f" AND m.entity_id = (SELECT entity_id FROM entities WHERE lower(name) = lower(${idx})))"
        )

    query = _tsquery(terms)
    if not query:
        return []
    params.append(query)
    params.append(int(limit))

    sql = f"""
        WITH ranked AS (
            SELECT c.chunk_id, c.document_id, d.name AS document_name, c.text, c.level,
                   c.section_id, c.parent_id, c.page, c.effective_date,
                   c.temporal_certainty,
                   -- Not "rank": RANK is the window function, and ORDER BY on the
                   -- bare keyword parses as a call and dies on the next comma.
                   ts_rank_cd(c.tsv, websearch_to_tsquery('english', ${len(params) - 1}::text)) AS relevance
            FROM document_chunks c
            JOIN documents d ON d.document_id = c.document_id
            WHERE {' AND '.join(filters)}
              AND c.tsv @@ websearch_to_tsquery('english', ${len(params) - 1}::text)
        )
        SELECT * FROM ranked
        ORDER BY relevance DESC, chunk_id
        LIMIT ${len(params)}
    """
    rows = await fetch(sql, *params)
    hits: list[Hit] = []
    for index, row in enumerate(rows):
        hits.append(
            Hit(
                chunk_id=row["chunk_id"],
                document_id=row["document_id"],
                document_name=row["document_name"],
                text=row["text"],
                level=int(row["level"]),
                section_id=row["section_id"],
                parent_id=row["parent_id"],
                page=row["page"],
                effective_date=row["effective_date"],
                temporal_certainty=row["temporal_certainty"] or "unknown",
                keyword_rank=index + 1,
            )
        )
    return hits


# ------------------------------------------------------------------- vector side
async def vector_search(
    question: str,
    *,
    as_of: date | None = None,
    start: date | None = None,
    end: date | None = None,
    document_ids: list[str] | None = None,
    document_types: list[str] | None = None,
    limit: int = 40,
) -> list[Hit]:
    """Vector search over the same temporal gate, expressed as a Qdrant filter."""
    vectors = await ollama.embed([question])
    # The filter goes into a JSON body; dates have to be strings on the way in.
    query_filter = qdrant.temporal_filter(
        as_of=as_of.isoformat() if as_of else None,
        start=start.isoformat() if start else None,
        end=end.isoformat() if end else None,
        document_ids=document_ids,
        document_types=document_types,
    )
    query_filter.setdefault("must", []).append(
        {"key": "level", "match": {"value": 3}}
    )
    try:
        points = await qdrant.search_points(vectors[0], limit=limit, query_filter=query_filter)
    except Exception as exc:  # noqa: BLE001 - keyword search must still work
        log_event(logger, "vector_search_failed", error=str(exc)[:200])
        return []

    hits: list[Hit] = []
    for index, point in enumerate(points):
        payload = point.get("payload") or {}
        doc_ts = payload.get("doc_ts")
        try:
            effective = date.fromisoformat(doc_ts) if doc_ts else None
        except ValueError:
            effective = None
        hits.append(
            Hit(
                chunk_id=payload.get("chunk_id") or str(point.get("id")),
                document_id=payload.get("document_id") or "",
                document_name=payload.get("document_name") or "",
                text="",
                level=int(payload.get("level") or 3),
                section_id=payload.get("section_id"),
                parent_id=payload.get("parent_id"),
                page=payload.get("page"),
                effective_date=effective,
                temporal_certainty=payload.get("temporal_certainty") or "unknown",
                vector_rank=index + 1,
                extra={"vector_score": point.get("score")},
            )
        )
    return hits


# ----------------------------------------------------------------------- fusion
def _apply_recency(hits: list[Hit], weight: float) -> None:
    """Prefer the newer of two documents that matched equally well.

    Pure RRF cannot do this, and for a business time machine that is the whole
    point: at ``as_of`` 2024-12-31 the 2023 and 2024 annual reports both match
    "customer churn", and the 2024 figure (3.6%) supersedes the 2023 one (4.1%).
    A rank-fusion score is blind to that, so without a recency term the stale
    answer wins whenever both documents sit at the same rank.

    The term is multiplicative and small, so it breaks ties between equally
    relevant documents without letting a fresher but irrelevant document displace
    a better match. At weight 0.15 the newest candidate gains 15% and the oldest
    gains nothing; an RRF gap between adjacent ranks is far smaller than that,
    while a candidate that both systems ranked far higher still wins.
    """
    if weight <= 0:
        return
    dated = [h.effective_date for h in hits if h.effective_date]
    if len(dated) < 2:
        return
    oldest, newest = min(dated), max(dated)
    span = (newest - oldest).days
    if span <= 0:
        return
    for hit in hits:
        if hit.effective_date is None:
            continue
        ratio = (hit.effective_date - oldest).days / span
        hit.score *= 1.0 + weight * ratio
        hit.extra["recency_ratio"] = round(ratio, 4)


def _fuse(*ranked_lists: list[Hit]) -> list[Hit]:
    """Reciprocal Rank Fusion over already-ranked lists."""
    merged: dict[str, Hit] = {}
    scores: dict[str, float] = {}
    for hits in ranked_lists:
        for hit in hits:
            existing = merged.get(hit.chunk_id)
            if existing is None:
                merged[hit.chunk_id] = hit
            else:
                # Keep whichever copy carries text; the keyword side always has it.
                if not existing.text and hit.text:
                    merged[hit.chunk_id] = hit
            if hit.keyword_rank is not None:
                merged[hit.chunk_id].keyword_rank = hit.keyword_rank
            if hit.vector_rank is not None:
                merged[hit.chunk_id].vector_rank = hit.vector_rank
            scores[hit.chunk_id] = scores.get(hit.chunk_id, 0.0) + 1.0 / (_RRF_K + (hit.keyword_rank or hit.vector_rank or 1))
    for chunk_id, score in scores.items():
        merged[chunk_id].score = score
    return sorted(merged.values(), key=lambda h: (-h.score, h.chunk_id))


async def _attach_parents(hits: list[Hit]) -> None:
    """Replace a winning child with its parent's text, keeping the child's id.

    The child identifies *where* the answer is; the parent explains it. Returning
    the child text alone gives a citation a reader cannot follow, and returning
    the parent alone loses the precision of the match.
    """
    parent_ids = sorted({h.parent_id for h in hits if h.parent_id})
    if not parent_ids:
        return
    # One array parameter, not a placeholder per id: ANY() takes a single array
    # expression, so "ANY($1,$2)" is a syntax error, not a slow query.
    rows = await fetch(
        """
        SELECT chunk_id, text FROM document_chunks
        WHERE chunk_id = ANY($1::text[])
        """,
        parent_ids,
    )
    parents = {row["chunk_id"]: row["text"] for row in rows}
    for hit in hits:
        if hit.parent_id and hit.parent_id in parents:
            hit.parent_text = parents[hit.parent_id]


async def search(
    question: str,
    *,
    as_of: date | None = None,
    start: date | None = None,
    end: date | None = None,
    document_ids: list[str] | None = None,
    document_types: list[str] | None = None,
    entity: str | None = None,
    limit: int = 8,
    candidate_limit: int = 40,
    with_parents: bool = True,
) -> dict[str, Any]:
    """Hybrid search. Returns hits plus the provenance needed to audit them."""
    question = (question or "").strip()
    if not question:
        raise EmptyQuestion()
    if as_of and (start or end):
        raise MalformedQuery("Use either as_of or start/end, not both.")
    if not as_of and not (start and end):
        as_of = date.today()

    started = time.perf_counter()
    keyword = await keyword_search(
        question,
        as_of=as_of,
        start=start,
        end=end,
        document_ids=document_ids,
        document_types=document_types,
        entity=entity,
        limit=candidate_limit,
    )
    vector = await vector_search(
        question,
        as_of=as_of,
        start=start,
        end=end,
        document_ids=document_ids,
        document_types=document_types,
        limit=candidate_limit,
    )

    fused = _fuse(keyword, vector)
    if settings.rerank_enabled:
        fused = rerank.rerank(question, fused)
    else:
        _apply_recency(fused, settings.retrieval_recency_weight)
        fused.sort(key=lambda h: (-h.score, h.chunk_id))
    fused = fused[:limit]

    # The vector side has no text; fill it from the database so a hit that only
    # matched semantically still gets a citation.
    missing = [h.chunk_id for h in fused if not h.text]
    if missing:
        rows = await fetch(
            """
            SELECT c.chunk_id, c.text, c.parent_id, c.page, c.effective_date, c.temporal_certainty,
                   d.name AS document_name
            FROM document_chunks c
            JOIN documents d ON d.document_id = c.document_id
            WHERE c.chunk_id = ANY($1::text[])
            """,
            missing,
        )
        by_id = {row["chunk_id"]: row for row in rows}
        for hit in fused:
            row = by_id.get(hit.chunk_id)
            if row is not None:
                hit.text = row["text"]
                hit.parent_id = hit.parent_id or row["parent_id"]
                hit.page = hit.page if hit.page is not None else row["page"]
                hit.effective_date = hit.effective_date or row["effective_date"]
                hit.temporal_certainty = hit.temporal_certainty or row["temporal_certainty"] or "unknown"
                hit.document_name = hit.document_name or row["document_name"]

    if with_parents:
        await _attach_parents(fused)

    elapsed = (time.perf_counter() - started) * 1000
    log_event(
        logger,
        "hybrid_search",
        as_of=str(as_of) if as_of else None,
        start=str(start) if start else None,
        end=str(end) if end else None,
        keyword=len(keyword),
        vector=len(vector),
        fused=len(fused),
        ms=int(elapsed),
    )
    return {
        "hits": fused,
        "stats": {
            "keyword_candidates": len(keyword),
            "vector_candidates": len(vector),
            "fused": len(fused),
            "keyword_only": sum(1 for h in fused if h.vector_rank is None),
            "vector_only": sum(1 for h in fused if h.keyword_rank is None),
            "both": sum(1 for h in fused if h.keyword_rank and h.vector_rank),
            "search_ms": int(elapsed),
        },
    }
