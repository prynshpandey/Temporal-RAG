"""Ollama client: local embeddings (always) and local chat (fallback provider).

Embeddings never leave the machine - Groq is only used for generation, which is
why this module is the single place that calls ``/api/embed``.
"""

from __future__ import annotations

from typing import Any

import httpx

from app.config import settings
from app.errors import EmbeddingFailed, LlmFailed, OllamaUnavailable
from app.logging import get_logger, log_event

logger = get_logger("btm.ollama")


def _client(timeout: float | None = None) -> httpx.AsyncClient:
    return httpx.AsyncClient(base_url=settings.ollama_base_url, timeout=timeout or settings.embedding_timeout_s)


async def _post(path: str, body: dict[str, Any], timeout: float | None = None) -> dict[str, Any]:
    try:
        async with _client(timeout) as client:
            response = await client.post(path, json=body)
    except httpx.HTTPError as exc:
        raise OllamaUnavailable(f"Ollama is not reachable at {settings.ollama_base_url}: {exc}") from exc
    if response.status_code >= 400:
        raise EmbeddingFailed(f"Ollama returned HTTP {response.status_code}: {response.text[:300]}")
    return response.json()


async def list_models() -> list[str]:
    try:
        async with _client(10.0) as client:
            response = await client.get("/api/tags")
        if response.status_code >= 400:
            return []
        return [m["name"] for m in response.json().get("models", [])]
    except httpx.HTTPError:
        return []


async def embed(texts: list[str], *, model: str | None = None, keep_alive: str = "5m") -> list[list[float]]:
    """Embed one batch. Order of the returned vectors matches ``texts``."""
    if not texts:
        return []
    model = model or settings.embedding_model
    data = await _post(
        "/api/embed",
        {
            "model": model,
            "input": texts,
            "truncate": settings.embed_truncate,
            "keep_alive": keep_alive,
        },
    )
    vectors = data.get("embeddings")
    if not isinstance(vectors, list) or len(vectors) != len(texts):
        raise EmbeddingFailed(
            f"embedding count mismatch: sent {len(texts)} texts, got "
            f"{len(vectors) if isinstance(vectors, list) else 'no list'}"
        )
    log_event(logger, "embedded", model=model, inputs=len(texts), dim=len(vectors[0]))
    return [[float(x) for x in vector] for vector in vectors]


async def embed_batch(
    texts: list[str], *, model: str | None = None, batch_size: int | None = None
) -> list[list[float]]:
    """Embed many texts in CPU-friendly batches (``EMBED_BATCH_SIZE``, default 8)."""
    batch_size = batch_size or settings.embedding_batch_size
    out: list[list[float]] = []
    for start in range(0, len(texts), batch_size):
        out.extend(await embed(texts[start : start + batch_size], model=model))
    return out


async def model_dimension(model: str | None = None) -> int | None:
    """Dimension of the embedding model, read from one tiny embed call."""
    try:
        vector = await embed(["dimension probe"], model=model)
        return len(vector[0]) if vector else None
    except (EmbeddingFailed, OllamaUnavailable):
        return None


async def chat(
    system_prompt: str,
    user_prompt: str,
    *,
    model: str | None = None,
    temperature: float = 0.1,
    num_predict: int = 1200,
    num_ctx: int = 8192,
    json_mode: bool = False,
) -> dict[str, Any]:
    model = model or settings.local_llm_model
    body: dict[str, Any] = {
        "model": model,
        "stream": False,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        "options": {
            "temperature": temperature,
            "num_predict": num_predict,
            "num_ctx": num_ctx,
        },
    }
    if json_mode:
        body["format"] = "json"
    try:
        async with _client(settings.local_llm_timeout_s) as client:
            response = await client.post("/api/chat", json=body)
    except httpx.HTTPError as exc:
        raise OllamaUnavailable(f"Ollama chat failed: {exc}") from exc
    if response.status_code >= 400:
        raise LlmFailed(f"Ollama returned HTTP {response.status_code}: {response.text[:300]}")
    data = response.json()
    return {
        "text": (data.get("message") or {}).get("content") or "",
        "model": data.get("model", model),
        "done_reason": data.get("done_reason"),
        "prompt_tokens": data.get("prompt_eval_count"),
        "completion_tokens": data.get("eval_count"),
    }
