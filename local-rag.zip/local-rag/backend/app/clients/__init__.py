"""HTTP clients for the local infrastructure (Qdrant, Ollama).

Plain HTTP instead of vendor SDKs: every request is visible in the logs, the
dependency surface stays small, and the code matches how the n8n workflows talk
to the same services.
"""

from app.clients.ollama import chat, embed, embed_batch, list_models, model_dimension
from app.clients.qdrant import (
    QdrantClient,
    collection_exists,
    count_points,
    delete_by_filter,
    delete_collection,
    ensure_collection,
    recreate_indexes,
    scroll_points,
    search_points,
    upsert_points,
)

__all__ = [
    "QdrantClient",
    "chat",
    "collection_exists",
    "count_points",
    "delete_by_filter",
    "delete_collection",
    "embed",
    "embed_batch",
    "ensure_collection",
    "list_models",
    "model_dimension",
    "recreate_indexes",
    "scroll_points",
    "search_points",
    "upsert_points",
]
