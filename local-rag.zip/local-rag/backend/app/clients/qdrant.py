"""Qdrant client (HTTP API).

Only the calls this application needs, with the 1.19 semantics:

* upsert a point list -> ``PUT /collections/{c}/points`` (POST is the *batch
  update* format and fails with "missing field 'ids'")
* filter everything by ``embedding_level`` so document/section/chunk vectors
  share one collection without mixing
"""

from __future__ import annotations

from typing import Any

import httpx

from app.config import settings
from app.errors import QdrantUnavailable
from app.logging import get_logger, log_event

logger = get_logger("btm.qdrant")

# keyword payload indexes: everything retrieval filters on.
PAYLOAD_INDEXES: dict[str, str] = {
    "embedding_level": "keyword",
    "document_id": "keyword",
    "document_name": "keyword",
    "section_id": "keyword",
    "chunk_id": "keyword",
    "parent_id": "keyword",
    "document_type": "keyword",
    "source": "keyword",
    "temporal_certainty": "keyword",
    "entity_names": "keyword",
    "page": "integer",
    "chunk_index": "integer",
    "level": "integer",
    "char_count": "integer",
    "doc_ts": "datetime",
    "event_ts": "datetime",
    # request_ts is the fallback for undated knowledge, and the validity bounds
    # are what keep expired knowledge out of the vector path. All three are
    # filtered on, so all three are indexed: an unindexed date field still
    # filters correctly but scans the collection, which is a silent cliff.
    "request_ts": "datetime",
    "valid_from": "datetime",
    "valid_until": "datetime",
}


def _client() -> httpx.AsyncClient:
    return httpx.AsyncClient(base_url=settings.qdrant_url, timeout=settings.qdrant_timeout_s)


async def _json(client: httpx.AsyncClient, method: str, path: str, **kwargs) -> dict[str, Any]:
    try:
        response = await client.request(method, path, **kwargs)
    except httpx.HTTPError as exc:
        raise QdrantUnavailable(f"Qdrant request failed: {exc}") from exc
    if response.status_code >= 400:
        raise QdrantUnavailable(
            f"Qdrant returned HTTP {response.status_code}: {response.text[:400]}"
        )
    return response.json() if response.content else {}


async def collection_exists(name: str | None = None) -> bool:
    name = name or settings.qdrant_collection
    async with _client() as client:
        response = await client.get(f"/collections/{name}")
        return response.status_code == 200


async def ensure_collection(
    name: str | None = None,
    *,
    size: int | None = None,
    distance: str | None = None,
) -> bool:
    """Create the collection and its payload indexes if they are missing.

    Returns True when the collection already existed.
    """
    name = name or settings.qdrant_collection
    size = size or settings.qdrant_vector_size
    distance = distance or settings.qdrant_distance
    async with _client() as client:
        if (await client.get(f"/collections/{name}")).status_code == 200:
            await recreate_indexes(client, name)
            return True
        await _json(
            client,
            "PUT",
            f"/collections/{name}",
            json={
                "vectors": {"size": size, "distance": distance},
                "on_disk_payload": True,
                "hnsw_config": {"m": 16, "ef_construct": 128},
            },
        )
        await recreate_indexes(client, name)
    log_event(logger, "collection_created", collection=name, size=size, distance=distance)
    return False


async def recreate_indexes(client: httpx.AsyncClient, name: str | None = None) -> None:
    name = name or settings.qdrant_collection
    for field, schema in PAYLOAD_INDEXES.items():
        await _json(
            client,
            "PUT",
            f"/collections/{name}/index",
            params={"wait": "true"},
            json={"field_name": field, "field_schema": schema},
        )


async def upsert_points(points: list[dict[str, Any]], name: str | None = None) -> dict[str, Any]:
    name = name or settings.qdrant_collection
    if not points:
        return {"status": "skipped", "points": 0}
    async with _client() as client:
        result = await _json(
            client,
            "PUT",
            f"/collections/{name}/points",
            params={"wait": "true"},
            json={"points": points},
        )
    log_event(logger, "points_upserted", points=len(points), result=result.get("status"))
    return result


async def delete_document_vectors(document_id: str, name: str | None = None) -> int:
    """Remove every vector of one document, whatever its level.

    Qdrant's delete-by-filter does not report a count, so the number is measured
    by counting the collection before and after. Callers treat a failure here as
    non-fatal: PostgreSQL is the source of truth and the leftover points are
    swept by ``scripts/cleanup_orphans.py``.
    """
    try:
        before = await count_points(name=name)
        result = await delete_by_filter(
            {"must": [{"key": "document_id", "match": {"value": document_id}}]}, name=name
        )
        after = await count_points(name=name)
    except QdrantUnavailable:
        log_event(logger, "vector_delete_failed", document_id=document_id, reason="qdrant_unavailable")
        return 0
    status = result.get("result", {}).get("status") or result.get("status")
    deleted = max(before - after, 0)
    log_event(logger, "vectors_deleted", document_id=document_id, points=deleted, status=status)
    return deleted


async def search_points(
    vector: list[float],
    *,
    limit: int = 20,
    query_filter: dict[str, Any] | None = None,
    score_threshold: float | None = None,
    with_payload: bool = True,
    name: str | None = None,
) -> list[dict[str, Any]]:
    name = name or settings.qdrant_collection
    body: dict[str, Any] = {
        "vector": vector,
        "limit": limit,
        "with_payload": with_payload,
        "with_vector": False,
    }
    if query_filter:
        body["filter"] = query_filter
    if score_threshold is not None:
        body["score_threshold"] = score_threshold
    async with _client() as client:
        data = await _json(client, "POST", f"/collections/{name}/points/search", json=body)
    return data.get("result") or []


async def scroll_points(
    *,
    query_filter: dict[str, Any] | None = None,
    limit: int = 1000,
    offset: int | None = None,
    with_vector: bool = False,
    name: str | None = None,
) -> list[dict[str, Any]]:
    name = name or settings.qdrant_collection
    body: dict[str, Any] = {
        "limit": limit,
        "with_payload": True,
        "with_vector": with_vector,
    }
    if query_filter:
        body["filter"] = query_filter
    if offset is not None:
        body["offset"] = offset
    async with _client() as client:
        data = await _json(client, "POST", f"/collections/{name}/points/scroll", json=body)
    return (data.get("result") or {}).get("points") or []


async def delete_by_filter(query_filter: dict[str, Any], name: str | None = None) -> dict[str, Any]:
    name = name or settings.qdrant_collection
    async with _client() as client:
        data = await _json(
            client,
            "POST",
            f"/collections/{name}/points/delete",
            params={"wait": "true"},
            json={"filter": query_filter},
        )
    log_event(logger, "points_deleted", filter=query_filter, result=data.get("status"))
    return data


async def count_points(
    query_filter: dict[str, Any] | None = None, *, exact: bool = True, name: str | None = None
) -> int:
    name = name or settings.qdrant_collection
    async with _client() as client:
        if query_filter is None and not exact:
            data = await _json(client, "GET", f"/collections/{name}")
            return int(data["result"]["points_count"] or 0)
        body: dict[str, Any] = {"exact": exact, "with_payload": False, "with_vector": False}
        if query_filter:
            body["filter"] = query_filter
        data = await _json(client, "POST", f"/collections/{name}/points/count", json=body)
    return int(data.get("result", {}).get("count", 0))


async def delete_collection(name: str) -> None:
    async with _client() as client:
        response = await client.delete(f"/collections/{name}")
        if response.status_code not in (200, 404):
            raise QdrantUnavailable(f"could not delete {name}: HTTP {response.status_code}")


def temporal_filter(
    *,
    as_of: str | None = None,
    start: str | None = None,
    end: str | None = None,
    document_ids: list[str] | None = None,
    document_types: list[str] | None = None,
) -> dict[str, Any]:
    """A Qdrant filter that cannot return knowledge from the future.

    The payload carries the document's effective date as ``doc_ts``. The rule
    mirrors the SQL in the repository: a dated document is visible from its own
    date onwards, and a chunk with no date is visible from the ingest run that
    produced it (``request_ts``). Both are expressed as filter conditions so the
    exclusion happens inside Qdrant, before anything is scored.

    Two Qdrant API details, both learned the hard way:

    * Expiry is expressed with ``must_not`` on a range. A knowledge item is
      valid at a point in time unless its validity has *ended* by then, and a
      null bound is not <= any date, so the null case needs no condition of its
      own. Getting this wrong is silent: the SQL row is filtered correctly and
      the vector hit is not, so an expired document still reaches the answer.
    * ``should`` is a sibling of ``must`` at the top level of the filter, not a
      condition you can nest inside one. Nesting it returns HTTP 400.
    * ``is_null`` is a plain boolean alongside ``key`` in this version, not the
      nested object form newer Qdrant releases use.
    * The minimum for a ``should`` is spelled ``min_should`` here. Qdrant renamed
      it to ``minimum_should_match`` in later releases and rejects the old name.
    """
    must: list[dict[str, Any]] = []
    must_not: list[dict[str, Any]] = []
    should: list[dict[str, Any]] = []

    if as_of:
        # Either the document's own date has arrived, or it has no date and was
        # ingested by then. One of the two has to hold.
        should.append({"key": "doc_ts", "range": {"lte": as_of}})
        should.append(
            {
                "must": [
                    {"key": "doc_ts", "is_null": True},
                    {"key": "request_ts", "range": {"lte": as_of}},
                ]
            }
        )
        # Mirrors SQL ``(valid_until IS NULL OR valid_until > as_of)``. Spelled
        # as an exclusion rather than a should: "still valid at as_of" is
        # ``NOT (valid_until <= as_of)``, and a null bound is never <= a date,
        # so this needs no extra null handling.
        must_not.append({"key": "valid_until", "range": {"lte": as_of}})
    elif start and end:
        should.append({"key": "doc_ts", "range": {"gt": start, "lte": end}})
        # Mirrors SQL ``(valid_from IS NULL OR valid_from <= end)``.
        must_not.append({"key": "valid_from", "range": {"gt": end}})

    if document_ids is not None:
        must.append(
            {
                "key": "document_id",
                "match": {"any": sorted(set(document_ids)) or ["__none__"]},
            }
        )
    if document_types:
        must.append(
            {
                "key": "document_type",
                "match": {"any": sorted(set(document_types))},
            }
        )

    query_filter: dict[str, Any] = {"must": must}
    if must_not:
        query_filter["must_not"] = must_not
    if should:
        # min_should carries the alternatives itself, as a MinShould object.
        query_filter["min_should"] = {"conditions": should, "min_count": 1}
    return query_filter


def level_filter(level: str, document_ids: list[str] | None = None) -> dict[str, Any]:
    """Qdrant filter for one embedding level, optionally restricted to documents."""
    must: list[dict[str, Any]] = [{"key": "embedding_level", "match": {"value": level}}]
    if document_ids is not None:
        must.append(
            {
                "key": "document_id",
                "match": {"any": sorted(set(document_ids)) or ["__none__"]},
            }
        )
    return {"must": must}


class QdrantClient:
    """Small facade kept for readability at call sites."""

    url = settings.qdrant_url
    collection = settings.qdrant_collection

    ensure_collection = staticmethod(ensure_collection)
    upsert_points = staticmethod(upsert_points)
    search_points = staticmethod(search_points)
    scroll_points = staticmethod(scroll_points)
    delete_by_filter = staticmethod(delete_by_filter)
    count_points = staticmethod(count_points)
