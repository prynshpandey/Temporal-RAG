"""PDF parser (pypdf): page-accurate text plus a heading outline.

PDFs carry no reliable structure, so three passes are used:

1. extract the text of every page;
2. drop *running* headers/footers - lines that repeat across most pages (the
   "CONFIDENTIAL" banner) or match a page-number pattern. Left in place they
   pollute every chunk and beat the real headings in the embedding;
3. split what remains at detected heading lines, which is what gives the
   retrieval layer a real section to point at instead of a page-sized blob.
"""

from __future__ import annotations

import re
from collections import Counter

from pypdf import PdfReader
from pypdf.errors import PdfReadError

from app.errors import CorruptDocument, NoTextLayer
from app.parsers.base import Page, ParsedDocument, Section, normalize_text, split_lines

# A heading-ish line: short, no trailing sentence punctuation, not a bullet, and
# either title-cased, ALL CAPS, or numbered like "2.1 Scope".
_HEADING_RE = re.compile(r"^(?:\d+(?:\.\d+)*[.)]?\s+)?[A-Z0-9][^.!?;:,]{2,140}$", re.UNICODE)
_SENTENCE_END = (".", ",", ";", ":", "!", "?")
# "Page 3 of 12", "- 3 -", "3 / 12", "(c) 2025 Acme"
_PAGE_NUMBER_RE = re.compile(
    r"^(?:[-–—(\[]?\s*(?:page\s+)?\d+\s*(?:/|of|out of)?\s*\d*\s*[-–—)\]]?|\(\s*[cC©©]\s*.*\)|[-–—]\s*\d+\s*[-–—])$",
    re.IGNORECASE,
)


def _looks_like_heading(line: str) -> bool:
    if not (3 <= len(line) <= 140) or line.endswith(_SENTENCE_END):
        return False
    if re.match(r"^\s*[-*\u2022]\s", line):          # bullet
        return False
    if _PAGE_NUMBER_RE.match(line):
        return False
    words = line.split()
    if not 1 <= len(words) <= 14:
        return False
    if re.match(r"^\d+(\.\d+)*[.)]?\s", line):        # numbered heading
        return True
    if line.isupper() and len(line) > 3:
        return True
    if not _HEADING_RE.match(line):
        return False
    title_cased = sum(1 for w in words if w[:1].isupper() or w[:1].isdigit())
    return title_cased / len(words) >= 0.5


def _is_page_number(line: str) -> bool:
    return bool(_PAGE_NUMBER_RE.match(line.strip()))


def _running_lines(pages: list[list[str]], min_pages: int = 3, ratio: float = 0.4) -> set[str]:
    """Short lines that repeat on most pages: headers and footers."""
    if len(pages) < min_pages:
        return set()
    threshold = max(min_pages - 1, int(len(pages) * ratio) - 1)
    per_page = [set(lines) for lines in pages]
    counts: Counter[str] = Counter()
    for line_set in per_page:
        counts.update(line for line in line_set if len(line) <= 100)
    return {line for line, count in counts.items() if count >= threshold}


class PdfParser:
    document_type = "pdf"

    def __init__(self, max_pages: int = 2000, max_headings_per_page: int = 12) -> None:
        self.max_pages = max_pages
        self.max_headings_per_page = max_headings_per_page

    def parse(self, path: str) -> ParsedDocument:
        try:
            reader = PdfReader(path, strict=False)
            if reader.is_encrypted:
                try:
                    reader.decrypt("")
                except Exception as exc:  # pragma: no cover - depends on the file
                    raise CorruptDocument(
                        "The PDF is password protected, so its text cannot be read."
                    ) from exc
        except PdfReadError as exc:
            raise CorruptDocument(f"pypdf could not read the PDF: {exc}") from exc

        if len(reader.pages) > self.max_pages:
            raise CorruptDocument(
                f"The PDF has {len(reader.pages)} pages; the limit is {self.max_pages}."
            )

        page_lines: list[list[str]] = []
        for page in reader.pages[: self.max_pages]:
            try:
                raw = page.extract_text() or ""
            except Exception:  # a single broken page must not fail the upload
                raw = ""
            page_lines.append([line for line in split_lines(normalize_text(raw)) if line])

        if not any(any(lines) for lines in page_lines):
            raise NoTextLayer()

        running = _running_lines(page_lines)

        pages: list[Page] = []
        sections: list[Section] = []
        for number, lines in enumerate(page_lines, start=1):
            kept = [line for line in lines if line not in running and not _is_page_number(line)]
            text = "\n".join(kept).strip()
            pages.append(Page(number=number, text=text))
            for title, body in self._split_page(kept, len(sections)):
                sections.append(
                    Section(
                        key=f"s{len(sections)}",
                        title=title,
                        level=1 if title else 0,
                        ordinal=len(sections),
                        page=number,
                        text=body,
                    )
                )

        info = reader.metadata or {}
        return ParsedDocument(
            document_type=self.document_type,
            text="\n\n".join(f"[p{page.number}]\n{page.text}" for page in pages if page.text),
            pages=pages,
            sections=sections,
            title=_clean(info.get("/Title")),
            authors=[a for a in (_clean(info.get("/Author")),) if a],
            metadata={
                "producer": _clean(info.get("/Producer")),
                "creator": _clean(info.get("/Creator")),
                "page_count": len(pages),
                "removed_running_lines": sorted(running)[:5],
            },
            page_count=len(pages),
        )

    def _split_page(self, lines: list[str], offset: int):
        """Yield ``(title, body)`` for one page, splitting at detected headings."""
        if not lines:
            return
        found = 0
        for position, line in enumerate(lines):
            if found >= self.max_headings_per_page:
                break
            if not _looks_like_heading(line):
                continue
            found += 1
            yield line, "\n".join(lines[position:]).strip()
        if not found:
            yield None, "\n".join(lines).strip()


def _clean(value) -> str | None:
    if not value:
        return None
    text = str(value).strip()
    return text or None
