"""PPTX parser (python-pptx): one section per slide, speaker notes included.

Slides are the natural section boundary, and the notes often carry the
narrative that the bullet text alone loses - so both end up in the section body.
"""

from __future__ import annotations

from pptx import Presentation
from pptx.exc import PackageNotFoundError

from app.errors import CorruptDocument, NoTextLayer
from app.parsers.base import Page, ParsedDocument, Section, normalize_text


def _shape_text(shape) -> str:
    if not shape.has_text_frame:
        if getattr(shape, "has_table", False):
            rows = [
                " | ".join(normalize_text(cell.text) for cell in row.cells)
                for row in shape.table.rows
            ]
            return "\n".join(row for row in rows if row.strip(" |"))
        return ""
    lines = [normalize_text(p.text) for p in shape.text_frame.paragraphs]
    return "\n".join(line for line in lines if line)


class PptxParser:
    document_type = "pptx"

    def __init__(self, max_slides: int = 1000) -> None:
        self.max_slides = max_slides

    def parse(self, path: str) -> ParsedDocument:
        try:
            deck = Presentation(path)
        except (PackageNotFoundError, KeyError, ValueError) as exc:
            raise CorruptDocument(f"python-pptx could not open the file: {exc}") from exc

        slides = list(deck.slides)
        if not slides:
            raise NoTextLayer()
        if len(slides) > self.max_slides:
            raise CorruptDocument(
                f"The deck has {len(slides)} slides; the limit is {self.max_slides}."
            )

        pages: list[Page] = []
        sections: list[Section] = []
        for number, slide in enumerate(slides, start=1):
            title = None
            if slide.shapes.title is not None:
                title = normalize_text(slide.shapes.title.text) or None
            body: list[str] = []
            for shape in slide.shapes:
                if title and shape is slide.shapes.title:
                    continue
                text = _shape_text(shape)
                if text:
                    body.append(text)
            notes = ""
            if slide.has_notes_slide:
                notes = normalize_text(slide.notes_slide.notes_text_frame.text or "")
                if notes:
                    body.append(f"Speaker notes: {notes}")
            joined = "\n".join(body).strip()
            page_text = f"{title}\n{joined}".strip() if title else joined
            pages.append(Page(number=number, text=page_text))
            sections.append(
                Section(
                    key=f"s{len(sections)}",
                    title=title or f"Slide {number}",
                    level=1,
                    ordinal=len(sections),
                    page=number,
                    text=page_text,
                )
            )

        core = deck.core_properties
        return ParsedDocument(
            document_type=self.document_type,
            text="\n\n".join(f"[slide{p.number}]\n{p.text}" for p in pages if p.text),
            pages=pages,
            sections=sections,
            title=(core.title or "").strip() or None,
            authors=[a.strip() for a in (core.author or "").split(",") if a.strip()],
            metadata={
                "slides": len(slides),
                "layout": (core.subject or "").strip() or None,
            },
            page_count=len(pages),
        )
