"""Parser abstraction.

Every supported format produces the same :class:`ParsedDocument`:

* ``pages``    - page-like units (PDF pages, slides, sheets). Empty when the
                 format has no page concept.
* ``sections`` - a flat, ordered outline with a level per entry, derived from
                 real structure (headings, slides, sheets) rather than guessed
                 from text. The hierarchical chunker walks this.
* ``text``     - the flattened plain text, kept for whole-document summaries.

Adding a format means writing one module with a ``parse(path) -> ParsedDocument``
and registering it in :data:`PARSERS`. Nothing else in the codebase changes.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Protocol

from app.errors import ParseFailed


@dataclass
class Page:
    """One page-like unit of the source document."""

    number: int
    text: str = ""


@dataclass
class Section:
    """One structural unit (heading block, slide, sheet, form feed page)."""

    key: str                      # local key; the ingest service qualifies it
    title: str | None = None
    level: int = 1
    ordinal: int = 0
    page: int | None = None
    text: str = ""


@dataclass
class ParsedDocument:
    """Format-independent parse result."""

    document_type: str
    mime_type: str | None = None
    text: str = ""
    pages: list[Page] = field(default_factory=list)
    sections: list[Section] = field(default_factory=list)
    title: str | None = None
    authors: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    page_count: int | None = None

    @property
    def char_count(self) -> int:
        return len(self.text)

    def summary_source(self, limit: int) -> str:
        """Text for the document-level embedding: bounded, never the whole file."""
        head = self.text.strip()
        if len(head) <= limit:
            return head
        return head[:limit].rsplit(" ", 1)[0] + " ..."


class DocumentParser(Protocol):
    document_type: str

    def parse(self, path: str) -> ParsedDocument: ...


class ParserError(ParseFailed):
    """Alias so parser modules can catch the shared taxonomy entry point."""


#: document_type -> parser instance
PARSERS: dict[str, DocumentParser] = {}


def register(parser: DocumentParser) -> DocumentParser:
    PARSERS[parser.document_type] = parser
    return parser


# ----------------------------------------------------------------- utilities
_WS_RUN = re.compile(r"[ \t ]+")
_BLANK_RUN = re.compile(r"\n{3,}")


def normalize_text(text: str) -> str:
    """Collapse whitespace runs but keep paragraph breaks."""
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = _WS_RUN.sub(" ", text)
    return _BLANK_RUN.sub("\n\n", text).strip()


def read_text_file(path: str) -> str:
    """Read a text file without ever raising a decode error.

    Order: BOM sniffing, UTF-8 strict, UTF-16, then latin-1 (which cannot fail).
    Keystrokes stay searchable because nothing is replaced with U+FFFD.
    """
    raw = Path(path).read_bytes()
    if not raw:
        return ""
    if raw.startswith(b"\xef\xbb\xbf"):
        return raw.decode("utf-8-sig", errors="replace")
    if raw.startswith((b"\xff\xfe", b"\xfe\xff")):
        # Plain "utf-16" consumes the BOM it finds; the explicit endian codecs
        # would leave it in the text as U+FEFF.
        return raw.decode("utf-16", errors="replace")
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError:
        pass
    # BOM-less UTF-16 is the only remaining case worth trying: it needs a NUL in
    # every other byte. Without that check a short latin-1 file decodes into
    # mojibake, because "caf\xe9" is a perfectly valid 4-byte UTF-16 sequence.
    if b"\x00" in raw[:4096]:
        for encoding in ("utf-16-le", "utf-16-be"):
            try:
                return raw.decode(encoding)
            except UnicodeDecodeError:
                continue
    return raw.decode("latin-1")


def split_lines(text: str) -> list[str]:
    """Non-empty, whitespace-trimmed lines."""
    return [stripped for line in text.split("\n") if (stripped := line.strip())]


def is_heading(line: str) -> tuple[bool, int, str]:
    """Detect an ATX-style heading: ``## Title`` -> (True, 2, "Title")."""
    match = re.match(r"^(#{1,6})\s+(.*\S)\s*$", line)
    if match:
        return True, len(match.group(1)), match.group(2)
    # Setext style: a short line followed by === or ---
    return False, 0, ""


def build_sections_from_blocks(blocks: list[dict[str, Any]]) -> list[Section]:
    """Group heading/paragraph blocks into outline sections.

    ``blocks`` items: ``{"text", "level", "title", "page", "kind"}``. A heading
    opens a section; everything after it belongs to that section until the next
    heading of the same or a higher level. Content before the first heading
    becomes an untitled level-0 section so no text is ever dropped.
    """
    sections: list[Section] = []
    current: Section | None = None
    preamble: list[str] = []
    preamble_page: int | None = None

    def flush_preamble() -> None:
        nonlocal preamble, preamble_page, current
        if preamble:
            body = "\n".join(preamble).strip()
            if body:
                sections.append(
                    Section(
                        key=f"s{len(sections)}",
                        title=None,
                        level=0,
                        ordinal=len(sections),
                        page=preamble_page,
                        text=body,
                    )
                )
            preamble = []
            preamble_page = None
        current = None

    for block in blocks:
        text = (block.get("text") or "").strip()
        if not text:
            continue
        level = int(block.get("level") or 0)
        page = block.get("page")
        if level > 0 and block.get("kind") in (None, "heading", "slide", "sheet"):
            flush_preamble()
            current = Section(
                key=f"s{len(sections)}",
                title=block.get("title") or text,
                level=level,
                ordinal=len(sections),
                page=page,
                text=text,
            )
            sections.append(current)
            continue
        if current is None:
            if not preamble and page is not None:
                preamble_page = page
            preamble.append(text)
        else:
            if current.page is None and page is not None:
                current.page = page
            current.text += "\n" + text
    flush_preamble()
    for index, section in enumerate(sections):
        section.ordinal = index
    return sections


def sections_to_text(sections: list[Section]) -> str:
    parts: list[str] = []
    for section in sections:
        if section.title and section.text.startswith(section.title):
            parts.append(section.text)
        else:
            parts.append(f"{section.title}\n{section.text}" if section.title else section.text)
    return "\n\n".join(p for p in parts if p.strip())
