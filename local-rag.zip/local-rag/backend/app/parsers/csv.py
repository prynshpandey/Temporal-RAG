"""CSV/TSV parser: header-aware rows, delimiter sniffed, row capped."""

from __future__ import annotations

import csv as _csv
import io

from app.errors import NoTextLayer
from app.parsers.base import Page, ParsedDocument, Section, read_text_file, normalize_text


class CsvParser:
    document_type = "csv"

    def __init__(self, max_rows: int = 20000, max_delimiter_scan: int = 64 * 1024) -> None:
        self.max_rows = max_rows
        self.max_delimiter_scan = max_delimiter_scan

    def parse(self, path: str) -> ParsedDocument:
        raw = read_text_file(path)
        if not raw.strip():
            raise NoTextLayer()

        sample = raw[: self.max_delimiter_scan]
        try:
            dialect = _csv.Sniffer().sniff(sample, delimiters=",;\t|")
        except _csv.Error:
            dialect = _csv.excel_tab if "\t" in sample else _csv.excel

        reader = _csv.reader(io.StringIO(raw), dialect)
        rows: list[list[str]] = []
        for index, row in enumerate(reader):
            if index > self.max_rows:
                rows.append([f"... (row limit {self.max_rows} reached)"])
                break
            rows.append([normalize_text(cell) for cell in row])
        if not rows:
            raise NoTextLayer()

        header = rows[0]
        has_header = bool(header) and sum(1 for c in header if c) >= 2 and not all(
            c.replace(".", "").replace("-", "").isdigit() for c in header if c
        )
        lines: list[str] = []
        if has_header:
            lines.append("Columns: " + " | ".join(c for c in header if c))
        for row in rows[1:] if has_header else rows:
            if has_header and any(header):
                pairs = [f"{name}: {value}" for name, value in zip(header, row) if name and value]
                if pairs:
                    lines.append("; ".join(pairs))
                    continue
            line = " | ".join(c for c in row if c)
            if line:
                lines.append(line)
        if not lines:
            raise NoTextLayer()

        body = "\n".join(lines)
        title = " | ".join(c for c in header if c) if has_header else None
        section = Section(key="s0", title=title, level=1, ordinal=0, page=1, text=body)
        return ParsedDocument(
            document_type=self.document_type,
            text=body,
            pages=[Page(number=1, text=body)],
            sections=[section],
            title=title,
            authors=[],
            metadata={
                "rows": len(rows),
                "columns": len(header),
                "delimiter": dialect.delimiter,
            },
            page_count=1,
        )
