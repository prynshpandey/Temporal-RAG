"""Format detection plus the parse entrypoint used by the ingest pipeline.

``parse_upload`` is the only function the API needs: it enforces the size limit,
detects the real type from the bytes, dispatches to the right parser and
guarantees a non-empty result (or raises a structured error).
"""

from __future__ import annotations

import logging
import os
import time

from app.errors import EmptyUpload, FileTooLarge, ParseFailed
from app.parsers.base import Page, ParsedDocument, Section, ParserError
from app.parsers.detect import (
    MIME_TYPES,
    SUPPORTED,
    UnsupportedFileType,
    UnsafeArchive,
    detect_document_type,
    sanitize_filename,
)
from app.parsers.csv import CsvParser
from app.parsers.docx import DocxParser
from app.parsers.html import HtmlParser
from app.parsers.json_data import JsonParser
from app.parsers.pdf import PdfParser
from app.parsers.pptx import PptxParser
from app.parsers.text import MarkdownParser, TxtParser
from app.parsers.xlsx import XlsxParser

log = logging.getLogger(__name__)

_PARSER_INSTANCES = [
    PdfParser(),
    DocxParser(),
    PptxParser(),
    XlsxParser(),
    CsvParser(),
    TxtParser(),
    MarkdownParser(),
    HtmlParser(),
    JsonParser(),
]

PARSERS: dict[str, object] = {p.document_type: p for p in _PARSER_INSTANCES}

__all__ = [
    "MIME_TYPES",
    "Page",
    "PARSERS",
    "ParserError",
    "ParsedDocument",
    "SUPPORTED",
    "Section",
    "UnsupportedFileType",
    "UnsafeArchive",
    "detect_document_type",
    "parse_upload",
    "sanitize_filename",
]


def parse_upload(
    path: str,
    filename: str | None = None,
    content_type: str | None = None,
    *,
    max_bytes: int,
    max_sections: int = 5000,
    max_zip_entries: int = 4000,
    max_uncompressed_mb: int = 400,
) -> ParsedDocument:
    """Parse one stored upload into a :class:`ParsedDocument`."""
    if not os.path.isfile(path):
        raise EmptyUpload("The uploaded file is missing on disk.")

    size = os.path.getsize(path)
    if size == 0:
        raise EmptyUpload()
    if size > max_bytes:
        raise FileTooLarge(
            f"The upload is {size / (1024 * 1024):.1f} MB; the limit is "
            f"{max_bytes / (1024 * 1024):.0f} MB.",
            details={"bytes": size, "max_bytes": max_bytes},
        )

    document_type, mime = detect_document_type(
        path,
        filename,
        content_type,
        max_entries=max_zip_entries,
        max_uncompressed_mb=max_uncompressed_mb,
    )
    parser = PARSERS.get(document_type)
    if parser is None:  # pragma: no cover - detection and PARSERS are in sync
        raise UnsupportedFileType(f"No parser is registered for {document_type}.")

    started = time.perf_counter()
    try:
        document = parser.parse(path)
    except ParserError:
        raise
    except (UnsupportedFileType, UnsafeArchive):
        raise
    except MemoryError as exc:  # pragma: no cover - resource guard
        raise ParseFailed("The file needs more memory than the parser is allowed to use.") from exc
    except Exception as exc:
        log.exception("parser %s failed for %s", document_type, filename)
        raise ParseFailed(
            f"The {document_type.upper()} parser failed: {exc}",
            details={"document_type": document_type},
        ) from exc

    if not document.text.strip():
        from app.errors import NoTextLayer

        raise NoTextLayer()

    document.mime_type = mime
    if len(document.sections) > max_sections:
        log.warning(
            "trimming %d sections down to %d for %s",
            len(document.sections),
            max_sections,
            filename,
        )
        document.sections = document.sections[:max_sections]
        document.metadata["sections_truncated"] = True

    document.metadata.setdefault("bytes", size)
    document.metadata["parse_ms"] = int((time.perf_counter() - started) * 1000)
    document.metadata["filename"] = sanitize_filename(filename)
    log.info(
        "parsed %s as %s: %d chars, %d sections, %d pages in %d ms",
        filename,
        document_type,
        document.char_count,
        len(document.sections),
        document.page_count or 0,
        document.metadata["parse_ms"],
    )
    return document
