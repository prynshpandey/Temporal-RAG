"""XLSX parser (openpyxl, read-only): one section per sheet.

Rows are rendered as ``header: value`` pairs when a header row is present, and
as ``a | b | c`` otherwise. Read-only mode keeps memory flat, and the row cap
stops a spreadsheet of a million blank rows from becoming a denial of service.
"""

from __future__ import annotations

from openpyxl import load_workbook
from openpyxl.utils.exceptions import InvalidFileException

from app.errors import CorruptDocument, NoTextLayer
from app.parsers.base import Page, ParsedDocument, Section, normalize_text


def _cell(value) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return normalize_text(value)
    if isinstance(value, bool):
        return "true" if value else "false"
    return str(value)


class XlsxParser:
    document_type = "xlsx"

    def __init__(self, max_rows_per_sheet: int = 20000, max_cols: int = 64) -> None:
        self.max_rows_per_sheet = max_rows_per_sheet
        self.max_cols = max_cols

    def parse(self, path: str) -> ParsedDocument:
        try:
            workbook = load_workbook(path, read_only=True, data_only=True)
        except (InvalidFileException, KeyError, ValueError, OSError) as exc:
            raise CorruptDocument(f"openpyxl could not open the workbook: {exc}") from exc

        pages: list[Page] = []
        sections: list[Section] = []
        try:
            for sheet in workbook.worksheets:
                rows = sheet.iter_rows(
                    max_row=min(sheet.max_row or 0, self.max_rows_per_sheet) or None,
                    max_col=self.max_cols,
                    values_only=True,
                )
                header: list[str] | None = None
                lines: list[str] = []
                truncated = False
                for position, row in enumerate(rows, start=1):
                    cells = [_cell(v) for v in row]
                    if not any(cells):
                        continue
                    if position > self.max_rows_per_sheet:
                        truncated = True
                        break
                    if header is None and position <= 5 and any(
                        cell and not cell.replace(".", "").replace("-", "").isdigit()
                        for cell in cells
                    ):
                        header = cells
                        lines.append("Columns: " + " | ".join(c for c in cells if c))
                        continue
                    if header and any(header):
                        pairs = [
                            f"{name}: {value}"
                            for name, value in zip(header, cells)
                            if name and value
                        ]
                        lines.append("; ".join(pairs) or " | ".join(c for c in cells if c))
                    else:
                        lines.append(" | ".join(c for c in cells if c))
                if truncated:
                    lines.append(f"... (row limit {self.max_rows_per_sheet} reached)")
                if not lines:
                    continue
                body = "\n".join(lines)
                pages.append(Page(number=len(pages) + 1, text=body))
                sections.append(
                    Section(
                        key=f"s{len(sections)}",
                        title=sheet.title,
                        level=1,
                        ordinal=len(sections),
                        page=len(pages),
                        text=body,
                    )
                )
        finally:
            workbook.close()

        if not sections:
            raise NoTextLayer()

        return ParsedDocument(
            document_type=self.document_type,
            text="\n\n".join(f"[sheet:{p.number}] {s.title}\n{p.text}" for p, s in zip(pages, sections)),
            pages=pages,
            sections=sections,
            title=next((s.title for s in sections), None),
            authors=[],
            metadata={"sheets": len(sections)},
            page_count=len(pages),
        )
