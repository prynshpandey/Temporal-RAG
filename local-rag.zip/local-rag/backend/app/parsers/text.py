"""Plain-text and Markdown parsers.

TXT: form feeds become pages, blank-line-separated blocks become sections.
MD: ATX and setext headings drive the outline, fenced code is preserved verbatim.
"""

from __future__ import annotations

import re

from app.errors import NoTextLayer
from app.parsers.base import (
    Page,
    ParsedDocument,
    Section,
    build_sections_from_blocks,
    is_heading,
    normalize_text,
    read_text_file,
    sections_to_text,
    split_lines,
)

_FENCE = re.compile(r"^\s*(```|~~~)")


class TxtParser:
    document_type = "txt"

    def parse(self, path: str) -> ParsedDocument:
        raw = read_text_file(path)
        text = normalize_text(raw)
        if not text:
            raise NoTextLayer()

        chunks = [normalize_text(part) for part in re.split(r"\f", raw)]
        pages = [Page(number=i, text=t) for i, t in enumerate(chunks, start=1) if t.strip()]
        if not pages:
            pages = [Page(number=1, text=text)]

        blocks: list[dict] = []
        for page in pages:
            for block in re.split(r"\n\s*\n", page.text):
                block = block.strip()
                if not block:
                    continue
                heading, level, title = is_heading(split_lines(block)[0])
                blocks.append(
                    {
                        "text": block,
                        "level": level if heading else 1,
                        "title": title if heading else None,
                        "kind": "heading" if heading else "text",
                        "page": page.number,
                    }
                )
        sections = build_sections_from_blocks(blocks)
        if not sections:
            sections = [Section(key="s0", title=None, level=0, ordinal=0, page=1, text=text)]
        return ParsedDocument(
            document_type=self.document_type,
            text=text,
            pages=pages,
            sections=sections,
            title=sections[0].title,
            authors=[],
            metadata={"pages": len(pages)},
            page_count=len(pages),
        )


class MarkdownParser:
    document_type = "md"

    def parse(self, path: str) -> ParsedDocument:
        raw = read_text_file(path)
        if not raw.strip():
            raise NoTextLayer()

        lines = raw.replace("\r\n", "\n").split("\n")
        blocks: list[dict] = []
        buffer: list[str] = []
        buffer_fence = False
        buffer_start = 0
        fence_marker = ""

        def flush() -> None:
            nonlocal buffer
            if not buffer:
                return
            body = "\n".join(buffer).strip()
            if body:
                blocks.append(
                    {"text": body, "level": 0, "title": None, "kind": "code" if buffer_fence else "text"}
                )
            buffer = []

        for number, line in enumerate(lines):
            fence = _FENCE.match(line)
            if fence:
                if not buffer:
                    buffer_fence = True
                    buffer_start = number
                flush()
                buffer_fence = not buffer_fence
                continue
            if buffer_fence:
                buffer.append(line)
                continue

            stripped = line.rstrip()
            if not stripped.strip():
                flush()
                continue

            atx = re.match(r"^(#{1,6})\s+(.*\S)\s*$", stripped)
            setext_next = number + 1 < len(lines) and re.match(
                r"^\s*(=+|-{3,})\s*$", lines[number + 1]
            )
            if atx:
                flush()
                blocks.append(
                    {
                        "text": atx.group(2),
                        "level": len(atx.group(1)),
                        "title": atx.group(2),
                        "kind": "heading",
                    }
                )
                continue
            if setext_next and stripped.strip():
                level = 1 if lines[number + 1].strip()[0] == "=" else 2
                flush()
                blocks.append(
                    {"text": stripped.strip(), "level": level, "title": stripped.strip(), "kind": "heading"}
                )
                continue
            if not buffer:
                buffer_start = number
            buffer.append(stripped)
        flush()

        if not blocks:
            raise NoTextLayer()

        # A document that is one giant code block still needs one section.
        sections = build_sections_from_blocks(blocks)
        if not sections:
            sections = [Section(key="s0", title=None, level=0, ordinal=0, text=raw.strip())]
        return ParsedDocument(
            document_type=self.document_type,
            text=normalize_text(raw),
            pages=[Page(number=1, text=normalize_text(raw))],
            sections=sections,
            title=sections[0].title,
            authors=[],
            metadata={
                "headings": sum(1 for b in blocks if b["kind"] == "heading"),
                "code_blocks": sum(1 for b in blocks if b["kind"] == "code"),
            },
            page_count=None,
        )
