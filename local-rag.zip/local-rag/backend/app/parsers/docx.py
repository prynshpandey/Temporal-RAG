"""DOCX parser (python-docx): real heading levels, tables kept as text.

Body children are walked in document order so a paragraph, a table and a heading
keep their relative positions - ``document.paragraphs`` alone would drop tables.
"""

from __future__ import annotations

import re

from docx import Document
from docx.opc.exceptions import PackageNotFoundError

from app.errors import CorruptDocument, NoTextLayer
from app.parsers.base import (
    Page,
    ParsedDocument,
    Section,
    build_sections_from_blocks,
    normalize_text,
    sections_to_text,
)

_HEADING_STYLE = re.compile(r"^heading\s*(\d+)$", re.IGNORECASE)
_TITLE_STYLES = {"title": 1, "subtitle": 2}


def _table_to_text(table, max_rows: int = 2000) -> str:
    rows: list[str] = []
    for index, row in enumerate(table.rows):
        if index >= max_rows:
            rows.append(f"... ({len(table.rows) - max_rows} more rows)")
            break
        cells = [normalize_text(cell.text).replace("\n", " ") for cell in row.cells]
        if any(cells):
            rows.append(" | ".join(cells))
    return "\n".join(rows)


class DocxParser:
    document_type = "docx"

    def __init__(self, max_blocks: int = 20000) -> None:
        self.max_blocks = max_blocks

    def parse(self, path: str) -> ParsedDocument:
        try:
            document = Document(path)
        except (PackageNotFoundError, KeyError, ValueError) as exc:
            raise CorruptDocument(f"python-docx could not open the file: {exc}") from exc

        blocks: list[dict] = []
        tables = 0
        for child in document.element.body.iterchildren():
            tag = child.tag.split("}")[-1]
            if tag == "p" and len(blocks) < self.max_blocks:
                paragraph = next(
                    (p for p in document.paragraphs if p._p is child), None
                )
                if paragraph is None:
                    continue
                text = normalize_text(paragraph.text)
                if not text:
                    continue
                style = (paragraph.style.name or "").strip() if paragraph.style else ""
                level = 0
                heading_match = _HEADING_STYLE.match(style)
                if heading_match:
                    level = int(heading_match.group(1))
                elif style.lower() in _TITLE_STYLES:
                    level = _TITLE_STYLES[style.lower()]
                blocks.append(
                    {
                        "text": text,
                        "level": level,
                        "title": text if level else None,
                        "kind": "heading" if level else "text",
                    }
                )
            elif tag == "tbl" and len(blocks) < self.max_blocks:
                table = next((t for t in document.tables if t._tbl is child), None)
                if table is None:
                    continue
                text = _table_to_text(table)
                if text:
                    tables += 1
                    blocks.append({"text": text, "level": 0, "title": None, "kind": "table"})

        if not blocks:
            raise NoTextLayer()

        sections = build_sections_from_blocks(blocks)
        core = document.core_properties
        return ParsedDocument(
            document_type=self.document_type,
            text=sections_to_text(sections),
            pages=[Page(number=1, text=sections_to_text(sections))],
            sections=sections,
            title=(core.title or "").strip() or None,
            authors=[a.strip() for a in (core.author or "").split(",") if a.strip()],
            metadata={
                "tables": tables,
                "paragraphs": len(document.paragraphs),
                "created": core.created.isoformat() if core.created else None,
                "modified": core.modified.isoformat() if core.modified else None,
            },
            page_count=None,
        )
