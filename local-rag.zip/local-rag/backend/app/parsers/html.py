"""HTML parser (BeautifulSoup): scripts removed, headings kept as the outline."""

from __future__ import annotations

import re

from bs4 import BeautifulSoup

from app.errors import NoTextLayer
from app.parsers.base import (
    Page,
    ParsedDocument,
    Section,
    build_sections_from_blocks,
    normalize_text,
    read_text_file,
    sections_to_text,
)

_DROP_TAGS = ("script", "style", "noscript", "template", "svg", "iframe", "head")
_WS = re.compile(r"[ \t]+")


def _collapse(text: str) -> str:
    return normalize_text(_WS.sub(" ", text.replace("\xa0", " ")))


class HtmlParser:
    document_type = "html"

    def __init__(self, max_blocks: int = 20000) -> None:
        self.max_blocks = max_blocks

    def parse(self, path: str) -> ParsedDocument:
        raw = read_text_file(path)
        if not raw.strip():
            raise NoTextLayer()

        soup = BeautifulSoup(raw, "html.parser")
        for tag in soup.find_all(_DROP_TAGS):
            tag.decompose()

        title_tag = soup.find("title") or soup.find("h1")
        title = _collapse(title_tag.get_text(" ")).strip() if title_tag else None

        blocks: list[dict] = []
        for tag in soup.find_all(
            ["h1", "h2", "h3", "h4", "h5", "h6", "p", "li", "pre", "blockquote", "table"]
        ):
            if len(blocks) >= self.max_blocks:
                break
            if tag.name == "table":
                text = self._table(tag)
                if text:
                    blocks.append({"text": text, "level": 0, "title": None, "kind": "table"})
                continue
            text = _collapse(tag.get_text(" "))
            if not text or len(text) < 2:
                continue
            if tag.name in ("h1", "h2", "h3", "h4", "h5", "h6"):
                level = int(tag.name[1])
                blocks.append({"text": text, "level": level, "title": text, "kind": "heading"})
            else:
                blocks.append(
                    {
                        "text": text,
                        "level": 0,
                        "title": None,
                        "kind": "list_item" if tag.name == "li" else "text",
                    }
                )

        if not blocks:
            body = _collapse(soup.get_text(" "))
            if not body:
                raise NoTextLayer()
            blocks = [{"text": body, "level": 0, "title": None, "kind": "text"}]

        sections = build_sections_from_blocks(blocks)
        return ParsedDocument(
            document_type=self.document_type,
            text=sections_to_text(sections),
            pages=[Page(number=1, text=sections_to_text(sections))],
            sections=sections,
            title=title or (sections[0].title if sections else None),
            authors=[],
            metadata={"headings": sum(1 for b in blocks if b["kind"] == "heading")},
            page_count=None,
        )

    def _table(self, table) -> str:
        rows: list[str] = []
        for row in table.find_all("tr")[:500]:
            cells = [_collapse(c.get_text(" ")) for c in row.find_all(["td", "th"])]
            if any(cells):
                rows.append(" | ".join(c for c in cells if c))
        return "\n".join(rows)
