"""JSON parser: walks the document into ``path: value`` lines.

Depth and width are capped so a deeply nested or enormous payload cannot blow up
the section list; truncation is recorded in the metadata rather than hidden.
"""

from __future__ import annotations

import json
from typing import Any

from app.errors import CorruptDocument, NoTextLayer
from app.parsers.base import Page, ParsedDocument, Section, normalize_text

MAX_DEPTH = 12
MAX_CHILDREN = 200
MAX_LINES = 5000


def _scalar(value: Any) -> str:
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return str(value)
    return normalize_text(str(value))


class JsonParser:
    document_type = "json"

    def __init__(self, max_bytes: int = 32 * 1024 * 1024) -> None:
        self.max_bytes = max_bytes

    def parse(self, path: str) -> ParsedDocument:
        from pathlib import Path

        raw_bytes = Path(path).read_bytes()
        if not raw_bytes.strip():
            raise NoTextLayer()
        if len(raw_bytes) > self.max_bytes:
            raise CorruptDocument(
                f"The JSON file is {len(raw_bytes) // (1024 * 1024)} MB; "
                f"the limit is {self.max_bytes // (1024 * 1024)} MB."
            )
        try:
            data = json.loads(raw_bytes.decode("utf-8", errors="replace"))
        except json.JSONDecodeError as exc:
            raise CorruptDocument(
                f"The file is not valid JSON: {exc.msg} (line {exc.lineno}, column {exc.colno})."
            ) from exc

        sections: list[Section] = []
        truncated = False

        def emit(path_label: str, value: Any, level: int) -> None:
            nonlocal truncated
            if len(sections) >= MAX_LINES:
                truncated = True
                return
            if isinstance(value, dict):
                if not value:
                    sections.append(Section(key=f"s{len(sections)}", title=path_label, level=level,
                                            ordinal=len(sections), text=f"{path_label}: {{}}"))
                    return
                header = f"{path_label}: object with {len(value)} keys"
                body = [header]
                for index, (key, child) in enumerate(value.items()):
                    if index >= MAX_CHILDREN:
                        body.append(f"... ({len(value) - MAX_CHILDREN} more keys)")
                        break
                    label = f"{path_label}.{key}" if path_label else str(key)
                    if isinstance(child, (dict, list)) and level < MAX_DEPTH:
                        emit(label, child, level + 1)
                    else:
                        body.append(f"{label}: {_scalar(child)}")
                sections.append(
                    Section(key=f"s{len(sections)}", title=path_label, level=level,
                            ordinal=len(sections), text="\n".join(body))
                )
                return
            if isinstance(value, list):
                body = [f"{path_label}: array with {len(value)} items"]
                for index, child in enumerate(value):
                    if index >= MAX_CHILDREN:
                        body.append(f"... ({len(value) - MAX_CHILDREN} more items)")
                        break
                    label = f"{path_label}[{index}]"
                    if isinstance(child, (dict, list)) and level < MAX_DEPTH:
                        emit(label, child, level + 1)
                    else:
                        body.append(f"{label}: {_scalar(child)}")
                sections.append(
                    Section(key=f"s{len(sections)}", title=path_label, level=level,
                            ordinal=len(sections), text="\n".join(body))
                )
                return
            sections.append(
                Section(key=f"s{len(sections)}", title=path_label, level=level,
                        ordinal=len(sections), text=f"{path_label}: {_scalar(value)}")
            )

        emit("", data, 1)

        # A single scalar document has no outline worth keeping.
        if not sections:
            raise NoTextLayer()
        if len(sections) == 1 and sections[0].level == 1 and "\n" not in sections[0].text:
            sections = [
                Section(key="s0", title="document", level=0, ordinal=0, text=sections[0].text)
            ]

        text = "\n\n".join(s.text for s in sections)
        return ParsedDocument(
            document_type=self.document_type,
            text=text,
            pages=[Page(number=1, text=text)],
            sections=sections,
            title=None,
            authors=[],
            metadata={
                "root_type": type(data).__name__,
                "sections": len(sections),
                "truncated": truncated,
            },
            page_count=None,
        )
