"""Business Time Machine backend package."""

__version__ = "1.0.0"
