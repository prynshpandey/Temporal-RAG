"""Change detection: what counts as a change, and what counts as a contradiction.

The distinction under test is the one that makes a time machine trustworthy. A
revenue figure that differs between the 2023 and 2025 reports is not a conflict -
it is the whole reason the corpus exists. Two documents that were valid at the
same moment and still disagree is a genuine contradiction, and presenting one of
those values as settled history would be a lie with a timestamp on it.
"""

from __future__ import annotations

from datetime import date

from app.services import compare as compare_service
from app.services import facts as facts_service
from app.services import state as state_service


def _fact(label: str, value: float, unit: str, when: date | None, doc: str = "d") -> facts_service.Fact:
    return facts_service.Fact(
        label=label,
        value=value,
        unit=unit,
        kind="level",
        sentence=f"{label} was {value}.",
        document_id=doc,
        document_name=f"{doc}.md",
        chunk_id=f"{doc}-c",
        effective_date=when,
        confidence=0.9,
    )


def _window(as_of: date, values: list[facts_service.Fact]) -> compare_service.Window:
    return compare_service.Window(
        as_of=as_of,
        snapshot=state_service.State(as_of=as_of),
        metrics=facts_service.index_by_metric(values),
    )


def test_the_same_metric_in_different_years_is_not_a_conflict() -> int:
    window = _window(
        date(2025, 12, 31),
        [
            _fact("revenue", 41.2, "million_currency", date(2023, 12, 31), "a"),
            _fact("revenue", 48.9, "million_currency", date(2024, 12, 31), "b"),
            _fact("revenue", 57.4, "million_currency", date(2025, 6, 30), "c"),
        ],
    )
    assert compare_service._conflicts(window) == []
    return 1


def test_two_documents_valid_at_the_same_moment_do_conflict() -> int:
    window = _window(
        date(2025, 12, 31),
        [
            _fact("revenue", 48.9, "million_currency", date(2024, 12, 31), "a"),
            _fact("revenue", 44.1, "million_currency", date(2024, 12, 20), "b"),
        ],
    )
    conflicts = compare_service._conflicts(window)
    assert len(conflicts) == 1, conflicts
    entry = conflicts[0]
    assert entry["label"] == "revenue", entry
    assert entry["value_count"] == 2, entry
    assert {s["value"] for s in entry["statements"]} == {48.9, 44.1}
    # The most recent statement is the one a reader would have believed.
    assert entry["resolved_value"]["value"] == 48.9, entry["resolved_value"]
    return 1


def test_a_conflict_is_reported_at_the_edge_of_the_window() -> int:
    inside = _window(
        date(2025, 1, 1),
        [
            _fact("revenue", 10.0, "million_currency", date(2024, 12, 31), "a"),
            _fact("revenue", 11.0, "million_currency", date(2024, 12, 1), "b"),
        ],
    )
    outside = _window(
        date(2025, 1, 1),
        [
            _fact("revenue", 10.0, "million_currency", date(2024, 12, 31), "a"),
            _fact("revenue", 11.0, "million_currency", date(2024, 11, 1), "b"),
        ],
    )
    assert len(compare_service._conflicts(inside)) == 1, "30 days apart is still contemporaneous"
    assert compare_service._conflicts(outside) == [], "60 days apart is a revision, not a conflict"
    return 1


def test_agreement_is_not_a_conflict() -> int:
    window = _window(
        date(2025, 1, 1),
        [
            _fact("revenue", 10.0, "million_currency", date(2024, 12, 31), "a"),
            _fact("revenue", 10.0, "million_currency", date(2024, 12, 1), "b"),
        ],
    )
    assert compare_service._conflicts(window) == []
    return 1


def test_different_units_are_never_compared() -> int:
    """"31 percent of revenue" and "31 million euro" share a number, not a meaning."""
    window = _window(
        date(2025, 1, 1),
        [
            _fact("revenue", 31.0, "percent", date(2024, 12, 31), "a"),
            _fact("revenue", 31.0, "million_currency", date(2024, 12, 1), "b"),
        ],
    )
    assert compare_service._conflicts(window) == []
    return 1


def test_undated_statements_are_only_compared_with_undated_ones() -> int:
    """"Assuming" two undated documents are contemporaneous would invent conflicts."""
    dated = _window(
        date(2025, 1, 1),
        [
            _fact("headcount", 465.0, "headcount", None, "a"),
            _fact("headcount", 511.0, "headcount", date(2024, 12, 31), "b"),
        ],
    )
    both_undated = _window(
        date(2025, 1, 1),
        [
            _fact("headcount", 465.0, "headcount", None, "a"),
            _fact("headcount", 511.0, "headcount", None, "b"),
        ],
    )
    assert compare_service._conflicts(dated) == [], "a dated/undated pair is not a contradiction"
    assert len(compare_service._conflicts(both_undated)) == 1, "two undated disagreements are"
    return 1


def test_a_value_at_a_date_is_the_most_recent_statement() -> int:
    values = [
        _fact("revenue", 41.2, "million_currency", date(2023, 12, 31), "a"),
        _fact("revenue", 48.9, "million_currency", date(2024, 12, 31), "b"),
        _fact("revenue", 57.4, "million_currency", date(2025, 6, 30), "c"),
    ]
    window = _window(date(2025, 12, 31), values)
    assert window.current("revenue|million_currency").value == 57.4
    return 1


def test_a_metric_missing_from_a_window_has_no_current_value() -> int:
    window = _window(date(2025, 12, 31), [])
    assert window.current("revenue|million_currency") is None
    return 1


def test_direction_and_percentage_are_reported() -> int:
    assert compare_service._delta(10.0, 12.5)[:2] == ("increased", 25.0)
    assert compare_service._delta(4.1, 3.2)[:2] == ("decreased", -22.0)
    assert compare_service._delta(5.0, 5.0)[:2] == ("unchanged", 0.0)
    # A change from zero has no meaningful percentage; reporting one would be a
    # division by zero dressed as insight.
    assert compare_service._delta(0.0, 7.0)[1] is None
    return 1


def test_values_render_with_their_unit() -> int:
    assert compare_service._format_value(4.1, "percent") == "4.1%"
    assert compare_service._format_value(41.2, "million_currency") == "41.2M"
    assert compare_service._format_value(465, "headcount") == "465 people"
    return 1


def test_a_family_advance_is_reported_when_the_current_version_changes() -> int:
    def family(document_id: str, name: str, when: date) -> dict:
        return {
            "key": "helios",
            "current_version": document_id,
            "versions": [{"document_id": document_id, "name": name, "effective_date": when, "in_scope": True}],
        }

    before = compare_service.Window(
        as_of=date(2023, 12, 31),
        snapshot=state_service.State(as_of=date(2023, 12, 31), families=[family("d23", "ar2023.md", date(2023, 12, 31))]),
    )
    after = compare_service.Window(
        as_of=date(2025, 12, 31),
        snapshot=state_service.State(as_of=date(2025, 12, 31), families=[family("d25", "ar2025.md", date(2025, 6, 30))]),
    )
    rows = compare_service._family_changes(before, after)
    assert len(rows) == 1 and rows[0]["status"] == "revised", rows
    assert rows[0]["from_version"]["document_id"] == "d23", rows
    assert rows[0]["to_version"]["document_id"] == "d25", rows
    return 1
