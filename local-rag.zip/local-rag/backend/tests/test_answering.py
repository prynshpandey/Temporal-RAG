"""Answer-synthesis rules that must hold whether or not a model was reachable.

These are the parts that decide whether an answer is trustworthy, and none of
them need a network call: citation validation, the no-context path, and the
extractive fallback. The live behaviour is covered by ``make test-answer``.
"""

from __future__ import annotations

from datetime import date

from app.services import answering, retrieval


def _hit(number: int, name: str = "doc.md", day: str = "2024-06-30") -> retrieval.Hit:
    return retrieval.Hit(
        chunk_id=f"chunk-{number}",
        document_id=f"doc-{number}",
        document_name=name,
        text=f"Revenue for FY2024 reached {number}.0 million euro.",
        parent_text=f"Annual Report 2024 > 1. Financial summary\nRevenue for FY2024 reached {number}.0 million euro.",
        effective_date=date.fromisoformat(day),
        page=1,
    )


def test_citations_inside_the_retrieved_set_are_kept() -> int:
    hits = [_hit(1), _hit(2), _hit(3)]
    citations, rejected, _ = answering._validate_citations([1, 3], hits)
    assert [c.number for c in citations] == [1, 3], [c.number for c in citations]
    assert rejected == [], rejected
    assert citations[0].document_name == "doc.md"
    return 1


def test_invented_citations_are_rejected_not_passed_through() -> int:
    """A model citing [7] out of three passages has invented a source."""
    hits = [_hit(1), _hit(2), _hit(3)]
    citations, rejected, _ = answering._validate_citations([1, 7, 9, 0, -3], hits)
    assert [c.number for c in citations] == [1], [c.number for c in citations]
    assert sorted(rejected) == [-3, 0, 7, 9], rejected
    return 1


def test_citation_markers_in_the_text_are_also_collected() -> int:
    """Some models return the markers inline instead of in the citations list."""
    hits = [_hit(1), _hit(2)]
    citations, rejected, _ = answering._validate_citations("Revenue rose [2] in FY2024.", hits)
    assert [c.number for c in citations] == [2], [c.number for c in citations]
    assert rejected == []
    return 1


def test_string_and_float_citations_are_coerced_or_refused() -> int:
    hits = [_hit(1), _hit(2)]
    citations, rejected, _ = answering._validate_citations(["2", 1.0 if False else 1, "x", 2.7], hits)
    assert sorted(c.number for c in citations) == [1, 2], [c.number for c in citations]
    assert 3 not in [c.number for c in citations]
    return 1


def test_an_answer_with_no_citations_is_marked_unsupported() -> int:
    result = answering.Answer(text="They made 99 million.", mode="generated", supported=True)
    assert not result.citations
    result.supported = False
    assert result.supported is False
    return 1


def test_no_context_says_so_instead_of_guessing() -> int:
    result = answering._no_context(date(2023, 12, 31), "What was revenue in 2025?")
    assert result.mode == "no_context"
    assert result.supported is False
    assert result.citations == []
    assert "2023-12-31" in result.text
    return 1


def test_extractive_quotes_verbatim_and_numbers_its_passages() -> int:
    hits = [_hit(1), _hit(2), _hit(3), _hit(4)]
    result = answering._extractive(hits, date(2024, 12, 31), reason="model unavailable")
    assert result.mode == "extractive"
    assert len(result.citations) == 3, len(result.citations)
    for citation in result.citations:
        # A quotation cannot misstate a number: it must appear character for
        # character in the passage it claims to come from.
        assert citation.quote in hits[citation.number - 1].text, citation.number
    return 1


def test_extractive_says_which_date_the_knowledge_is_from() -> int:
    result = answering._extractive([_hit(1)], date(2023, 6, 30), reason="x")
    assert "2023-06-30" in result.text, result.text[:120]
    return 1


def test_quote_trims_on_a_sentence_boundary() -> int:
    hit = _hit(1)
    hit.text = ("Sentence one is here. " * 40).strip()
    quote = answering._quote(hit, 100)
    assert len(quote) <= 110, len(quote)
    assert quote.endswith("…"), quote[-20:]
    return 1


def test_context_is_budgeted_by_whole_passages() -> int:
    hits = [_hit(i) for i in range(1, 6)]
    context = answering._build_context(hits, date(2024, 6, 30))
    assert context.count("[1]") == 1
    # Every passage is labelled with its document and effective date, so the
    # model can tell a 2023 claim from a 2025 one.
    assert "effective 2024-06-30" in context
    return 1


# ------------------------------------------------------------- degradation text
def test_a_provider_error_is_quoted_cleanly() -> int:
    """The JSON envelope is noise; the message inside it is a whole sentence."""
    raw = (
        "Groq HTTP 429: {\"error\":{\"message\":\"Rate limit reached for model "
        "`qwen/qwen3.8-27b\",\"type\":\"rate_limit_error\"}} after 3 attempts"
    )
    brief = answering._brief_reason(raw)
    assert "`" not in brief, brief
    assert "{" not in brief and "}" not in brief, brief
    assert brief == "Rate limit reached for model qwen/qwen3.8-27b", brief
    return 1


def test_an_unparseable_error_is_cut_on_a_word_boundary() -> int:
    long_error = "upstream timeout " * 30
    brief = answering._brief_reason(long_error)
    assert len(brief) <= 145, len(brief)
    assert brief.endswith("\u2026"), brief
    assert " " not in brief[-2:], "must not cut mid-word"
    return 1


def test_a_short_reason_is_left_alone() -> int:
    assert answering._brief_reason("the model returned no answer text") == (
        "the model returned no answer text"
    )
    return 1


def test_extractive_still_quotes_even_when_the_model_is_down() -> int:
    """Degrading to an error message with no content would be useless."""
    hit = retrieval.Hit(
        chunk_id="c1", document_id="d1", document_name="annual.md",
        text="Customer churn fell to 3.6 percent in FY2024.",
        effective_date=date(2024, 6, 30),
    )
    out = answering._extractive([hit], date(2024, 6, 30), reason="Groq HTTP 429: rate limit")
    assert out.mode == "extractive", out.mode
    assert "3.6 percent" in out.text, out.text
    assert "429" in out.text, "the reason must survive"
    assert len(out.citations) == 1, out.citations
    return 1


def test_a_full_provider_envelope_yields_its_message() -> int:
    """The provider keeps the whole body now, so the message is recoverable."""
    envelope = (
        'Groq HTTP 429: {"error":{"message":"Rate limit reached for model '
        '`qwen/qwen3.8-27b`. Please try again in 20s.","type":"rate_limit_error",'
        '"metadata":{"x":"padding that would have been cut off before"}}'
    )
    brief = answering._brief_reason(f"the model was unavailable: {envelope}")
    assert brief == "Rate limit reached for model qwen/qwen3.8-27b. Please try again in 20s.", brief
    assert "{" not in brief, brief
    return 1
