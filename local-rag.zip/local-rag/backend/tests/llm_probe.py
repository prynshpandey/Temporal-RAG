"""Probe the configured LLM provider and report what actually works.

Local stacks rot: model names get retired, JSON mode gets dropped by a provider
for one model but not another, and a "healthy" key can still be refused at
inference time. This runs the real extraction prompt against each candidate
model and prints a verdict, so picking ``GROQ_MODEL`` is a measurement instead
of a guess.

    make llm-probe                      # probe the configured provider
    make llm-probe GROQ_MODELS="a b c"  # probe specific models
"""

from __future__ import annotations

import asyncio
import hashlib
import os
import sys
import time
from datetime import date
from pathlib import Path
from typing import Any

import httpx

from app.config import settings
from app.llm.groq import parse_json_text
from app.parsers import parse_upload
from app.services.chunking import build_chunks
from app.services.extraction import SYSTEM_PROMPT, _bounded_text, _user_prompt, find_dates
from app.services.ingestion import build_plan

SAMPLE = "/seed/sample.pdf"


def _candidates() -> list[str]:
    override = os.environ.get("GROQ_MODELS", "").strip()
    if override:
        return override.split()
    return [settings.groq_model]


async def _plan_text() -> tuple[str, set[date]]:
    raw = Path(SAMPLE).read_bytes()
    plan = await build_plan(
        SAMPLE, Path(SAMPLE).name, None, hashlib.sha256(raw).hexdigest(), len(raw)
    )
    text = _bounded_text(plan)
    return text, {m.value for m in find_dates(text) if m.value}


async def probe_groq(model: str, user_prompt: str, known: set[date]) -> dict[str, Any]:
    body = {
        "model": model,
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_prompt},
        ],
        "temperature": 0.0,
        "max_tokens": 2000,
    }
    started = time.perf_counter()
    async with httpx.AsyncClient(timeout=240) as client:
        response = await client.post(
            f"{settings.groq_base_url}/chat/completions",
            headers={"Authorization": f"Bearer {settings.groq_api_key}"},
            json=body,
        )
    elapsed = time.perf_counter() - started

    if response.status_code != 200:
        return {"model": model, "ok": False, "detail": f"HTTP {response.status_code}: {response.text[:160]}"}

    data = response.json()
    choice = (data.get("choices") or [{}])[0]
    message = choice.get("message") or {}
    content = message.get("content") or ""
    verdict: dict[str, Any] = {
        "model": model,
        "ok": False,
        "seconds": round(elapsed, 1),
        "finish_reason": choice.get("finish_reason"),
        "reasoning": bool(message.get("reasoning")),
        "tokens": (data.get("usage") or {}).get("completion_tokens"),
    }
    try:
        parsed = parse_json_text(content)
    except ValueError as exc:
        verdict["detail"] = f"unparseable JSON: {exc}; tail={content[-80:]!r}"
        return verdict

    entities = [e.get("name") for e in parsed.get("entities") or [] if e.get("name")]
    events = parsed.get("events") or []
    facts = parsed.get("facts") or []
    invented = []
    for event in events:
        raw_date = event.get("event_date")
        if raw_date and _safe_date(raw_date) not in known:
            invented.append(raw_date)
    verdict.update(
        {
            "ok": bool(entities),
            "entities": len(entities),
            "events": len(events),
            "facts": len(facts),
            "invented_dates": invented,
            "detail": ", ".join(str(n) for n in entities[:4]),
        }
    )
    if invented:
        # An invented date is worse than no date: it can hide a document behind a
        # wrong point in time, so the model is not trustworthy for this task.
        verdict["ok"] = False
        verdict["detail"] += f" | INVENTED DATES {invented}"
    return verdict


def _safe_date(value: str) -> date | None:
    try:
        return date.fromisoformat(str(value)[:10])
    except ValueError:
        return None


async def main() -> int:
    if not settings.groq_configured:
        print("GROQ_API_KEY is missing or malformed; nothing to probe.")
        return 1

    async with httpx.AsyncClient(timeout=30) as client:
        listing = await client.get(
            f"{settings.groq_base_url}/models",
            headers={"Authorization": f"Bearer {settings.groq_api_key}"},
        )
    reachable = sorted(m["id"] for m in listing.json().get("data", [])) if listing.status_code == 200 else []
    print(f"key fingerprint : {settings.fingerprint()}")
    print(f"models reachable: {len(reachable)}")
    for name in reachable:
        print(f"  - {name}")

    if not Path(SAMPLE).exists():
        print(f"sample missing: {SAMPLE}")
        return 1

    text, known = await _plan_text()
    prompt = _user_prompt(text, {"name": Path(SAMPLE).name, "document_date": "2025-03-31", "document_type": "pdf"})
    print(f"\nprompt: {len(prompt)} chars, {len(known)} deterministic dates in the sample\n")

    failures = 0
    for model in _candidates():
        verdict = await probe_groq(model, prompt, known)
        mark = "ok  " if verdict.get("ok") else "FAIL"
        print(f"[{mark}] {verdict['model']}")
        for key in ("seconds", "finish_reason", "reasoning", "tokens", "entities", "events", "facts", "invented_dates", "detail"):
            if key in verdict:
                print(f"         {key}: {verdict[key]}")
        failures += 0 if verdict.get("ok") else 1

    print("\nRecommended: set GROQ_MODEL to a model marked ok above.")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
