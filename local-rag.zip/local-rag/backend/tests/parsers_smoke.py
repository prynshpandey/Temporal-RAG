"""Parser smoke test: builds a file of every supported type, parses it.

Run inside the backend container:

    docker compose exec backend python -m tests.parsers_smoke
"""

from __future__ import annotations

import json
import pathlib
import sys
import tempfile

from docx import Document as DocxWriter
from openpyxl import Workbook
from pptx import Presentation
from pptx.util import Inches

from app.parsers import parse_upload

MAX_BYTES = 100 * 1024 * 1024


def make_txt(root: pathlib.Path) -> pathlib.Path:
    path = root / "notes.txt"
    path.write_text(
        "Quarterly Review\n\nRevenue grew 12%.\f\nRisks\n\nThe Atlas migration slipped.\n",
        encoding="utf-8",
    )
    return path


def make_md(root: pathlib.Path) -> pathlib.Path:
    path = root / "handbook.md"
    path.write_text(
        "# Handbook\n\nIntro paragraph.\n\n## Policy\n\nAll vendors need approval.\n\n"
        "```python\nprint('hi')\n```\n\nSetext Title\n===\n\nUnder a setext heading.\n",
        encoding="utf-8",
    )
    return path


def make_csv(root: pathlib.Path) -> pathlib.Path:
    path = root / "people.csv"
    path.write_text(
        "name,role,start_date\nAda Lovelace,Engineer,2024-03-01\nGrace Hopper,Admiral,2024-07-15\n",
        encoding="utf-8",
    )
    return path


def make_json(root: pathlib.Path) -> pathlib.Path:
    path = root / "config.json"
    path.write_text(
        json.dumps(
            {
                "service": "atlas",
                "owners": [{"name": "Ada", "since": "2024-03-01"}],
                "retired": False,
                "limits": {"rps": 500},
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    return path


def make_html(root: pathlib.Path) -> pathlib.Path:
    path = root / "page.html"
    path.write_text(
        "<html><head><title>Atlas</title><script>alert(1)</script></head>"
        "<body><h1>Atlas</h1><p>First paragraph.</p><h2>Owners</h2>"
        "<ul><li>Ada Lovelace</li></ul>"
        "<table><tr><th>field</th><th>value</th></tr><tr><td>owner</td><td>Ada</td></tr></table>"
        "</body></html>",
        encoding="utf-8",
    )
    return path


def make_docx(root: pathlib.Path) -> pathlib.Path:
    path = root / "memo.docx"
    document = DocxWriter()
    document.add_heading("Acquisition Memo", level=1)
    document.add_paragraph("Acme Corp was acquired for 40 million on 2025-03-15.")
    document.add_heading("Terms", level=2)
    document.add_paragraph("Cash and stock.")
    table = document.add_table(rows=2, cols=2)
    table.cell(0, 0).text = "field"
    table.cell(0, 1).text = "value"
    table.cell(1, 0).text = "owner"
    table.cell(1, 1).text = "Ada"
    document.core_properties.title = "Acquisition Memo"
    document.core_properties.author = "Ada Lovelace, Grace Hopper"
    document.save(str(path))
    return path


def make_pptx(root: pathlib.Path) -> pathlib.Path:
    path = root / "deck.pptx"
    deck = Presentation()
    slide = deck.slides.add_slide(deck.slide_layouts[1])
    slide.shapes.title.text = "Roadmap"
    slide.placeholders[1].text = "Atlas ships in Q3"
    slide.notes_slide.notes_text_frame.text = "Mention the migration risk."
    deck.core_properties.title = "Roadmap"
    deck.save(str(path))
    return path


def make_xlsx(root: pathlib.Path) -> pathlib.Path:
    path = root / "headcount.xlsx"
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Engineering"
    sheet.append(["name", "team", "start_date"])
    sheet.append(["Ada Lovelace", "platform", "2024-03-01"])
    sheet.append(["Grace Hopper", "compilers", "2024-07-15"])
    workbook.save(str(path))
    return path


def make_bad(root: pathlib.Path) -> pathlib.Path:
    path = root / "actually-binary.txt"
    path.write_bytes(b"\x00\x01\x02\x03binary garbage" * 20)
    return path


BUILDERS = [
    ("txt", make_txt, "text/plain"),
    ("md", make_md, "text/markdown"),
    ("csv", make_csv, "text/csv"),
    ("json", make_json, "application/json"),
    ("html", make_html, "text/html"),
    ("docx", make_docx, "application/vnd.openxmlformats-officedocument.wordprocessingml.document"),
    ("pptx", make_pptx, "application/vnd.openxmlformats-officedocument.presentationml.presentation"),
    ("xlsx", make_xlsx, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
]


def main() -> int:
    failures = 0
    with tempfile.TemporaryDirectory() as tmp:
        root = pathlib.Path(tmp)
        sample = pathlib.Path("/seed/sample.pdf")
        if sample.exists():
            print("pdf  from the repo sample corpus")
            failures = _report(sample, "application/pdf", failures, expected="pdf")
        else:
            print("skip: /seed/sample.pdf is not mounted")

        for expected, builder, mime in BUILDERS:
            path = builder(root)
            failures = _report(path, mime, failures, expected=expected)

        # Rejection paths.
        print("\nrejection paths:")
        bad = make_bad(root)
        unknown = root / "mystery.bin"
        unknown.write_bytes(bytes(range(256)) * 4)
        legacy = root / "old.doc"
        legacy.write_bytes(b"\xd0\xcf\x11\xe0legacy OLE2 header")
        for label, path, mime in (
            ("binary-as-txt", bad, "text/plain"),
            ("unknown-ext", unknown, "application/octet-stream"),
            ("legacy-doc", legacy, "application/msword"),
        ):
            try:
                parse_upload(str(path), path.name, mime, max_bytes=MAX_BYTES)
                print(f"  FAIL {label}: accepted a file it must reject")
                failures += 1
            except Exception as exc:
                print(f"  ok   {label}: {type(exc).__name__} ({getattr(exc, 'code', '-')})")

    print("\n" + ("all parsers ok" if not failures else f"{failures} failure(s)"))
    return 1 if failures else 0


def _report(path: pathlib.Path, mime: str | None, failures: int, expected: str | None = None) -> int:
    try:
        document = parse_upload(str(path), path.name, mime, max_bytes=MAX_BYTES)
    except Exception as exc:
        print(f"FAIL {path.name}: {type(exc).__name__} {exc}")
        return failures + 1
    ok = expected is None or document.document_type == expected
    mark = "ok  " if ok else "FAIL"
    if not ok:
        failures += 1
    first = next((s.title for s in document.sections if s.title), None)
    print(
        f"{mark} {path.name:<18} type={document.document_type:<5} chars={document.char_count:<6} "
        f"sections={len(document.sections):<3} pages={document.page_count or '-'} "
        f"title={str(document.title)[:28]!r} first_section={str(first)[:28]!r} "
        f"ms={document.metadata['parse_ms']}"
    )
    return failures


if __name__ == "__main__":
    sys.exit(main())
