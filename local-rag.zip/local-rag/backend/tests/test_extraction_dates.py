"""Unit checks for deterministic date extraction.

The dates that decide point-in-time visibility come from this code, not from a
model, so it is the part of extraction that must be boring and predictable.
"""

from __future__ import annotations

from datetime import date

from app.services.extraction import (
    MONTH,
    PRECISE,
    QUARTER,
    YEAR,
    _certainty,
    document_date_from,
    find_dates,
)


def test_iso_dates_are_found_in_order() -> None:
    mentions = find_dates("Signed on 2025-03-15 and reviewed 2024-12-31.")
    assert [m.value for m in mentions] == [date(2025, 3, 15), date(2024, 12, 31)]
    assert all(m.precision == PRECISE for m in mentions)


def test_slashed_dates_accept_both_conventions() -> None:
    values = {m.value for m in find_dates("Paid 15/03/2025 and 03/15/2025 in other docs.")}
    assert date(2025, 3, 15) in values


def test_month_names_and_abbreviations() -> None:
    mentions = find_dates("Dated March 2025, Sept 2024 and feb 2023.")
    values = {m.value for m in mentions}
    assert values == {date(2025, 3, 1), date(2024, 9, 1), date(2023, 2, 1)}
    assert all(m.precision == MONTH for m in mentions)


def test_month_day_year_is_recognised_in_both_conventions() -> None:
    us = find_dates("Effective March 15, 2025.")
    assert us[0].value == date(2025, 3, 15) and us[0].precision == PRECISE
    uk = find_dates("Effective 15 March 2025.")
    assert uk[0].value == date(2025, 3, 15) and uk[0].precision == PRECISE
    # "March 15, 2025" must not also register as a bare "March 2025".
    assert len(us) == 1


def test_year_month_iso() -> None:
    assert find_dates("Report 2025-07 covers the period.")[0].value == date(2025, 7, 1)


def test_quarters_and_fiscal_years() -> None:
    quarters = [m for m in find_dates("Closed in Q3 2025.") if m.precision == QUARTER]
    assert quarters and quarters[0].value == date(2025, 7, 1)
    assert find_dates("Q1 2024 kickoff")[0].value == date(2024, 1, 1)
    assert find_dates("FY2024 results")[0].value == date(2024, 12, 31)
    assert find_dates("2024 Q2")[0].value == date(2024, 4, 1)


def test_bare_years_are_found_for_grounding() -> None:
    mentions = find_dates("Helios was founded in 2011 and revenue has grown since 2019.")
    years = {m.value.year for m in mentions if m.precision == "year_ref"}
    assert years == {2011, 2019}


def test_bare_year_does_not_date_the_document() -> None:
    # "founded in 2011" is history, not authorship: the document must fall back
    # to its upload date rather than becoming visible from 2011.
    value, precision = document_date_from(find_dates("Helios was founded in 2011."))
    assert value is None and precision == "unknown"
    value, _ = document_date_from(find_dates("Founded in 2011, filed 2025-04-02."))
    assert value == date(2025, 4, 2)


def test_fiscal_year_does_date_the_document() -> None:
    value, precision = document_date_from(find_dates("FY2024 results."))
    assert value == date(2024, 12, 31) and precision == YEAR


def test_relative_dates_are_marked_and_never_dated() -> None:
    mentions = find_dates("We will ship it next quarter and review in the coming weeks.")
    relative = [m for m in mentions if m.relative]
    assert relative, "relative phrasing must be detected"
    assert all(m.value is None for m in relative)
    assert all("next" in m.text.lower() or "coming" in m.text.lower() for m in relative)


def test_past_relative_phrases_are_relative_too() -> None:
    mentions = find_dates("As discussed yesterday, the plan slipped a month ago.")
    assert all(m.value is None for m in mentions if m.relative)
    assert any(m.precision == "past_relative" for m in mentions)


def test_impossible_dates_are_dropped_not_crashed() -> None:
    # No precise reading survives, but the year itself is still true of the text,
    # so it degrades to a year reference instead of vanishing.
    bogus = find_dates("2025-02-30 and 2025-13-01 and 2025-99-99")
    assert [m.precision for m in bogus] == ["year_ref"]
    assert all(m.value == date(2025, 12, 31) for m in bogus)
    unparseable = find_dates("February 30, 2025")
    assert [m.precision for m in unparseable] == ["year_ref"], "no month/day reading survives"


def test_document_date_prefers_the_most_recent_precise_mention() -> None:
    mentions = find_dates("Header: as of 2024-01-05. History: in 2019 we shipped. Filed 2025-06-30.")
    value, precision = document_date_from(mentions)
    assert value == date(2025, 6, 30), "the newest exact date dates the document"
    assert precision == PRECISE


def test_document_date_ignores_relative_mentions() -> None:
    mentions = find_dates("Filed 2025-02-02. We will ship next quarter.")
    value, precision = document_date_from(mentions)
    assert value == date(2025, 2, 2) and precision == PRECISE


def test_coarse_dates_round_up_to_the_end_of_their_period() -> None:
    # "March 2025" must not make the document visible before March is over.
    value, precision = document_date_from(find_dates("Dated March 2025."))
    assert value == date(2025, 3, 31) and precision == MONTH

    december, _ = document_date_from(find_dates("Dated December 2025."))
    assert december == date(2025, 12, 31), "December must not roll into the next year"

    quarter, precision = document_date_from(find_dates("Closed Q3 2025."))
    assert quarter == date(2025, 9, 30) and precision == QUARTER


def test_exact_date_beats_a_later_fiscal_year() -> None:
    mentions = find_dates("Signed 2019-03-15. Printed for FY2025.")
    value, precision = document_date_from(mentions)
    assert value == date(2019, 3, 15), "precision outranks recency"


def test_document_date_is_none_without_dates() -> None:
    value, precision = document_date_from([])
    assert value is None and precision == "unknown"

    value, precision = document_date_from([], fallback=date(2025, 1, 1))
    assert value == date(2025, 1, 1) and precision == "unknown"


def test_document_date_falls_back_to_uploaded_date() -> None:
    fallback = date(2025, 8, 8)
    value, precision = document_date_from(find_dates("No dates here at all."), fallback=fallback)
    assert value == fallback and precision == "unknown"


def test_certainty_reflects_precision() -> None:
    precise = find_dates("Dated 2025-01-02.")
    assert _certainty(PRECISE, precise) == "explicit"

    monthly = find_dates("Dated March 2025.")
    assert _certainty(MONTH, monthly) == "inferred"

    quarters = find_dates("Dated Q1 2025.")
    assert _certainty(QUARTER, quarters) == "inferred"

    # A fiscal year alone is weak evidence of authorship: it falls back to the
    # upload date rather than pretending the document is from that year.
    years = find_dates("FY2025 only.")
    assert _certainty(YEAR, years) == "unknown"

    assert _certainty("unknown", []) == "unknown"


def test_relative_only_text_never_claims_explicit_certainty() -> None:
    mentions = find_dates("Ships next quarter.")
    assert _certainty(YEAR, mentions) == "relative"
