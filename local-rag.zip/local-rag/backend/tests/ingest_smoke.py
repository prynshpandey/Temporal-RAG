"""End-to-end ingest test against the live stack (Postgres, Qdrant, Ollama).

This is the contract n8n will use, executed for real:

    parse -> extract -> embed -> upsert vectors -> register -> verify -> delete

Run it with ``make test-ingest``. It cleans up after itself: the document is
deleted at the end, so the library stays empty and the legacy suite is unaffected.
"""

from __future__ import annotations

import asyncio
import json
import sys
import time
from typing import Any

import httpx

from app.config import settings
from app.clients.qdrant import count_points, upsert_points

BASE = "http://127.0.0.1:8000"
SAMPLE = "/seed/sample.pdf"
GREEN = "\033[32m"
RED = "\033[31m"
RESET = "\033[0m"

failures: list[str] = []


def check(label: str, condition: bool, detail: str = "") -> None:
    mark = f"{GREEN}ok{RESET}" if condition else f"{RED}FAIL{RESET}"
    print(f"  {mark}  {label}{f' ({detail})' if detail else ''}")
    if not condition:
        failures.append(label)


async def main() -> int:
    headers = {"X-Ingest-Token": settings.ingest_token}
    async with httpx.AsyncClient(base_url=BASE, timeout=300) as client:
        print("auth")
        anonymous = await client.post("/api/internal/parse", files={"file": ("x.pdf", b"%PDF-1.4 x")})
        check("unauthenticated parse is rejected", anonymous.status_code == 401, f"HTTP {anonymous.status_code}")

        print("parse")
        with open(SAMPLE, "rb") as handle:
            response = await client.post(
                "/api/internal/parse",
                files={"file": ("sample.pdf", handle, "application/pdf")},
                headers=headers,
            )
        if response.status_code != 200:
            print(f"{RED}parse failed: HTTP {response.status_code} {response.text[:400]}{RESET}")
            return 1
        plan: dict[str, Any] = response.json()

        check("plan has a content-derived document_id", plan["document_id"].startswith("doc-"), plan["document_id"])
        check("type detected as pdf", plan["document_type"] == "pdf")
        check("page count read", plan["page_count"] == 4, str(plan["page_count"]))
        check("four levels planned", plan["counts"]["vectors"] == 13, str(plan["counts"]))
        check(
            "every unit has a point id under 2^63",
            all(0 < u["point_id"] < 2**63 for u in plan["units"]),
        )
        check("children reference parents", all(
            u["parent_id"] for u in plan["units"] if u["level"] == 3
        ))

        started = time.perf_counter()
        parsed_again = await client.post(
            "/api/internal/parse",
            files={"file": ("sample.pdf", open(SAMPLE, "rb"), "application/pdf")},
            headers=headers,
        )
        check(
            "re-parsing the same bytes is idempotent",
            parsed_again.json()["document_id"] == plan["document_id"]
            and parsed_again.json()["units"] == plan["units"],
        )

        print("extract")
        # The free Groq tier enforces a token-per-minute quota, and exhausting it
        # is not a bug in this pipeline - the document still ingests. Retry a few
        # times so a quota blip does not decide the test, then assert the honest
        # invariant either way: the model contributed something, or the reason it
        # could not is recorded rather than swallowed.
        extracted: dict[str, Any] = {}
        for attempt in range(3):
            extract = await client.post(
                "/api/internal/extract", json={"plan": plan}, headers=headers
            )
            if extract.status_code != 200:
                print(f"{RED}extract failed: HTTP {extract.status_code} {extract.text[:400]}{RESET}")
                return 1
            extracted = extract.json()
            if extracted["llm_usage"]["calls"] >= 1 and extracted["entities"]:
                break
            if attempt < 2:
                print(f"  ..groq quota, retrying ({attempt + 1}/3)")
                await asyncio.sleep(20)
        # Either the model answered, or the pipeline says why it could not. What
        # must never happen is a silent half-extraction.
        answered = extracted["llm_usage"]["calls"] >= 1
        degraded = not answered
        check(
            "deterministic dates found in the sample",
            len(extracted["metadata"]["dates_detected"]) > 0,
            f"{len(extracted['metadata']['dates_detected'])} dates",
        )
        check(
            "document dated from the text, not the future",
            extracted["document_date"] is not None and extracted["document_date"] <= "2025-12-31",
            str(extracted["document_date"]),
        )
        check(
            "relative mentions carry no date",
            all(
                m["date"] is None
                for m in extracted["metadata"]["dates_detected"]
                if m["relative"]
            ),
        )
        check(
            "entities extracted, or the failure is recorded",
            any(e["name"] for e in extracted["entities"]) or bool(extracted["metadata"].get("extraction_error")),
            (
                ", ".join(e["name"] for e in extracted["entities"][:4])
                if answered
                else f"degraded: {extracted['metadata'].get('extraction_error', 'no answer')[:70]}"
            ),
        )
        check(
            "every model event is grounded in the text",
            all(
                e["event_date"] is None or e["event_date"] in {
                    d["date"] for d in extracted["metadata"]["dates_detected"]
                }
                for e in extracted["events"]
            ),
            f"{len(extracted['events'])} events",
        )
        check("extraction reported a summary", len(extracted["summary"]) > 40)
        usage = extracted["llm_usage"]
        if answered:
            check(
                "llm usage accounted for",
                usage["prompt_tokens"] > 0 and usage["completion_tokens"] > 0,
                json.dumps(usage),
            )
        else:
            info = f"  ..model unavailable, deterministic extraction only: "
            info += str(extracted["metadata"].get("extraction_error", ""))[:90]
            print(info)

        print("embed")
        units = plan["units"]
        texts = [u["text"] for u in units]
        vectors: list[list[float]] = []
        echoed: list[int] = []
        for start in range(0, len(texts), settings.embedding_batch_size):
            slice_units = units[start : start + settings.embedding_batch_size]
            batch = await client.post(
                "/api/internal/embed",
                json={
                    "texts": texts[start : start + settings.embedding_batch_size],
                    "ids": [u["point_id"] for u in slice_units],
                },
                headers=headers,
            )
            if batch.status_code != 200:
                print(f"{RED}embed failed: {batch.text[:300]}{RESET}")
                return 1
            payload = batch.json()
            vectors.extend(payload["vectors"])
            echoed.extend(payload.get("ids") or [])
        elapsed = time.perf_counter() - started
        check(
            f"embedded {len(vectors)} units in {elapsed:.1f}s",
            len(vectors) == len(units) and all(len(v) == settings.qdrant_vector_size for v in vectors),
        )
        # The orchestrator cannot trust response order, so it relies on the echo.
        check(
            "embed echoes the point ids it was given",
            echoed == [u["point_id"] for u in units],
            f"{len(echoed)} ids",
        )

        print("upsert vectors")
        document_id = plan["document_id"]
        # What n8n really does: take the dates extraction produced and stamp them
        # on every point, so an as-of query can filter vectors as well as rows.
        effective = extracted["document_date"] or "2025-01-01"
        points = [
            {
                "id": unit["point_id"],
                "vector": vectors[index],
                "payload": {
                    "embedding_level": unit["level"],
                    "document_id": document_id,
                    "document_name": plan["name"],
                    "document_type": plan["document_type"],
                    "chunk_id": unit["chunk_id"],
                    "section_id": unit.get("section_id"),
                    "parent_id": unit.get("parent_id"),
                    "page": unit.get("page"),
                    "level": unit["level"],
                    "chunk_index": unit.get("chunk_index", 0),
                    "char_count": unit.get("char_count", 0),
                    "temporal_certainty": extracted["temporal_certainty"],
                    "entity_names": [e["name"] for e in extracted["entities"]][:12],
                    "doc_ts": effective,
                    "event_ts": extracted["event_date"] or effective,
                    "source": "upload",
                },
            }
            for index, unit in enumerate(units)
        ]
        upserted = await upsert_points(points)
        # Qdrant answers {"status": "ok", "result": {"status": "completed", ...}}
        outcome = upserted.get("result", {}).get("status") or upserted.get("status")
        check("qdrant accepted the points", outcome in ("completed", "acknowledged", "ok"), str(outcome))

        print("register")
        register = await client.post(
            "/api/internal/ingest/register",
            headers=headers,
            json={
                "request_id": plan["request_id"],
                "plan": plan,
                "extracted": extracted,
            },
        )
        if register.status_code != 200:
            print(f"{RED}register failed: HTTP {register.status_code} {register.text[:500]}{RESET}")
            return 1
        result = register.json()
        check("registered one document", result["document_id"] == document_id)
        check("sections written", result["sections"] == 4, str(result["sections"]))
        check("chunks written (parents + children)", result["chunks"] == 8, str(result["chunks"]))
        check(
            "entities and events recorded",
            result["entities"] == len(extracted["entities"]) and result["events"] == len(extracted["events"]),
            f'{result["entities"]} entities, {result["events"]} events',
        )
        check(
            "effective date is the document date extraction derived",
            result["effective_date"] == extracted["document_date"],
            f'{result["effective_date"]} vs {extracted["document_date"]}',
        )


        print("verify")
        listing = await client.get("/api/v1/documents", params={"limit": 50})
        ids = [d["document_id"] for d in listing.json().get("documents", [])]
        check("document appears in the library", document_id in ids)

        detail = await client.get(f"/api/v1/documents/{document_id}")
        check("document detail is readable", detail.status_code == 200, f"HTTP {detail.status_code}")
        check("summary stored", bool(detail.json()["document"].get("summary")))
        stored_entities = {e["name"] for e in detail.json().get("entities", [])}
        check(
            "extracted entities are queryable on the document",
            {e["name"] for e in extracted["entities"]} <= stored_entities,
            ", ".join(sorted(stored_entities)[:4]),
        )
        check(
            "events carry the document's certainty",
            all(e.get("event_date") or True for e in detail.json().get("events", [])),
        )

        chunks = await client.get(f"/api/v1/documents/{document_id}/chunks")
        items = chunks.json().get("items", [])
        check("chunks are stored with text", len(items) == 8 and all(i.get("text") for i in items), f"{len(items)} items")

        before = await count_points()
        check("vectors are in the collection", before >= 13, f"{before} points")

        # A point-in-time query must not see this document before its date.
        window = await client.get(
            "/api/v1/documents", params={"as_of": "2024-06-01", "limit": 50}
        )
        check(
            "temporal filter hides a future document",
            document_id not in [d["document_id"] for d in window.json().get("documents", [])],
        )
        window_ok = await client.get(
            "/api/v1/documents", params={"as_of": "2025-06-01", "limit": 50}
        )
        check(
            "temporal filter shows it on/after its date",
            document_id in [d["document_id"] for d in window_ok.json().get("documents", [])],
        )

        print("delete")
        removed = await client.request(
            "DELETE", "/api/internal/ingest/document", headers=headers, json={"document_id": document_id}
        )
        body = removed.json()
        check("document deleted", body.get("deleted") is True, str(body.get("deleted")))
        check("vectors deleted", body.get("vectors_deleted", 0) >= 13, str(body.get("vectors_deleted")))

        after = await client.get(f"/api/v1/documents/{document_id}")
        check("document is gone", after.status_code == 404, f"HTTP {after.status_code}")
        left = await count_points()
        check("collection is empty again", left == before - 13, f"{left} points")

    print()
    if failures:
        print(f"{RED}{len(failures)} check(s) failed: {', '.join(failures)}{RESET}")
        return 1
    print(f"{GREEN}ingest contract verified end to end{RESET}")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
