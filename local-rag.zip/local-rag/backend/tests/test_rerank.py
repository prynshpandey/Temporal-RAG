"""Reranking: relevance decides, and recency only breaks ties.

The defect this pins down was measured, not hypothesised: with the old
multiplicative recency term, a document ranked 8th by *both* retrievers was
promoted above one ranked 1st by both, because the 10.3% relevance gap between
those ranks was smaller than the 15% recency bonus. The retrieval docstring
claimed the opposite of what the code did.

Two properties are therefore load-bearing, and each is checked against the case
that broke:

* past the relevance band, relevance decides and recency is never consulted
* inside the band, recency decides - a small score multiplier is not enough,
  because then the residual base-score difference stays in charge
"""

from __future__ import annotations

from datetime import date

from app.services import rerank
from app.services.retrieval import Hit


def _hit(
    name: str,
    text: str,
    *,
    keyword_rank: int | None = None,
    vector_rank: int | None = None,
    score: float = 0.03,
    when: date | None = None,
    parent: str = "",
) -> Hit:
    hit = Hit(
        chunk_id=name,
        document_id=name,
        document_name=f"{name}.md",
        text=text,
        parent_text=parent,
        effective_date=when,
        keyword_rank=keyword_rank,
        vector_rank=vector_rank,
    )
    hit.score = score
    return hit


def _rrf(keyword_rank: int | None, vector_rank: int | None) -> float:
    return 1.0 / (60 + (keyword_rank or 1)) + 1.0 / (60 + (vector_rank or 1))


# ---------------------------------------------------------------- query terms
def test_query_terms_drop_question_words_and_questions() -> int:
    terms = rerank.query_terms("What was the customer churn rate in FY2024?")
    assert "churn" in terms and "customer" in terms and "rate" in terms, terms
    for junk in ("what", "was", "the", "in", "fy2024"):
        assert junk not in terms, junk
    return 1


def test_longer_terms_are_ordered_first() -> int:
    terms = rerank.query_terms("churn customer")
    assert terms[0] == "customer", terms
    return 1


# ------------------------------------------------------------------ features
def test_coverage_rewards_answering_the_whole_question() -> int:
    terms = rerank.query_terms("revenue churn")
    full = "Revenue rose while churn fell."
    partial = "Revenue rose."
    assert rerank.coverage(terms, full) == 1.0
    assert rerank.coverage(terms, partial) == 0.5
    return 1


def test_proximity_rewards_terms_that_sit_together() -> int:
    terms = rerank.query_terms("revenue churn")
    together = "Revenue and churn were both reported."
    apart = "Revenue is the total. " * 20 + "Churn is a rate."
    assert rerank.proximity(terms, together) > rerank.proximity(terms, apart)
    assert rerank.proximity(terms, together) > 0.8, rerank.proximity(terms, together)
    return 1


def test_proximity_requires_at_least_two_terms() -> int:
    assert rerank.proximity(["revenue"], "Revenue rose") == 0.0
    return 1


def test_heading_match_uses_the_section_title() -> int:
    terms = rerank.query_terms("financial summary")
    hit = _hit("a", "body", parent="Annual Report 2024 > 1. Financial summary\nbody")
    assert rerank.heading(terms, rerank._heading_text(hit)) == 1.0
    return 1


def test_density_does_not_reward_an_enormous_passage() -> int:
    terms = rerank.query_terms("revenue")
    short = "Revenue was 57.4 million euro."
    padded = "Revenue was 57.4 million euro. " + ("Filler sentence. " * 200)
    assert rerank.density(terms, short) > rerank.density(terms, padded)
    return 1


def test_quality_is_between_zero_and_one() -> int:
    hit = _hit("a", "Revenue rose and churn fell sharply this quarter.")
    score, parts = rerank.quality_score("revenue churn", hit, rerank.RerankWeights())
    assert 0.0 <= score <= 1.0, score
    assert set(parts) == {"coverage", "proximity", "heading", "density"}
    return 1


# ----------------------------------------------------- the defect that existed
def test_recency_cannot_promote_a_clearly_weaker_match() -> int:
    """The measured bug: rank 8+8 behind rank 1+1, then promoted by recency."""
    strong = _hit("strong", "Revenue churn", keyword_rank=1, vector_rank=1, score=_rrf(1, 1), when=date(2023, 12, 31))
    weak = _hit("weak", "Revenue churn", keyword_rank=8, vector_rank=8, score=_rrf(8, 8), when=date(2025, 6, 30))
    assert (strong.score - weak.score) / strong.score > 0.10, "the gap must exceed the band"

    ordered = rerank.rerank("revenue churn", [weak, strong], recency_weight=0.15, band=0.10)
    assert [h.chunk_id for h in ordered] == ["strong", "weak"], [h.chunk_id for h in ordered]
    assert ordered[1].extra.get("outside_relevance_band") is True, ordered[1].extra
    return 1


def test_a_stronger_match_wins_even_when_considerably_older() -> int:
    strong = _hit("strong", "Revenue churn", score=0.0328, when=date(2020, 1, 1))
    weak = _hit("weak", "Revenue churn", score=0.0294, when=date(2025, 6, 30))
    ordered = rerank.rerank("revenue churn", [weak, strong], recency_weight=0.15, band=0.10)
    assert ordered[0].chunk_id == "strong", [h.chunk_id for h in ordered]
    return 1


# ------------------------------------------------------------ ties, by recency
def test_a_tie_is_broken_by_the_newer_document() -> int:
    """The case the whole feature exists for: 2023 and 2024 both state churn."""
    old = _hit("old", "Customer churn was 4.1 percent in FY2023.", score=0.0328, when=date(2023, 12, 31))
    new = _hit("new", "Customer churn fell to 3.6 percent in FY2024.", score=0.0328, when=date(2024, 12, 31))
    ordered = rerank.rerank("customer churn", [old, new], recency_weight=0.15, band=0.10)
    assert [h.chunk_id for h in ordered] == ["new", "old"], [h.chunk_id for h in ordered]
    assert ordered[0].extra.get("ranking_basis") == "recency_within_band"
    return 1


def test_recency_breaks_a_tie_even_when_the_base_scores_differ_slightly() -> int:
    """A small multiplier is not enough here; recency has to be the deciding key.

    These two figures come from a real query: identical relevance, but the
    fused base scores differed by 1.6%, more than a 1.5% multiplier could
    overcome, so the older document won the tie it should have lost.
    """
    newer = _hit("newer", "Revenue in Q1 2025 update", score=0.032002, when=date(2025, 6, 30))
    older = _hit("older", "Revenue for FY2025 annual", score=0.032522, when=date(2025, 3, 31))
    ordered = rerank.rerank("revenue 2025", [older, newer], recency_weight=0.15, band=0.10)
    assert ordered[0].chunk_id == "newer", [h.chunk_id for h in ordered]
    return 1


def test_undated_passages_do_not_win_a_tie() -> int:
    dated = _hit("dated", "Revenue", score=0.0328, when=date(2020, 1, 1))
    undated = _hit("undated", "Revenue", score=0.0328, when=None)
    ordered = rerank.rerank("revenue", [undated, dated], recency_weight=0.15, band=0.10)
    assert ordered[0].chunk_id == "dated", [h.chunk_id for h in ordered]
    return 1


def test_recency_is_ignored_when_switched_off() -> int:
    old = _hit("old", "Customer churn", score=0.0328, when=date(2023, 12, 31))
    new = _hit("new", "Customer churn", score=0.0329, when=date(2024, 12, 31))
    ordered = rerank.rerank("customer churn", [old, new], recency_weight=0.0, band=0.10)
    assert ordered[0].chunk_id == "new", "relevance already favours it, and recency was not used"
    assert ordered[0].extra.get("ranking_basis") is None
    return 1


def test_a_single_candidate_is_returned_untouched_in_order() -> int:
    only = _hit("only", "Revenue", score=0.03, when=date(2020, 1, 1))
    assert rerank.rerank("revenue", [only]) == [only]
    return 1


def test_rerank_is_stable_for_identical_passages() -> int:
    a = _hit("a", "Revenue churn", score=0.0328, when=date(2024, 1, 1))
    b = _hit("b", "Revenue churn", score=0.0328, when=date(2024, 1, 1))
    ordered = rerank.rerank("revenue churn", [a, b], recency_weight=0.15, band=0.10)
    assert [h.chunk_id for h in ordered] == ["a", "b"], "ties must resolve by id, not by input order"
    return 1


def test_every_hit_reports_why_it_was_chosen() -> int:
    hits = [_hit("a", "Revenue and churn", score=0.0328, when=date(2024, 1, 1))]
    ordered = rerank.rerank("revenue churn", hits, recency_weight=0.15, band=0.10)
    extra = ordered[0].extra
    for key in ("base_score", "rerank_quality", "rerank_features"):
        assert key in extra, key
    assert set(extra["rerank_features"]) == {"coverage", "proximity", "heading", "density"}
    return 1


def test_reranking_never_reintroduces_an_excluded_document() -> int:
    """Ranking is downstream of filtering; nothing here may widen the window."""
    in_scope = _hit("in", "Revenue churn", score=0.03, when=date(2024, 1, 1))
    ordered = rerank.rerank("revenue", [in_scope], recency_weight=0.15, band=0.10)
    assert [h.chunk_id for h in ordered] == ["in"]
    return 1
