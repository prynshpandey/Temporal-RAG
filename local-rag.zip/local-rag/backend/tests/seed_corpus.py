"""Ingest the seed corpus, so retrieval and as-of queries have something to say.

Runs the real internal API - parse, extract, embed, upsert, register - because a
seeding shortcut that skipped the temporal metadata would make the corpus
useless for the only thing it exists to test.

Usage:
    python -m tests.seed_corpus            # write the corpus and ingest it
    python -m tests.seed_corpus --reset    # delete the previous corpus first
"""

from __future__ import annotations

import argparse
import asyncio
import pathlib
import time

import httpx

from app.clients import qdrant
from app.config import settings
from eval_seed.corpus import corpus_paths

BASE = "http://127.0.0.1:8000"

# The corpus is identified by this prefix so --reset can remove exactly what this
# script created and nothing else.
CORPUS_PREFIX = "helios-"


def _qdrant_filter(document_ids: list[str]) -> dict:
    return {"must": [{"key": "document_id", "match": {"any": document_ids}}]}


async def _delete_previous(client: httpx.AsyncClient) -> int:
    from app.clients import qdrant

    rows = await client.get(f"{BASE}/api/v1/documents?limit=200")
    documents = rows.json().get("documents", [])
    doomed = [d["document_id"] for d in documents if d.get("name", "").startswith(CORPUS_PREFIX)]
    for document_id in doomed:
        await client.delete(f"{BASE}/api/v1/documents/{document_id}")
    return len(doomed)


async def ingest_one(client: httpx.AsyncClient, path: pathlib.Path, token: str) -> dict:
    headers = {"X-Ingest-Token": token}
    with path.open("rb") as handle:
        response = await client.post(
            f"{BASE}/api/internal/parse",
            files={"file": (path.name, handle, "text/markdown")},
            headers=headers,
            timeout=300,
        )
    if response.status_code != 200:
        return {"name": path.name, "ok": False, "error": response.text[:200]}
    plan = response.json()

    response = await client.post(
        f"{BASE}/api/internal/extract",
        json={"plan": plan},
        headers=headers,
        timeout=900,
    )
    extracted = response.json() if response.status_code == 200 else {}
    request_id = plan["request_id"]

    units = plan["units"]
    vectors: dict[str, list[float]] = {}
    batch = settings.embedding_batch_size
    for start in range(0, len(units), batch):
        slice_units = units[start : start + batch]
        response = await client.post(
            f"{BASE}/api/internal/embed",
            json={
                "texts": [u["text"] for u in slice_units],
                "ids": [u["point_id"] for u in slice_units],
            },
            headers=headers,
            timeout=900,
        )
        if response.status_code != 200:
            return {"name": path.name, "ok": False, "error": response.text[:200]}
        body = response.json()
        for point_id, vector in zip(body["ids"], body["vectors"]):
            vectors[str(point_id)] = vector

    entity_names = [e["name"] for e in extracted.get("entities", [])][:12]
    points = [
        {
            "id": unit["point_id"],
            "vector": vectors[str(unit["point_id"])],
            "payload": {
                "document_id": plan["document_id"],
                "document_name": plan["name"],
                "document_type": plan["document_type"],
                "chunk_id": unit["chunk_id"],
                "section_id": unit.get("section_id"),
                "parent_id": unit.get("parent_id"),
                "page": unit.get("page"),
                "level": unit["level"],
                "chunk_index": unit.get("chunk_index", 0),
                "char_count": unit.get("char_count", 0),
                "temporal_certainty": extracted.get("temporal_certainty", "unknown"),
                "entity_names": entity_names,
                # Same chain the SQL filter and the n8n payload use. Using
                # document_date alone makes undated-effective documents visible
                # from the wrong day on the vector path.
                "doc_ts": (
                    extracted.get("effective_date")
                    or extracted.get("document_date")
                    or extracted.get("event_date")
                ),
                "event_ts": extracted.get("event_date"),
                "source": plan.get("source", "upload"),
                "request_id": request_id,
                "request_ts": plan.get("request_ts"),
                "valid_from": extracted.get("valid_from"),
                "valid_until": extracted.get("valid_until"),
            },
        }
        for unit in units
        if str(unit["point_id"]) in vectors
    ]
    await qdrant.upsert_points(points)

    response = await client.post(
        f"{BASE}/api/internal/ingest/register",
        json={"plan": plan, "extracted": extracted, "request_id": request_id, "vectors": len(points)},
        headers=headers,
        timeout=300,
    )
    if response.status_code != 200:
        return {"name": path.name, "ok": False, "error": response.text[:200]}
    result = response.json()
    return {
        "name": path.name,
        "ok": True,
        "document_id": result["document_id"],
        "effective_date": result["effective_date"],
        "document_date": extracted.get("document_date"),
        "certainty": result["temporal_certainty"],
        "vectors": len(points),
        "entities": len(extracted.get("entities", [])),
        "events": len(extracted.get("events", [])),
    }


async def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--reset", action="store_true", help="delete the previous corpus first")
    args = parser.parse_args()

    written = corpus_paths()
    print(f"{len(written)} seed documents")

    async with httpx.AsyncClient() as client:
        if args.reset:
            removed = await _delete_previous(client)
            print(f"removed {removed} previous seed documents")

        rows = []
        for path in written:
            started = time.perf_counter()
            row = await ingest_one(client, path, settings.ingest_token)
            row["seconds"] = round(time.perf_counter() - started, 1)
            rows.append(row)
            flag = "ok  " if row["ok"] else "FAIL"
            print(
                f"  {flag} {row['name']:<34} effective={row.get('effective_date')} "
                f"certainty={row.get('certainty')} vectors={row.get('vectors')} "
                f"entities={row.get('entities')} {row.get('seconds')}s"
                + ("" if row["ok"] else f"  {row.get('error')}")
            )

    failed = [r for r in rows if not r["ok"]]
    if failed:
        print(f"\n{len(failed)} of {len(rows)} documents failed to ingest")
        return 1
    print(f"\nseed corpus ingested: {len(rows)} documents")
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
