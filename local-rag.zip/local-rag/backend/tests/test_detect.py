"""Unit checks for upload hardening: filenames and type detection."""

from __future__ import annotations

import json
import tempfile
import zipfile
from pathlib import Path

from app.errors import UnsupportedFileType, UnsafeArchive
from app.parsers.detect import detect_document_type, sanitize_filename


def _detect(path: Path, name: str | None, mime: str | None, **kwargs) -> tuple[str, str]:
    return detect_document_type(str(path), name, mime, **kwargs)


def test_sanitize_strips_directories_and_traversal() -> None:
    assert sanitize_filename("../../etc/passwd") == "passwd"
    assert sanitize_filename("/tmp/report.pdf") == "report.pdf"
    assert sanitize_filename(r"C:\Users\ada\report.pdf") == "report.pdf"
    assert sanitize_filename("....//....//x.txt") == "x.txt"


def test_sanitize_removes_control_characters() -> None:
    cleaned = sanitize_filename("re\nport\r\n\t.txt")
    assert "\n" not in cleaned and "\r" not in cleaned
    assert cleaned.endswith(".txt")


def test_sanitize_bounds_length_and_keeps_extension() -> None:
    long_name = sanitize_filename(("x" * 400) + ".pdf")
    assert len(long_name) <= 180
    assert long_name.endswith(".pdf")


def test_sanitize_fallbacks() -> None:
    assert sanitize_filename(None) == "upload"
    assert sanitize_filename("") == "upload"
    assert sanitize_filename("...") == "upload"
    assert sanitize_filename("....") == "upload"


def test_detect_pdf_from_magic_even_with_wrong_extension() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "sneaky.txt"
        path.write_bytes(b"%PDF-1.7\n" + b"x" * 64)
        assert _detect(path, "sneaky.txt", "text/plain")[0] == "pdf"


def test_detect_docx_pptx_xlsx_inside_the_zip() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        for kind, marker in (
            ("docx", "word/document.xml"),
            ("pptx", "ppt/presentation.xml"),
            ("xlsx", "xl/workbook.xml"),
        ):
            path = root / f"f.{kind}"
            with zipfile.ZipFile(path, "w") as archive:
                archive.writestr(marker, "<xml/>")
                archive.writestr("other/file.xml", "<xml/>")
            detected, mime = _detect(path, path.name, None)
            assert detected == kind, f"{path.name} detected as {detected}"
            assert mime.startswith("application/vnd.openxmlformats")

        # A zip that is none of the three is rejected, not guessed.
        other = root / "f.zip"
        with zipfile.ZipFile(other, "w") as archive:
            archive.writestr("readme.txt", "hi")
        try:
            _detect(other, "f.zip", None)
        except UnsupportedFileType as exc:
            assert exc.code == "unsupported_file"
        else:
            raise AssertionError("a plain zip must be rejected")


def test_detect_rejects_broken_zip() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "broken.docx"
        path.write_bytes(b"PK\x03\x04 not really a zip")
        try:
            _detect(path, "broken.docx", None)
        except UnsafeArchive as exc:
            assert exc.code == "unsafe_archive"
        else:
            raise AssertionError("a corrupt office file must raise UnsafeArchive")


def test_detect_rejects_zip_bomb_by_entry_count() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "bomb.docx"
        with zipfile.ZipFile(path, "w") as archive:
            archive.writestr("word/document.xml", "<xml/>")
            for index in range(60):
                archive.writestr(f"filler/{index}.xml", "x")
        try:
            _detect(path, "bomb.docx", None, max_entries=10)
        except UnsafeArchive as exc:
            assert "entries" in exc.message
        else:
            raise AssertionError("entry-count limit must be enforced")


def test_detect_rejects_zip_bomb_by_uncompressed_size() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "bomb2.docx"
        with zipfile.ZipFile(path, "w") as archive:
            archive.writestr("word/document.xml", "<xml/>")
            archive.writestr("big.bin", b"\0" * (3 * 1024 * 1024))
        try:
            _detect(path, "bomb2.docx", None, max_uncompressed_mb=1)
        except UnsafeArchive as exc:
            assert "expands to" in exc.message
        else:
            raise AssertionError("uncompressed-size limit must be enforced")


def test_detect_text_formats_and_mime_fallback() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        csv = root / "data.csv"
        csv.write_text("a,b\n1,2\n", encoding="utf-8")
        # Browsers send text/plain for CSV; the extension must win.
        assert _detect(csv, "data.csv", "text/plain")[0] == "csv"

        md = root / "readme.md"
        md.write_text("# hi", encoding="utf-8")
        assert _detect(md, "readme.md", None)[0] == "md"

        js = root / "payload.json"
        js.write_text(json.dumps({"a": 1}), encoding="utf-8")
        assert _detect(js, "payload.json", "application/json") == (
            "json",
            "application/json",
        )

        # A text extension with binary content is refused instead of being
        # silently fed to the text parser as mojibake.
        bogus = root / "notes.txt"
        bogus.write_bytes(b"\x00\x01\x02\x03" * 40)
        try:
            _detect(bogus, "notes.txt", "text/plain")
        except UnsupportedFileType as exc:
            assert exc.code == "unsupported_file"
        else:
            raise AssertionError("binary content named .txt must be rejected")


def test_detect_rejects_legacy_office_and_unknown() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        legacy = root / "old.doc"
        legacy.write_bytes(b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1" + b"\x00" * 100)
        try:
            _detect(legacy, "old.doc", "application/msword")
        except UnsupportedFileType as exc:
            assert "legacy binary Office" in exc.message
        else:
            raise AssertionError(".doc must be rejected with guidance")

        unknown = root / "thing.bin"
        unknown.write_bytes(b"\x01\x02\x03\x04 random")
        try:
            _detect(unknown, "thing.bin", "application/octet-stream")
        except UnsupportedFileType as exc:
            assert "Unsupported file type" in exc.message
        else:
            raise AssertionError("unknown types must be rejected")
