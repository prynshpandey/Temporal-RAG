"""Unit checks for hierarchical chunking: bounds, coverage, boundaries, ids."""

from __future__ import annotations

from app.parsers.base import Page, ParsedDocument, Section
from app.services.chunking import (
    CHILD_MAX_CHARS,
    CHILD_TARGET_CHARS,
    PARENT_MAX_CHARS,
    Chunk,
    build_chunks,
)


def _doc(sections: list[Section], text: str | None = None, title: str | None = "Doc") -> ParsedDocument:
    joined = text if text is not None else "\n\n".join(s.text for s in sections)
    return ParsedDocument(
        document_type="md",
        text=joined,
        pages=[Page(number=1, text=joined)],
        sections=sections,
        title=title,
        page_count=1,
    )


def _section(ordinal: int, title: str, text: str, level: int = 1, page: int | None = 1) -> Section:
    return Section(key=f"s{ordinal}", title=title, level=level, ordinal=ordinal, page=page, text=text)


def test_small_document_shape() -> None:
    document = _doc([_section(0, "Intro", "One sentence. Two sentences.")])
    chunks = build_chunks(document, "doc1")

    assert chunks.document_summary.level == 0
    assert len(chunks.section_summaries) == 1
    assert chunks.parents and chunks.children
    assert chunks.stats()["total"] == len(chunks.all_chunks)


def test_children_always_reference_a_real_parent() -> None:
    document = _doc(
        [
            _section(0, "One", "Alpha beta gamma. " * 40),
            _section(1, "Two", "Delta epsilon zeta. " * 40, level=2),
        ]
    )
    chunks = build_chunks(document, "doc1")
    parent_ids = {p.text and f"doc1-p{p.ordinal:04d}" for p in chunks.parents}

    assert parent_ids, "expected parents"
    for child in chunks.children:
        assert child.parent_id in parent_ids, f"orphan child: {child.parent_id}"
        assert child.level == 3


def test_parent_and_child_bounds_respected() -> None:
    long_paragraph = "The migration slipped by two weeks. " * 200
    document = _doc([_section(0, "Long", long_paragraph)])
    chunks = build_chunks(document, "doc1")

    for parent in chunks.parents:
        assert len(parent.text) <= PARENT_MAX_CHARS
    for child in chunks.children:
        # A child may exceed the target by one sentence, but never the hard max
        # (unless a single sentence is longer than the max, which cannot happen
        # because long sentences are word-split).
        assert len(child.text) <= CHILD_MAX_CHARS, f"child too long: {len(child.text)}"
    assert len(chunks.children) > len(chunks.parents), "long text must produce many children"
    assert all(len(c.text) <= CHILD_TARGET_CHARS + 200 for c in chunks.children)


def test_no_text_is_lost_between_sections_and_parents() -> None:
    sections = [
        _section(0, "Alpha", "First part of the alpha section. " * 20),
        _section(1, "Beta", "Second part of the beta section. " * 20, level=2),
        _section(2, "Gamma", "Third part of the gamma section. " * 20, level=3),
    ]
    chunks = build_chunks(_doc(sections), "doc1")

    def words(text: str) -> set[str]:
        return {w for w in text.replace("\n", " ").split() if w}

    for section in sections:
        section_words = words(section.text)
        parent_words = set().union(*(words(p.text) for p in chunks.parents if p.section_id.endswith(f"{section.ordinal:04d}")))
        assert section_words <= parent_words, f"lost words from section {section.title}"


def test_children_split_on_sentence_boundaries() -> None:
    document = _doc([_section(0, "Prose", "Alpha one two. Beta three four. Gamma five six. Delta seven eight. " * 30)])
    chunks = build_chunks(document, "doc1")

    for child in chunks.children:
        for piece in [p for p in child.text.split(". ") if p.strip()]:
            assert "  " not in piece, "child fragment broke mid-sentence"
            # Every sentence fragment must exist verbatim in its parent.
            parent = next(p for p in chunks.parents if f"doc1-p{p.ordinal:04d}" == child.parent_id)
            assert piece.rstrip(".").strip() in parent.text


def test_children_overlap_so_context_is_never_lost() -> None:
    document = _doc([_section(0, "Prose", "Sentence number one here. Sentence number two here. Sentence number three here. " * 20)])
    chunks = build_chunks(document, "doc1")

    assert len(chunks.children) > 2
    for previous, current in zip(chunks.children, chunks.children[1:]):
        first_words = previous.text.split()[:3]
        if first_words:
            tail = " ".join(previous.text.split()[-3:])
            assert tail in current.text or " ".join(first_words) in current.text


def test_breadcrumb_tracks_heading_depth() -> None:
    document = _doc(
        [
            _section(0, "Handbook", "Top level body."),
            _section(1, "Policy", "Policy body.", level=2),
            _section(2, "Vendors", "Vendor body.", level=3),
            _section(3, "Appendix", "Appendix body.", level=1),
        ]
    )
    chunks = build_chunks(document, "doc1")
    paths = [c.level_path for c in chunks.section_summaries]

    assert paths[0] == "Handbook"
    assert paths[1] == "Handbook > Policy"
    assert paths[2] == "Handbook > Policy > Vendors"
    assert paths[3] == "Appendix"


def test_degenerate_document_still_yields_a_child() -> None:
    document = _doc([_section(0, "Tiny", "Hi.")])
    chunks = build_chunks(document, "doc1")

    assert chunks.parents and chunks.children
    assert chunks.children[0].parent_id == f"doc1-p{chunks.parents[0].ordinal:04d}"


def test_oversized_single_sentence_is_word_split() -> None:
    document = _doc([_section(0, "Run-on", " ".join(f"word{i}" for i in range(2000)))])
    chunks = build_chunks(document, "doc1")

    assert all(len(c.text) <= CHILD_MAX_CHARS for c in chunks.children)
    assert all(len(p.text) <= PARENT_MAX_CHARS for p in chunks.parents)


def test_bulleted_content_stays_on_one_line_per_item() -> None:
    bullets = "\n\n".join(f"- Item {i}: value {i}" for i in range(200))
    document = _doc([_section(0, "Checklist", bullets)])
    chunks = build_chunks(document, "doc1")

    for parent in chunks.parents:
        for paragraph in parent.text.split("\n\n"):
            assert paragraph.strip(), "packer produced an empty paragraph"
            for line in paragraph.split("\n"):
                assert line.strip() or line == "", "packer left a dangling newline"


def test_document_summary_is_bounded() -> None:
    document = _doc(
        [_section(i, f"Section {i}", "Body text. " * 500) for i in range(40)],
        title="Very long document",
    )
    chunks = build_chunks(document, "doc1")

    assert len(chunks.document_summary.text) <= 1200 + 800
    assert chunks.document_summary.kind == "document"
    assert "Very long document" in chunks.document_summary.text


def test_embed_text_carries_the_breadcrumb() -> None:
    document = _doc([_section(0, "Policy", "All vendors need approval.")])
    chunks = build_chunks(document, "doc1")

    for chunk in chunks.all_chunks:
        if chunk.level_path:
            assert chunk.embed_text().startswith(chunk.level_path)
        assert chunk.display()
