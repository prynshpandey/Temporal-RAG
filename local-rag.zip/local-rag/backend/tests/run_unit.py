"""Zero-dependency test runner.

The image ships no test framework on purpose: the backend image is runtime-only,
and these checks must run offline inside the container. Drop a module named
``test_*.py`` into this package and its ``test_*`` callables are picked up.

    make test-backend          # or: python -m tests.run_unit [pattern]
"""

from __future__ import annotations

import importlib
import inspect
import pkgutil
import sys
import time
import traceback
from typing import Callable

GREEN = "\033[32m"
RED = "\033[31m"
DIM = "\033[2m"
RESET = "\033[0m"


def _load(pattern: str | None) -> list[tuple[str, str, Callable]]:
    found: list[tuple[str, str, Callable]] = []
    package = importlib.import_module(__package__ or "tests")
    for module_info in pkgutil.iter_modules(list(package.__path__)):
        name = module_info.name
        if not name.startswith("test_"):
            continue
        if pattern and pattern not in name:
            continue
        module = importlib.import_module(f"{__package__}.{name}")
        for attr, value in sorted(vars(module).items()):
            if attr.startswith("test_") and inspect.isfunction(value) and value.__module__ == module.__name__:
                found.append((name, attr, value))
    return found


def main(argv: list[str]) -> int:
    pattern = argv[1] if len(argv) > 1 else None
    tests = _load(pattern)
    if not tests:
        print("no tests found" + (f" matching {pattern!r}" if pattern else ""))
        return 1

    passed = failed = 0
    started = time.perf_counter()
    for module_name, test_name, test in tests:
        try:
            test()
        except Exception:
            failed += 1
            print(f"{RED}FAIL{RESET} {module_name}.{test_name}")
            print("".join("      " + line for line in traceback.format_exc().splitlines(True)))
        else:
            passed += 1
            print(f"{GREEN}PASS{RESET} {module_name}.{test_name}")

    total = passed + failed
    colour = GREEN if not failed else RED
    print(
        f"\n{colour}{passed}/{total} unit checks passed{RESET} "
        f"{DIM}in {time.perf_counter() - started:.2f}s{RESET}"
    )
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
