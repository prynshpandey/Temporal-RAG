"""Unit checks for the parser primitives (no files, no network)."""

from __future__ import annotations

import tempfile
from pathlib import Path

from app.parsers.base import (
    build_sections_from_blocks,
    is_heading,
    normalize_text,
    read_text_file,
    sections_to_text,
    split_lines,
)


def test_normalize_text_collapses_runs_but_keeps_paragraphs() -> None:
    text = "a  \t b\r\n\r\n\r\n\r\nc   d"
    assert normalize_text(text) == "a b\n\nc d"


def test_normalize_text_trims() -> None:
    assert normalize_text("\n\n  hello  \n") == "hello"


def test_is_heading_atx_and_plain() -> None:
    assert is_heading("## Terms") == (True, 2, "Terms")
    assert is_heading("###### Six") == (True, 6, "Six")
    assert is_heading("Just a sentence.") == (False, 0, "")


def test_split_lines_strips_and_drops_empty_lines() -> None:
    assert split_lines(" a \n b\n\n c ") == ["a", "b", "c"]
    assert split_lines("\n\n") == []


def test_build_sections_groups_under_headings() -> None:
    blocks = [
        {"text": "preamble line", "level": 0},
        {"text": "Top", "level": 1, "title": "Top", "kind": "heading"},
        {"text": "body of top", "level": 0},
        {"text": "Sub", "level": 2, "title": "Sub", "kind": "heading"},
        {"text": "body of sub", "level": 0},
        {"text": "Second top", "level": 1, "title": "Second top", "kind": "heading"},
        {"text": "more body", "level": 0},
    ]
    sections = build_sections_from_blocks(blocks)

    # Flat outline with levels: every heading opens a section, and the text
    # before a subheading stays with the parent. Nesting is the chunker's job.
    assert [s.title for s in sections] == [None, "Top", "Sub", "Second top"]
    assert [s.level for s in sections] == [0, 1, 2, 1]
    assert sections[0].text == "preamble line"
    assert sections[1].text == "Top\nbody of top"
    assert sections[2].text == "Sub\nbody of sub"
    assert sections[3].text == "Second top\nmore body"
    assert [s.ordinal for s in sections] == [0, 1, 2, 3]
    assert [s.key for s in sections] == ["s0", "s1", "s2", "s3"]


def test_build_sections_keeps_nothing_dropped() -> None:
    blocks = [
        {"text": "one", "level": 0},
        {"text": "H", "level": 1, "title": "H", "kind": "heading"},
        {"text": "two", "level": 0},
        {"text": "three", "level": 0},
        {"text": "   ", "level": 0},
    ]
    joined = " ".join(s.text for s in build_sections_from_blocks(blocks))
    for word in ("one", "H", "two", "three"):
        assert word in joined
    assert "   " not in joined


def test_build_sections_empty_input() -> None:
    assert build_sections_from_blocks([]) == []
    assert build_sections_from_blocks([{"text": "", "level": 0}]) == []


def test_sections_to_text_never_duplicates_titles() -> None:
    blocks = [
        {"text": "Terms", "level": 1, "title": "Terms", "kind": "heading"},
        {"text": "Cash and stock.", "level": 0},
    ]
    sections = build_sections_from_blocks(blocks)
    text = sections_to_text(sections)
    assert text.count("Terms") == 1
    assert "Cash and stock." in text


def test_read_text_file_handles_boms_and_latin1() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        utf8 = root / "u8.txt"
        utf8.write_bytes("café".encode("utf-8-sig"))
        assert read_text_file(str(utf8)) == "café"

        utf16 = root / "u16.txt"
        utf16.write_bytes("héllo".encode("utf-16"))
        assert read_text_file(str(utf16)) == "héllo"

        # BOM-less UTF-16 still decodes, and short latin-1 never gets mistaken
        # for it.
        nobom = root / "nobom.txt"
        nobom.write_bytes("héllo wörld".encode("utf-16-le"))
        assert read_text_file(str(nobom)) == "héllo wörld"

        latin = root / "l1.txt"
        latin.write_bytes(b"caf\xe9")
        assert read_text_file(str(latin)) == "café"

        empty = root / "empty.txt"
        empty.write_bytes(b"")
        assert read_text_file(str(empty)) == ""
