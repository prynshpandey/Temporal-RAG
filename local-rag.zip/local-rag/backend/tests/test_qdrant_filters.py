"""The Qdrant filter must enforce the same temporal rules as the SQL query.

Retrieval fuses a SQL row with a Qdrant hit. If the two disagree about which
knowledge exists at a point in time, a correct filter in one of them is not
enough: the other one can still admit knowledge that should not be there. These
checks pin the filter to the SQL clauses in ``services/retrieval.py``.
"""

from __future__ import annotations

from app.clients import qdrant


def _clause(query_filter: dict, key: str) -> dict:
    """The single condition a clause contributes, whatever wrapper it sits in."""
    for group in ("must", "must_not"):
        for condition in query_filter.get(group) or []:
            if key in str(condition):
                return condition
    return {}


def test_expired_knowledge_is_excluded_at_a_point_in_time() -> int:
    """SQL: ``(valid_until IS NULL OR valid_until > as_of)``.

    The filter has to reject a chunk whose validity ended before the window.
    This was the missing clause: the payload carried no ``valid_until`` at all,
    so an expired document could still be returned by vector search.
    """
    f = qdrant.temporal_filter(as_of="2024-06-30")
    expired = _clause(f, "valid_until")
    assert expired, f"as_of filter ignores validity end: {f}"
    assert expired.get("key") == "valid_until"
    assert "range" in expired, f"must reject an expired range, got {expired}"
    assert "must_not" in f, f"expiry has to be an exclusion, got {f}"
    return 1


def test_not_yet_valid_knowledge_is_excluded_from_a_range() -> int:
    """SQL: ``(valid_from IS NULL OR valid_from <= end)``."""
    f = qdrant.temporal_filter(start="2024-01-01", end="2024-06-30")
    future = _clause(f, "valid_from")
    assert future, f"range filter ignores validity start: {f}"
    assert future.get("key") == "valid_from"
    assert "must_not" in f, f"expiry has to be an exclusion, got {f}"
    return 1


def test_undated_knowledge_falls_back_to_its_ingest_run() -> int:
    """Undated knowledge is known from when it was ingested, not never."""
    f = qdrant.temporal_filter(as_of="2024-06-30")
    blob = str(f)
    assert "request_ts" in blob, f"undated fallback lost: {f}"
    assert "doc_ts" in blob, blob
    return 1


def test_a_filter_with_no_window_still_excludes_nothing() -> int:
    """No window means no time restriction, only the document scope."""
    f = qdrant.temporal_filter(document_ids=["doc_a"])
    assert "must_not" not in f, f"nothing to exclude without a window: {f}"
    assert "min_should" not in f, f
    return 1


def test_every_temporal_payload_field_is_indexed() -> int:
    """A filter on an unindexed field still works, but scans the collection.

    So an unindexed date field is a silent performance cliff, not a correctness
    bug, which is why it is easy to leave behind.
    """
    for field in ("doc_ts", "event_ts", "request_ts", "valid_from", "valid_until"):
        assert field in qdrant.PAYLOAD_INDEXES, f"{field} is filtered on but not indexed"
        assert qdrant.PAYLOAD_INDEXES[field] == "datetime", field
    return 1
