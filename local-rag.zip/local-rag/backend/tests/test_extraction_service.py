"""Extraction must degrade, not fail, when the model cannot answer.

A dead Groq key, a rate limit or a local model that is still loading should cost
the document its entities and events, never the document itself. The dates that
drive point-in-time visibility are computed without the model, so they are
always there.
"""

from __future__ import annotations

import asyncio
from typing import Any

from app.errors import LlmFailed, LlmUnavailable
from app.services import extraction


def _plan(text: str, **overrides: Any) -> dict[str, Any]:
    plan: dict[str, Any] = {
        "document_id": "doc-test",
        "request_id": "req-test",
        "name": "plan.pdf",
        "document_type": "pdf",
        "source": "upload",
        "units": [
            {
                "level": 0,
                "chunk_id": "doc-test-d0000",
                "text": text,
                "point_id": 1,
            }
        ],
    }
    plan.update(overrides)
    return plan


def _with_broken_model(replacement: Any):
    original = extraction.complete_json
    extraction.complete_json = replacement  # type: ignore[assignment]
    return original


def test_dates_survive_a_dead_model() -> None:
    async def boom(*args: Any, **kwargs: Any) -> Any:
        raise LlmUnavailable("GROQ_API_KEY is not set")

    original = _with_broken_model(boom)
    try:
        result = asyncio.run(extraction.extract(_plan("Filed 2025-03-14. Revenue rose 18%.")))
    finally:
        extraction.complete_json = original  # type: ignore[assignment]

    assert result["document_date"] == "2025-03-14"
    assert result["temporal_certainty"] == "explicit"
    assert result["entities"] == [] and result["events"] == [] and result["facts"] == []
    assert "GROQ_API_KEY" in result["metadata"]["extraction_error"]
    assert result["summary"], "the deterministic summary is still usable"


def test_dates_survive_a_model_that_returns_nonsense() -> None:
    async def junk(*args: Any, **kwargs: Any) -> Any:
        return "I am sorry, I cannot do that."

    original = _with_broken_model(junk)
    try:
        result = asyncio.run(extraction.extract(_plan("Effective 2024-06-01 for all sites.")))
    finally:
        extraction.complete_json = original  # type: ignore[assignment]

    assert result["document_date"] == "2024-06-01"
    assert result["entities"] == []
    assert result["summary"]
    assert "not an object" in result["metadata"]["extraction_error"]


def test_an_empty_document_extracts_to_dates_only() -> None:
    result = asyncio.run(extraction.extract(_plan("")))
    assert result["document_date"] is None
    assert result["temporal_certainty"] == "unknown"
    assert result["entities"] == [] and result["events"] == []
    assert "extraction_error" not in result["metadata"]


def test_model_events_are_dropped_when_they_carry_an_unknown_date() -> None:
    async def with_events(*args: Any, **kwargs: Any) -> Any:
        return {
            "summary": "Annual report.",
            "entities": [{"name": "Helios Robotics", "entity_type": "organization"}],
            "events": [
                {"title": "Shipped Atlas", "event_date": "2025-06-01", "confidence": 0.9},
                {"title": "Founded", "event_date": "2011-03-15", "confidence": 0.8},
                {"title": "Undated plan", "event_date": None, "confidence": 0.5},
            ],
            "facts": [],
        }

    original = _with_broken_model(with_events)
    try:
        result = asyncio.run(
            extraction.extract(_plan("Shipped Atlas in 2025-06-01. The company was founded in 2011."))
        )
    finally:
        extraction.complete_json = original  # type: ignore[assignment]

    dated = {e["title"]: e["event_date"] for e in result["events"]}
    assert dated["Shipped Atlas"] == "2025-06-01", "a date in the text is kept"
    assert dated["Founded"] is None, (
        "the text only says 2011, so the model's 2011-03-01 reading is not trusted as a date"
    )
    assert dated["Undated plan"] is None
    assert [e["name"] for e in result["entities"]] == ["Helios Robotics"]


def test_duplicate_entities_are_collapsed() -> None:
    async def many(*args: Any, **kwargs: Any) -> Any:
        return {
            "summary": "s",
            "entities": [
                {"name": "Atlas", "entity_type": "product"},
                {"name": "atlas", "entity_type": "product"},
                {"name": "Atlas", "entity_type": "other"},
                {"name": "  ", "entity_type": "other"},
            ],
            "events": [],
            "facts": [],
        }

    original = _with_broken_model(many)
    try:
        result = asyncio.run(extraction.extract(_plan("Dated 2025-01-01.")))
    finally:
        extraction.complete_json = original  # type: ignore[assignment]

    assert [e["name"] for e in result["entities"]] == ["Atlas"]


def test_confidence_is_clamped() -> None:
    async def wild(*args: Any, **kwargs: Any) -> Any:
        return {
            "summary": "s",
            "entities": [],
            "events": [
                {"title": "a", "confidence": 4.2},
                {"title": "b", "confidence": -1},
                {"title": "c", "confidence": "not a number"},
            ],
            "facts": [],
        }

    original = _with_broken_model(wild)
    try:
        result = asyncio.run(extraction.extract(_plan("Dated 2025-01-01.")))
    finally:
        extraction.complete_json = original  # type: ignore[assignment]

    assert [e["confidence"] for e in result["events"]] == [1.0, 0.0, 0.5]


def test_an_llm_failure_does_not_escape_extract() -> None:
    async def boom(*args: Any, **kwargs: Any) -> Any:
        raise LlmFailed("The model did not return valid JSON")

    original = _with_broken_model(boom)
    try:
        result = asyncio.run(extraction.extract(_plan("Dated 2025-01-01.")))
    finally:
        extraction.complete_json = original  # type: ignore[assignment]

    assert result["document_date"] == "2025-01-01"
    assert "valid JSON" in result["metadata"]["extraction_error"]
