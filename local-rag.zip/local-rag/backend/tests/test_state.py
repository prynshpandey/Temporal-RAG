"""Snapshot reconstruction rules: revision grouping and honest exclusions.

Grouping decides which documents are treated as successive states of one thing.
A key that is too coarse merges unrelated documents into a fake history; one
that is too fine leaves every edition looking like a separate entity. Both
failure modes are silent, so both are pinned here.
"""

from __future__ import annotations

from datetime import date

from app.services import state as state_service


def test_successive_editions_of_one_report_share_a_family() -> int:
    keys = {
        state_service.family_key(f"helios-annual-report-{year}.md") for year in (2023, 2024, 2025)
    }
    assert len(keys) == 1, keys
    return 1


def test_different_subjects_do_not_share_a_family() -> int:
    assert state_service.family_key("helios-corvus-launch-note.md") != state_service.family_key(
        "helios-utrecht-office-closure.md"
    )
    return 1


def test_a_quarterly_update_is_not_the_annual_report() -> int:
    assert state_service.family_key("helios-q1-2025-update.md") != state_service.family_key(
        "helios-annual-report-2025.md"
    )
    return 1


def test_a_key_of_only_period_words_falls_back_to_the_filename() -> int:
    """"fy v" would chain every fiscal filing in the corpus into one family."""
    key = state_service.family_key("Report FY2023 v2.pdf")
    assert key == "report fy v", key
    assert len(key) >= 4, key


def test_a_key_never_becomes_empty_or_a_single_character() -> int:
    for name in ("2024.pdf", "a.md", "q3.pdf", "___", "x"):
        key = state_service.family_key(name)
        assert key, name
        assert len(key) >= 2 or key.isdigit(), (name, key)
    return 1


def test_grouping_marks_out_of_scope_editions_without_using_them() -> int:
    in_scope = [
        {"document_id": "d23", "name": "helios-annual-report-2023.md", "effective_date": date(2023, 12, 31), "temporal_certainty": "explicit"},
        {"document_id": "d24", "name": "helios-annual-report-2024.md", "effective_date": date(2024, 12, 31), "temporal_certainty": "explicit"},
    ]
    excluded = [
        {"document_id": "d25", "name": "helios-annual-report-2025.md", "effective_date": date(2025, 6, 30), "temporal_certainty": "explicit", "reason": "dated_after_window"},
    ]
    families = state_service._group_families(in_scope, excluded)
    family = next(f for f in families if f["key"] == state_service.family_key("helios-annual-report-2023.md"))
    assert family["in_scope_count"] == 2, family
    assert family["current_version"] == "d24", family["current_version"]
    versions = {v["document_id"]: v["in_scope"] for v in family["versions"]}
    assert versions == {"d23": True, "d24": True, "d25": False}, versions
    return 1


def test_expired_documents_do_not_join_a_revision_chain() -> int:
    in_scope = [{"document_id": "d1", "name": "policy v1.md", "effective_date": date(2023, 1, 1), "temporal_certainty": "explicit"}]
    excluded = [{"document_id": "d2", "name": "policy v2.md", "effective_date": date(2023, 6, 1), "temporal_certainty": "explicit", "reason": "expired_before_window"}]
    families = state_service._group_families(in_scope, excluded)
    total = sum(len(f["versions"]) for f in families)
    assert total == 1, families
    return 1


def test_an_empty_snapshot_says_the_corpus_was_empty_not_that_it_failed() -> int:
    snapshot = state_service.State(as_of=date(2019, 1, 1))
    body = snapshot.as_dict()
    assert body["summary"]["documents_in_scope"] == 0
    assert body["warnings"], "an empty snapshot must explain itself"
    assert "nothing was known" in body["warnings"][0], body["warnings"][0]
    return 1


def test_staleness_is_reported_when_the_corpus_has_gone_quiet() -> int:
    snapshot = state_service.State(
        as_of=date(2025, 12, 31),
        documents=[{"name": "old.md", "effective_date": date(2023, 1, 1)}],
    )
    body = snapshot.as_dict()
    assert body["summary"]["stale_days"] == 1095, body["summary"]
    assert any("not keeping up" in w for w in body["warnings"]), body["warnings"]
    return 1


def test_every_exclusion_carries_a_reason_a_reader_can_understand() -> int:
    for reason in ("dated_after_window", "expired_before_window", "unknown"):
        assert reason in state_service.REASON_TEXT, reason
        assert len(state_service.REASON_TEXT[reason]) > 10
    return 1
