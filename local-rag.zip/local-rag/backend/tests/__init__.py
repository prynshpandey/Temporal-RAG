"""Backend test suite (pytest-style, runnable without pytest too)."""
