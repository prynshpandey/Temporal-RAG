"""Metric extraction: the rules that keep a comparison from being wrong.

A diff that pairs "revenue 41.2" with "up 18 percent" is worse than no diff,
because it looks authoritative. Every rule here exists to prevent a wrong
pairing from being made silently, and each is pinned against the phrasings the
seed corpus actually uses.
"""

from __future__ import annotations

from datetime import date

from app.services import facts


def _by_label(sentence: str) -> dict[str, facts.Fact]:
    return {f.label: f for f in facts.extract_facts(sentence)}


def test_a_level_is_labelled_by_the_words_before_it() -> int:
    got = _by_label("Gross margin was 47.0 percent.")
    assert got["gross margin"].value == 47.0, got
    assert got["gross margin"].unit == "percent"
    return 1


def test_a_verb_before_the_number_does_not_hide_the_metric() -> int:
    """"was" and "reached" separate the name from the value; the walk must pass them."""
    got = _by_label("Revenue for FY2023 reached 41.2 million euro.")
    assert got["revenue"].value == 41.2, got
    assert got["revenue"].unit == "million_currency"
    return 1


def test_a_percentage_movement_is_never_compared_to_a_level() -> int:
    """"up 18 percent" is the size of a change, not a level in its own right."""
    sentence = "Revenue for FY2025 reached 57.4 million euro, up 18 percent on FY2024."
    got = _by_label(sentence)
    assert got["revenue"].value == 57.4, got
    assert "up 18 percent" not in sentence or all(
        f.value != 18 for f in facts.extract_facts(sentence)
    ), "the delta was kept as a level"
    return 1


def test_a_movement_with_to_is_a_new_level() -> int:
    """"fell to 3.6 percent" states where churn ended up."""
    got = _by_label("Customer churn fell to 3.6 percent in FY2024.")
    assert got["customer churn"].value == 3.6, got
    assert got["customer churn"].kind == "level"
    return 1


def test_a_second_number_in_a_sentence_is_not_given_a_garbled_label() -> int:
    """"euro million 41 2" is not a metric name; the second figure is dropped."""
    sentence = "Revenue for FY2023 reached 41.2 million euro, up from 36.4 million euro in FY2022."
    got = facts.extract_facts(sentence)
    assert [f.value for f in got] == [41.2], [(f.label, f.value) for f in got]
    return 1


def test_dates_are_not_metrics() -> int:
    for sentence in (
        "Corvus entered general availability in April 2024.",
        "The company was founded on 2011-03-15 in Utrecht.",
        "The report covers FY2023 and was published in 2024.",
    ):
        assert facts.extract_facts(sentence) == [], (sentence, facts.extract_facts(sentence))
    return 1


def test_verbs_and_connectors_never_become_metric_names() -> int:
    got = _by_label("Gross margin remained unchanged at 55.0 percent.")
    assert got["gross margin"].value == 55.0, got
    for junk in ("unchanged", "remain", "against", "further"):
        assert junk not in _by_label(f"Revenue rose to 10.0 percent against {junk} guidance."), junk
    return 1


def test_a_word_ending_in_s_is_not_mangled() -> int:
    """"atlas" must survive; naive plural folding turns it into "atla"."""
    key = facts._normalise_label(["Atlas"])
    assert key == "atlas", key
    assert facts._normalise_label(["revenue"]) == "revenue"
    return 1


def test_headcount_is_named_by_its_unit_when_the_subject_is_generic() -> int:
    got = _by_label("The company employs 465 employees at the end of 2024.")
    assert got["headcount"].value == 465, got
    assert got["headcount"].unit == "headcount"
    return 1


def test_a_specific_subject_survives_for_headcount() -> int:
    got = _by_label("Engineering headcount reached 88 employees.")
    assert "engineering" in got, got
    return 1


def test_inflected_stopwords_are_matched() -> int:
    for word in ("contributes", "employs", "reported", "grew"):
        assert facts._is_stopword(word), word
    assert not facts._is_stopword("revenue")
    return 1


def test_a_bare_number_with_no_unit_is_not_a_metric() -> int:
    assert facts.extract_facts("The office is on floor 4 and opened in 2011.") == []
    return 1


def test_facts_carry_provenance_from_their_passage() -> int:
    passages = [
        {
            "text": "Revenue for FY2024 reached 48.9 million euro.",
            "document_id": "d1",
            "document_name": "ar2024.md",
            "chunk_id": "c1",
            "effective_date": "2024-12-31",
        }
    ]
    got = facts.facts_from_passages(passages)
    assert len(got) == 1, got
    assert got[0].document_name == "ar2024.md"
    assert got[0].chunk_id == "c1"
    assert got[0].effective_date == date(2024, 12, 31)
    assert "48.9" in got[0].sentence
    return 1


def test_a_metric_is_grouped_by_label_and_unit() -> int:
    a = facts.Fact(label="revenue", value=41.2, unit="million_currency", effective_date=date(2023, 12, 31))
    b = facts.Fact(label="revenue", value=57.4, unit="million_currency", effective_date=date(2025, 6, 30))
    c = facts.Fact(label="revenue", value=12.0, unit="percent", effective_date=date(2025, 6, 30))
    grouped = facts.index_by_metric([a, b, c])
    assert set(grouped) == {"revenue|million_currency", "revenue|percent"}, set(grouped)
    assert grouped["revenue|million_currency"][0].value == 57.4, "newest evidence must sort first"
    return 1


def test_deduplication_keeps_the_most_confident_statement() -> int:
    passages = [
        {"text": "Revenue reached 41.2 million euro.", "document_id": "d1", "chunk_id": "c1"},
        {"text": "Revenue reached 41.2 million euro.", "document_id": "d1", "chunk_id": "c2"},
    ]
    got = facts.deduplicate(facts.facts_from_passages(passages))
    assert len(got) == 2, [(f.chunk_id) for f in got]
    return 1


def test_deltas_never_enter_the_comparable_set() -> int:
    delta = facts.Fact(label="increase", value=18, unit="percent", kind="delta")
    assert facts.deduplicate([delta]) == []
    return 1


# ------------------------------------------------- a quantity named before the figure
# "the number of employees was 180" is the commonest way to state a headcount, and
# the extractor used to require a unit *after* the number, so it found nothing.
def test_headcount_named_before_the_number() -> int:
    got = _by_label(
        "At the end of FY2023 the number of employees was 180."
    )
    assert got["headcount"].value == 180, got
    return 1


def test_headcount_after_period_scaffolding() -> int:
    """'end of' sits between the metric and the figure and names nothing."""
    got = _by_label(
        "employees at the end of FY2025 was 260"
    )
    assert got["headcount"].value == 260, got
    return 1


def test_both_phrasings_produce_one_metric() -> int:
    """Otherwise a comparison between them reports no change, which is a lie."""
    a = facts.extract_facts("The company has 260 employees.")
    b = facts.extract_facts("the number of employees was 260")
    assert {f.label for f in a} == {f.label for f in b} == {"headcount"}, (a, b)
    return 1


def test_qualifier_before_the_quantity_noun_is_kept() -> int:
    """64 research staff are not the same metric as 260 total staff."""
    got = _by_label("The number of research employees was 64.")
    assert "headcount" not in got, got
    assert got["research"].value == 64, got
    return 1


# ------------------------------------------------------------------- dates
def test_day_of_month_is_not_a_count() -> int:
    """'close its Utrecht office on 31 December 2023' is a date, not 31 offices."""
    found = facts.extract_facts(
        "Helios Robotics will close its Utrecht office on 31 December 2023."
    )
    assert not [f for f in found if f.value == 31], found
    return 1


def test_year_at_the_end_of_a_period_is_not_a_count() -> int:
    """The bare year looks like a metric until you read what precedes it."""
    found = facts.extract_facts("The company employs 465 employees at the end of 2024.")
    assert [f.value for f in found] == [465], found
    assert found[0].label == "headcount", found
    return 1


def test_a_figure_does_not_lend_its_name_across_a_number() -> int:
    found = facts.extract_facts("Headcount reached 214 in 2023.")
    got = _by_label("Headcount reached 214 in 2023.")
    assert got.get("headcount") and got["headcount"].value == 214, got
    assert not [f for f in found if f.value == 2023], found
    return 1
