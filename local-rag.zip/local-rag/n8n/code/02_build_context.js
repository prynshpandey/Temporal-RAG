// ---------------------------------------------------------------------------
// Query step 5 - turn the Qdrant response into (a) the context block that goes
// into the prompt and (b) the source list the UI displays.
//
// Nothing is passed to Llama when retrieval came back empty or when every hit
// fell below MIN_SCORE: that is what keeps the model from answering out of its
// own pretrained knowledge.
// ---------------------------------------------------------------------------

const config = $('Query Config').first().json;
const response = $input.first().json;

function fail(code, message, hint) {
  return [{ json: { ok: false, error: { code, message, hint: hint || null } } }];
}

if (response && response.error) {
  const status = response.status !== undefined ? ' (HTTP ' + response.status + ')' : '';
  return fail(
    'qdrant_unavailable',
    'Qdrant did not accept the search request' + status + ': ' + String((response.error && (response.error.message || response.error)) || 'unknown error'),
    'Check that Qdrant is running at ' + config.qdrant_url + ' and that the collection exists: python3 scripts/setup_qdrant.py'
  );
}

const hits = response && response.result && Array.isArray(response.result) ? response.result : [];

function render(list) {
  return list
    .map((s) => '[Retrieved Chunk ' + s.rank + ' | document: ' + s.document + ' | page: ' + (s.page != null ? s.page : 'unknown') +
      ' | chunk_id: ' + s.chunk_id + ' | similarity: ' + s.score + ']\n' + s.text)
    .join('\n\n');
}

if (hits.length === 0) {
  return [{
    json: {
      ok: true,
      no_context: true,
      reason: 'no_results',
      context: '',
      context_chars: 0,
      context_truncated: false,
      sources: [],
      dropped_sources: [],
      search_ms: response.time != null ? Math.round(response.time * 1000) : null,
    },
  }];
}

const sources = hits.map((hit, index) => {
  const payload = hit.payload || {};
  return {
    rank: index + 1,
    document: payload.document_name || 'unknown document',
    document_id: payload.document_id || null,
    page: payload.page != null ? payload.page : null,
    page_known: payload.page_known === true,
    chunk_id: payload.chunk_id || null,
    chunk_index: payload.chunk_index != null ? payload.chunk_index : null,
    score: typeof hit.score === 'number' ? Math.round(hit.score * 10000) / 10000 : null,
    char_count: payload.char_count != null ? payload.char_count : null,
    indexed_at: payload.indexed_at || null,
    text: payload.text || '',
  };
});

// Guard the context window: keep the strongest chunks that fit.
const used = [];
let budget = 0;
let truncated = false;
for (const source of sources) {
  const cost = source.text.length + source.document.length + 120;
  if (budget + cost > config.max_context_chars) {
    truncated = true;
    break;
  }
  budget += cost;
  used.push(source);
}

const context = render(used);

return [{
  json: {
    ok: true,
    no_context: used.length === 0,
    reason: used.length === 0 ? 'below_score_threshold' : null,
    context,
    context_chars: context.length,
    context_truncated: truncated,
    sources: used,
    dropped_sources: truncated ? sources.slice(used.length) : [],
    search_ms: response.time != null ? Math.round(response.time * 1000) : null,
  },
}];
