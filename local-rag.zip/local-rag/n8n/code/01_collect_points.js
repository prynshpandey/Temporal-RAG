// ---------------------------------------------------------------------------
// Ingest step 7 - run after the embedding loop.
//
// The loop parked its points in the execution's workflow static data (see
// 01_normalize_embeddings.js).  Read them back, order them by chunk index and
// hand them to Qdrant in batches: the HTTP Request node that follows runs once
// per item, so several small upserts keep the request bodies small instead of
// posting one huge JSON document.
// ---------------------------------------------------------------------------

const upload = $('Validate Upload').first().json;
const documentId = upload.document_id;
const upsertBatch = Math.max(1, Number($env.QDRANT_UPSERT_BATCH || 64));

const staticData = $getWorkflowStaticData('global');
const state = (staticData.ragIngest || {})[documentId] || null;

if (!state || !state.points) {
  return [{
    json: {
      ok: false,
      error: {
        code: 'no_chunks_produced',
        message: 'The embedding loop returned no points for "' + upload.document_name + '".',
        hint: 'Check EMBED_BATCH_SIZE, and inspect the Normalize Embeddings node output in this execution.',
      },
    },
  }];
}

if (state.error) {
  return [{ json: { ok: false, error: state.error } }];
}

const points = Object.keys(state.points)
  .map((key) => state.points[key])
  .sort((a, b) => {
    const ia = a.payload && Number(a.payload.chunk_index);
    const ib = b.payload && Number(b.payload.chunk_index);
    return (Number.isFinite(ia) ? ia : 0) - (Number.isFinite(ib) ? ib : 0);
  });

if (points.length === 0) {
  return [{
    json: {
      ok: false,
      error: {
        code: 'no_chunks_produced',
        message: 'The embedding loop returned no points for "' + upload.document_name + '".',
        hint: 'Check EMBED_BATCH_SIZE, and inspect the Normalize Embeddings node output in this execution.',
      },
    },
  }];
}

const out = [];
for (let offset = 0; offset < points.length; offset += upsertBatch) {
  const slice = points.slice(offset, offset + upsertBatch);
  out.push({
    json: {
      ok: true,
      points: slice,
      chunk_count: points.length,
      vector_dim: points[0].vector.length,
      batch_index: Math.floor(offset / upsertBatch),
      batch_count: Math.ceil(points.length / upsertBatch),
      document_id: documentId,
      document_name: upload.document_name,
      sha256: upload.sha256,
      size_bytes: upload.size_bytes,
      started_at: upload.started_at,
    },
  });
}

return out;
