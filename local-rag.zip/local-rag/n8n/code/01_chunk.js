// ---------------------------------------------------------------------------
// Ingest step 4 - boundary aware chunking.
//
// Strategy (in order of preference):
//   1. normalise whitespace / unicode so offsets are stable
//   2. drop running headers & footers that repeat on >= 60% of pages
//   3. pack whole paragraphs into a chunk until CHUNK_SIZE is reached
//   4. an oversized paragraph is split on sentence boundaries
//   5. the tail of every chunk (CHUNK_OVERLAP characters, snapped to a
//      sentence or word start) is prepended to the next chunk of the same page
//      so that facts crossing a boundary stay retrievable
//
// Why these defaults: CHUNK_SIZE=1200 characters is roughly 300 tokens, which
// sits inside nomic-embed-text's 8192 token window while still being small
// enough that a 1000 character paragraph is rarely diluted by unrelated
// neighbours. A 200 character overlap (~17%) is enough to carry a sentence
// that straddles a cut without flooding the index with duplicates.
// ---------------------------------------------------------------------------

const chunkSize = Number($env.CHUNK_SIZE || 1200);
const overlap = Math.max(0, Number($env.CHUNK_OVERLAP || 200));
const minChunkChars = Number($env.MIN_CHUNK_CHARS || 120);
const stripMargins = ($env.STRIP_REPEATED_MARGINS || 'true') !== 'false';
const maxChunkChars = Math.max(chunkSize, Math.round(chunkSize * 1.35));

function normalize(text) {
  return text
    .replace(/\r\n?/g, '\n')
    .replace(/[\u00a0\u2007\u202f]/g, ' ')
    .replace(/[\u2018\u2019]/g, "'")
    .replace(/[\u201c\u201d]/g, '"')
    .replace(/[\u2010\u2011\u2012\u2013\u2014]/g, '-')
    .replace(/[\u2022\u00b7]/g, '*')
    .split('\n').map((line) => line.replace(/[ \t]+/g, ' ').trim()).join('\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

// Running headers / footers / page numbers: identical short lines that show up
// at the very top or bottom of most pages carry no retrieval value and push
// real sentences out of the chunk budget. Digits are masked before comparing so
// that "Page 3 of 12" / "Page 4 of 12" counts as one repeated margin.
function marginKey(line) {
  return line.replace(/\d+/g, '#');
}

function stripRepeatedMargins(pages) {
  if (!stripMargins || pages.length < 3) return pages;

  const counts = new Map();
  for (const p of pages) {
    const lines = p.text.split('\n').map((l) => l.trim()).filter(Boolean);
    if (lines.length < 4) continue;
    const candidates = new Set();
    for (const i of [0, 1, lines.length - 2, lines.length - 1]) {
      const line = lines[i];
      if (line && line.length <= 120) candidates.add(marginKey(line));
    }
    for (const c of candidates) counts.set(c, (counts.get(c) || 0) + 1);
  }

  const threshold = Math.max(3, Math.ceil(pages.length * 0.6));
  const repeated = new Set();
  for (const [line, count] of counts.entries()) {
    if (count >= threshold) repeated.add(line);
  }
  if (repeated.size === 0) return pages;

  return pages.map((p) => ({
    page: p.page,
    text: p.text
      .split('\n')
      .filter((line) => !repeated.has(marginKey(line.trim())))
      .join('\n'),
  }));
}

function splitSentences(text) {
  const parts = text.split(/(?<=[.!?;])\s+/).filter((s) => s.trim().length > 0);
  return parts.length > 0 ? parts : [text];
}

// Last `overlap` characters of a chunk, starting at a sentence or word start.
function tailForOverlap(text) {
  if (overlap <= 0 || text.length <= overlap) return '';
  const window = text.slice(text.length - overlap);
  const sentence = window.match(/^[\s\S]*?[.!?]["')\]]?\s+/);
  let cut = sentence ? sentence[0].length : -1;
  if (cut < Math.floor(overlap * 0.3)) {
    const space = window.indexOf(' ');
    cut = space > 0 ? space + 1 : -1;
  }
  const tail = cut > 0 ? window.slice(cut) : window;
  return tail.trim();
}

// Greedily pack pieces into chunks. `cursor` walks the page text so that the
// reported char_start / char_end refer to real positions in the page.
function chunkPage(pageText, pageNumber) {
  const paragraphs = pageText.split(/\n{2,}/).map((p) => p.trim()).filter(Boolean);
  const joined = paragraphs.join('\n\n');
  const out = [];
  let buffer = '';
  let bufferStart = 0;
  let cursor = 0;

  const flush = (end) => {
    if (buffer.trim().length > 0) {
      out.push({ text: buffer.trim(), start: bufferStart, end });
    }
  };

  const take = (piece, pieceStart) => {
    if (!piece) return;
    if (buffer && buffer.length + 2 + piece.length > maxChunkChars) {
      const previousLength = buffer.length;
      flush(pieceStart);
      // Carry the overlap only when it still fits; a piece that is already at
      // the limit must not push the chunk past CHUNK_SIZE.
      const tail = tailForOverlap(buffer);
      buffer = tail && tail.length + 2 + piece.length <= maxChunkChars ? tail : '';
      // Anchor the carried-over text where it actually came from.
      bufferStart = Math.max(0, pieceStart - previousLength);
      if (bufferStart > pieceStart) bufferStart = pieceStart;
    }
    buffer = buffer ? buffer + '\n\n' + piece : piece;
  };

  for (const paragraph of paragraphs) {
    const pieceStart = cursor;
    cursor += paragraph.length + 2;

    if (paragraph.length <= maxChunkChars) {
      take(paragraph, pieceStart);
      continue;
    }

    // Oversized paragraph (long table row, unbroken column): fall back to
    // sentence boundaries, then to hard cuts.
    let sentenceBuffer = '';
    for (const sentence of splitSentences(paragraph)) {
      if (sentence.length > maxChunkChars) {
        if (sentenceBuffer) {
          take(sentenceBuffer, pieceStart);
          sentenceBuffer = '';
        }
        for (let i = 0; i < sentence.length; i += maxChunkChars) {
          take(sentence.slice(i, i + maxChunkChars), pieceStart + i);
        }
        continue;
      }
      if (sentenceBuffer && sentenceBuffer.length + 1 + sentence.length > maxChunkChars) {
        take(sentenceBuffer, pieceStart);
        sentenceBuffer = sentence;
      } else {
        sentenceBuffer = sentenceBuffer ? sentenceBuffer + ' ' + sentence : sentence;
      }
    }
    if (sentenceBuffer) take(sentenceBuffer, pieceStart);
  }

  flush(joined.length);

  // Drop fragments that carry almost no information (a trailing footer, a
  // single orphan line). Always keep at least one chunk for the page.
  const meaningful = out.filter((c) => c.text.length >= minChunkChars);
  return meaningful.length > 0 ? meaningful : out;
}

const source = $input.first().json;
const normalizedPages = source.pages.map((p) => ({ page: p.page, text: normalize(p.text) }));
const stripped = stripRepeatedMargins(normalizedPages);

const chunks = [];
let chunkIndex = 0;

  for (const page of stripped) {
    const pageChunks = chunkPage(page.text, page.page);
    for (const chunk of pageChunks) {
      chunkIndex += 1;
      const pageLabel = page.page == null ? 'x' : page.page;
      chunks.push({
        json: {
          ok: true,
          chunk_id: `${source.document_id}-p${pageLabel}-c${chunkIndex}`,
          chunk_index: chunkIndex,
          document_id: source.document_id,
          document_name: source.document_name,
          sha256: source.sha256,
          page: page.page,
          page_known: page.page != null,
          char_start: chunk.start,
          char_end: chunk.end,
          char_count: chunk.text.length,
          word_count: chunk.text.split(/\s+/).filter(Boolean).length,
          text: chunk.text,
        },
      });
    }
  }

return chunks;
