// ---------------------------------------------------------------------------
// BTM ingest step 4 - park one batch of embeddings in the execution's state.
//
// Runs inside the batch loop, once per /api/internal/embed response. The vectors
// are keyed by the point ids the parser already assigned, so the upsert step
// cannot pair a vector with the wrong chunk even if batches arrive out of order.
// ---------------------------------------------------------------------------

const plan = $('Parse Document').first().json;
const response = $input.first().json;

// The HTTP node replaced the batch item with its response, so the point ids come
// back from the endpoint rather than from the loop input: the request sent them
// and the endpoint echoed them next to the vectors.
const ids = response.ids;

if (response.error || !Array.isArray(response.vectors)) {
  return [{
    json: {
      ok: false,
      error: {
        code: 'embedding_failed',
        message: 'The embedding endpoint did not return vectors: '
          + String((response.error && (response.error.message || response.error)) || 'no vectors in the response'),
        hint: 'Check that Ollama is reachable from the backend and that the model is pulled.',
      },
    },
  }];
}

if (!Array.isArray(ids)) {
  return [{
    json: {
      ok: false,
      error: {
        code: 'embedding_ids_missing',
        message: 'The embed endpoint returned no ids, so vectors cannot be matched to chunks.',
        hint: 'Send "ids" with the texts; the backend echoes them back with the vectors.',
      },
    },
  }];
}

const vectors = response.vectors;
if (vectors.length !== ids.length) {
  return [{
    json: {
      ok: false,
      error: {
        code: 'embedding_mismatch',
        message: 'Asked for ' + ids.length + ' embeddings and got ' + vectors.length + '.',
        hint: 'The text sent and the vectors returned do not line up; check EMBED_BATCH_SIZE.',
      },
    },
  }];
}

const staticData = $getWorkflowStaticData('global');
const state = (staticData.btmIngest || {})[plan.document_id];
if (!state) {
  return [{
    json: {
      ok: false,
      error: {
        code: 'ingest_state_lost',
        message: 'The ingest state for ' + plan.document_id + ' disappeared mid-loop.',
        hint: 'Another execution for the same document may have overwritten it.',
      },
    },
  }];
}

ids.forEach((pointId, index) => {
  state.vectors[String(pointId)] = vectors[index];
});

return [{ json: { ok: true, stored: vectors.length } }];
