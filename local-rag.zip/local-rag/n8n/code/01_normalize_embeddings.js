// ---------------------------------------------------------------------------
// Ingest step 6 - pair every embedding with its metadata and turn the pair
// into a Qdrant point.
//
// Qdrant point ids must be an unsigned integer or a UUID, so the human readable
// chunk_id lives in the payload while the point id is a deterministic 53-bit
// integer derived from document_id + chunk_id.  Deterministic ids make a
// re-upload an upsert of the same points instead of a second copy of the data.
//
// The node runs once per loop iteration, so the points of every batch are
// parked in the execution's workflow static data, keyed by point id.  That
// keeps memory bounded (only one batch of embeddings is alive at a time) and
// makes a re-run of the same execution idempotent instead of duplicating.
// ---------------------------------------------------------------------------

const batch = $('Build Embed Batch').first().json;
const response = $input.first().json;

const expectedDim = Number($env.QDRANT_VECTOR_SIZE || 768);
const embeddingModel = batch.embedding_model;
const documentId = batch.document_id;

function fnv1a32(str, seed) {
  let hash = seed >>> 0;
  for (let i = 0; i < str.length; i++) {
    hash ^= str.charCodeAt(i);
    hash = Math.imul(hash, 0x01000193) >>> 0;
  }
  return hash >>> 0;
}

function pointId(documentId, chunkId) {
  const key = documentId + ':' + chunkId;
  const high = fnv1a32(key, 0x811c9dc5) % 0x1fffff; // 21 bits
  const low = fnv1a32(key, 0x9dc5811c);            // 32 bits
  return high * 4294967296 + low;                   // <= 2^53, exact in JS
}

function fail(code, message, hint) {
  const error = { code, message, hint: hint || null };
  const staticData = $getWorkflowStaticData('global');
  staticData.ragIngest = staticData.ragIngest || {};
  staticData.ragIngest[documentId] = Object.assign({}, staticData.ragIngest[documentId], { error });
  return [{ json: { ok: false, error } }];
}

if (response && response.error) {
  return fail('embedding_failed', String(response.error), `Check that Ollama is running (${$env.OLLAMA_URL || 'http://localhost:11434'}) and that the model is pulled: ollama pull ${embeddingModel}`);
}

const vectors = response && Array.isArray(response.embeddings) ? response.embeddings : null;
if (!vectors) {
  return fail('embedding_failed', 'Ollama returned no embeddings array.', `Expected {"embeddings": [[...]]} from POST ${$env.OLLAMA_URL || 'http://localhost:11434'}/api/embed`);
}
if (vectors.length !== batch.input.length) {
  return fail('embedding_failed', `Ollama returned ${vectors.length} embeddings for ${batch.input.length} chunks.`, 'The batch was not embedded completely; retry the upload.');
}
if (vectors[0].length !== expectedDim) {
  return fail(
    'embedding_dimension_mismatch',
    `The embedding model "${embeddingModel}" produced ${vectors[0].length}-dimension vectors but QDRANT_VECTOR_SIZE is ${expectedDim}.`,
    'Use the same model for indexing and querying, or run `make qdrant-reset` after changing QDRANT_VECTOR_SIZE / EMBEDDING_MODEL.'
  );
}

const indexedAt = new Date().toISOString();
const points = [];
for (let i = 0; i < vectors.length; i++) {
  const meta = batch.point_meta[i];
  points.push({
    id: pointId(meta.document_id, meta.chunk_id),
    vector: vectors[i],
    payload: {
      text: meta.text,
      document_id: meta.document_id,
      document_name: meta.document_name,
      page: meta.page == null ? null : meta.page,
      page_known: meta.page_known,
      chunk_id: meta.chunk_id,
      chunk_index: meta.chunk_index,
      char_start: meta.char_start,
      char_end: meta.char_end,
      char_count: meta.char_count,
      word_count: meta.word_count,
      sha256: meta.sha256,
      embedding_model: embeddingModel,
      indexed_at: indexedAt,
      chunker: { size: Number($env.CHUNK_SIZE || 1200), overlap: Number($env.CHUNK_OVERLAP || 200) },
    },
  });
}

const staticData = $getWorkflowStaticData('global');
staticData.ragIngest = staticData.ragIngest || {};
const state = Object.assign({ points: {}, error: null }, staticData.ragIngest[documentId]);
for (const point of points) {
  state.points[String(point.id)] = point;
}
staticData.ragIngest[documentId] = state;

return [{ json: { ok: true, points, batch_size: points.length, vector_dim: vectors[0].length } }];
