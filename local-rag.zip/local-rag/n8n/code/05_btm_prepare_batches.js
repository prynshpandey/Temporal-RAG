// ---------------------------------------------------------------------------
// BTM ingest step 3 - turn the backend's parse plan into embedding batches.
//
// The plan already carries the four-level chunk tree, so this node has no
// parsing or chunking to do: it slices the units into request-sized batches and
// hands each to the backend's /api/internal/embed.
//
// The plan itself is deliberately NOT copied into every batch. It is large
// (every unit's text) and it is still reachable at any later node through
// $('Parse Document'), so repeating it here would only bloat the execution.
// ---------------------------------------------------------------------------

const plan = $('Parse Document').first().json;
const extracted = $('Extract Metadata').first().json;

if (!plan || !Array.isArray(plan.units) || plan.units.length === 0) {
  return [{
    json: {
      ok: false,
      error: {
        code: 'no_chunks_produced',
        message: 'The parser returned no units for "' + (plan ? plan.name : 'the upload') + '".',
        hint: 'Check the Parse Document node output: a scanned PDF has no text layer.',
      },
    },
  }];
}

const batchSize = Math.max(1, Number($env.EMBED_BATCH_SIZE || 8));
const units = plan.units;
const batches = [];

for (let offset = 0; offset < units.length; offset += batchSize) {
  const slice = units.slice(offset, offset + batchSize);
  batches.push({
    json: {
      ok: true,
      batch_index: batches.length,
      batch_count: Math.ceil(units.length / batchSize),
      point_ids: slice.map((unit) => unit.point_id),
      texts: slice.map((unit) => unit.text),
    },
  });
}

if (batches.length === 0) {
  return [{
    json: {
      ok: false,
      error: {
        code: 'no_chunks_produced',
        message: 'The plan produced zero embedding batches.',
        hint: 'EMBED_BATCH_SIZE must be a positive number.',
      },
    },
  }];
}

// Remember what the caller will need later, while the run is still cheap.
const staticData = $getWorkflowStaticData('global');
(staticData.btmIngest || (staticData.btmIngest = {}))[plan.document_id] = {
  request_id: plan.request_id,
  document_id: plan.document_id,
  name: plan.name,
  document_type: plan.document_type,
  unit_count: units.length,
  batch_count: batches.length,
  effective_date: extracted.document_date || null,
  temporal_certainty: extracted.temporal_certainty || 'unknown',
  started_at: new Date().toISOString(),
  vectors: {},
  error: null,
};

return batches;
