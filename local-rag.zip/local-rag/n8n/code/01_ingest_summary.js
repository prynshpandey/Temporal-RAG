// ---------------------------------------------------------------------------
// Ingest step 10 - build the response returned to the browser.
// ---------------------------------------------------------------------------

const collectionInfo = $input.first().json;                 // GET /collections/{name}
const stats = $('Check Upsert').first().json;               // reduced upsert result
const upload = $('Validate Upload').first().json;
const pages = $('Validate Text').first().json;

if (!stats.ok) {
  return [{
    json: {
      status: 'error',
      document_id: upload.document_id || null,
      document_name: upload.document_name || null,
      error: stats.error,
    },
  }];
}

const info = collectionInfo && collectionInfo.result ? collectionInfo.result : null;
const durationMs = Date.now() - new Date(upload.started_at).getTime();

return [{
  json: {
    status: 'indexed',
    document_id: stats.document_id,
    document_name: stats.document_name,
    sha256: stats.sha256,
    size_bytes: stats.size_bytes,
    page_count: pages.page_count,
    page_known: pages.page_known,
    extracted_chars: pages.total_chars,
    chunk_count: stats.chunk_count,
    vector_dim: stats.vector_dim,
    upsert_batches: stats.upsert_batches,
    embedding_model: $env.EMBEDDING_MODEL || 'nomic-embed-text',
    collection: $env.QDRANT_COLLECTION || 'local_rag_chunks',
    points_in_collection: info ? info.points_count : null,
    indexed_vectors_count: info ? info.indexed_vectors_count : null,
    collection_status: info ? info.status : null,
    qdrant_operation_id: stats.operation_id || null,
    duration_ms: durationMs,
  },
}];
