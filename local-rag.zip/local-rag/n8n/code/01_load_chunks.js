// ---------------------------------------------------------------------------
// Ingest step 4b - hand the chunks to the embedding loop.
//
// The Qdrant delete request above produced its own response items, so the chunk
// items it replaced are taken back from the chunking node before the loop
// starts batching them for /api/embed.
// ---------------------------------------------------------------------------

const chunks = $('Chunk Document').all();

return chunks;
