// ---------------------------------------------------------------------------
// Query step 7 - assemble the RAG prompt.
//
// The system prompt is injected at build time from prompts/system_prompt.txt
// (see scripts/build_workflows.py) so it stays editable as a plain text file
// and visible as a node parameter inside n8n.
// ---------------------------------------------------------------------------

const SYSTEM_PROMPT = __SYSTEM_PROMPT__;

const context = $input.first().json;
const config = $('Query Config').first().json;

const userPrompt = [
  'CONTEXT:',
  context.context,
  '',
  'QUESTION:',
  config.question,
  '',
  'ANSWER:',
].join('\n');

return [{
  json: {
    ok: true,
    system_prompt: SYSTEM_PROMPT,
    user_prompt: userPrompt,
    context_chars: context.context_chars,
    context_truncated: context.context_truncated,
    sources: context.sources,
    dropped_sources: context.dropped_sources,
    search_ms: context.search_ms,
  },
}];
