// ---------------------------------------------------------------------------
// Library step 1 - list the indexed documents by scrolling Qdrant's payloads
// and grouping the points by document_id.  Proves that ingestion is persistent
// and gives the UI something to show between runs.
// ---------------------------------------------------------------------------

const collection = $env.QDRANT_COLLECTION || 'local_rag_chunks';
const response = $input.first().json;

if (response && response.error) {
  return [{
    json: {
      ok: false,
      error: {
        code: 'qdrant_unavailable',
        message: 'Could not read the collection: ' + String((response.error && (response.error.message || response.error)) || 'unknown error'),
        hint: 'Start Qdrant (docker compose up -d qdrant) and create the collection: python3 scripts/setup_qdrant.py',
      },
    },
  }];
}

const points = response && response.result && Array.isArray(response.result.points) ? response.result.points : [];
const byDocument = new Map();

for (const point of points) {
  const payload = (point && point.payload) || {};
  const id = payload.document_id || 'unknown';
  if (!byDocument.has(id)) {
    byDocument.set(id, {
      document_id: id,
      document_name: payload.document_name || 'unknown',
      sha256: payload.sha256 || null,
      size_bytes: null,
      chunk_count: 0,
      pages: new Set(),
      page_known: false,
      indexed_at: payload.indexed_at || null,
      embedding_model: payload.embedding_model || null,
    });
  }
  const entry = byDocument.get(id);
  entry.chunk_count += 1;
  if (payload.page != null) {
    entry.pages.add(payload.page);
    entry.page_known = true;
  }
  if (!entry.indexed_at || (payload.indexed_at && payload.indexed_at > entry.indexed_at)) {
    entry.indexed_at = payload.indexed_at || entry.indexed_at;
  }
}

const documents = Array.from(byDocument.values())
  .map((entry) => ({
    document_id: entry.document_id,
    document_name: entry.document_name,
    sha256: entry.sha256,
    chunk_count: entry.chunk_count,
    page_count: entry.pages.size,
    page_known: entry.page_known,
    indexed_at: entry.indexed_at,
    embedding_model: entry.embedding_model,
  }))
  .sort((a, b) => String(b.indexed_at || '').localeCompare(String(a.indexed_at || '')));

return [{
  json: {
    ok: true,
    collection,
    total_chunks: points.length,
    total_documents: documents.length,
    documents,
  },
}];
