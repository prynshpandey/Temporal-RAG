// ---------------------------------------------------------------------------
// Library step 2 - delete every chunk of one document (Qdrant delete-by-filter)
// and report the outcome.
// ---------------------------------------------------------------------------

const request = $('Delete Document Request').first().json;
const response = $input.first().json;
const collection = $env.QDRANT_COLLECTION || 'local_rag_chunks';

// The request node normalises the id to a flat field; the nested shapes are
// only used when this node is run against a raw webhook payload.
const incoming = (request && Object.prototype.hasOwnProperty.call(request, 'query') ? request.query : null) || {};
const body = (request && request.body && typeof request.body === 'object' ? request.body : {}) || {};
const documentId = (request && request.document_id) || incoming.document_id || body.document_id || null;

if (!documentId) {
  return [{
    json: {
      ok: false,
      error: {
        code: 'missing_document_id',
        message: 'No document_id was supplied.',
        hint: 'Call DELETE /webhook/rag/document?document_id=doc_xxxxxxxx',
      },
    },
  }];
}

if (response && response.error) {
  return [{
    json: {
      ok: false,
      error: {
        code: 'qdrant_delete_failed',
        message: 'Qdrant refused the delete: ' + String((response.error && (response.error.message || response.error)) || 'unknown error'),
        hint: 'Check that Qdrant is running and that ' + collection + ' exists.',
      },
    },
  }];
}

return [{
  json: {
    ok: true,
    status: 'deleted',
    collection,
    document_id: documentId,
  },
}];
