// ---------------------------------------------------------------------------
// BTM ingest step 5 - assemble the Qdrant points and stamp the temporal fields.
//
// Two things are joined here: the plan (chunk tree, ids, structure) and the
// vectors collected during the loop. The payload is what the retrieval side
// filters on, so the dates written here are the ones that make an as-of query
// show a document only from the moment its knowledge existed.
//
// Parent ids are embedded in child payloads so retrieval can walk a child up to
// its parent without a second round trip.
// ---------------------------------------------------------------------------

const plan = $('Parse Document').first().json;
const extracted = $('Extract Metadata').first().json;
const staticData = $getWorkflowStaticData('global');
const state = (staticData.btmIngest || {})[plan.document_id] || null;

if (!state || !state.vectors) {
  return [{
    json: {
      ok: false,
      error: {
        code: 'no_vectors_collected',
        message: 'The embedding loop returned no vectors for "' + plan.name + '".',
        hint: 'Inspect the Embed Texts node output in this execution.',
      },
    },
  }];
}

if (state.error) {
  return [{ json: { ok: false, error: state.error } }];
}

// A document is visible from the day it was written, not from the day its most
// interesting event happened: knowledge about a future event does not exist yet.
const effectiveDate = extracted.document_date || null;
const eventDate = extracted.event_date || null;
const entityNames = (extracted.entities || [])
  .map((entity) => entity && entity.name)
  .filter(Boolean)
  .slice(0, 12);

const points = plan.units
  .filter((unit) => state.vectors[String(unit.point_id)])
  .map((unit) => ({
    id: unit.point_id,
    vector: state.vectors[String(unit.point_id)],
    payload: {
      document_id: plan.document_id,
      document_name: plan.name,
      document_type: plan.document_type,
      chunk_id: unit.chunk_id,
      section_id: unit.section_id || null,
      parent_id: unit.parent_id || null,
      page: unit.page === undefined ? null : unit.page,
      level: unit.level,
      chunk_index: unit.chunk_index === undefined ? 0 : unit.chunk_index,
      char_count: unit.char_count || 0,
      temporal_certainty: extracted.temporal_certainty || 'unknown',
      entity_names: entityNames,
      doc_ts: effectiveDate,
      event_ts: eventDate,
      source: plan.source || 'upload',
      request_id: plan.request_id,
      // Undated knowledge is known from the moment it was ingested, which is
      // what the retrieval filter falls back to when doc_ts is null.
      request_ts: plan.request_ts || null,
    },
  }));

if (points.length === 0) {
  return [{
    json: {
      ok: false,
      error: {
        code: 'no_vectors_collected',
        message: 'None of the ' + plan.units.length + ' plan units had an embedding.',
        hint: 'Compare the point ids in the Parse Document and Embed Texts nodes.',
      },
    },
  }];
}

const missing = plan.units.length - points.length;
if (missing > 0) {
  return [{
    json: {
      ok: false,
      error: {
        code: 'incomplete_embeddings',
        message: missing + ' of ' + plan.units.length + ' units never came back from the embedder.',
        hint: 'A batch failed; re-run the ingest rather than storing a partial document.',
      },
    },
  }];
}

// Upsert in batches: the HTTP node runs once per item, which keeps each request
// body small instead of posting one enormous JSON document.
const upsertBatch = Math.max(1, Number($env.QDRANT_UPSERT_BATCH || 64));
const out = [];
for (let offset = 0; offset < points.length; offset += upsertBatch) {
  out.push({
    json: {
      ok: true,
      points: points.slice(offset, offset + upsertBatch),
      point_count: points.length,
      vector_dim: points[0].vector.length,
      document_id: plan.document_id,
      batch_index: Math.floor(offset / upsertBatch),
      batch_count: Math.ceil(points.length / upsertBatch),
    },
  });
}

return out;
