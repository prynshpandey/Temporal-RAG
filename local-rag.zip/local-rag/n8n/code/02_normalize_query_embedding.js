// ---------------------------------------------------------------------------
// Query step 4 - normalise the query embedding or explain why there is none.
// ---------------------------------------------------------------------------

const config = $('Query Config').first().json;
const response = $input.first().json;

function fail(code, message, hint) {
  return [{ json: { ok: false, error: { code, message, hint: hint || null } } }];
}

if (response && response.error) {
  return fail(
    'embedding_failed',
    'Ollama could not embed the question: ' + String(response.error),
    `Check that Ollama is running at ${config.ollama_url} and that the model is pulled: ollama pull ${config.embedding_model}`
  );
}

const vectors = response && Array.isArray(response.embeddings) ? response.embeddings : null;
if (!vectors || vectors.length === 0) {
  return fail(
    'embedding_failed',
    'Ollama returned no embeddings for the question.',
    `Check that the model exists: ollama list | grep ${config.embedding_model}`
  );
}

const vector = vectors[0];
if (vector.length !== config.expected_dim) {
  return fail(
    'embedding_dimension_mismatch',
    `The question was embedded into ${vector.length} dimensions but the collection expects ${config.expected_dim}.`,
    'The collection was built with a different embedding model. Run `make qdrant-reset` and re-upload the documents, or set EMBEDDING_MODEL back to the model used at index time.'
  );
}

return [{ json: { ok: true, query_vector: vector, vector_dim: vector.length, embed_ms: response.total_duration ? Math.round(response.total_duration / 1e6) : null } }];
