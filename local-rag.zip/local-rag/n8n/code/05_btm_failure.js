// ---------------------------------------------------------------------------
// BTM ingest - failure path.
//
// A half-ingested document is worse than a missing one: vectors without rows, or
// rows without vectors, both show up as answers that cite nothing. So every
// failure funnels through here, which records the reason on the document and
// removes whatever was already written.
//
// The reason is resolved leniently: a failure can happen before any of these
// nodes ran, and a cross-node reference to a node that never executed throws
// and hides the real error.
// ---------------------------------------------------------------------------

function firstJson(nodeName) {
  try {
    const node = $(nodeName);
    return node && node.first() ? node.first().json : null;
  } catch (err) {
    return null;
  }
}

const plan = firstJson('Parse Document');
const extracted = firstJson('Extract Metadata');
const current = $input.first().json || {};
const documentId = (plan && plan.document_id) || current.document_id || null;

const reason = (current.error && (current.error.message || current.error.code)) || current.message || 'unknown error';

if (!documentId) {
  return [{
    json: {
      ok: false,
      status: 'error',
      error: {
        code: 'ingest_failed',
        message: 'The ingest failed before a document id existed: ' + reason,
        hint: 'Inspect the first failing node in this execution.',
      },
    },
  }];
}

return [{
  json: {
    ok: false,
    status: 'failed',
    document_id: documentId,
    document_name: plan ? plan.name : documentId,
    reason: reason,
    // The backend's /ingest/fail records why the document is missing, and the
    // delete clears any partial rows or vectors this run already wrote.
    fail_payload: {
      document_id: documentId,
      name: plan ? plan.name : documentId,
      error: reason,
    },
    delete_payload: { document_id: documentId },
    knowledge_cut: {
      entities: extracted ? (extracted.entities || []).length : 0,
      events: extracted ? (extracted.events || []).length : 0,
      facts: extracted ? (extracted.facts || []).length : 0,
    },
  },
}];
