// ---------------------------------------------------------------------------
// BTM ingest - turn a parse failure into something a caller can act on.
//
// The backend answers a bad upload in two different shapes: a structured
// {status, error: {code, message, hint}} for a file it could not read, and
// FastAPI's {detail: [...]} for a request that never had a file in it. Both are
// flattened here, because a webhook that answers "[object Object]" tells the
// caller nothing.
// ---------------------------------------------------------------------------

function text(value) {
  if (value === null || value === undefined) return '';
  return typeof value === 'string' ? value : String(value);
}

const response = $input.first().json || {};
const parts = [];

// 1. the structured error
if (response.error) {
  if (response.error.message) parts.push(text(response.error.message));
  else if (typeof response.error === 'string') parts.push(response.error);
}

// 2. FastAPI's detail: a string, or a list of {loc, msg} objects
if (!parts.length && response.detail) {
  if (typeof response.detail === 'string') {
    parts.push(response.detail);
  } else if (Array.isArray(response.detail)) {
    for (const entry of response.detail) {
      if (entry && entry.msg) {
        const where = Array.isArray(entry.loc) ? entry.loc[entry.loc.length - 1] : null;
        parts.push(where ? where + ': ' + text(entry.msg) : text(entry.msg));
      }
    }
  } else if (response.detail.message) {
    parts.push(text(response.detail.message));
  }
}

if (!parts.length) {
  parts.push('the upload produced no readable text');
}

const code = (response.error && response.error.code)
  || (Array.isArray(response.detail) && response.detail[0] && response.detail[0].type)
  || 'parse_failed';

return [{
  json: {
    ok: false,
    status: 'error',
    error: {
      code: code,
      message: parts.join('; '),
      hint: (response.error && response.error.hint)
        || 'Scanned documents need OCR, and password protected files must be unlocked first.',
    },
  },
}];
