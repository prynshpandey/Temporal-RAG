// ---------------------------------------------------------------------------
// Query step 9 - final response for the browser, including the sources that
// produced the answer so the response is traceable back to the document.
// ---------------------------------------------------------------------------

const config = $('Query Config').first().json;
const context = $('Build Context').first().json;
const embedding = $('Normalize Query Embedding').first().json;
const generation = $input.first().json;

if (generation && generation.error) {
  return [{
    json: {
      ok: false,
      error: {
        code: 'llm_failed',
        message: 'Llama could not generate an answer: ' + String((generation.error && (generation.error.message || generation.error)) || 'unknown error'),
        hint: 'Check that Ollama is running at ' + config.ollama_url + ' and that the model is pulled: ollama pull ' + config.llm_model,
      },
    },
  }];
}

const answer = generation && generation.message && typeof generation.message.content === 'string'
  ? generation.message.content.trim()
  : '';

if (answer.length === 0) {
  return [{
    json: {
      ok: false,
      error: {
        code: 'llm_empty_response',
        message: 'The model returned an empty answer (done_reason: ' + String(generation && generation.done_reason) + ').',
        hint: 'Increase MAX_TOKENS or NUM_CTX in .env, or try a smaller model (LLM_MODEL=llama3.2:3b).',
      },
    },
  }];
}

const documents = [];
for (const source of context.sources) {
  if (documents.indexOf(source.document) === -1) documents.push(source.document);
}

return [{
  json: {
    ok: true,
    status: 'answered',
    answer,
    question: config.question,
    sources: context.sources,
    documents,
    dropped_sources: context.dropped_sources,
    context_chars: context.context_chars,
    context_truncated: context.context_truncated,
    llm_model: (generation && generation.model) || config.llm_model,
    embedding_model: config.embedding_model,
    vector_dim: embedding.vector_dim,
    top_k: config.top_k,
    min_score: config.min_score,
    document_filter: config.document_id,
    system_prompt: $('Build Prompt').first().json.system_prompt,
    usage: {
      prompt_tokens: generation ? generation.prompt_eval_count : null,
      completion_tokens: generation ? generation.eval_count : null,
      retrieval_ms: context.search_ms,
      generation_ms: generation && generation.total_duration ? Math.round(generation.total_duration / 1e6) : null,
    },
  },
}];
