// ---------------------------------------------------------------------------
// Ingest step 5 - one /api/embed request for the current batch of chunks.
// Ollama accepts an array of strings and returns one embedding per input, so
// a whole batch costs a single round trip.
// ---------------------------------------------------------------------------

const items = $input.all();
const embeddingModel = $env.EMBEDDING_MODEL || 'nomic-embed-text';
const truncate = ($env.EMBED_TRUNCATE || 'true') !== 'false';
const first = items.length ? items[0].json : {};

return [{
  json: {
    embedding_model: embeddingModel,
    truncate,
    document_id: first.document_id || null,
    document_name: first.document_name || null,
    input: items.map((i) => i.json.text),
    point_meta: items.map((i) => i.json),
  },
}];
