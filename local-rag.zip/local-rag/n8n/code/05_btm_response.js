// ---------------------------------------------------------------------------
// BTM ingest step 7 - the response the caller gets back.
//
// Answers the same shape the legacy pipeline used (status, document_id,
// chunk_count, ...) plus the temporal fields, so a client can tell immediately
// from which date this document is answerable.
// ---------------------------------------------------------------------------

const plan = $('Parse Document').first().json;
const extracted = $('Extract Metadata').first().json;
const registered = $('Register Document').first().json;
const points = $('Build Points').first().json;
const upserts = $input.all().map((item) => item.json);
const failed = upserts.find((item) => item && item.error);

if (failed) {
  return [{ json: { ok: false, error: failed.error } }];
}

return [{
  json: {
    // `ok` is what the Ingest Complete? branch tests, and callers read it too.
    ok: true,
    status: 'indexed',
    document_id: registered.document_id || plan.document_id,
    document_name: plan.name,
    document_type: plan.document_type,
    request_id: plan.request_id,
    chunk_count: points.point_count,
    sections: registered.sections,
    vectors: registered.vectors,
    entities: registered.entities,
    events: registered.events,
    facts: registered.facts,
    vector_dim: points.vector_dim,
    upsert_batches: upserts.length,
    page_count: plan.page_count,
    // The temporal contract, stated for the caller.
    document_date: extracted.document_date,
    event_date: extracted.event_date,
    effective_date: registered.effective_date,
    temporal_certainty: registered.temporal_certainty,
    summary: extracted.summary,
    // The backend reports who actually answered, or null when nobody did. A
    // hardcoded provider would credit groq for an answer it never gave.
    llm: { provider: extracted.llm_provider || null, usage: extracted.llm_usage || null },
    ingest_ms: registered.register_ms,
  },
}];
