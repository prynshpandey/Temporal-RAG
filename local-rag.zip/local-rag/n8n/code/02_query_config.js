// ---------------------------------------------------------------------------
// Query step 1 - normalise the request and read the configuration.
//
// The frontend posts text/plain with a JSON string (keeps the browser request
// a CORS "simple request"); a regular application/json body works too.
// ---------------------------------------------------------------------------

const minScoreDefault = Number($env.MIN_SCORE || 0.25);
const topKDefault = Number($env.TOP_K || 5);
const maxQuestionChars = Number($env.MAX_QUESTION_CHARS || 2000);

const incoming = $input.first().json;
let payload = incoming && Object.prototype.hasOwnProperty.call(incoming, 'body') ? incoming.body : incoming;

if (typeof payload === 'string') {
  try {
    payload = JSON.parse(payload);
  } catch (err) {
    return [{
      json: {
        ok: false,
        error: {
          code: 'malformed_json',
          message: 'The request body is not valid JSON: ' + err.message,
          hint: 'Send {"question": "..."} as JSON.',
        },
      },
    }];
  }
}

if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
  return [{
    json: {
      ok: false,
      error: {
        code: 'malformed_request',
        message: 'Expected a JSON object with a "question" field.',
        hint: 'Send {"question": "What is the revenue?", "top_k": 5, "document_id": "doc_..."}.',
      },
    },
  }];
}

const question = String(payload.question != null ? payload.question : payload.query != null ? payload.query : '').trim();

if (question.length === 0) {
  return [{
    json: {
      ok: false,
      error: {
        code: 'empty_question',
        message: 'The "question" field is empty.',
        hint: 'Ask something about the indexed documents.',
      },
    },
  }];
}

if (question.length > maxQuestionChars) {
  return [{
    json: {
      ok: false,
      error: {
        code: 'question_too_long',
        message: `The question is ${question.length} characters long, the limit is ${maxQuestionChars}.`,
        hint: `Raise MAX_QUESTION_CHARS in .env if this is intentional.`,
      },
    },
  }];
}

const requestedTopK = Number(payload.top_k != null ? payload.top_k : topKDefault);
const topK = Math.min(20, Math.max(1, Number.isFinite(requestedTopK) ? Math.round(requestedTopK) : topKDefault));
const requestedScore = Number(payload.score_threshold != null ? payload.score_threshold : minScoreDefault);
const minScore = Number.isFinite(requestedScore) ? requestedScore : minScoreDefault;
const documentId = payload.document_id ? String(payload.document_id) : null;

return [{
  json: {
    ok: true,
    question,
    top_k: topK,
    min_score: minScore,
    document_id: documentId,
    // Qdrant payload filter: restrict retrieval to one document when given.
    filter: documentId ? { must: [{ key: 'document_id', match: { value: documentId } }] } : null,
    llm_model: $env.LLM_MODEL || 'llama3.1',
    embedding_model: $env.EMBEDDING_MODEL || 'nomic-embed-text',
    expected_dim: Number($env.QDRANT_VECTOR_SIZE || 768),
    num_ctx: Number($env.NUM_CTX || 8192),
    temperature: Number($env.LLM_TEMPERATURE || 0.1),
    max_tokens: Number($env.MAX_TOKENS || 1200),
    max_context_chars: Number($env.MAX_CONTEXT_CHARS || 8000),
    qdrant_url: $env.QDRANT_URL || 'http://qdrant:6333',
    qdrant_collection: $env.QDRANT_COLLECTION || 'local_rag_chunks',
    ollama_url: $env.OLLAMA_URL || 'http://host.docker.internal:11434',
  },
}];
