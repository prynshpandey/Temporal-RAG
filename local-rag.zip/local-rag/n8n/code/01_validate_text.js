// ---------------------------------------------------------------------------
// Ingest step 3 - turn the raw extractor output into a page list and decide
// whether the PDF actually contains a usable text layer.
//
// Extractors differ: some return the whole document as one string, some keep
// the form feed (\f) page separator, some return an array of pages. All three
// shapes are handled so the workflow keeps working across n8n versions.
// ---------------------------------------------------------------------------

const minChars = Number($env.MIN_EXTRACT_CHARS || 400);

function toPages(raw) {
  if (Array.isArray(raw)) {
    return raw.map((text, i) => ({ page: i + 1, text: String(text == null ? '' : text) }));
  }
  if (raw && typeof raw === 'object' && Array.isArray(raw.pages)) {
    return raw.pages.map((p, i) => ({
      page: Number(p && (p.page || p.pageNumber || p.page_number) ? (p.page || p.pageNumber || p.page_number) : i + 1),
      text: String((p && (p.text || p.content)) || ''),
    }));
  }

  let text = '';
  if (typeof raw === 'string') text = raw;
  else if (raw && typeof raw === 'object' && typeof raw.text === 'string') text = raw.text;
  else if (raw == null) text = '';
  else text = String(raw);

  if (text.indexOf('\f') !== -1) {
    const parts = text.split('\f').map((p) => p.trim()).filter((p) => p.length > 0);
    if (parts.length > 1) {
      return parts.map((p, i) => ({ page: i + 1, text: p }));
    }
  }
  // Page numbers are not recoverable from this shape; say so explicitly
  // instead of inventing a page number.
  return [{ page: null, text }];
}

const source = $input.first().json;
const rawText = source.data != null ? source.data : source.text != null ? source.text : source;
const pages = toPages(rawText);

const cleaned = pages.map((p) => p.text.replace(/\u0000/g, '').trim());
const totalChars = cleaned.reduce((sum, t) => sum + t.length, 0);
const nonEmptyPages = cleaned.filter((t) => t.length > 0).length;
const pageKnown = pages.some((p) => p.page != null);

if (totalChars < minChars) {
  return [{
    json: {
      ok: false,
      started_at: source.started_at,
      document_id: source.document_id,
      document_name: source.document_name,
      error: {
        code: 'no_text_layer',
        message: `Only ${totalChars} characters of text could be extracted from "${source.document_name}" (minimum is ${minChars}).`,
        hint: 'The PDF is most likely a scan without a text layer. Run OCR first, e.g. `ocrmypdf --force-ocr in.pdf out.pdf`, then upload again.',
      },
    },
  }];
}

return [{
  json: {
    ok: true,
    started_at: source.started_at,
    document_id: source.document_id,
    document_name: source.document_name,
    mime_type: source.mime_type,
    size_bytes: source.size_bytes,
    sha256: source.sha256,
    reingest: source.reingest,
    page_count: pages.length,
    page_known: pageKnown,
    non_empty_pages: nonEmptyPages,
    total_chars: totalChars,
    pages: pages.map((p, i) => ({ page: p.page, text: cleaned[i] })),
  },
}];
