// ---------------------------------------------------------------------------
// Ingest step 1 - validate the upload before spending CPU on it.
//
// Checks (in order): a file is present, the bytes really are a PDF, it is not
// empty, and it is not larger than MAX_UPLOAD_MB.  Also derives a stable
// document id so that re-uploading the same file replaces its chunks instead
// of duplicating them.
// ---------------------------------------------------------------------------

const maxUploadMb = Number($env.MAX_UPLOAD_MB || 25);
const maxBytes = maxUploadMb * 1024 * 1024;
const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
const PDF_MAGIC = '%PDF-';

// item.binary.data is storage- and compression-dependent (in filesystem mode
// n8n hands over the compressed payload), so the bytes are always read through
// the helper that returns the original file content.
async function fileBuffer(index, binary) {
  if (!binary) return null;
  if (typeof $getBinaryDataBuffer === 'function') {
    try {
      return await $getBinaryDataBuffer(index, 'data');
    } catch (e) {
      /* fall through to the older accessor */
    }
  }
  const ctx = typeof this === 'undefined' ? null : this;
  if (ctx && ctx.helpers && typeof ctx.helpers.getBinaryDataBuffer === 'function') {
    try {
      return await ctx.helpers.getBinaryDataBuffer(index, 'data');
    } catch (e) {
      /* fall through to the raw value */
    }
  }
  const raw = binary.data;
  if (raw == null) return null;
  if (typeof Buffer !== 'undefined') {
    if (Buffer.isBuffer(raw)) return raw;
    if (typeof raw === 'string') {
      if (/^[A-Za-z0-9+/=\r\n]+$/.test(raw)) return Buffer.from(raw, 'base64');
      return Buffer.from(raw, 'latin1');
    }
    if (Array.isArray(raw)) return Buffer.from(raw);
  }
  return null;
}

function base64Decoder(b64) {
  const bytes = [];
  for (let i = 0; i < b64.length; i += 4) {
    const c1 = B64.indexOf(b64[i]);
    const c2 = B64.indexOf(b64[i + 1]);
    if (c1 < 0 || c2 < 0) break;
    bytes.push((c1 << 2) | (c2 >> 4));
    if (b64[i + 2] === '=') break;
    const c3 = B64.indexOf(b64[i + 2]);
    if (c3 < 0) break;
    bytes.push(((c2 & 15) << 4) | (c3 >> 4));
    if (b64[i + 3] === '=') break;
    const c4 = B64.indexOf(b64[i + 3]);
    if (c4 < 0) break;
    bytes.push(((c3 & 3) << 6) | c4);
  }
  return bytes;
}

function sizeOfBuffer(buffer, binary) {
  if (buffer) return buffer.length;
  const raw = binary && binary.data;
  if (typeof raw === 'string') {
    if (typeof Buffer !== 'undefined') return Buffer.from(raw, 'latin1').length;
    return raw.length;
  }
  if (raw && typeof raw.length === 'number') return raw.length;
  return 0;
}

function headOfBuffer(buffer, binary) {
  const wanted = PDF_MAGIC.length + 1;
  if (buffer) return buffer.subarray(0, wanted).toString('latin1');
  const raw = binary && binary.data;
  if (typeof raw === 'string') {
    if (/^[A-Za-z0-9+/=\r\n]+$/.test(raw)) {
      return base64Decoder(raw.replace(/[^A-Za-z0-9+/=]/g, ''))
        .slice(0, wanted)
        .map((b) => String.fromCharCode(b))
        .join('');
    }
    return raw.slice(0, wanted);
  }
  if (raw && typeof raw.length === 'number') {
    return Array.prototype.slice.call(raw, 0, wanted)
      .map((b) => String.fromCharCode(b))
      .join('');
  }
  return '';
}

// Two differently seeded 32 bit FNV-1a passes -> 64 bit hex identity.
function fnv1a32(str, seed) {
  let hash = seed >>> 0;
  for (let i = 0; i < str.length; i++) {
    hash ^= str.charCodeAt(i);
    hash = Math.imul(hash, 0x01000193) >>> 0;
  }
  return hash >>> 0;
}

const out = [];
const items = $input.all();

for (let index = 0; index < items.length; index++) {
  const item = items[index];
  const startedAt = new Date().toISOString();
  const binary = item.binary ? item.binary.data : null;
  // Values arrive either as multipart form fields (json.body) or as query
  // parameters (json.query); accept both so the browser can use whichever the
  // upload path allows.
  const body = Object.assign(
    {},
    item.json && item.json.query && typeof item.json.query === 'object' ? item.json.query : {},
    item.json && item.json.body && typeof item.json.body === 'object' ? item.json.body : {}
  );
  const fileName = (binary && binary.fileName) || body.fileName || 'upload.pdf';
  const mimeType = (binary && binary.mimeType) || body.mimeType || '';

  const reject = (code, message, hint) => {
    out.push({
      json: {
        ok: false,
        started_at: startedAt,
        error: { code, message, hint: hint || null },
      },
    });
  };

  if (!binary) {
    reject('no_file', 'No file was received.', 'POST the PDF as multipart/form-data with the field name "data".');
    continue;
  }

  const buffer = await fileBuffer(index, binary);
  const sizeBytes = sizeOfBuffer(buffer, binary);
  const head = headOfBuffer(buffer, binary);

  if (sizeBytes === 0) {
    reject('empty_file', `The uploaded file "${fileName}" is empty (0 bytes).`, 'Re-export the PDF and try again.');
    continue;
  }

  if (!head.startsWith(PDF_MAGIC)) {
    reject(
      'invalid_pdf',
      `"${fileName}" is not a PDF: the first bytes are ${JSON.stringify(head)} instead of "%PDF-".`,
      'The upload is corrupt, or it is a renamed file of another type. Only PDF is supported.'
    );
    continue;
  }

  if (sizeBytes > maxBytes) {
    reject(
      'file_too_large',
      `"${fileName}" is ${(sizeBytes / 1048576).toFixed(1)} MB which exceeds the ${maxUploadMb} MB limit.`,
      `Raise MAX_UPLOAD_MB in .env, or split the document before uploading.`
    );
    continue;
  }

  // The browser sends a SHA-256 (crypto.subtle works on localhost). When it is
  // missing we fall back to name + size + file header, which is stable enough
  // to make re-uploads idempotent.
  const sha256 = typeof body.sha256 === 'string' && /^[0-9a-f]{16,64}$/i.test(body.sha256)
    ? body.sha256.toLowerCase()
    : null;
  const identity = sha256 || `${fileName}:${sizeBytes}:${head}`;
  const documentId = 'doc_' + fnv1a32(identity, 0x811c9dc5).toString(16).padStart(8, '0') +
    fnv1a32(identity, 0x9dc5811c).toString(16).padStart(8, '0');

  out.push({
    json: {
      ok: true,
      started_at: startedAt,
      document_id: documentId,
      document_name: fileName,
      mime_type: mimeType,
      size_bytes: sizeBytes,
      sha256,
      reingest: Boolean(body.reingest),
    },
    binary: item.binary,
  });
}

return out;
